<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\Reports\Controller\Export;

use Magento\Framework\App\Filesystem\DirectoryList;

use Magento\Framework\Exception\NoSuchEntityException;

class Index extends \Magento\Framework\App\Action\Action
{
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
        \Magento\Framework\Filesystem $filesystem,
        \Aria\Reports\Api\SupplierReportsInterface $reportsInterface,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->_fileFactory = $fileFactory;
        $this->reportsInterface = $reportsInterface;
        $this->scopeConfig = $scopeConfig;
        $this->directory = $filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);
        return parent::__construct($context);
    }
    public function execute()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $dateFormat = $this->scopeConfig->getValue('catalog/custom_options/date_fields_order', $storeScope);
        $defaultDateFormat =  str_replace('y','Y',strtolower($dateFormat));
        $gridDateFormat = str_replace(',','/',$defaultDateFormat);
        $dateFormat =  str_replace(',','_',$defaultDateFormat);
        $name = date($dateFormat.'_H_i');
        
        $params = $this->getRequest()->getParams();
        $from = $this->getRequestParam($params,'from');
        $to = $this->getRequestParam($params,'to');
        $supplierId = $this->getRequestParam($params,'supplierId');
        $dcId = $this->getRequestParam($params,'dcId');
        $dcUserId = $this->getRequestParam($params,'dcUserId');
        $period = $this->getRequestParam($params,'period');
        $type = $this->getRequestParam($params,'type');

        $filepath = 'export/custom' . $name . '.csv';
        $this->directory->create('export');
        /* Open file */
        $stream = $this->directory->openFile($filepath, 'w+');
        $stream->lock();
        
        $columns = $this->getColumnHeader($type,$period);
        foreach ($columns as $column) {
            $header[] = $column;
        }
        /* Write Header */
        $stream->writeCsv($header);

        $result = $this->reportsInterface->generateReport($from, $to, $type, $supplierId, $dcId, $dcUserId, $period);

        if ($type == "view") {
            $csvName =  "ProductViewReport";
            foreach ($result as $items) {
                foreach ($items['items'] as $item) {
                    $itemData = [];
                    $newformatedTime = $this->getFormattedDate($gridDateFormat,$items['period'],$period);
                    $itemData[] = $newformatedTime;
                    $itemData[] = $item['product_name'];
                    $itemData[] = $item['sku'];
                    $itemData[] = $item['views_num'];
                    $stream->writeCsv($itemData);
                }
            }
        }
        if ($type == "sales") {
            $csvName =  "SalesReport";
            foreach ($result as $items) {
                foreach ($items['items'] as $item) {
                    $itemData = [];
                    $newformatedTime = $this->getFormattedDate($gridDateFormat,$items['period'],$period);
                    $itemData[] = $newformatedTime;
                    $itemData[] = $item['orders'];
                    $itemData[] = $item['sales items'];
                    $itemData[] = $item['revenue'];
                    $itemData[] = $item['tax'];
                    $stream->writeCsv($itemData);
                }
            }
        }
        if($type == "sold") {
            $csvName =  "ProductSoldReport";
            foreach ($result as $items) {
                foreach ($items['items'] as $item) {
                    $itemData = [];
                    $newformatedTime = $this->getFormattedDate($gridDateFormat,$items['period'],$period);
                    $itemData[] = $newformatedTime;
                    $itemData[] = $item['order_items_name'];
                    $itemData[] = $item['order_items_sku'];
                    $itemData[] = $item['ordered_qty'];
                    $stream->writeCsv($itemData);
                }
            }
        }
        $content = [];
        $content['type'] = 'filename'; // must keep filename
        $content['value'] = $filepath;
        $content['rm'] = '1'; //remove csv from var folder

        $csvfilename = $csvName.'_'.$name.'.csv';
        return $this->_fileFactory->create($csvfilename, $content, DirectoryList::VAR_DIR);
    }
    /* GetFormatted Date */
    public function getFormattedDate($format,$period,$periodType)
    {   if($periodType == 'day'){
            $time = strtotime($period);
            return date($format,$time);
        }
        return $period;
    }

    /* Get Header Columns */
    public function getColumnHeader($type,$period)
    {
        switch ($type) {
            case 'sales':
                $headers = [ucfirst($period), 'Orders', 'Sales Items', 'Revenue', 'Tax'];
                break;
            case 'view':
                $headers = [ucfirst($period), 'Product Name', 'SKU', 'Views'];
                break;
            case 'sold':
                $headers = [ucfirst($period), 'Product Name', 'SKU', 'Qty'];
                break;
            default:
                $headers = [];
        }
        return $headers;
    }

    /* Get Request Param */
    public function getRequestParam($params,$paramCode) {
        if(isset($params[$paramCode])){
            return $params[$paramCode];
        } else {
            throw new NoSuchEntityException(__($paramCode." Not provided"));
        }

    }
}
