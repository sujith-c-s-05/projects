<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Reports\Model\Data;

use Aria\Reports\Api\Data\ProductDailyViewInterface;

class ProductDailyView extends \Magento\Framework\Api\AbstractExtensibleObject implements ProductDailyViewInterface
{

    /**
     * Get productdailyview_id
     * @return string|null
     */
    public function getProductdailyviewId()
    {
        return $this->_get(self::PRODUCTDAILYVIEW_ID);
    }

    /**
     * Set productdailyview_id
     * @param string $productdailyviewId
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setProductdailyviewId($productdailyviewId)
    {
        return $this->setData(self::PRODUCTDAILYVIEW_ID, $productdailyviewId);
    }

    /**
     * Get period
     * @return string|null
     */
    public function getPeriod()
    {
        return $this->_get(self::PERIOD);
    }

    /**
     * Set period
     * @param string $period
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setPeriod($period)
    {
        return $this->setData(self::PERIOD, $period);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\Reports\Api\Data\ProductDailyViewExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\Reports\Api\Data\ProductDailyViewExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\Reports\Api\Data\ProductDailyViewExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get product_id
     * @return string|null
     */
    public function getProductId()
    {
        return $this->_get(self::PRODUCT_ID);
    }

    /**
     * Set product_id
     * @param string $productId
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setProductId($productId)
    {
        return $this->setData(self::PRODUCT_ID, $productId);
    }

    /**
     * Get sku
     * @return string|null
     */
    public function getSku()
    {
        return $this->_get(self::SKU);
    }

    /**
     * Set sku
     * @param string $sku
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setSku($sku)
    {
        return $this->setData(self::SKU, $sku);
    }

    /**
     * Get product_name
     * @return string|null
     */
    public function getProductName()
    {
        return $this->_get(self::PRODUCT_NAME);
    }

    /**
     * Set product_name
     * @param string $productName
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setProductName($productName)
    {
        return $this->setData(self::PRODUCT_NAME, $productName);
    }

    /**
     * Get views_num
     * @return string|null
     */
    public function getViewsNum()
    {
        return $this->_get(self::VIEWS_NUM);
    }

    /**
     * Set views_num
     * @param string $viewsNum
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setViewsNum($viewsNum)
    {
        return $this->setData(self::VIEWS_NUM, $viewsNum);
    }

    /**
     * Get rating_pos
     * @return string|null
     */
    public function getRatingPos()
    {
        return $this->_get(self::RATING_POS);
    }

    /**
     * Set rating_pos
     * @param string $ratingPos
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setRatingPos($ratingPos)
    {
        return $this->setData(self::RATING_POS, $ratingPos);
    }

    /**
     * Get supplier_id
     * @return string|null
     */
    public function getSupplierId()
    {
        return $this->_get(self::SUPPLIER_ID);
    }

    /**
     * Set supplier_id
     * @param string $supplierId
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setSupplierId($supplierId)
    {
        return $this->setData(self::SUPPLIER_ID, $supplierId);
    }
}

