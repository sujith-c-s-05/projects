<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Reports\Model;

use Aria\Reports\Api\SupplierReportsInterface;
use Aria\SupplyCompanyAccount\Helper\Data as HelperData;


class SupplierReportsManagement implements SupplierReportsInterface
{     protected $helper;

    
    public function __construct(
    	\Aria\Reports\Model\ResourceModel\Report\Collection\Product\Sold\InitialFactory $soldInitialFactory,
		\Aria\Reports\Model\ResourceModel\Report\Collection\Sales\InitialFactory $orderInitialFactory,
        \Aria\Reports\Model\ResourceModel\Report\Collection\Product\View\InitialFactory $viewInitialFactory,
    	\Aria\Reports\Block\Grid $ariagrid,
        \Aria\Reports\Model\ResourceModel\ProductDailyView\CollectionFactory $productViewCollection,
        \Aria\Reports\Model\ResourceModel\Report\Collection\Product\Sold\CollectionFactory $productSoldCollection,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $dateTime,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        HelperData $helper


    ){
    	$this->soldInitialFactory = $soldInitialFactory;
		$this->orderInitialFactory = $orderInitialFactory;
        $this->viewInitialFactory = $viewInitialFactory;
		$this->ariagrid = $ariagrid;
        $this->productViewCollection =  $productViewCollection;
        $this->productSoldCollection =  $productSoldCollection;
        $this->dateTime = $dateTime;
        $this->productRepository = $productRepository;
        $this->helper = $helper;

    }
    /**
     * {@inheritdoc}
     */
    public function generateReport($from,$to,$type,$supplierId,$dcId,$dcUserId,$period='day')
    {   
        $result= [];
        switch($type)
        {
            case 'sales': 
                $this->helper->permissionCheck($dcId, $dcUserId, 'Sales Report');
                $result = $this->generateSalesReport($from,$to,$supplierId,$period);
                break;
            case 'view': 
                $this->helper->permissionCheck($dcId, $dcUserId, 'Top Product Views');
                $result = $this->generateProductViewReport($from,$to,$supplierId,$period);
                break;
            case 'sold':
                $this->helper->permissionCheck($dcId, $dcUserId, 'Top Products by Units Sold');
                $result = $this->generateProductSoldReport($from,$to,$supplierId,$period);
                break;
            case 'dashboard':
                $dashboard= [];
                $startTime = $this->generateStartTime($from);
                $endTime = $this->generateEndTime($to);
                $dashboard['order_data'] = $this->generateSalesReport($from,$to,$supplierId,$period);
                $dashboard['sold_data'] = $this->generateSoldData($startTime,$endTime,$supplierId);
                $dashboard['view_data'] = $this->generateViewData($startTime,$endTime,$supplierId);
                $result['dashboard'] = $dashboard;
                break;
            default:
                $result= [];
        }

        return $result;
    }
    /**
     * {@inheritdoc}
     */
    public function generateStartTime($from)
    {
        $from = $this->dateTime->date($from, null, true, false);
        $dateStart = new \DateTime($from->format('Y-m-d'), $from->getTimezone());
        $startTime = $this->dateTime->convertConfigTimeToUtc($dateStart->format('Y-m-d 00:00:00'));
        return $startTime;

    }
    /**
     * {@inheritdoc}
     */
    public function generateEndTime($to)
    {
        $to = $this->dateTime->date($to, null, true, false);
        $dateEnd = new \DateTime($to->format('Y-m-d'), $to->getTimezone());
        $endTime = $this->dateTime->convertConfigTimeToUtc($dateEnd->format('Y-m-d 23:59:59'));
        return $endTime;

    }
    /**
     * {@inheritdoc}
     */
    public function generateSoldData($startTime,$endTime,$supplierId)
    {
        $productSold = $this->productSoldCollection->create();
        $productSoldItems = $productSold->setCustomDateRange($startTime,$endTime,$supplierId);
        $productSoldItems->getSelect()->limit(5);
        return $productSoldItems->getData();
    }
    /**
     * {@inheritdoc}
     */
    public function generateViewData($startTime,$endTime,$supplierId)
    {
        $productView = $this->productViewCollection->create();
        $productViewIitems = $productView->setCustomDateRange($startTime,$endTime,$supplierId);
        $productViewIitems->getSelect()->limit(5);
        return $productViewIitems->getData();
    }
    /**
     * {@inheritdoc}
     */
    public function generateSalesReport($from='',$to='',$supplierId ='',$period='')
    {
    	$result = [];
		$data = [];
        $data['report_from'] = $from;
        $data['report_to'] = $to;
        $data['report_period'] = $period;
        $orderCollection = $this->orderInitialFactory->create();
        $productView = $this->productViewCollection->create();
		$collection = $this->ariagrid->getPrepareCollection($data,$orderCollection,$supplierId);
		$items = $collection->getItems();
		foreach($items as $item){
			$interval = [];
            $products = $item->getChildren()->getData();
            if(empty($products) || !$products[0]['orders']){
                continue;
            }
			$interval['period'] = $item->getPeriod();
			$interval['items'] = $products;
			$result[] = $interval;

		}
        return $result;
    }
    /**
     * {@inheritdoc}
     */
    public function generateProductSoldReport($from='',$to='',$supplierId ='',$period='')
    {
    	$result = [];
		$data = [];
        $data['report_from'] = $from;
        $data['report_to'] = $to;
        $data['report_period'] = $period;
		$productsSoldCollection = $this->soldInitialFactory->create();
		$collection = $this->ariagrid->getPrepareCollection($data,$productsSoldCollection,$supplierId);
		$items = $collection->getItems();
		foreach($items as $item){
			$interval = [];
            $products = $item->getChildren()->getData();
            if(empty($products)){
                continue;
            }
            foreach($products as $k => $pr){
                $aria_sku =  $products[$k]['order_items_sku'];
                try{
                    $productObj = $this->productRepository->get($aria_sku);
                    $supplierSku = $productObj->getSupplierSku();
                    if($supplierSku)
                    $products[$k]['order_items_sku'] = $supplierSku;
                }
                catch (\Exception $e) {
                    continue;
                } 
            }
			$interval['period'] = $item->getPeriod();
			$interval['items'] = $products;
			$result[] = $interval;

		}
        return $result;
    }

    public function generateProductViewReport($from='',$to='',$supplierId ='',$period='')
    {
    	$result = [];
		$data = [];
        $data['report_from'] = $from;
        $data['report_to'] = $to;
        $data['report_period'] = $period;
        $productViewCollection = $this->viewInitialFactory->create();
        $collection = $this->ariagrid->getPrepareCollection($data,$productViewCollection,$supplierId);
        $items = $collection->getItems();
        foreach($items as $item)
        {
            $interval = [];
            $products = $item->getChildren()->getData();
            if(empty($products)){
                continue;
            }
            foreach($products as $k => $pr){
                $aria_sku =  $products[$k]['sku'];
                try{
                    $productObj = $this->productRepository->get($aria_sku);
                    $supplierSku = $productObj->getSupplierSku();
                    if($supplierSku)
                    $products[$k]['sku'] = $supplierSku;
                }
                catch (\Exception $e) {
                    continue;
                }
            }
			$interval['period'] = $item->getPeriod();
			$interval['items'] = $products;
			$result[] = $interval;
        }
        return $result;
    }

}