<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Reports\Model;

use Aria\Reports\Api\Data\ProductDailyViewInterface;
use Aria\Reports\Api\Data\ProductDailyViewInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class ProductDailyView extends \Magento\Framework\Model\AbstractModel
{

    protected $dataObjectHelper;

    protected $productdailyviewDataFactory;

    protected $_eventPrefix = 'aria_reports_productdailyview';

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param ProductDailyViewInterfaceFactory $productdailyviewDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\Reports\Model\ResourceModel\ProductDailyView $resource
     * @param \Aria\Reports\Model\ResourceModel\ProductDailyView\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        ProductDailyViewInterfaceFactory $productdailyviewDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\Reports\Model\ResourceModel\ProductDailyView $resource,
        \Aria\Reports\Model\ResourceModel\ProductDailyView\Collection $resourceCollection,
        array $data = []
    ) {
        $this->productdailyviewDataFactory = $productdailyviewDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve productdailyview model with productdailyview data
     * @return ProductDailyViewInterface
     */
    public function getDataModel()
    {
        $productdailyviewData = $this->getData();
        
        $productdailyviewDataObject = $this->productdailyviewDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $productdailyviewDataObject,
            $productdailyviewData,
            ProductDailyViewInterface::class
        );
        
        return $productdailyviewDataObject;
    }
}

