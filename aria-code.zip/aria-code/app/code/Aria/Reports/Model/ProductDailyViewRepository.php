<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\Reports\Model;

use Aria\Reports\Api\Data\ProductDailyViewInterfaceFactory;
use Aria\Reports\Api\Data\ProductDailyViewSearchResultsInterfaceFactory;
use Aria\Reports\Api\ProductDailyViewRepositoryInterface;
use Aria\Reports\Model\ResourceModel\ProductDailyView as ResourceProductDailyView;
use Aria\Reports\Model\ResourceModel\ProductDailyView\CollectionFactory as ProductDailyViewCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Model\ProductRepository as productRepository;
use Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany\CollectionFactory as SupplyCompanyCollectionFactory;


class ProductDailyViewRepository implements ProductDailyViewRepositoryInterface
{

    protected $productDailyViewFactory;

    protected $resource;

    protected $extensibleDataObjectConverter;
    protected $searchResultsFactory;

    protected $productDailyViewCollectionFactory;

    private $storeManager;

    protected $dataObjectHelper;

    protected $dataProductDailyViewFactory;

    protected $dataObjectProcessor;

    protected $extensionAttributesJoinProcessor;

    private $collectionProcessor;

    public function __construct(
        ResourceProductDailyView $resource,
        ProductDailyViewFactory $productDailyViewFactory,
        ProductDailyViewInterfaceFactory $dataProductDailyViewFactory,
        ProductDailyViewCollectionFactory $productDailyViewCollectionFactory,
        ProductDailyViewSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        productRepository $productRepository,
        SupplyCompanyCollectionFactory $supplyCompanyCollectionFactory
    ) {
        $this->resource = $resource;
        $this->productDailyViewFactory = $productDailyViewFactory;
        $this->productDailyViewCollectionFactory = $productDailyViewCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataProductDailyViewFactory = $dataProductDailyViewFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->productRepository    = $productRepository;
        $this->supplyCompanyCollectionFactory = $supplyCompanyCollectionFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\Reports\Api\Data\ProductDailyViewInterface $productDailyView
    ) {
        /* if (empty($productDailyView->getStoreId())) {
            $storeId = $this->storeManager->getStore()->getId();
            $productDailyView->setStoreId($storeId);
        } */

        $productDailyViewData = $this->extensibleDataObjectConverter->toNestedArray(
            $productDailyView,
            [],
            \Aria\Reports\Api\Data\ProductDailyViewInterface::class
        );

        $productDailyViewModel = $this->productDailyViewFactory->create()->setData($productDailyViewData);

        try {
            $this->resource->save($productDailyViewModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the productDailyView: %1',
                $exception->getMessage()
            ));
        }
        return $productDailyViewModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($productDailyViewId)
    {
        $productDailyView = $this->productDailyViewFactory->create();
        $this->resource->load($productDailyView, $productDailyViewId);
        if (!$productDailyView->getId()) {
            throw new NoSuchEntityException(__('ProductDailyView with id "%1" does not exist.', $productDailyViewId));
        }
        return $productDailyView->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->productDailyViewCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\Reports\Api\Data\ProductDailyViewInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \Aria\Reports\Api\Data\ProductDailyViewInterface $productDailyView
    ) {
        try {
            $productDailyViewModel = $this->productDailyViewFactory->create();
            $this->resource->load($productDailyViewModel, $productDailyView->getProductdailyviewId());
            $this->resource->delete($productDailyViewModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the ProductDailyView: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($productDailyViewId)
    {
        return $this->delete($this->get($productDailyViewId));
    }

    /**
     * {@inheritdoc}
     */
    public function createView($productId)
    {
        try {
            $checkviewExist = $this->checkViewExist($productId);

            $today = date("Y-m-d ");

            if (!$checkviewExist) {
                $product = $this->productRepository->getById($productId);

                $name = $product->getName();
                $sku = $product->getSku();

                $sellerId = $product->getSellerId();

                if (!isset($sellerId) || $sellerId == null) {
                    return false;
                }

                $supplierId = $this->getSupplierId($sellerId);

                $productViewFactory = $this->productDailyViewFactory->create();

                $productViewFactory->setProductId($productId);
                $productViewFactory->setSku($sku);
                $productViewFactory->setProductName($name);
                $productViewFactory->setPeriod($today);
                $productViewFactory->setViewsNum(1);
                $productViewFactory->setSupplierId($supplierId);
                $this->resource->save($productViewFactory);
            }
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save product view log',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * To check whether view exist for a product
     */
    public function checkViewExist($productId)
    {
        $today = date("Y-m-d ");
        $collection = $this->productDailyViewCollectionFactory->create();

        $collection->addFieldToFilter('product_id', $productId);
        $collection->addFieldToFilter('period', $today);

        if (count($collection) >= 1) {
            $view = $collection->getFirstItem();

            $view->setViewsNum($view->getViewsNum() + 1);
            $view->save();
            return true;
        }

        return false;
    }

    /**
     * To get suppy company Id from product seller Id 
     */
    public function getSupplierId($sellerId)
    {
        $supplyCompanyCollection = $this->supplyCompanyCollectionFactory->create();

        $supplyCompanyCollection->addFieldToFilter('company_admin', $sellerId);

        if (count($supplyCompanyCollection) >= 1) {
            $supplyCompany = $supplyCompanyCollection->getFirstItem();

            return $supplyCompany->getSupplycompanyId();
        }
    }
}
