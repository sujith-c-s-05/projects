<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Report Sold Products collection
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 */
namespace Aria\Reports\Model\ResourceModel\Report\Collection\Sales;

use Magento\Framework\DB\Select;
use Zend_Db_Select_Exception;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DC\CollectionFactory as DCCollectionFactory;

/**
 * Data collection.
 *
 * @SuppressWarnings(PHPMD.DepthOfInheritance)
 * @api
 * @since 100.0.2
 */
class Collection extends \Magento\Reports\Model\ResourceModel\Order\Collection
{
    public function __construct(
        \Magento\Framework\Data\Collection\EntityFactory $entityFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Framework\Model\ResourceModel\Db\VersionControl\Snapshot $entitySnapshot,
        \Magento\Framework\DB\Helper $coreResourceHelper,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
        \Magento\Sales\Model\Order\Config $orderConfig,
        \Magento\Sales\Model\ResourceModel\Report\OrderFactory $reportOrderFactory,
        \Magento\Framework\DB\Adapter\AdapterInterface $connection = null,
        \Magento\Framework\Model\ResourceModel\Db\AbstractDb $resource = null,
        DCCollectionFactory $dCCollectionFactory
    ) {
        $this->dCCollectionFactory = $dCCollectionFactory;
        parent::__construct(
            $entityFactory,
            $logger,
            $fetchStrategy,
            $eventManager,
            $entitySnapshot,
            $coreResourceHelper,
            $scopeConfig,
            $storeManager,
            $localeDate,
            $orderConfig,
            $reportOrderFactory,
            $connection,
            $resource
        );
    }
    
    /**
     * Set Date range to collection.
     *
     * @param string $from
     * @param string $to
     * @return $this
     * @throws Zend_Db_Select_Exception
     */
    public function setCustomDateRange($from, $to, $supplierId)
    {
        $this->_reset()->addAttributeToSelect(
            '*'
        )->addCustomOrderedQty(
            $from,
            $to,
            $supplierId
        )->setOrder(
            'orders',
            self::SORT_ORDER_DESC
        );
        return $this;
    }

    /**
     * Add ordered qty's
     *
     * @param string $from
     * @param string $to
     * @return $this
     * @throws Zend_Db_Select_Exception
     */
    public function addCustomOrderedQty($from = '', $to = '',$supplierId)
    {
        $dcCollection = $this->dCCollectionFactory->create();
        $supplyCollection=$dcCollection->addFieldToFilter('supply_id', array('eq' => $supplierId));
        $dcIds=$supplyCollection->addFieldToSelect('dc_id');
        $sdcidList=$dcIds->getData();
        $ids = array_column($sdcidList, 'dc_id');
        
        $connection = $this->getConnection();
        $orderTableAliasName = $connection->quoteIdentifier('order');
        
        $fieldName = $orderTableAliasName . '.created_at';
        $whereCondition[] = 'dcid IN ('.implode(',',$ids).')';
        $whereCondition[] = 'status = "Delivered"';
        $whereCondition[] = $this->prepareBetweenSql($fieldName, $from, $to);

        $this->getSelect()->reset()->from(
            ['order' => $this->getTable('sales_order')],
            [
                'tax' => 'SUM(order.tax_amount)',
                'revenue' => 'SUM(order.subtotal)',
                'sales items' => 'SUM(order.total_item_count)',
                'orders' => 'COUNT(order.entity_id)'
            ]
        )->where(
           implode(' AND ', $whereCondition)
        );
        return $this;
    }

    /**
     * Set store filter to collection
     *
     * @param array $storeIds
     * @return $this
     */
    public function setStoreIds($storeIds)
    {
        if ($storeIds) {
            $this->getSelect()->where('order.store_id IN (?)', (array)$storeIds);
        }
        return $this;
    }

    /**
     * Set order
     *
     * @param string $attribute
     * @param string $dir
     * @return $this
     */
    public function setOrder($attribute, $dir = self::SORT_ORDER_DESC)
    {
        if (in_array($attribute, ['orders', 'entity_id'])) {
            $this->getSelect()->order($attribute . ' ' . $dir);
        } else {
            parent::setOrder($attribute, $dir);
        }

        return $this;
    }

    /**
     * @inheritdoc
     *
     * @return Select
     * @since 100.2.0
     */
    public function getSelectCountSql()
    {
        $countSelect = clone parent::getSelectCountSql();

        $countSelect->reset(Select::COLUMNS);
        $countSelect->columns('COUNT(DISTINCT order.entity_id)');

        return $countSelect;
    }

    /**
     * Prepare between sql
     *
     * @param string $fieldName Field name with table suffix ('created_at' or 'main_table.created_at')
     * @param string $from
     * @param string $to
     * @return string Formatted sql string
     */
    protected function prepareBetweenSql($fieldName, $from, $to)
    {
        return sprintf(
            '(%s BETWEEN %s AND %s)',
            $fieldName,
            $this->getConnection()->quote($from),
            $this->getConnection()->quote($to)
        );
    }
    /**
     * Load data
     *
     * @param bool $printQuery
     * @param bool $logQuery
     * @return $this
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function loadData($printQuery = false, $logQuery = false)
    {
        $this->_items = $this->getReports();
        return $this;
    }
    
}
