<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Reports\Model\ResourceModel\ProductDailyView;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    /**
     * @var string
     */
    protected $_idFieldName = 'productdailyview_id';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Aria\Reports\Model\ProductDailyView::class,
            \Aria\Reports\Model\ResourceModel\ProductDailyView::class
        );
    }
    public function setCustomDateRange($from, $to, $supplierId)
    {
        $this->addCustomOrderedQty(
            $from,
            $to,
            $supplierId
        )->setOrder(
            'views_num',
            self::SORT_ORDER_DESC
        );
        return $this;
    }

    /**
     * Add ordered qty's
     *
     * @param string $from
     * @param string $to
     * @return $this
     * @throws Zend_Db_Select_Exception
     */
    public function addCustomOrderedQty($from = '', $to = '',$supplierId)
    {        
        $connection = $this->getConnection();
        $orderTableAliasName = $connection->quoteIdentifier('view');
        
        $fieldName = $orderTableAliasName . '.created_at';
        $whereCondition[] = 'view.supplier_id = '.$supplierId.' ';
        $whereCondition[] = $this->prepareBetweenSql($fieldName, $from, $to);

        $this->getSelect()->reset()->from(
            ['view' => $this->getTable('aria_reports_productdailyview')],
            [
                'sku' => 'view.sku',
                'views_num' => 'SUM(view.views_num)',
                'product_name' => 'view.product_name'
            ]
        )->where(
           implode('AND', $whereCondition)
        )->group(
            'view.product_id'
        );
        return $this;
    }
    /**
     * Set store filter to collection
     *
     * @param array $storeIds
     * @return $this
     */
    public function setStoreIds($storeIds)
    {
        // if ($storeIds) {
        //     $this->getSelect()->where('order_items.store_id IN (?)', (array)$storeIds);
        // }
        return $this;
    }

    /**
     * Set order
     *
     * @param string $attribute
     * @param string $dir
     * @return $this
     */
    public function setOrder($attribute, $dir = self::SORT_ORDER_DESC)
    {
        if (in_array($attribute, ['views_num', 'views_num'])) {
            $this->getSelect()->order($attribute . ' ' . $dir);
        } else {
            parent::setOrder($attribute, $dir);
        }

        return $this;
    }

    /**
     * @inheritdoc
     *
     * @return Select
     * @since 100.2.0
     */
    public function getSelectCountSql()
    {
        $countSelect = clone parent::getSelectCountSql();

        $countSelect->reset(Select::COLUMNS);
        $countSelect->columns('COUNT(DISTINCT view.productdailyview_id)');

        return $countSelect;
    }

    /**
     * Prepare between sql
     *
     * @param string $fieldName Field name with table suffix ('created_at' or 'main_table.created_at')
     * @param string $from
     * @param string $to
     * @return string Formatted sql string
     */
    protected function prepareBetweenSql($fieldName, $from, $to)
    {
        return sprintf(
            '(%s BETWEEN %s AND %s)',
            $fieldName,
            $this->getConnection()->quote($from),
            $this->getConnection()->quote($to)
        );
    }
}

