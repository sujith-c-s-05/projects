<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Aria\Reports\Model\ResourceModel\Report;

/**
 * Class Collection
 *
 * @api
 * @since 100.0.2
 */
class Collection extends \Magento\Reports\Model\ResourceModel\Report\Collection
{
    protected $supplierId;
    protected $dcIds = [];
    /**
     * Get report for some interval
     *
     * @param int $fromDate
     * @param int $toDate
     * @return \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
     */
    protected function _getReport($fromDate, $toDate)
    {
        if ($this->_reportCollection === null) {
            return [];
        }
        $reportResource = $this->_collectionFactory->create($this->_reportCollection);
        $reportResource->setCustomDateRange($fromDate, $toDate, $this->getSupplierId())->setStoreIds($this->getStoreIds());
        return $reportResource;
    }

    /**
     * Get Reports based on intervals
     *
     * @return array
     */
    public function getReports()
    {
        if (!$this->_reports) {
            $reports = [];
            foreach ($this->_getIntervals() as $interval) {
                $interval->setChildren($this->_getReport($interval->getStart(), $interval->getEnd()));
                if (count($interval->getChildren()) == 0) {
                    $interval->setIsEmpty(true);
                }
                $reports[] = $interval;
            }
            $this->_reports = $reports;
        }
        return $this->_reports;
    }

    /**
     * Load data
     *
     * @param bool $printQuery
     * @param bool $logQuery
     * @return $this
     *
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function loadData($printQuery = false, $logQuery = false)
    {
        $this->_items = $this->getReports();
        return $this;
    }
    /**
     * @inheritDoc
     */
    public function setSupplierId($supplierId){
        $this->supplierId = $supplierId;

    }
    /**
     * @inheritDoc
     */
    public function getSupplierId(){
        return $this->supplierId;

    }
    /**
     * @inheritDoc
     */
    public function setDcIds(array $dcIds){
        $this->dcIds = $dcIds;

    }
    /**
     * @inheritDoc
     */
    public function getDcIds(){

        return $this->supplierId;

    }
}
