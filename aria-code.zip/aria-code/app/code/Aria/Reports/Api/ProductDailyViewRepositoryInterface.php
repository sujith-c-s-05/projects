<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Reports\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface ProductDailyViewRepositoryInterface
{

    /**
     * Save ProductDailyView
     * @param \Aria\Reports\Api\Data\ProductDailyViewInterface $productDailyView
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\Reports\Api\Data\ProductDailyViewInterface $productDailyView
    );

    /**
     * Retrieve ProductDailyView
     * @param string $productdailyviewId
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($productdailyviewId);

    /**
     * Retrieve ProductDailyView matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\Reports\Api\Data\ProductDailyViewSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete ProductDailyView
     * @param \Aria\Reports\Api\Data\ProductDailyViewInterface $productDailyView
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Aria\Reports\Api\Data\ProductDailyViewInterface $productDailyView
    );

    /**
     * Delete ProductDailyView by ID
     * @param string $productdailyviewId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($productdailyviewId);

    /**
     * Log a product view
     * @param int $productId
     * @param string $sku
     * @return bool true on success
     */
    public function createView($productId);
    
}

