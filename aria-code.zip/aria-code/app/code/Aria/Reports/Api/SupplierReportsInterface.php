<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Reports\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface SupplierReportsInterface
{

    /**
     * To generate Supplier report
     * @param string $from
     * @param string $to
     * @param string $type
     * @param int $supplierId
     * @param int $dcId
     * @param int $dcuserId
     * @param string $period
     * @return mixed[]
     */
    public function generateReport($from,$to,$type,$supplierId,$dcId,$dcuserId,$period='day');
}

