<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Reports\Api\Data;

interface ProductDailyViewInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const RATING_POS = 'rating_pos';
    const PRODUCTDAILYVIEW_ID = 'productdailyview_id';
    const PERIOD = 'period';
    const SUPPLIER_ID = 'supplier_id';
    const SKU = 'sku';
    const PRODUCT_ID = 'product_id';
    const PRODUCT_NAME = 'product_name';
    const VIEWS_NUM = 'views_num';

    /**
     * Get productdailyview_id
     * @return string|null
     */
    public function getProductdailyviewId();

    /**
     * Set productdailyview_id
     * @param string $productdailyviewId
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setProductdailyviewId($productdailyviewId);

    /**
     * Get period
     * @return string|null
     */
    public function getPeriod();

    /**
     * Set period
     * @param string $period
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setPeriod($period);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\Reports\Api\Data\ProductDailyViewExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\Reports\Api\Data\ProductDailyViewExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\Reports\Api\Data\ProductDailyViewExtensionInterface $extensionAttributes
    );

    /**
     * Get product_id
     * @return string|null
     */
    public function getProductId();

    /**
     * Set product_id
     * @param string $productId
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setProductId($productId);

    /**
     * Get sku
     * @return string|null
     */
    public function getSku();

    /**
     * Set sku
     * @param string $sku
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setSku($sku);

    /**
     * Get product_name
     * @return string|null
     */
    public function getProductName();

    /**
     * Set product_name
     * @param string $productName
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setProductName($productName);

    /**
     * Get views_num
     * @return string|null
     */
    public function getViewsNum();

    /**
     * Set views_num
     * @param string $viewsNum
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setViewsNum($viewsNum);

    /**
     * Get rating_pos
     * @return string|null
     */
    public function getRatingPos();

    /**
     * Set rating_pos
     * @param string $ratingPos
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setRatingPos($ratingPos);

    /**
     * Get supplier_id
     * @return string|null
     */
    public function getSupplierId();

    /**
     * Set supplier_id
     * @param string $supplierId
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface
     */
    public function setSupplierId($supplierId);
}

