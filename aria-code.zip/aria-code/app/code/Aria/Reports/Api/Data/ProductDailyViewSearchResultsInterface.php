<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Reports\Api\Data;

interface ProductDailyViewSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get ProductDailyView list.
     * @return \Aria\Reports\Api\Data\ProductDailyViewInterface[]
     */
    public function getItems();

    /**
     * Set period list.
     * @param \Aria\Reports\Api\Data\ProductDailyViewInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

