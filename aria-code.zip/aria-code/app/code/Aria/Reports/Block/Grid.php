<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Aria\Reports\Block;

use Magento\Backend\Block\Template\Context;
use Magento\Backend\Helper\Data;
use Magento\Framework\Url\DecoderInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Stdlib\Parameters;

/**
 * Backend report grid block
 *
 * @api
 * @author     Magento Core Team <core@magentocommerce.com>
 * @since 100.0.2
 */
class Grid extends \Magento\Reports\Block\Adminhtml\Grid
{

    public function __construct(
        Context $context,
        Data $backendHelper,
        array $data = [],
        DecoderInterface $urlDecoder = null,
        Parameters $parameters = null,
        \Magento\Reports\Model\ResourceModel\Report\CollectionFactory $reportCollectionFactory
    ) {
        $this->reportCollectionFactory = $reportCollectionFactory;
        parent::__construct($context, $backendHelper, $data, $urlDecoder, $parameters);
    }

    /**
     * Apply sorting and filtering to collection
     *
     * @return $this
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     */
    public function getPrepareCollection($data, $collection, $supplierId)
    {
            if (!isset($data['report_from'])) {
                // Get records for the past month
                $date = new \DateTime('-1 month');
                $data['report_from'] = $this->_localeDate->formatDateTime(
                    $date,
                    \IntlDateFormatter::SHORT,
                    \IntlDateFormatter::NONE
                );
            }

            if (!isset($data['report_to'])) {
                $date = new \DateTime();
                $data['report_to'] = $this->_localeDate->formatDateTime(
                    $date,
                    \IntlDateFormatter::SHORT,
                    \IntlDateFormatter::NONE
                );
            }

            $this->_setFilterValues($data);
        
        if ($collection) {
            $collection->setSupplierId($supplierId);
            $collection->setPeriod($this->getFilter('report_period'));

            if ($this->getFilter('report_from') && $this->getFilter('report_to')) {
                /**
                 * Validate from and to date
                 */
                try {
                    $from = $this->_localeDate->date($this->getFilter('report_from'), null, true, false);
                    $to = $this->_localeDate->date($this->getFilter('report_to'), null, true, false);
                    $collection->setInterval($from, $to);
                } catch (\Exception $e) {
                    $this->_errors[] = __('Invalid date specified');
                }
            }

            $collection->setStoreIds($this->_getAllowedStoreIds());

            if ($this->getSubReportSize() !== null) {
                $collection->setPageSize($this->getSubReportSize());
            }

            $this->_eventManager->dispatch(
                'adminhtml_widget_grid_filter_collection',
                ['collection' => $this->getCollection(), 'filter_values' => $this->_filterValues]
            );
        }
        return $collection;
    }
}
