define([
    'jquery',
    'jquery/validate',
    'mage/translate'
 ], function($) {
    'use strict';
 
    return function() {
       // Add a validation method to validate NZ phone number.
        $.validator.addMethod(
            'phoneNZ',
           function(value) {
                 return value.length > 10 &&  value.length < 12
                 && value.match(/^(0|(\+64(\s|-)?)){1}\d{1}(\s|-)?\d{3}(\s|-)?\d{4}$/);
             },
             $.mage.__('Phone Number Format should be +64XXXXXXXX.')
        );
    }
 });
 