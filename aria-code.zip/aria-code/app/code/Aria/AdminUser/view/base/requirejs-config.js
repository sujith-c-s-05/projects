var config = {
    config: {
      mixins: {
        'mage/validation': {
          'Aria_AdminUser/js/validation': true
        }
      }
    }
}