<?php
/**
 * Copyright ©  All rights reserved.
 */
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Aria_QuickAccess', __DIR__);