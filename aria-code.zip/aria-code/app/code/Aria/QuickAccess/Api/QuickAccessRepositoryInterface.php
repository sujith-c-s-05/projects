<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\QuickAccess\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface QuickAccessRepositoryInterface
{

    /**
     * Save Quick Access
     * @param \Aria\QuickAccess\Api\Data\QuickAccessInterface $quickAccess
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\QuickAccess\Api\Data\QuickAccessInterface $quickAccess
    );

    /**
     * Get Quick Access
     * @param int id
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getQuickAccess($id);

    /**
     * delete Quick Access
     * @param int id
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteQuickAccess($id);

    /**
     * Retrieve Quick Access matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\QuickAccess\Api\Data\QuickAccessSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );
}