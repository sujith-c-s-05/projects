<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\QuickAccess\Api\Data;

interface QuickAccessInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const ID = 'id';
    const VENUE_USER_ID = 'venue_user_id';
    const VENUE_ID = 'venue_id';
    const REFERRAL_URL= 'referral_url';
    const NAME='name';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const IS_DELETE = 'is_delete';

    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param int $Id
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     */
    public function setId($Id);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\QuickAccess\Api\Data\QuickAccessExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\QuickAccess\Api\Data\QuickAccessExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\QuickAccess\Api\Data\QuickAccessExtensionInterface $extensionAttributes
    );

     /**
     * Get venue_id
     * @return int|null
     */
    public function getVenueId();

    /**
     * Set venue_id
     * @param int $venueId
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     */
    public function setVenueId($venueId);

    /**
     * Get venue_user_id
     * @return int|null
     */
    public function getVenueUserId();

    /**
     * Set venue_user_id
     * @param int $venueUserId
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     */
    public function setVenueUserId($venueUserId);

    /**
     * Get name
     * @return string|null
     */
    public function getName();

    /**
     * Set name
     * @param string $name
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     */
    public function setName($name);

    /**
     * Get referral_url
     * @return string|null
     */
    public function getReferralUrl();

    /**
     * Set referral_url
     * @param string $referralUrl
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     */
    public function setReferralUrl($referralUrl);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     */
    public function setUpdatedBy($updatedBy);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     */
    public function setUpdatedAt($updatedAt);
     /**
     * Get is_active
     * @return bool|true
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     */
    public function setIsActive($isActive);

     /**
     * Get is_delete
     * @return bool
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface
     */
    public function setIsDelete($isDelete);



}