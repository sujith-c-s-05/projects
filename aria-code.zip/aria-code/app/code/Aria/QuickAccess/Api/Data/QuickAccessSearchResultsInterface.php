<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\QuickAccess\Api\Data;

interface QuickAccessSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get QuickAccess list.
     * @return \Aria\QuickAccess\Api\Data\QuickAccessInterface[]
     */
    public function getItems();

    /**
     * Set QuickAccess list.
     * @param \Aria\QuickAccess\Api\Data\QuickAccessInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

