<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\QuickAccess\Model;

use Aria\QuickAccess\Api\QuickAccessRepositoryInterface;
use Aria\QuickAccess\Api\Data\QuickAccessInterfaceFactory;
use Aria\QuickAccess\Api\Data\QuickAccessSearchResultsInterfaceFactory;
use Aria\QuickAccess\Model\ResourceModel\QuickAccess as ResourceQuickAccess;
use Aria\QuickAccess\Model\ResourceModel\QuickAccess\CollectionFactory as QuickAccessCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;

class QuickAccessRepository implements QuickAccessRepositoryInterface
{

    protected $quickAccessCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;

    protected $quickAccessFactory;

    protected $searchResultsFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataQuickAccessFactory;

     /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;


    /**
     * @param ResourceQuickAccess $resource
     * @param QuickAccessFactory $quickAccessFactory
     * @param QuickAccessInterfaceFactory $dataQuickAccessFactory
     * @param QuickAccessCollectionFactory $quickAccessCollectionFactory
     * @param QuickAccessSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        ResourceQuickAccess $resource,
        QuickAccessFactory $quickAccessFactory,
        QuickAccessInterfaceFactory $dataQuickAccessFactory,
        QuickAccessCollectionFactory $quickAccessCollectionFactory,
        QuickAccessSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->resource = $resource;
        $this->quickAccessFactory = $quickAccessFactory;
        $this->quickAccessCollectionFactory = $quickAccessCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataQuickAccessFactory = $dataQuickAccessFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->scopeConfig = $scopeConfig;

    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\QuickAccess\Api\Data\QuickAccessInterface $quickAccess
    ) {
        
        $quickAccessData = $this->extensibleDataObjectConverter->toNestedArray(
            $quickAccess,
            [],
            \Aria\QuickAccess\Api\Data\QuickAccessInterface::class
        );

        $quickAccessModel = $this->quickAccessFactory->create()->setData($quickAccessData);

        try {
            $venueId=$quickAccess->getVenueId();
            $venueUserId=$quickAccess->getVenueUserId();
            $quickAccessLimit=$this->scopeConfig->getValue('quickaccess/general/display_text',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $accessCollection = $this->quickAccessCollectionFactory->create();
            $accessCollection->addFieldToFilter('is_delete', array('eq' =>0));
            $accessCollection->addFieldToFilter('venue_id',$venueId);
            $accessCollection->addFieldToFilter('venue_user_id',$venueUserId); 
            $count = $accessCollection->count();
            if($count<$quickAccessLimit)
            {
                $this->resource->save($quickAccessModel);
            }
            else
            {
                throw new \Magento\Framework\Webapi\Exception(    __('Quick Access Cannot be added.Limit for adding Quick Access exceeded'),
                0,\Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST
                );
            }
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the venue: %1',
                $exception->getMessage()
            ));
        }
        return $quickAccessModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getQuickAccess($id)
    { 
        $quickAccess = $this->quickAccessFactory->create();
        $this->resource->load($quickAccess, $id);
        if (!$quickAccess->getId()) {
            throw new NoSuchEntityException(__('QuickAccess with id "%1" does not exist.', $id));
        }
        return $quickAccess->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->quickAccessCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\QuickAccess\Api\Data\QuickAccessInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }
    
     /**
     * @inheritdoc
     */
    public function deleteQuickAccess($id)
    {
        try {
                $quickAccess = $this->quickAccessFactory->create();
                $this->resource->load($quickAccess, $id);
                if (!$quickAccess->getId()) {
                    throw new NoSuchEntityException(__('Quick Access  with id "%1" does not exist.', $id));
                }
                $quickAccess->setIsDelete(1);
                $quickAccess->setIsActive(0);
                $quickAccess->save();
            } catch (\Exception $e) {
                throw new CouldNotDeleteException(__(
                    'Could not delete the Quick Access',
                    $e->getMessage()
                ));
            }
        return true;
    }

}