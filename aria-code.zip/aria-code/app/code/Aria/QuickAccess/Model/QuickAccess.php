<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\QuickAccess\Model;

use Aria\QuickAccess\Api\Data\QuickAccessInterface;
use Aria\QuickAccess\Api\Data\QuickAccessInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class QuickAccess extends \Magento\Framework\Model\AbstractModel
{

    protected $quickAccessDataFactory;

    protected $_eventPrefix = 'aria_quick_access';
    protected $dataObjectHelper;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param QuickAccessInterfaceFactory $quickAccessDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\QuickAccess\Model\ResourceModel\QuickAccess $resource
     * @param \Aria\QuickAccess\Model\ResourceModel\QuickAccess\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        QuickAccessInterfaceFactory $quickAccessDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\QuickAccess\Model\ResourceModel\QuickAccess $resource,
        \Aria\QuickAccess\Model\ResourceModel\QuickAccess\Collection $resourceCollection,
        array $data = []
    ) {
        $this->quickAccessDataFactory = $quickAccessDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve Quick Access model  data
     * @return QuickAccessInterface
     */
    public function getDataModel()
    {
        $quickAccessData = $this->getData();
        
        $quickAccessDataObject = $this->quickAccessDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $quickAccessDataObject,
            $quickAccessData,
            QuickAccessInterface::class
        );
        
        return $quickAccessDataObject;
    }
 
}

