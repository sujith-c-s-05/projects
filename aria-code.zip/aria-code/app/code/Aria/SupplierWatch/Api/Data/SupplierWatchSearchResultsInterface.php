<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Api\Data;

interface SupplierWatchSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get SupplierWatch list.
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchInterface[]
     */
    public function getItems();

    /**
     * Set SupplierWatch list.
     * @param \Aria\SupplierWatch\Api\Data\SupplierWatchInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
