<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Api\Data;

interface BulkProductSchedulerSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get BulkProductScheduler list.
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface[]
     */
    public function getItems();

    /**
     * Set BulkProductScheduler list.
     * @param \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
