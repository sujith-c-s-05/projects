<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Api\Data;

interface BulkProductSchedulerInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const ID = 'id';
    const BULK_UUID = 'bulk_uuid';
    const BULK_ITEM_ID ='bulk_item_id';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const STATUS = 'status';

    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param string $Id
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface
     */
    public function setId($Id);


    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplierWatch\Api\Data\BulkProductSchedulerExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplierWatch\Api\Data\BulkProductSchedulerExtensionInterface $extensionAttributes
    );

    /**
     * Get bulk_uuid
     * @return string|null
     */
    public function getBulkUuid();

    /**
     * Set bulk_uuid
     * @param string $bulkUuid
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface
     */
    public function setBulkUuid($bulkUuid);



    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get status
     * @return string|null
     */
    public function getStatus();

    /**
     * Set status
     * @param string $status
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface
     */
    public function setStatus($status);
}