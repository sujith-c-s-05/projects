<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Api\Data;

interface SupplierWatchInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const SUPPLIERWATCH_ID = 'supplierwatch_id';
    const SUPPLIER_ID = 'supplier_id';
    const VENUE_USER_ID = 'venue_user_id';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const STATUS = 'status';
    const VENUE_ID ='venue_id';

    /**
     * Get supplierwatch_id
     * @return int|null
     */
    public function getSupplierwatchId();

    /**
     * Set supplierwatch_id
     * @param string $supplierwatchId
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchInterface
     */
    public function setSupplierwatchId($supplierwatchId);

    /**
     * Get venue_user_id
     * @return int|null
     */
    public function getVenueUserId();

    /**
     * Set venue_user_id
     * @param int $venueUserId
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchInterface
     */
    public function setVenueUserId($venueUserId);

     /**
     * Get venue_id
     * @return int|null
     */
    public function getVenueId();

    /**
     * Set venue_id
     * @param int $venueId
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchInterface
     */
    public function setVenueId($venueId);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplierWatch\Api\Data\SupplierWatchExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplierWatch\Api\Data\SupplierWatchExtensionInterface $extensionAttributes
    );

    /**
     * Get supplier_id
     * @return int|null
     */
    public function getSupplierId();

    /**
     * Set supplier_id
     * @param int $supplierId
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchInterface
     */
    public function setSupplierId($supplierId);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get status
     * @return bool|true
     */
    public function getStatus();

    /**
     * Set status
     * @param bool $status
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchInterface
     */
    public function setStatus($status);
}