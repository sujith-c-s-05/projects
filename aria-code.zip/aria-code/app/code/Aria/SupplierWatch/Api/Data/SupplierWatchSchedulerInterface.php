<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Api\Data;

interface SupplierWatchSchedulerInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const SCHEDULER_ID = 'scheduler_id';
    const SUPPLIER_ID = 'supplier_id';
    const SKU = 'sku';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const STATUS = 'status';

    /**
     * Get scheduler_id
     * @return int|null
     */
    public function getSchedulerId();

    /**
     * Set scheduler_id
     * @param string $schedulerId
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     */
    public function setSchedulerId($schedulerId);


    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerExtensionInterface $extensionAttributes
    );

    /**
     * Get supplier_id
     * @return int|null
     */
    public function getSupplierId();

    /**
     * Set supplier_id
     * @param int $supplierId
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     */
    public function setSupplierId($supplierId);


    /**
     * Get sku
     * @return string|null
     */
    public function getSku();

    /**
     * Set sku
     * @param int $sku
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     */
    public function setSku($sku);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get status
     * @return string|null
     */
    public function getStatus();

    /**
     * Set status
     * @param string $status
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     */
    public function setStatus($status);
}