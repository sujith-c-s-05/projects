<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Api\Data;

interface SupplierWatchSchedulerSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get SupplierWatchScheduler list.
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface[]
     */
    public function getItems();

    /**
     * Set SupplierWatchScheduler list.
     * @param \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
