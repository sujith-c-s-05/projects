<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface BulkProductSchedulerRepositoryInterface
{

    /**
     * Save BulkProductScheduler
     * @param \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface $bulkProductScheduler
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface $bulkProductScheduler
    );

    /**
     * Retrieve BulkProductScheduler
     * @param int $Id
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($Id);

    /**
     * Retrieve BulkProductScheduler matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete BulkProductScheduler
     * @param \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface $bulkProductScheduler
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface $bulkProductScheduler
    );

    /**
     * Delete BulkProductScheduler by ID
     * @param int $Id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($Id);
}
