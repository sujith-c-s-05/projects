<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface SupplierWatchSchedulerRepositoryInterface
{

    /**
     * Save SupplierWatchScheduler
     * @param \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface $supplierWatchScheduler
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface $supplierWatchScheduler
    );

    /**
     * Retrieve SupplierWatchScheduler
     * @param int $schedulerId
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($schedulerId);

    /**
     * Retrieve SupplierWatchScheduler matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete SupplierWatchScheduler
     * @param \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface $supplierWatch
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface $supplierWatchScheduler
    );

    /**
     * Delete SupplierWatchScheduler by ID
     * @param int $schedulerId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($schedulerId);
}
