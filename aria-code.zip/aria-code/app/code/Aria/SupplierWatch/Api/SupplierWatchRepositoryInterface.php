<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface SupplierWatchRepositoryInterface
{

    /**
     * Save SupplierWatch
     * @param \Aria\SupplierWatch\Api\Data\SupplierWatchInterface $supplierWatch
     * @param int $customerId
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\SupplierWatch\Api\Data\SupplierWatchInterface $supplierWatch,$customerId=null
    );

    /**
     * Retrieve SupplierWatch
     * @param int $supplierwatchId
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($supplierwatchId);

    /**
     * Retrieve SupplierWatch matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete SupplierWatch
     * @param \Aria\SupplierWatch\Api\Data\SupplierWatchInterface $supplierWatch
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Aria\SupplierWatch\Api\Data\SupplierWatchInterface $supplierWatch
    );

    /**
     * Delete SupplierWatch by ID
     * @param int $supplierwatchId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($supplierwatchId);

    /**
     * @param int $supplierWatchId
     * @param bool $status
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function updateStatus($supplierwatchId,$status);

    /**
     * Check Wether supplier is on watch
     * @param int $participantId
     * @param int $userId
     * @param int $supplierId
     * @param int $customerId
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function checkSupplierIsOnWatch($participantId,$userId,$supplierId,$customerId);
}
