<?php

namespace Aria\SupplierWatch\Cron;

use Aria\SupplierWatch\Model\ResourceModel\BulkProductScheduler\CollectionFactory as BulkProductSchedulerCollectionFactory;
use Aria\SupplierWatch\Model\ResourceModel\SupplierWatch\CollectionFactory as SupplierWatchCollectionFactory;


class BulkUploadNotification
{
    public function __construct(
        BulkProductSchedulerCollectionFactory $bulkProductSchedulerCollectionFactory,
        SupplierWatchCollectionFactory $supplierWatchCollectionFactory,
        \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface

    ) {
        
        $this->bulkProductSchedulerCollectionFactory=$bulkProductSchedulerCollectionFactory;
        $this->supplierWatchCollectionFactory=$supplierWatchCollectionFactory;
        $this->participantsRepositoryInterface=$participantsRepositoryInterface;



    }

    public function execute()
	{
        
            $bulkProductSchedulerCollection = $this->bulkProductSchedulerCollectionFactory->create();
            $bulkProductSchedulerCollection->addFieldToFilter('status',1);
            foreach($bulkProductSchedulerCollection as $bulkProduct)
            {
                $bulkUuid= $bulkProduct->getBulkUuid();
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
                $connection = $resource->getConnection();
                $sql = 'CALL bulkSku("'.$bulkUuid.'")'; //This is the main query
                $result = $connection->fetchAll($sql); 

                $supplierId=$result[0]['result2'];
                $supplierName=$result[0]['result3'];
                $skulist=$result[0]['result'];
                $count = substr_count($skulist, ',') + 1;

                $supplierWatchCollection = $this->supplierWatchCollectionFactory->create();
                $supplierWatchCollection->addFieldToFilter('supplier_id', $supplierId)->addFieldToFilter('status', 1);
                foreach($supplierWatchCollection as $supplierWatch){
                    $des = $supplierName." added ".$count." products";  
                    $venueId = $supplierWatch->getVenueId();
                    $venueUserId = $supplierWatch->getVenueUserId();
                    $this->participantsRepositoryInterface->saveParticipantNotification(5,$venueId,$venueUserId,$des,'venue_user','Supplier added products',$skulist);
                }
                $bulkProduct->setStatus(0);
                $bulkProduct->save();
            }   
            
    }
}