<?php

namespace Aria\SupplierWatch\Cron;

use Aria\SupplierWatch\Model\ResourceModel\BulkProductScheduler\CollectionFactory as BulkProductSchedulerCollectionFactory;

class BulkUploadWatch
{
    public function __construct(
        \Aria\SupplierWatch\Api\BulkProductSchedulerRepositoryInterface $bulkProductRepositoryInterface,
        BulkProductSchedulerCollectionFactory $bulkProductSchedulerCollectionFactory

    ) {
        
        $this->bulkProductRepositoryInterface=$bulkProductRepositoryInterface;
        $this->bulkProductSchedulerCollectionFactory=$bulkProductSchedulerCollectionFactory;

    }

    public function execute()
	{
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $sql = 'CALL bulkProducts()'; //This is the main query
        $result = $connection->fetchAll($sql); 
        $ids = array_column($result, 'bulk_uuid');
       

        foreach($ids as $res)
        {
            $bulkProductSchedulerCollection = $this->bulkProductSchedulerCollectionFactory->create();
            $bulkProductSchedulerCollection->addFieldToFilter('bulk_uuid', $res)->addFieldToFilter('status',0);
            if(count($bulkProductSchedulerCollection) == 0)
            {
                $bulkWatchScheduler = $objectManager->create('Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface');
                $bulkWatchScheduler->setBulkUuid($res)
                ->setStatus(1);
                $this->bulkProductRepositoryInterface->save($bulkWatchScheduler);
            }
        }
    }
}