<?php

namespace Aria\SupplierWatch\Cron;

use Aria\SupplierWatch\Model\ResourceModel\SupplierWatchScheduler\CollectionFactory as SupplierWatchSchedulerCollectionFactory;
use Aria\SupplierWatch\Model\ResourceModel\SupplierWatch\CollectionFactory as SupplierWatchCollectionFactory;

class WatchSupplier
{
    public function __construct(
        SupplierWatchSchedulerCollectionFactory $supplierWatchSchedulerCollectionFactory,
        SupplierWatchCollectionFactory $supplierWatchCollectionFactory,
        \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface,
        \Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface
    ) {
        
        $this->supplierWatchSchedulerCollectionFactory=$supplierWatchSchedulerCollectionFactory;
        $this->supplierWatchCollectionFactory=$supplierWatchCollectionFactory;
        $this->participantsRepositoryInterface=$participantsRepositoryInterface;
        $this->supplyCompanyRepositoryInterface=$supplyCompanyRepositoryInterface;
    }

    public function execute()
	{
        $supplierWatchCollection = $this->supplierWatchCollectionFactory->create();
        $supplierWatchSchedulerCollection = $this->supplierWatchSchedulerCollectionFactory->create();
        $supplierWatchSchedulerCollection->addFieldToFilter('status', 1);
        foreach($supplierWatchSchedulerCollection as $supplierWatchScheduler){
            $supplierId = $supplierWatchScheduler->getSupplierId();
            $supplyCompany=$this->supplyCompanyRepositoryInterface->get($supplierId);
            $supplierName = $supplyCompany->getCompanyName();
            $sku = $supplierWatchScheduler->getSku();
            $supplierWatchCollection->addFieldToFilter('supplier_id', $supplierId)->addFieldToFilter('status', 1);
            foreach($supplierWatchCollection as $supplierWatch){
                $des = $supplierName." added a New Product";  
                $venueId = $supplierWatch->getVenueId();
                $venueUserId = $supplierWatch->getVenueUserId();
                $this->participantsRepositoryInterface->saveParticipantNotification(5,$venueId,$venueUserId,$des,'venue_user','Supplier added a new product',$sku);
            }
            $supplierWatchScheduler->setStatus(0);  
            $supplierWatchScheduler->save(); 
        }
    }
}