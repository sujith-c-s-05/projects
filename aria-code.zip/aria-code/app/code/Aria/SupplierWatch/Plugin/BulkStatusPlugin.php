<?php
namespace Aria\SupplierWatch\Plugin;

use Magento\Framework\Exception\CouldNotSaveException;
use Aria\SupplierWatch\Model\ResourceModel\SupplierWatch\CollectionFactory as SupplierWatchCollectionFactory;

/**
 * Class is used for sending notifications when supplier add a group of products.
 */
class BulkStatusPlugin
{
    public function __construct(
        \Aria\ProductManagement\Model\SupplierProducts $supplierProduct,
        SupplierWatchCollectionFactory $supplierWatchCollectionFactory,
        \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface,
        \Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface

    ) {
        $this->supplierProduct = $supplierProduct;
        $this->supplierWatchCollectionFactory=$supplierWatchCollectionFactory;
        $this->participantsRepositoryInterface=$participantsRepositoryInterface;
        $this->supplyCompanyRepositoryInterface=$supplyCompanyRepositoryInterface;

    }
    
    public function afterGetBulkDetailedStatus(\Magento\AsynchronousOperations\Model\BulkOperationsStatus $subject,$result
   )
    {
        try{
            $bulk = $result->getOperationsList();
            $count = 0;
            $sku = [];
            foreach($bulk as $bulkitem){
                $status_type = $bulkitem['topic_name'];
                if($status_type == 'async.magento.catalog.api.productrepositoryinterface.save.post'){
                    $data = $bulkitem['result_serialized_data'];
                     $data1=json_decode($data,true);
                        $sku[] = $data1['sku'];
                        $object=$data1['extension_attributes'];
                        $supplierId = $object['supplier_id'];
                        $count++;
                    
                }
            }
            $supplyCompany=$this->supplyCompanyRepositoryInterface->get($supplierId);
           // $supplierId=$supplyCompany->getSupplycompanyId();
            $supplierName = $supplyCompany->getCompanyName();
            $supplierWatchCollection = $this->supplierWatchCollectionFactory->create();
            $supplierWatchCollection->addFieldToFilter('supplier_id', $supplierId)->addFieldToFilter('status', 1);
            $skuList = implode(', ', $sku);
            foreach($supplierWatchCollection as $supplierWatch){
                $des = $supplierName." added ".$count." products";  
                $venueId = $supplierWatch->getVenueId();
                $venueUserId = $supplierWatch->getVenueUserId();
                $this->participantsRepositoryInterface->saveParticipantNotification(5,$venueId,$venueUserId,$des,'venue_user','Supplier added products',$skuList);
            }
            return $result;
        }catch (CouldNotSaveException $e) {
            echo $e->getMessage();
        }
    }
}
