<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Model;

use Aria\SupplierWatch\Api\Data\SupplierWatchInterfaceFactory;
use Aria\SupplierWatch\Api\Data\SupplierWatchSearchResultsInterfaceFactory;
use Aria\SupplierWatch\Api\SupplierWatchRepositoryInterface;
use Aria\SupplierWatch\Model\ResourceModel\SupplierWatch as ResourceSupplierWatch;
use Aria\SupplierWatch\Model\ResourceModel\SupplierWatch\CollectionFactory as SupplierWatchCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Exception\AuthorizationException;


class SupplierWatchRepository implements SupplierWatchRepositoryInterface
{

    protected $resource;

    protected $extensibleDataObjectConverter;
    protected $searchResultsFactory;

    protected $dataSupplierWatchFactory;

    protected $supplierWatchCollectionFactory;

    private $storeManager;

    protected $dataObjectHelper;

    protected $dataObjectProcessor;

    protected $supplierWatchFactory;

    protected $extensionAttributesJoinProcessor;

    private $collectionProcessor;

    protected $venueUserRepositoryInterface;


    /**
     * @param ResourceSupplierWatch $resource
     * @param SupplierWatchFactory $supplierWatchFactory
     * @param SupplierWatchInterfaceFactory $dataSupplierWatchFactory
     * @param SupplierWatchCollectionFactory $supplierWatchCollectionFactory
     * @param SupplierWatchSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param Aria\Venue\Api\VenueUserRepositoryInterface $venueUserRepositoryInterface
     */
    public function __construct(
        ResourceSupplierWatch $resource,
        SupplierWatchFactory $supplierWatchFactory,
        SupplierWatchInterfaceFactory $dataSupplierWatchFactory,
        SupplierWatchCollectionFactory $supplierWatchCollectionFactory,
        SupplierWatchSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Aria\Venue\Api\VenueUserRepositoryInterface $venueUserRepositoryInterface

    ) {
        $this->resource = $resource;
        $this->supplierWatchFactory = $supplierWatchFactory;
        $this->supplierWatchCollectionFactory = $supplierWatchCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataSupplierWatchFactory = $dataSupplierWatchFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->venueUserRepositoryInterface=$venueUserRepositoryInterface;

    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\SupplierWatch\Api\Data\SupplierWatchInterface $supplierWatch,$customerId=null
    ) {
        $venueUserId=$supplierWatch->getVenueUserId();
        $venueUserDetails = $this->venueUserRepositoryInterface->get($venueUserId);
        $entityId=$venueUserDetails->getMagentoUserId();
        if($customerId!=$entityId)
        {
            throw new AuthorizationException(
                __("Access Denied.The consumer isn't authorized")
            );
        }


        $supplierWatchData = $this->extensibleDataObjectConverter->toNestedArray(
            $supplierWatch,
            [],
            \Aria\SupplierWatch\Api\Data\SupplierWatchInterface::class
        );

        $supplierWatchModel = $this->supplierWatchFactory->create()->setData($supplierWatchData);
        $supplierWatchObject=$this->getSupplierWatch($supplierWatchModel->getVenueUserId(),$supplierWatchModel->getVenueId()
                            ,$supplierWatchModel->getSupplierId());
        $supplierWatchModel->setSupplierwatchId($supplierWatchObject->getSupplierwatchId());    
       

        try {
            $this->resource->save($supplierWatchModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the supplierWatch: %1',
                $exception->getMessage()
            ));
        }
        return $supplierWatchModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($supplierwatchId)
    {
        $supplierWatch = $this->supplierWatchFactory->create();
        $this->resource->load($supplierWatch, $supplierwatchId);
        if (!$supplierWatch->getSupplierwatchId()) {
            throw new NoSuchEntityException(__('supplierWatch with id "%1" does not exist.', $supplierwatchId));
        }
        return $supplierWatch->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->supplierWatchCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\SupplierWatch\Api\Data\SupplierWatchInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \Aria\SupplierWatch\Api\Data\SupplierWatchInterface $supplierWatch
    ) {
        try {
            $supplierWatchModel = $this->supplierWatchFactory->create();
            $this->resource->load($supplierWatchModel, $supplierWatch->getSupplierwatchId());
            $this->resource->delete($supplierWatchModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the SupplierWatch: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($supplierwatchId)
    {
        return $this->delete($this->get($supplierwatchId));
    }

    /**
     * {@inheritdoc}
     */
    public function updateStatus($supplierwatchId, $status)
    {
        $supplierWatch = $this->supplierWatchFactory->create();
        $supplierWatch->setData('status', $status);
        $supplierWatch->setData('supplierwatch_id',$supplierwatchId);
        $this->resource->save($supplierWatch);
        return true;
    }
     /**
     * {@inheritdoc}
     */
    public function checkSupplierIsOnWatch($participantId,$userId,$supplierId,$customerId)
    {
        $venueUserDetails = $this->venueUserRepositoryInterface->get($userId);
        $entityId=$venueUserDetails->getMagentoUserId();
        if($customerId!=$entityId)
        {
            throw new AuthorizationException(
                __("Access Denied.The consumer isn't authorized")
            );
        }
        $collection = $this->supplierWatchCollectionFactory->create();
        $collection->addFieldToFilter('venue_user_id', $userId);
        $collection->addFieldToFilter('venue_id', $participantId);
        $collection->addFieldToFilter('supplier_id', $supplierId);
        $collection->addFieldToFilter('status',1);
        if(count($collection) >= 1)
        {
            return true;
        }

        return false;
        
    }

     /**
     * {@inheritdoc}
     */
    public function getSupplierWatch($venueUserId,$venueId,$supplierId)
    {
        $collection = $this->supplierWatchCollectionFactory->create();
        $supplierWatch=$collection->addFieldToFilter('venue_user_id',$venueUserId)
                    ->addFieldToFilter('venue_id',$venueId)
                    ->addFieldToFilter('supplier_id',$supplierId)
                    ->getFirstItem();
        return $supplierWatch;
    }
}
