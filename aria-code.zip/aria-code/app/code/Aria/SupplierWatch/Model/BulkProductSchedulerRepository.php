<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Model;

use Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterfaceFactory;
use Aria\SupplierWatch\Api\Data\BulkProductSchedulerSearchResultsInterfaceFactory;
use Aria\SupplierWatch\Api\BulkProductSchedulerRepositoryInterface;
use Aria\SupplierWatch\Model\ResourceModel\BulkProductScheduler as ResourceBulkProductScheduler;
use Aria\SupplierWatch\Model\ResourceModel\BulkProductScheduler\CollectionFactory as BulkProductSchedulerCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;

class BulkProductSchedulerRepository implements BulkProductSchedulerRepositoryInterface
{

    protected $resource;

    protected $extensibleDataObjectConverter;
    protected $searchResultsFactory;

    protected $dataBulkProductSchedulerFactory;

    protected $bulkProductSchedulerCollectionFactory;

    private $storeManager;

    protected $dataObjectHelper;

    protected $dataObjectProcessor;

    protected $bulkProductSchedulerFactory;

    protected $extensionAttributesJoinProcessor;

    private $collectionProcessor;


    /**
     * @param ResourceBulkProductScheduler $resource
     * @param BulkProductSchedulerFactory $bulkProductSchedulerFactory
     * @param BulkProductSchedulerInterfaceFactory $dataBulkProductSchedulerFactory
     * @param BulkProductSchedulerCollectionFactory $bulkProductSchedulerCollectionFactory
     * @param BulkProductSchedulerSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     */
    public function __construct(
        ResourceBulkProductScheduler $resource,
        BulkProductSchedulerFactory $bulkProductSchedulerFactory,
        BulkProductSchedulerInterfaceFactory $dataBulkProductSchedulerFactory,
        BulkProductSchedulerCollectionFactory $bulkProductSchedulerCollectionFactory,
        BulkProductSchedulerSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter
    ) {
        $this->resource = $resource;
        $this->bulkProductSchedulerFactory = $bulkProductSchedulerFactory;
        $this->bulkProductSchedulerCollectionFactory = $bulkProductSchedulerCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataBulkProductSchedulerFactory = $dataBulkProductSchedulerFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface $bulkProductScheduler
    ) {

        $bulkProductSchedulerData = $this->extensibleDataObjectConverter->toNestedArray(
            $bulkProductScheduler,
            [],
            \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface::class
        );

        $bulkProductSchedulerModel = $this->bulkProductSchedulerFactory->create()->setData($bulkProductSchedulerData);

        try {
            $this->resource->save($bulkProductSchedulerModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the bulkProductScheduler: %1',
                $exception->getMessage()
            ));
        }
        return $bulkProductSchedulerModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($Id)
    {
        $bulkProductScheduler = $this->bulkProductSchedulerFactory->create();
        $this->resource->load($bulkProductScheduler, $Id);
        if (!$bulkProductScheduler->getId()) {
            throw new NoSuchEntityException(__('bulkProductScheduler with id "%1" does not exist.', $Id));
        }
        return $bulkProductScheduler->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->bulkProductSchedulerCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface $bulkProductScheduler
    ) {
        try {
            $bulkProductSchedulerModel = $this->bulkProductSchedulerFactory->create();
            $this->resource->load($bulkProductSchedulerModel, $bulkProductScheduler->getId());
            $this->resource->delete($supplierWatchSchedulerModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the BulkProductScheduler: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($Id)
    {
        return $this->delete($this->get($Id));
    }
}
