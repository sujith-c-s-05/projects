<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Model\Data;

use Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface;

class SupplierWatchScheduler extends \Magento\Framework\Api\AbstractExtensibleObject implements SupplierWatchSchedulerInterface
{

    /**
     * Get scheduler_id
     * @return int|null
     */
    public function getSchedulerId()
    {
        return $this->_get(self::SCHEDULER_ID);
    }

    /**
     * Set scheduler_id
     * @param string $schedulerId
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     */
    public function setSchedulerId($schedulerId)
    {
        return $this->setData(self::SCHEDULER_ID, $schedulerId);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get sku
     * @return string|null
     */
    public function getSku()
    {
        return $this->_get(self::SKU);
    }

    /**
     * Set sku
     * @param string $sku
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     */
    public function setSku($sku)
    {
        return $this->setData(self::SKU, $sku);
    }
    /**
     * Get supplier_id
     * @return int|null
     */
    public function getSupplierId()
    {
        return $this->_get(self::SUPPLIER_ID);
    }

    /**
     * Set supplier_id
     * @param string $supplierId
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     */
    public function setSupplierId($supplierId)
    {
        return $this->setData(self::SUPPLIER_ID, $supplierId);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get status
     * @return string|null
     */
    public function getStatus()
    {
        return $this->_get(self::STATUS);
    }

    /**
     * Set status
     * @param string $status
     * @return \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }
}