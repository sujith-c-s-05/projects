<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Model\Data;

use Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface;

class BulkProductScheduler extends \Magento\Framework\Api\AbstractExtensibleObject implements BulkProductSchedulerInterface
{

    /**
     * Get id
     * @return int|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param string $Id
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface
     */
    public function setId($Id)
    {
        return $this->setData(self::ID, $Id);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplierWatch\Api\Data\BulkProductSchedulerExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplierWatch\Api\Data\BulkProductSchedulerExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get bulk_uuid
     * @return string|null
     */
    public function getBulkUuid()
    {
        return $this->_get(self::BULK_UUID);
    }

    /**
     * Set bulk_uuid
     * @param string $bulkUuid
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface
     */
    public function setBulkUuid($bulkUuid)
    {
        return $this->setData(self::BULK_UUID, $bulkUuid);
    }
    


    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get status
     * @return string|null
     */
    public function getStatus()
    {
        return $this->_get(self::STATUS);
    }

    /**
     * Set status
     * @param string $status
     * @return \Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }
}