<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Model;

use Aria\SupplierWatch\Api\Data\SupplierWatchInterface;
use Aria\SupplierWatch\Api\Data\SupplierWatchInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class SupplierWatch extends \Magento\Framework\Model\AbstractModel
{

    protected $supplierwatchDataFactory;

    protected $dataObjectHelper;

    protected $_eventPrefix = 'aria_supplier_watch';

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param SupplierWatchInterfaceFactory $supplierwatchDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\SupplierWatch\Model\ResourceModel\SupplierWatch $resource
     * @param \Aria\SupplierWatch\Model\ResourceModel\SupplierWatch\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        SupplierWatchInterfaceFactory $supplierwatchDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\SupplierWatch\Model\ResourceModel\SupplierWatch $resource,
        \Aria\SupplierWatch\Model\ResourceModel\SupplierWatch\Collection $resourceCollection,
        array $data = []
    ) {
        $this->supplierwatchDataFactory = $supplierwatchDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve supplierwatch model with supplierwatch data
     * @return SupplierWatchInterface
     */
    public function getDataModel()
    {
        $supplierwatchData = $this->getData();

        $supplierwatchDataObject = $this->supplierwatchDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $supplierwatchDataObject,
            $supplierwatchData,
            SupplierWatchInterface::class
        );

        return $supplierwatchDataObject;
    }
}

