<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Model;

use Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface;
use Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class SupplierWatchScheduler extends \Magento\Framework\Model\AbstractModel
{

    protected $supplierwatchSchedulerDataFactory;

    protected $dataObjectHelper;

    protected $_eventPrefix = 'aria_supplier_watch_scheduler';

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param SupplierWatchSchedulerInterfaceFactory $supplierwatchSchedulerDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\SupplierWatch\Model\ResourceModel\SupplierWatchScheduler $resource
     * @param \Aria\SupplierWatch\Model\ResourceModel\SupplierWatchScheduler\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        SupplierWatchSchedulerInterfaceFactory $supplierwatchSchedulerDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\SupplierWatch\Model\ResourceModel\SupplierWatchScheduler $resource,
        \Aria\SupplierWatch\Model\ResourceModel\SupplierWatchScheduler\Collection $resourceCollection,
        array $data = []
    ) {
        $this->supplierwatchSchedulerDataFactory = $supplierwatchSchedulerDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve supplierwatchscheduler model with supplierwatchscheduler data
     * @return SupplierWatchSchedulerInterface
     */
    public function getDataModel()
    {
        $supplierwatchSchedulerData = $this->getData();

        $supplierwatchSchedulerDataObject = $this->supplierwatchSchedulerDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $supplierwatchSchedulerDataObject,
            $supplierwatchSchedulerData,
            SupplierWatchSchedulerInterface::class
        );

        return $supplierwatchSchedulerDataObject;
    }
}

