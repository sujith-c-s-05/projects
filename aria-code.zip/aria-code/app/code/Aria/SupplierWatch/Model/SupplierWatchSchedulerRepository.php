<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Model;

use Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterfaceFactory;
use Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerSearchResultsInterfaceFactory;
use Aria\SupplierWatch\Api\SupplierWatchSchedulerRepositoryInterface;
use Aria\SupplierWatch\Model\ResourceModel\SupplierWatchScheduler as ResourceSupplierWatchScheduler;
use Aria\SupplierWatch\Model\ResourceModel\SupplierWatchScheduler\CollectionFactory as SupplierWatchSchedulerCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;

class SupplierWatchSchedulerRepository implements SupplierWatchSchedulerRepositoryInterface
{

    protected $resource;

    protected $extensibleDataObjectConverter;
    protected $searchResultsFactory;

    protected $dataSupplierWatchSchedulerFactory;

    protected $supplierWatchSchedulerCollectionFactory;

    private $storeManager;

    protected $dataObjectHelper;

    protected $dataObjectProcessor;

    protected $supplierWatchSchedulerFactory;

    protected $extensionAttributesJoinProcessor;

    private $collectionProcessor;


    /**
     * @param ResourceSupplierWatchScheduler $resource
     * @param SupplierWatchSchedulerFactory $supplierWatchSchedulerFactory
     * @param SupplierWatchSchedulerInterfaceFactory $dataSupplierWatchSchedulerFactory
     * @param SupplierWatchSchedulerCollectionFactory $supplierWatchSchedulerCollectionFactory
     * @param SupplierWatchSchedulerSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     */
    public function __construct(
        ResourceSupplierWatchScheduler $resource,
        SupplierWatchSchedulerFactory $supplierWatchSchedulerFactory,
        SupplierWatchSchedulerInterfaceFactory $dataSupplierWatchSchedulerFactory,
        SupplierWatchSchedulerCollectionFactory $supplierWatchSchedulerCollectionFactory,
        SupplierWatchSchedulerSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter
    ) {
        $this->resource = $resource;
        $this->supplierWatchSchedulerFactory = $supplierWatchSchedulerFactory;
        $this->supplierWatchSchedulerCollectionFactory = $supplierWatchSchedulerCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataSupplierWatchSchedulerFactory = $dataSupplierWatchSchedulerFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface $supplierWatchScheduler
    ) {

        $supplierWatchSchedulerData = $this->extensibleDataObjectConverter->toNestedArray(
            $supplierWatchScheduler,
            [],
            \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface::class
        );

        $supplierWatchSchedulerModel = $this->supplierWatchSchedulerFactory->create()->setData($supplierWatchSchedulerData);

        try {
            $this->resource->save($supplierWatchSchedulerModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the supplierWatch: %1',
                $exception->getMessage()
            ));
        }
        return $supplierWatchSchedulerModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($schedulerId)
    {
        $supplierWatchScheduler = $this->supplierWatchSchedulerFactory->create();
        $this->resource->load($supplierWatchScheduler, $schedulerId);
        if (!$supplierWatchScheduler->getSchedulerId()) {
            throw new NoSuchEntityException(__('supplierWatchScheduler with id "%1" does not exist.', $schedulerId));
        }
        return $supplierWatchScheduler->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->supplierWatchSchedulerCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface $supplierWatchScheduler
    ) {
        try {
            $supplierWatchSchedulerModel = $this->supplierWatchSchedulerFactory->create();
            $this->resource->load($supplierWatchSchedulerModel, $supplierWatchScheduler->getSchedulerId());
            $this->resource->delete($supplierWatchSchedulerModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the SupplierWatchScheduler: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($schedulerId)
    {
        return $this->delete($this->get($schedulerId));
    }
}
