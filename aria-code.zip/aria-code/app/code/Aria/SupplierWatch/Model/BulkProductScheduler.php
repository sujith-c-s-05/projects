<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplierWatch\Model;

use Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterface;
use Aria\SupplierWatch\Api\Data\BulkProductSchedulerInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class BulkProductScheduler extends \Magento\Framework\Model\AbstractModel
{

    protected $bulkProductSchedulerDataFactory;

    protected $dataObjectHelper;

    protected $_eventPrefix = 'aria_bulk_product_scheduler';

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param BulkProductSchedulerInterfaceFactory $bulkProductSchedulerDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\SupplierWatch\Model\ResourceModel\BulkProductScheduler $resource
     * @param \Aria\SupplierWatch\Model\ResourceModel\BulkProductScheduler\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        BulkProductSchedulerInterfaceFactory $bulkProductSchedulerDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\SupplierWatch\Model\ResourceModel\BulkProductScheduler $resource,
        \Aria\SupplierWatch\Model\ResourceModel\BulkProductScheduler\Collection $resourceCollection,
        array $data = []
    ) {
        $this->bulkProductSchedulerDataFactory = $bulkProductSchedulerDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve bulkProductscheduler model with bulkProductscheduler data
     * @return BulkProductSchedulerInterface
     */
    public function getDataModel()
    {
        $bulkProductSchedulerData = $this->getData();

        $bulkProductSchedulerDataObject = $this->bulkProductSchedulerDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $bulkProductSchedulerDataObject,
            $bulkProductSchedulerData,
            SupplierWatchSchedulerInterface::class
        );

        return $bulkProductSchedulerDataObject;
    }
}

