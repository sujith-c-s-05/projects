<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Controller\Adminhtml\SupplyCompany;

use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Customer\Model\AccountManagement;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany\CollectionFactory as SupplyCompanyCollectionFactory;
use Aria\AwsCognito\Helper\Data as HelperData;
use Magento\Eav\Api\AttributeOptionManagementInterface;
use Magento\Catalog\Api\Data\ProductAttributeInterface;
use Magento\Eav\Api\AttributeOptionUpdateInterface;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\Option\Collection;

class Save extends \Magento\Backend\App\Action
{

    protected $dataPersistor;

    public $customerFactory;

    public $customerRepository;

    public $customerAccountManagement;

    public $supplyCompanyCollectionFactory;

    /** @var  \Magento\Framework\DB\Adapter\AdapterInterface */
    protected $_conn;

    /** @var \Magento\Framework\App\ResourceConnection */
    protected $_resourceConnection;

     /**
     * @var AttributeOptionManagementInterface
     */
    protected $eavOptionManagement;

    /**
     * @var \Magento\Eav\Model\Config
     */
    protected $eavConfig;

    /**
     * @var \Magento\Eav\Model\ResourceModel\Entity\Attribute\Option\Collection
     */
    protected $_entityAttributeOptionCollection;

    /**
     * @var AttributeOptionUpdateInterface
     */
    protected $eavOptionUpdate;


    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     * @param AttributeOptionManagementInterface $eavOptionManagement
     * @param \Magento\Eav\Model\Config $eavConfig
     * @param \Magento\Eav\Model\ResourceModel\Entity\Attribute\Option\Collection $entityAttributeOptionCollection
     * @param AttributeOptionUpdateInterface $eavOptionUpdate
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        CustomerInterfaceFactory $customerFactory,
        CustomerRepositoryInterface $customerRepository,
        \Magento\Customer\Api\AccountManagementInterface $customerAccountManagement,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        StateInterface $state,
        TransportBuilder $transportBuilder,
        SupplyCompanyCollectionFactory $supplyCompanyCollectionFactory,
        HelperData $helper,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        AttributeOptionManagementInterface $eavOptionManagement,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Eav\Model\ResourceModel\Entity\Attribute\Option\Collection $entityAttributeOptionCollection,
        AttributeOptionUpdateInterface $eavOptionUpdate,
        \Aria\DeliverySlot\Api\DeliverySlotsRepositoryInterfaceFactory $deliverySlotsRepositoryInterfaceFactory,
        \Aria\DeliverySlot\Api\Data\DeliverySlotsInterfaceFactory $deliverySlotFactory

    ) {
        $this->dataPersistor = $dataPersistor;
        $this->customerFactory = $customerFactory;
        $this->customerRepository = $customerRepository;
        $this->customerAccountManagement = $customerAccountManagement;
        $this->storeManager = $storeManager;
        $this->supplyCompanyCollectionFactory = $supplyCompanyCollectionFactory;
        $this->scopeConfig = $scopeConfig;
        $this->inlineTranslation = $state;
        $this->transportBuilder = $transportBuilder;
        $this->helper = $helper;
        parent::__construct($context);
        $this->_resourceConnection = $resourceConnection;
        $this->_conn = $resourceConnection->getConnection();
        $this->eavOptionManagement = $eavOptionManagement;
        $this->eavConfig = $eavConfig;
        $this->_entityAttributeOptionCollection = $entityAttributeOptionCollection;
        $this->eavOptionUpdate = $eavOptionUpdate;
        $this->deliverySlotsRepositoryInterfaceFactory = $deliverySlotsRepositoryInterfaceFactory;
        $this->deliverySlotFactory = $deliverySlotFactory;
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $this->_conn->beginTransaction();
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        if ($data) {

            if (isset($data['supplycompany_id'])) {
                $id = $data['supplycompany_id'];;
            } else {
                $id = null;
            }
            $isExist = $this->checkSupplyCompanyNameExist($data['company_name'], $id);

            if ($isExist) {

                $this->messageManager->addErrorMessage('This Supply Company Name already Exist');
                $this->dataPersistor->set('aria_supplycompanyaccount_supplycompany', $data);
                return $resultRedirect->setPath('*/*/edit', ['supplycompany_id' => $this->getRequest()->getParam('supplycompany_id')]);
            }
            $id = $this->getRequest()->getParam('supplycompany_id');
            $model = $this->_objectManager->create(\Aria\SupplyCompanyAccount\Model\SupplyCompany::class)->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addErrorMessage(__('This Supply Company no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }

            $customer = $this->customerFactory->create();
            $customer->setWebsiteId($data['website_id']);
            $customer->setCustomAttribute('job_title', $data['job_title']);
            $customer->setCustomAttribute('mobile_number', $data['aria_username']);
            $customer->setPrefix($data['prefix']);
            $customer->setFirstname($data['first_name']);
            $customer->setMiddlename($data['middle_name']);
            $customer->setLastname($data['last_name']);
            $customer->setSuffix($data['suffix']);
            $customer->setGender($data['gender']);
            $customer->setGroupId(5);

            try {
                /** @var \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository*/
                if (!$id) {
                    $isCustomerExistInCognito = $this->helper->checkUserExist($data['aria_username']);
                    $isMagentoCustomerExist = $this->helper->checkMagentoCustomerExist($data['aria_username']);
                    $isPasswordReset = 1;
                    if (!$isCustomerExistInCognito) {
                        $isPasswordReset = 0;
                        $password = $this->helper->generateRandomPassword();
                        $this->registerInCognito($data['email'], $data['aria_username'], $data['first_name'], $data['last_name'], $password);
                    }
                    $customer->setEmail($data['email']);
                    $customer->setCustomAttribute('aria_username', $data['aria_username']);
                    $customer->setCustomAttribute('mobile_number', $data['aria_username']);
                    $customer->setCustomAttribute('is_password_set', $isPasswordReset);
                    $customer = $this->customerRepository->save($customer);
                    $customerId = $customer->getId();
                    $data['company_admin'] = $customerId;
                }
                $model->setData($data);
                $model->save();
                $this->updateCustomer($model,$data);
                $dcUser=$this->saveDCUser($customer,$model);
                $this->saveSupplierAttributeValue($model);
                $this->_conn->commit();
                if (!$id) {
                    $passwordText = "";

                    if (isset($password)) {
                        $passwordText = "Your password is " . $password;
                    }
                    $this->sendEmail($customer, $data['company_name'], $passwordText);
                    $this->addDeliverySlot($model->getId());

                }
                
                $this->messageManager->addSuccessMessage(__('You saved the SupplyCompany.'));
                $this->dataPersistor->clear('aria_supplycompanyaccount_supplycompany');

                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['supplycompany_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
                
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->_conn->rollBack();
                $this->messageManager->addErrorMessage($e->getMessage());
            }

            $this->dataPersistor->set('aria_supplycompanyaccount_supplycompany', $data);
            return $resultRedirect->setPath('*/*/edit', ['supplycompany_id' => $this->getRequest()->getParam('supplycompany_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
    /**
     * To check wether Supply Company Name already exist
     *
     * @return Bool
     */
    public function checkSupplyCompanyNameExist($name, $id = null)
    {
        $collection = $this->supplyCompanyCollectionFactory->create();

        $collection->addFieldToFilter('company_name', $name);

        if ($id != null) {
            $collection->addFieldToFilter('supplycompany_id', array('neq' => $id));
        }

        $collection->addFieldToFilter('is_delete', array('eq' => 0));

        if (count($collection) >= 1) {
            return true;
        }

        return false;
    }
    /**
     * {@inheritdoc}
     */
    public function addDeliverySlot($supplyCompanyId)
    {
        $deliverySlotData = $this->deliverySlotFactory->create();
        $slots = array("MON","TUE","WED","THU","FRI","SAT");
        $deliverySlotData->setSlots($slots);
        $skipDates = [];
        $deliverySlotData->setSkipDates($skipDates);
        $deliverySlotData->setCompanyId($supplyCompanyId);
        $deliverySlotData->setIsActive(1);
        $deliverySlot = $this->deliverySlotsRepositoryInterfaceFactory->create();
        $deliverySlot->save($deliverySlotData);
    }

    /**
     * To register admin user in cognito
     * @param $email
     * @param $phoneNumber
     * @param $firstName
     * @param $lastName 
     * @param $password
     * @return bool
     */
    public function registerInCognito($email, $phoneNumber, $firstName, $lastName, $password)
    {
        $attributes = [];
        $attributes['email'] = $email;
        $attributes['phone_number'] = $phoneNumber;
        $attributes['given_name'] = $firstName;
        $attributes['family_name'] = $lastName;

        return $this->helper->register($firstName, $password, $attributes);
    }

    public function sendEmail($customer, $companyName, $passwordText)
    {   
        $loginUrl = $this->helper->getFrontEndLoginUrl();
        
        if($passwordText=="")
        {
            $loginUrlText = '<a href="'.$loginUrl.'">click here</a> to verify your email address and use your existing password in ARIA to continue with the login.';
        }
        else
        {
            $loginUrlText = 'To verify your signup, <a href="'.$loginUrl.'">click here</a> to login and assign a password to your account.';
        }
        //Send Supply Company active mail to the admin
        $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId());
        $templateVars = array(
            'customerName' => $customer->getFirstName(),
            'groupName' => $companyName,
            'passwordText' => $passwordText,
            'loginText' => $loginUrlText

        );
        $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $sender_name  = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
        $from = ['email' => $email, 'name' => $sender_name];
        $this->inlineTranslation->suspend();
        $transport = $this->transportBuilder->setTemplateIdentifier('aria_company_account_register_template', ScopeInterface::SCOPE_STORE)
            ->setTemplateOptions($templateOptions)
            ->setTemplateVars($templateVars)
            ->setFrom($from)
            ->addTo($customer->getEmail())
            ->getTransport();
        $transport->sendMessage();
        $this->inlineTranslation->resume();

        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function saveDCUser($customer,$model) 
    {
        $customerId=$model->getCompanyAdmin();
        $dcUsermodel = $this->_objectManager->create(\Aria\SupplyCompanyAccount\Model\DCUser::class);
        $dcUser = $dcUsermodel->load($customerId,'dc_user_id');
        if($dcUser->getId()){
            $dcUsermodel->setDcUserId($customerId)
                        ->setFirstName($customer->getFirstname())
                        ->setLastName($customer->getLastname())
                        ->setId($dcUser->getId())
                        ->setScId($model->getId()??0);
        }
        else{
            $dcUsermodel->setDcUserId($customerId)
                        ->setFirstName($customer->getFirstname())
                        ->setLastName($customer->getLastname())
                        ->setDcUserEmail($customer->getEmail())
                        ->setCreatedAt($customer->getCreatedAt())
                        ->setUpdatedAt($customer->getUpdatedAt())
                        ->setIsActive(1)
                        ->setIsDelete(0)
                        ->setIsAdmin(1)
                        ->setScId($model->getId()??0);
        }
        
        $dcUsermodel->save();
    }
    public function updateCustomer($model,$data)
    {
        $customer = $this->customerRepository->getById($model->getData('company_admin'));
        $customer->setWebsiteId($data['website_id']);
        $customer->setCustomAttribute('job_title', $data['job_title']);
        $customer->setCustomAttribute('mobile_number', $data['aria_username']);
        $customer->setPrefix($data['prefix']);
        $customer->setFirstname($data['first_name']);
        $customer->setMiddlename($data['middle_name']);
        $customer->setLastname($data['last_name']);
        $customer->setSuffix($data['suffix']);
        $customer->setGender($data['gender']);
        $this->customerRepository->save($customer);
        return true;      
    }

    /**
     * {@inheritdoc}
     */
    public function saveSupplierAttributeValue($model)
    {
        $attributeCode='supply_company_name';
        $supplyCompanyId=$model->getSupplycompanyId();

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $option = $objectManager->create('Magento\Eav\Api\Data\AttributeOptionInterface');

        $attribute = $this->eavConfig->getAttribute('catalog_product', 'supply_company_name');
        $attributeId=$attribute->getAttributeId();
        $attributeCollection=$this->_entityAttributeOptionCollection
                                    ->setAttributeFilter($attributeId)
                                    ->load();
        $attributeCollection->addFieldToFilter('sort_order', $supplyCompanyId)->getFirstItem();

        $attributeData=$attributeCollection->getData();

        if(!is_null($attributeData) && count($attributeData) >=1){
            
            $optionId=(int)$attributeData[0]['option_id'];
            $option->setLabel($model->getCompanyName());
            $option->setSortOrder($supplyCompanyId);
            $this->eavOptionUpdate->update(
                ProductAttributeInterface::ENTITY_TYPE_CODE,
                $attributeCode,
                $optionId,
                $option
            );
        }
        else{
            $option->setLabel($model->getCompanyName());
            $option->setSortOrder($supplyCompanyId);
            $this->eavOptionManagement->add(
                ProductAttributeInterface::ENTITY_TYPE_CODE,
                $attributeCode,
                $option
            );
        }
    }
}
