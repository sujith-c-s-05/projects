<?php
/**
 * Copyright ©  All rights reserved.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Controller\Adminhtml\SupplyCompany;

class Delete extends \Aria\SupplyCompanyAccount\Controller\Adminhtml\SupplyCompany
{

    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        // check if we know what should be deleted
        $id = $this->getRequest()->getParam('supplycompany_id');
        if ($id) {
            try {
                // init model and delete
                $model = $this->_objectManager->create(\Aria\SupplyCompanyAccount\Model\SupplyCompany::class);
                $model->load($id);
                $model->setIsDelete(1);
                $model->save();
                // display success message
                $this->messageManager->addSuccessMessage(__('You deleted the Supply Company.'));
                // go to grid
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                // display error message
                $this->messageManager->addErrorMessage($e->getMessage());
                // go back to edit form
                return $resultRedirect->setPath('*/*/edit', ['supplycompany_id' => $id]);
            }
        }
        // display error message
        $this->messageManager->addErrorMessage(__('We can\'t find a Supply Company to delete.'));
        // go to grid
        return $resultRedirect->setPath('*/*/');
    }
}

