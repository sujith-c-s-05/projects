require([
    'jquery',
    'mage/url'
], function ($,url) {
    'use strict';

    $(document).ready(function(){

        document.addEventListener("click", function (e) {
            $(".result" ).remove();
        });

        $(document).on("click",".list", function() {

            var listVal = $(this).html();

            var listArr = listVal.split(',');

            $("input[name='email']").val(listArr[2]).change();
            $("input[name='first_name']").val(listArr[0]).change();
            $("input[name='last_name']").val(listArr[1]).change();
            $("input[name='aria_username']").val(listArr[3]).change();
            console.log(listArr);
            $(".result" ).remove();


        });
        
        $(document).on("keyup",".aria_username", function() {
            $(".result" ).remove();
            var userName = $(".aria_username").val();
            var customUrl = window.listUserUrl;
            if(userName.length < 5)
            {
                return false;
            }
    	    $.ajax({
                url: customUrl,
                type: 'POST',
                dataType: 'json',
                data: {
                    id: userName
                },
                success: function (response) {
                    $(".result" ).remove();
                    var html = "<div id='result' class ='result' style='position: absolute;background-color: #f5f2f2;z-index: 100;'> </div>";
                    $( html ).insertAfter(".aria_username");
                    $('#result').html(response.success);
                    console.log(response.success); 
                 }
            });
          });
    });

});