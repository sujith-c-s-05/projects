<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface DCUserroleRepositoryInterface
{

    /**
     * Save DC Userrole
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface $dcUserrole
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface $dcUserrole
    );


    /**
     * Retrieve DC Userrole matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    
    /**
     * Delete DC Userrole by ID
     * @param int $Id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($Id);

     /**
     * Retrieve Dc User Role
     * @param int $Id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($Id);

    /**
     * Retrieve Dc user role name
     * @param string $roleName
     * @param int $supplierid
     * @param int|null $id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function isRoleNameExists($roleName,$supplierid,$id=null);

}

