<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface SupplyCompanyRepositoryInterface
{

    /**
     * Save Supply Company
     * @param \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface $supplyCompany
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface $supplyCompany
    );

    /**
     * Retrieve SupplyCompany
     * @param int $supplyCompanyId
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($supplyCompanyId);

    /**
     * Retrieve Company matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanySearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete SupplyCompany
     * @param \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface $supplyCompany
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface $supplyCompany
    );

    /**
     * Delete SupplyCompany by ID
     * @param string $supplycompanyId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($supplycompanyId);

    /**
     * @param int $supplyCompanyId
     * @param bool $deliveryCost
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function setDeliveryCost($supplyCompanyId,$deliveryCost);
    
}

