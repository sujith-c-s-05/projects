<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api;


interface VacationRepositoryInterface
{

    /**
     * Save Vacation
     * @param \Aria\SupplyCompanyAccount\Api\Data\VacationInterface $vacation
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\VacationInterface $vacation
    );

    /**
     * Retrieve Vacation
     * @param string $vacationId
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($vacationId);

    /**
     * Delete Vacation
     * @param \Aria\SupplyCompanyAccount\Api\Data\VacationInterface $vacation
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Aria\SupplyCompanyAccount\Api\Data\VacationInterface $vacation
    );

    /**
     * Delete Vacation by ID
     * @param string $vacationId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($vacationId);

     /**
     * Retrieve Vacation
     * @param string $dcId
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getDc($dcId);
}
