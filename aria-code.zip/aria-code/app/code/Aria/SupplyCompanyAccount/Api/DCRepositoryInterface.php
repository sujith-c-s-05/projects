<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface DCRepositoryInterface
{

    /**
     * Save DC
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCInterface $dC
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\DCInterface $dC
    );

    /**
     * Retrieve DC
     * @param int $dcId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($dcId);

    /**
     * Retrieve DC matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    
    /**
     * Delete DC by ID
     * @param int $dcId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($dcId);

    /**
     * @param int $dcId
     * @param bool $isActive
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function setStatus($dcId,$isActive);

     /**
     * Retrieve Dc name
     * @param string $name
     * @param int $supplierid
     * @param int|null $dcId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function isDCNameExists($name,$supplierid,$dcId=null);

}

