<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api\Data;

interface SupplyCompanySearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get supply Company list.
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface[]
     */
    public function getItems();

    /**
     * Set Id list.
     * @param \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

