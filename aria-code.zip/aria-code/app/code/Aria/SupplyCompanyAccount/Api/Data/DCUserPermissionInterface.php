<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api\Data;

interface DCUserPermissionInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const ID = 'id';
    const PERMISSION_NAME = 'permission_name';
    const DESCRIPTION = 'description';
    const PARENT_ID = 'parent_id';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const IS_GRANTED = 'is_granted';
    const ROLE_ID = 'role_id';
    const PERMISSION_ID = 'permission_id';

    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param int $Id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     */
    public function setId($Id);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionExtensionInterface $extensionAttributes
    );

    /**
     * Get permission_name
     * @return string|null
     */
    public function getPermissionName();

    /**
     * Set permission_name
     * @param string $permissionName
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     */
    public function setPermissionName($permissionName);

    /**
     * Get description
     * @return string|null
     */
    public function getDescription();

    /**
     * Set description
     * @param string $description
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     */
    public function setDescription($description);

    /**
     * Get parent_id
     * @return int|null
     */
    public function getParentId();

    /**
     * Set parent_id
     * @param int $parentId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     */
    public function setParentId($parentId);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     */
    public function setUpdatedBy($updatedBy);


    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     */
    public function setIsActive($isActive);

      /**
     * Get is_granted
     * @return bool|null
     */
    public function getIsGranted();

    /**
     * Set is_granted
     * @param bool $isGranted
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     */
    public function setIsGranted($isGranted);

    /**
     * Get role_id
     * @return bool|null
     */
    public function getRoleId();


    /**
     * Set role_id
     * @param bool $roleId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     */
    public function setRoleId($roleId);

    /**
     * Get permission_id
     * @return bool|null
     */
    public function getPermissionId();

    /**
     * Set permission_id
     * @param bool $permissionId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     */
    public function setPermissionId($permissionId);

    
}