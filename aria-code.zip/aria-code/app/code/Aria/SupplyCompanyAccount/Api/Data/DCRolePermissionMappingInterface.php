<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api\Data;

interface DCRolePermissionMappingInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const ID = 'id';
    const ROLE_ID = 'role_id';
    const PERMISSION_ID = 'permission_id';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const IS_GRANTED = 'is_granted';
    const DESCRIPTION = 'description';
    



    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param int $Id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     */
    public function setId($Id);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingExtensionInterface $extensionAttributes
    );
    
    /**
     * Get role_id
     * @return int|null
     */
    public function getRoleId();

    /**
     * Set role_id
     * @param int $roleId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     */
    public function setRoleId($roleId);

    /**
     * Get permission_id
     * @return int|null
     */
    public function getPermissionId();

    /**
     * Set permission_id
     * @param int $permissionId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     */
    public function setPermissionId($permissionId);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     */
    public function setUpdatedBy($updatedBy);


    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     */
    public function setIsActive($isActive);
    
    /**
     * Get is_granted
     * @return bool|null
     */
    public function getIsGranted();

    /**
     * Set is_granted
     * @param bool $isGranted
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     */
    public function setIsGranted($isGranted);
     
       /**
     * Get permission name
     * @return string|null
     */
    public function getPermissionName();

    /**
     * Set permission name
     * @param string $permissionName
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     */
    public function setPermissionName($permissionName);

    /**
     * Get parent_id
     * @return int|null
     */
    public function getParentId();

    /**
     * Set parent_id
     * @param int $parentId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     */
    public function setParentId($parentId);

    /**
     * Get description
     * @return string|null
     */
    public function getDescription();

    /**
     * Set description
     * @param string $description
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     */
    public function setDescription($description);

}