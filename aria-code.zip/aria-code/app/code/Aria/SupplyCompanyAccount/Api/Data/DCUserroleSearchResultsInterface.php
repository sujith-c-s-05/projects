<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api\Data;

interface DCUserroleSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get DC User role list.
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface[]
     */
    public function getItems();

    /**
     * Set supply_id list.
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

