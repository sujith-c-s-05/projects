<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api\Data;

interface DCInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const STORE_ID = 'store_id';
    const CREATED_AT = 'created_at';
    const SUPPLY_ID = 'supply_id';
    const LONGITUDE = 'longitude';
    const LATITUDE = 'latitude';
    const UPDATED_AT = 'updated_at';
    const PHONE = 'phone';
    const DESCRIPTION = 'description';
    const EMAIL = 'email';
    const NAME = 'name';
    const DC_ID = 'dc_id';
    const IS_ACTIVE = 'is_active';
    const ADDRESS = 'address';
    const ZIP_CODE = 'zip_code';
    const IS_DELETE = 'is_delete';
    const CONTACT_NAME = 'contact_name';
    const CITY = 'city';
    const STATE = 'state';
    const COUNTRY = 'country';
    const CONTACT_PERSON_PHONE = 'contact_person_phone';
    const DELIVERY_LOCATION = 'delivery_location';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const DC_USER_ID = 'dc_user_id';

    /**
     * Get dc_id
     * @return int|null
     */
    public function getDcId();

    /**
     * Set dc_id
     * @param int $dcId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setDcId($dcId);

    /**
     * Get supply_id
     * @return int|null
     */
    public function getSupplyId();

    /**
     * Set supply_id
     * @param int $supplyId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setSupplyId($supplyId);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplyCompanyAccount\Api\Data\DCExtensionInterface $extensionAttributes
    );

    /**
     * Get name
     * @return string|null
     */
    public function getName();

    /**
     * Set name
     * @param string $name
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setName($name);

    /**
     * Get description
     * @return string|null
     */
    public function getDescription();

    /**
     * Set description
     * @param string $description
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setDescription($description);

    /**
     * Get address
     * @return string|null
     */
    public function getAddress();

    /**
     * Set address
     * @param string $address
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setAddress($address);

    /**
     * Get email
     * @return string|null
     */
    public function getEmail();

    /**
     * Set email
     * @param string $email
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setEmail($email);

    /**
     * Get phone
     * @return string|null
     */
    public function getPhone();

    /**
     * Set phone
     * @param string $phone
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setPhone($phone);

    /**
     * Get zip_code
     * @return string|null
     */
    public function getZipCode();

    /**
     * Set zip_code
     * @param string $zipCode
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setZipCode($zipCode);

    /**
     * Get latitude
     * @return float|null
     */
    public function getLatitude();

    /**
     * Set latitude
     * @param float $latitude
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setLatitude($latitude);

    /**
     * Get longitude
     * @return float|null
     */
    public function getLongitude();

    /**
     * Set longitude
     * @param floar $longitude
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setLongitude($longitude);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setUpdatedBy($updatedBy);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setIsActive($isActive);

    /**
     * Get store_id
     * @return int|null
     */
    public function getStoreId();

    /**
     * Set store_id
     * @param int $storeId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setStoreId($storeId);

     /**
     * Get is_delete
     * @return bool|null
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setIsDelete($isDelete);

    /**
     * Get contact_name
     * @return string|null
     */
    public function getContactName();

    /**
     * Set contact_name
     * @param string $contact_name
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setContactName($contact_name);

    /**
     * Get city
     * @return string|null
     */
    public function getCity();

    /**
     * Set city
     * @param string $city
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setCity($city);

    /**
     * Get state
     * @return string|null
     */
    public function getState();

    /**
     * Set state
     * @param string $state
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setState($state);

    /**
     * Get country
     * @return string|null
     */
    public function getCountry();

    /**
     * Set country
     * @param string $country
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setCountry($country);

    /**
     * Get contact_person_phone
     * @return string|null
     */
    public function getContactPersonPhone();

    /**
     * Set contact_person_phone
     * @param string $contact_person_phone
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setContactPersonPhone($contact_person_phone);

     /**
     * Get delivery_location
     * @return string|null
     */
    public function getDeliveryLocation();

    /**
     * Set delivery_location
     * @param string $delivery_location
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setDeliveryLocation($delivery_location);

    /**
    * Get dc vacation
    *
    * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface|null
    */
    public function getVacation();

    /**
    * Set dc vacation
    *
    * @param \Aria\SupplyCompanyAccount\Api\Data\VacationInterface $vacation
    * @return $this
    */
    public function setVacation(\Aria\SupplyCompanyAccount\Api\Data\VacationInterface $vacation = null);

    /**
     * Get dc_user_id
     * @return int|null
     */
    public function getDcUserId();

    /**
     * Set dc_user_id
     * @param int $dcUserId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setDcUserId($dcUserId);
}