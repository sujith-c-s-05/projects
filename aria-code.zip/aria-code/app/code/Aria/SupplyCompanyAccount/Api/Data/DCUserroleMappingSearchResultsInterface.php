<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api\Data;

interface DCUserroleMappingSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get DC User role Mapping list.
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface[]
     */
    public function getItems();

    /**
     * Set supply_id list.
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

