<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api\Data;

interface DCUserSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get DC User list.
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface[]
     */
    public function getItems();

    /**
     * Set supply_id list.
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

