<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api\Data;

interface DCUserroleMappingInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const ID = 'id';
    const DC_USER_ID ='dc_user_id';
    const DC_ID = 'dc_id';
    const ROLE_ID = 'role_id';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const IS_DELETE = 'is_delete';
    /**
     * Get id
     * @return string|null
     */
    public function getId();

    /**
     * Set id
     * @param string $Id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     */
    public function setId($Id);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingExtensionInterface $extensionAttributes
    );

     /**
     * Get dc_id
     * @return int|null
     */
    public function getDcId();

    /**
     * Set dc_id
     * @param int $dcId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     */
    public function setDcId($dcId);

    /**
     * Get dc_user_id
     * @return int|null
     */
    public function getDcUserId();

    /**
     * Set dc_user_id
     * @param int $dcUserId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     */
    public function setDcUserId($dcUserId);
    
     /**
     * Get role_id
     * @return int|null
     */
    public function getRoleId();

    /**
     * Set role_id
     * @param int $roleId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     */
    public function setRoleId($roleId); 


    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     */
    public function setUpdatedBy($updatedBy);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     */
    public function setUpdatedAt($updatedAt);
     /**
     * Get is_active
     * @return bool|true
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     */
    public function setIsActive($isActive);

    /**
     * Get is_delete
     * @return bool|true
     */
    public function getIsDelete();

    /** 
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     */
    public function setIsDelete($isDelete);

     /**
     * Get dc name
     * @return string|null
     */
    public function getDcName();

    /**
     * Set dc name
     * @param string $dcName
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     */
    public function setDcName($dcName);

    /**
     * Get role name
     * @return string|null
     */
    public function getRoleName();

    /**
     * Set role name
     * @param string $roleName
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     */
    public function setRoleName($roleName);
 

}