<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api\Data;

interface DCUserInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const ID = 'id';
    const DC_USER_ID = 'dc_user_id';
    const FIRST_NAME = 'first_name';
    const LAST_NAME = 'last_name';
    const DC_USER_EMAIL = 'dc_user_email';
    const PHONE = 'phone';
    const GENDER ='gender';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const IS_DELETE = 'is_delete';
    const SC_ID = 'sc_id';
    const IS_ADMIN = 'is_admin';

    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param int $Id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setId($Id);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserExtensionInterface $extensionAttributes
    );

     /**
    * Get dc user role info
    *
    * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface[]|null
    */
    public function getDcUserroleMapping();

    /**
    * Set dc user role info
    *
    * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface[] $dcUserroleMapping
    * @return $this
    */
    public function setDcUserroleMapping(array $dcUserroleMapping = null);

    /**
     * Get dc_user_id
     * @return int|null
     */
    public function getDcUserId();

    /**
     * Set dc_user_id
     * @param int $dcUserId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setDcUserId($dcUserId);
    /**
     * Get first_name
     * @return string|null
     */
    public function getFirstName();

    /**
     * Set first_name
     * @param string $firstName
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setFirstName($firstName);


    /**
     * Get last_name
     * @return string|null
     */
    public function getLastName();

    /**
     * Set last_name
     * @param string $lastName
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setLastName($lastName);

    /**
     * Get dc_user_email
     * @return string|null
     */
    public function getDcUserEmail();

    /**
     * Set dc_user_email
     * @param string $dcUserEmail
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setDcUserEmail($dcUserEmail);

    /**
     * Get phone
     * @return string|null
     */
    public function getPhone();

    /**
     * Set phone
     * @param string $phone
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setPhone($phone);
    
    /**
     * Get gender
     * @return string|null
     */
    public function getGender();

    /**
     * Set gender
     * @param string $gender
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setGender($gender);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedby
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setUpdatedBy($updatedBy);


    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setIsActive($isActive);

     /**
     * Get is_delete
     * @return bool|null
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setIsDelete($isDelete);

    /**
     * Get sc_id
     * @return int|null
     */
    public function getScId();

    /**
     * Set sc_id
     * @param int $scId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setScId($scId);

    /**
     * Get is_admin
     * @return int|null
     */
    public function getIsAdmin();

    /**
     * Set is_admin
     * @param int $isAdmin
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setIsAdmin($isAdmin);

}