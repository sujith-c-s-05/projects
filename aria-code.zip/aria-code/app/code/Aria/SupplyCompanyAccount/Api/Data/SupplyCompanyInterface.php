<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api\Data;

interface SupplyCompanyInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const SUPPLYCOMPANY_ID = 'supplycompany_id';
    const COMPANY_LEGAL_NAME = 'company_legal_name';
    const SALES_REP = 'sales_rep';
    const RESELLER_ID = 'reseller_id';
    const COMPANY_NAME = 'company_name';
    const CREATED_AT = 'created_at';
    const STATUS = 'status';
    const VAT_ID = 'vat_id';
    const CREATED_BY = 'created_by';
    const UPDATED_AT = 'updated_at';
    const WEBSITE_ID = 'website_id';
    const IS_ACTIVE = 'is_active';
    const JOB_TITLE = 'job_title';
    const UPDATED_BY = 'updated_by';
    const PHONE_NO = 'phone_no';
    const COMPANY_EMAIL = 'company_email';
    const COMMENT = 'comment';
    const STREET_ADDRESS = 'street_address';
    const COUNTRY = 'country';
    const STATE = 'state';
    const CITY = 'city';
    const ZIP_CODE = 'zip_code';
    const COMPANY_ADMIN='company_admin';
    const MOV ='mov';
    const RETURN_TIME_PERIOD = 'return_time_period';
    const WEBSITE_URL='website_url';
    const COUNTDOWN_TIMER='countdown_timer';
    const DELIVERY_COST='delivery_cost';
    /**
     * Get supplycompany_id
     * @return string|null
     */
    public function getSupplycompanyId();

    /**
     * Set supplycompany_id
     * @param string $supplycompanyId
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setSupplycompanyId($supplycompanyId);

     /**
     * Get company_name
     * @return string|null
     */

    public function getCompanyName();

    /**
     * Set company_name
     * @param string $companyName
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCompanyName($companyName);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyExtensionInterface $extensionAttributes
    );

    /**
     * Get website_id
     * @return string|null
     */
    public function getWebsiteId();

    /**
     * Set website_id
     * @param string $websiteId
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setWebsiteId($websiteId);

    /**
     * Get website_url
     * @return string|null
     */
    public function getWebsiteUrl();

    /**
     * Set website_url
     * @param string $websiteUrl
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setWebsiteUrl($websiteUrl);

    /**
     * Get status
     * @return string|null
     */
    public function getStatus();

    /**
     * Set status
     * @param string $status
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setStatus($status);

    /**
     * Get company_email
     * @return string|null
     */
    public function getCompanyEmail();

    /**
     * Set company_email
     * @param string $companyEmail
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCompanyEmail($companyEmail);

    /**
     * Get sales_rep
     * @return string|null
     */
    public function getSalesRep();

    /**
     * Set sales_rep
     * @param string $salesRep
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setSalesRep($salesRep);

    /**
     * Get company_legal_name
     * @return string|null
     */
    public function getCompanyLegalName();

    /**
     * Set company_legal_name
     * @param string $companyLegalName
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCompanyLegalName($companyLegalName);

    /**
     * Get vat_id
     * @return string|null
     */
    public function getVatId();

    /**
     * Set vat_id
     * @param string $vatId
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setVatId($vatId);

    /**
     * Get reseller_id
     * @return string|null
     */
    public function getResellerId();

    /**
     * Set reseller_id
     * @param string $resellerId
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setResellerId($resellerId);

    /**
     * Get comment
     * @return string|null
     */
    public function getComment();

    /**
     * Set comment
     * @param string $comment
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setComment($comment);

    /**
     * Get street_address
     * @return string|null
     */
    public function getStreetAddress();

    /**
     * Set street_address
     * @param string $streetAddress
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setStreetAddress($streetAddress);

    /**
     * Get city
     * @return string|null
     */
    public function getCity();

    /**
     * Set city
     * @param string $city
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCity($city);

    /**
     * Get country
     * @return string|null
     */
    public function getCountry();

    /**
     * Set country
     * @param string $country
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCountry($country);

     /**
     * Get state
     * @return string|null
     */
    public function getState();

    /**
     * Set state
     * @param string $state
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setState($state);

    /**
     * Get zip_code
     * @return string|null
     */
    public function getZipCode();

    /**
     * Set zip_code
     * @param string $zipCode
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setZipCode($zipCode);

    /**
     * Get phone_no
     * @return string|null
     */
    public function getPhoneNo();

    /**
     * Set phone_no
     * @param string $phoneNo
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setPhoneNo($phoneNo);

    /**
     * Get job_title
     * @return string|null
     */
    public function getJobTitle();

    /**
     * Set job_title
     * @param string $jobTitle
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setJobTitle($jobTitle);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setUpdatedBy($updatedBy);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get mov
     * @return int|null
     */
    public function getMov();

    /**
     * Set mov
     * @param int $mov
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setMov($mov);

     /**
     * Get return_time_period
     * @return int|null
     */
    public function getReturnTimePeriod();

    /**
     * Set return_time_period
     * @param int $returnTimePeriod
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setReturnTimePeriod($returnTimePeriod);


    /**
     * Get is_active
     * @return string|null
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param string $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setIsActive($isActive);
    
    /**
     * Get company admin
     *
     * @return int
     */
    public function getCompanyAdmin();

    /**
     * set company admin
     *
     * @param int $companyAdmin
     * @return int
     */
    public function setCompanyAdmin($companyAdmin);
    
     /**
     * Get countdown_timer
     * @return string|null
     */
    public function getCountdownTimer();

    /**
     * Set countdown_timer
     * @param string $countdownTimer
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCountdownTimer($countdownTimer);

    /**
     * Get delivery_cost
     * @return bool|null
     */
    public function getDeliveryCost();

    /**
     * Set delivery_cost
     * @param bool $deliveryCost
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setDeliveryCost($deliveryCost);
}
