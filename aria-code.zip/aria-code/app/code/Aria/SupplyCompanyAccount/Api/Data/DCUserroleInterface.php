<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api\Data;

interface DCUserroleInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const ID = 'id';
    const ROLE_NAME = 'role_name';
    const DESCRIPTION = 'description';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const IS_DELETE = 'is_delete';
    const SUPPLY_ID = 'supply_id';


    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param int $Id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setId($Id);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserroleExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserroleExtensionInterface $extensionAttributes
    );

     /**
     * Get supply_id
     * @return int|null
     */
    public function getSupplyId();

    /**
     * Set supply_id
     * @param int $supplyId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setSupplyId($supplyId);

    /**
    * Get dc role permission mapping info
    *
    * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface[]|null
    */
    public function getDcRolePermissionMapping();

    /**
    * Set dc role permission mapping info
    *
    * @param \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface[] $dcRolePermissionMapping
    * @return $this
    */
    public function setDcRolePermissionMapping(array $dcRolePermissionMapping = null);

    /**
     * Get role_name
     * @return string|null
     */
    public function getRoleName();

    /**
     * Set role_name
     * @param string $rolename
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setRoleName($rolename);

    /**
     * Get description
     * @return string|null
     */
    public function getDescription();

    /**
     * Set description
     * @param string $description
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setDescription($description);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedby
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setUpdatedBy($updatedBy);


    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setIsActive($isActive);

     /**
     * Get is_delete
     * @return bool|null
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setIsDelete($isDelete);

   
    
}