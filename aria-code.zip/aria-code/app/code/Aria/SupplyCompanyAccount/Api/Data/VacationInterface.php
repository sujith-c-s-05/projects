<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api\Data;

use Magento\Framework\Api\ExtensibleDataInterface;

interface VacationInterface extends ExtensibleDataInterface
{

    const TO = 'to';
    const DC_ID = 'dc_id';
    const COMMENT = 'comment';
    const IS_DELETE = 'is_delete';
    const STATUS = 'status';
    const FROM = 'from';
    const VACATION_ID = 'vacation_id';

    /**
     * Get vacation_id
     * @return string|null
     */
    public function getVacationId();

    /**
     * Set vacation_id
     * @param string $vacationId
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setVacationId($vacationId);

    /**
     * Get from
     * @return string|null
     */
    public function getFrom();

    /**
     * Set from
     * @param string $from
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setFrom($from);

    /**
     * Get to
     * @return string|null
     */
    public function getTo();

    /**
     * Set to
     * @param string $to
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setTo($to);

    /**
     * Get comment
     * @return string|null
     */
    public function getComment();

    /**
     * Set comment
     * @param string $comment
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setComment($comment);

    /**
     * Get status
     * @return string|null
     */
    public function getStatus();

    /**
     * Set status
     * @param string $status
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setStatus($status);

    /**
     * Get is_delete
     * @return string|null
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param string $isDelete
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setIsDelete($isDelete);

    /**
     * Get dc_id
     * @return string|null
     */
    public function getDcId();

    /**
     * Set dc_id
     * @param string $dcId
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setDcId($dcId);
}
