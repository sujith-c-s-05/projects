<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface DCUserRepositoryInterface
{

     /**
     * Save DC User
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface $dCUser
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface $dcUser
    );

     /**
     * Retrieve Dc User phone
     * @param string $phone
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function isPhoneExists($phone);
  
  /**
     * Delete DC User by id
     * @param int $id
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($id);

    /**
     * Check whether the DC's exist for adding dc user
     *
     * @return boolean
     */
    public function isActiveDCExists();

    /**
     * Retrieve DC user matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
      \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
  );

    /**
     * @param int $dcUserId
     * @param bool $isActive
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
  public function activateDeactivateDCUser($dcUserId,$isActive);

    /**
     * Retrieve Dc User
     * @param int $Id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($id);

    /**
     * Get dc user by id
     *
     * @param int $id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function get($id);

}

