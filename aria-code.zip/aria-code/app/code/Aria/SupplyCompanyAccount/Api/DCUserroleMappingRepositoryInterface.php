<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface DCUserroleMappingRepositoryInterface
{

    /**
     * Save SupplyCompanyAccount User Role
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface $dcUserroleMapping
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface $dcUserroleMapping
    );

     /**
     * @param int $dcUserId
     * @param bool $isActive
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function activateDeactivateDCUserRoleMapping($dcUserId,$isActive);

     /**
     * Get Dc User Role mapping
     * @param int id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getDCUserroleMappings($id);

     /**
     * delete Dc User Role mapping
     * @param int dcUserId
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteDCUserroleMapping($dcUserId);

    /**
     * Get DC User Role 
     * @param int $dcUserId
     * @param int $dc_id
     * @return int $roleId
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getDCUserRole($dcUserId,$dc_id);

    /**
     * Get DC Users
     * @param int $dc_id
     * @return mixed[]
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getDCUsers($dc_id);
    
}