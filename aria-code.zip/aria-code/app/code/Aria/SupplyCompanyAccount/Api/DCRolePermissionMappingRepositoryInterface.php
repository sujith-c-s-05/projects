<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface DCRolePermissionMappingRepositoryInterface
{

    /**
     * Save SupplyCompanyAccount User Role Permission
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface $dcRolePermissionMapping
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface $dcRolePermissionMapping
    );

    /**
     * delete Dc Role Permission mapping
     * @param int roleId
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteDCRolePermissionMapping($roleId);

    /**
     * Get Dc Role Permission mapping
     * @param int Id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getDCRolePermissionMappings($Id);

      /**
     * Get Dc Role Permission details
     * @param int Id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getDCRolePermissionDetails($Id);
    
    
}