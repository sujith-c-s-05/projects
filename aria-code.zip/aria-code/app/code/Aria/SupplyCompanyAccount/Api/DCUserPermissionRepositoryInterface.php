<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface DCUserPermissionRepositoryInterface
{


    /**
     * Retrieve DC User Permission matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Retrieve DC User Permission
     * @param int $Id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($Id);


}

