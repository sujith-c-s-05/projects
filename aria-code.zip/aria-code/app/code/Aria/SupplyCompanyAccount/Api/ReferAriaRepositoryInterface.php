<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api;

interface ReferAriaRepositoryInterface
{
    /**
     * Refer Aria function
     *
     * @param \Aria\SupplyCompanyAccount\Api\Data\ReferAriaInterface $refer
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function referAria(
        \Aria\SupplyCompanyAccount\Api\Data\ReferAriaInterface $refer
    );
}

