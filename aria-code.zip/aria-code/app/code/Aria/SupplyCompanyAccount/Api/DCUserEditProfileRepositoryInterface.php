<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface DCUserEditProfileRepositoryInterface
{

     /**
     * Save DC User
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserEditProfileInterface $dCUserEditProfile
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserEditProfileInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserEditProfileInterface $dcUserEditProfile
    );

 
}

