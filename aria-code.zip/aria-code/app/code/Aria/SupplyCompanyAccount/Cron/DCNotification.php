<?php

namespace Aria\SupplyCompanyAccount\Cron;

use Aria\SupplyCompanyAccount\Model\ResourceModel\Vacation\CollectionFactory as VacationCollectionFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Aria\Order\Api\SalesOrderGroupRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\VacationRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\DCRepositoryInterface;
use Aria\Venue\Api\VenueUserRoleMappingRepositoryInterface;
use Aria\Venue\Api\VenueRolePermissionMappingRepositoryInterface;
use Aria\Venue\Model\ResourceModel\VenueRolePermissionMapping\CollectionFactory as VenueRolePermissionMappingCollectionFactory;
class DCNotification
{
	protected $_pageFactory;
	protected $vacationCollectionFactory;
	protected $salesOrderGroupRepositoryInterface;
	protected $vacationRepositoryInterface;
	protected $_orderCollectionFactory;
	protected $dcRepositoryInterface;
	protected $participantsRepositoryInterface;
	protected $_date;
	protected $storeManager;
	protected $transportBuilder;
	protected $inlineTranslation;
	protected $scopeConfig;
	protected $venueUserRoleMappingRepositoryInterface;
    protected $venueRolePermissionMappingRepositoryInterface;
	protected $venueRolePermissionMappingCollectionFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		VacationCollectionFactory $vacationCollectionFactory,
		\Magento\Framework\Stdlib\DateTime\TimezoneInterface $date,
		TransportBuilder $transportBuilder,
        StateInterface $state,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
		SalesOrderGroupRepositoryInterface $salesOrderGroupRepositoryInterface,
		VacationRepositoryInterface $vacationRepositoryInterface,
		\Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface,
		DCRepositoryInterface $dcRepositoryInterface,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		\Magento\Sales\Model\ResourceModel\Order\CollectionFactory  $orderCollectionFactory,
		VenueUserRoleMappingRepositoryInterface $venueUserRoleMappingRepositoryInterface,
        VenueRolePermissionMappingRepositoryInterface $venueRolePermissionMappingRepositoryInterface,
		VenueRolePermissionMappingCollectionFactory $venueRolePermissionMappingCollectionFactory)
	{
		$this->_pageFactory = $pageFactory;
		$this->vacationCollectionFactory = $vacationCollectionFactory;
		$this->storeManager = $storeManager;
		$this->transportBuilder = $transportBuilder;
        $this->scopeConfig = $scopeConfig;
        $this->inlineTranslation = $state;
		$this->_date =  $date;
		$this->salesOrderGroupRepositoryInterface=$salesOrderGroupRepositoryInterface;
		$this->vacationRepositoryInterface=$vacationRepositoryInterface;
		$this->_orderCollectionFactory = $orderCollectionFactory;
		$this->participantsRepositoryInterface=$participantsRepositoryInterface;
		$this->dcRepositoryInterface=$dcRepositoryInterface;
		$this->venueUserRoleMappingRepositoryInterface=$venueUserRoleMappingRepositoryInterface;
        $this->venueRolePermissionMappingRepositoryInterface=$venueRolePermissionMappingRepositoryInterface;
		$this->venueRolePermissionMappingCollectionFactory = $venueRolePermissionMappingCollectionFactory;

	}

	public function execute()
	{
		$venueUserIdCollection=[];
		$vacationCollection = $this->vacationCollectionFactory->create();
		$vacationCollection->addFieldToFilter('status', 1)
		->addFieldToFilter('is_delete', 0);
		foreach($vacationCollection as $vacation){
			$startDate = $vacation->getFrom();
			$endDate = $vacation->getTo();
			$currentDate = $this->_date->date()->format('Y-m-d');
			$daylen = 60*60*24;
			$timestamp1 = strtotime($currentDate);
			$timestamp2 = strtotime($startDate);
			$duration=($timestamp2-$timestamp1)/$daylen;
			if(abs($duration)==7)
			{
				$vacationId=$vacation->getVacationId();
				$vacationDetails=$this->vacationRepositoryInterface->get($vacationId);
				$dcId=$vacationDetails->getDcId();
				$salesOrderDetails = $this->_orderCollectionFactory->create();
        		$orderDetails=$salesOrderDetails->addFieldToFilter('dcid',$dcId);
				$orderGroupIds=$orderDetails->addFieldToSelect('group_order_id');
				$orderGroupIdCollection=$orderGroupIds->getData();
				$ids=array_column($orderGroupIdCollection, 'group_order_id');
				$orderGroupIdList=array_unique($ids);
				//dc details
				$dcDetails=$this->dcRepositoryInterface->get($dcId);
				$dcName=$dcDetails->getName();
				foreach($orderGroupIdList as $orderGroupId)
				{
					$orderGroupDetails=$this->salesOrderGroupRepositoryInterface->get($orderGroupId);
					$createdDate=$orderGroupDetails->getCreatedAt();
					$createdDateTime=strtotime($createdDate);
					$currentYear = date('Y', $timestamp1);
					$orderYear = date('Y', $createdDateTime);
					$currentMonth = date('m', $timestamp1);
					$orderMonth = date('m', $createdDateTime);
					$monthDifference=(($currentYear - $orderYear) * 12) + ($currentMonth - $orderMonth);
					$venueUserId=$orderGroupDetails->getVenueUserId();
					$venueId=$orderGroupDetails->getVenueId();
					$roleId=$this->venueUserRoleMappingRepositoryInterface->getVenueUserRole($venueUserId,$venueId);
                    if($roleId)
                    {
						$venueRolePermissionMapping = $this->venueRolePermissionMappingCollectionFactory->create();
                        $venueRolePermissionMapping->addFieldToFilter('role_id',$roleId,'permission_id',42);
                        if(count($venueRolePermissionMapping)==0)
                        {
							$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
							$venueUserRoleDetails = $objectManager->create('Aria\Venue\Api\Data\VenueRolePermissionMappingInterface');
							$venueUserRoleDetails->setRoleId($roleId)
							->setPermissionId(42)
							->setParentId(0)
							->setIsActive(1)
							->setIsGranted(1);
							$this->venueRolePermissionMappingRepositoryInterface->save($venueUserRoleDetails);
						}
                    }
					if(abs($monthDifference)<=6)
					{
						$venueUserIdCollection[]=$venueUserId;
					}
				}
				$description = $dcName . " will be on vacation from " . $this->getFormattedDate($vacation->getFrom()) . " to " . $this->getFormattedDate($vacation->getTo()) . ". Message from supplier: " .$vacation->getComment();
				$venueUserIdList=array_unique($venueUserIdCollection);
				foreach($venueUserIdList as $venueuserIds)
				{
					$this->participantsRepositoryInterface->saveParticipantNotification(3, $venueId, $venueuserIds, $description, 'venue_user', 'DC on vacation');
				}
			}
		}
		
	}

	public function getFormattedDate($date)
    {
        $date = date_create($date);
        return date_format($date,"d/m/Y");
    }

}