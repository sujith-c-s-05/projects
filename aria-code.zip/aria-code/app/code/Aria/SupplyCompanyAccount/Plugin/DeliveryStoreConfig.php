<?php

namespace Aria\SupplyCompanyAccount\Plugin;

use Magento\Store\Api\Data\StoreConfigExtensionInterface;
use Magento\Store\Api\Data\StoreConfigInterface;
use Magento\Store\Api\Data\StoreConfigExtensionFactory;
use Magento\Setup\Exception;
use Magento\Directory\Model\Currency;
use Magento\Store\Model\StoreManagerInterface;


/**
 * classname
 */
class DeliveryStoreConfig
{
    protected $storeConfigExtensionFactory;
    protected $storeConfigInterface;
    protected $storeConfigExtensionInterface;
    protected $scopeConfig;

   
    public function __construct(
    Currency $currencyFactory, 
    StoreManagerInterface $storeManager, 
    StoreConfigExtensionFactory $storeConfigExtensionFactory, 
    StoreConfigInterface $storeConfigInterface, 
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
            $this->storeConfigExtensionFactory = $storeConfigExtensionFactory;
            $this->storeConfigInterface = $storeConfigInterface;
            $this->scopeConfig = $scopeConfig;
            $this->currencyFactory = $currencyFactory;
            $this->storeManager = $storeManager;

     }
    /**
     * @param string[] $storeCodes list of stores by store codes, will return all if storeCodes is not set
     * @return \Magento\Store\Api\Data\StoreConfigInterface[]
     */
    public function afterGetStoreConfigs(\Magento\Store\Model\Service\StoreConfigManager $storeConfigManager, $result, array $storeCodes = null)
    {
        foreach ($result as $storevalues) {
            if($storeCodes === null){
                $storeCodes = $this->storeManager->getStore()->getCode();
            }
            $val =$this->scopeConfig->getValue('deliverycost/general/delivery_cost_configuration',\Magento\Store\Model\ScopeInterface::SCOPE_STORES,
            $storeCodes);


            $extensionAttribute=$storevalues->getExtensionAttributes();
            $extensionAttribute->setDeliveryCost($val); //attribute code
            $storevalues->setExtensionAttributes($extensionAttribute);
        }
        return $result;
    }

}