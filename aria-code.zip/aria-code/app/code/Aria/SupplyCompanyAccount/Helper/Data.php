<?php

namespace Aria\SupplyCompanyAccount\Helper;
use Magento\Framework\App\Helper\AbstractHelper;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserroleMapping\CollectionFactory;
use Aria\SupplyCompanyAccount\Api\DCRolePermissionMappingRepositoryInterface;
use Magento\Framework\Exception\AuthorizationException;


class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    protected $dcUserroleMappingCollectionFactory;

    protected $dcRolePermissionMappingRepositoryInterface;


    public function __construct(
        CollectionFactory $dcUserroleMappingCollectionFactory,
        DCRolePermissionMappingRepositoryInterface $dcRolePermissionMappingRepositoryInterface,
        \Magento\Framework\App\Helper\Context $context       
    ) {
        $this->dcUserroleMappingCollectionFactory = $dcUserroleMappingCollectionFactory;
        $this->dcRolePermissionMappingRepositoryInterface=$dcRolePermissionMappingRepositoryInterface;
        parent::__construct($context);
    }

     /**
     * To Check permission
     */
    public function permissionCheck($dcId,$dcUserId,$permission)
    { 
        
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $dcUsermodel = $objectManager->create(\Aria\SupplyCompanyAccount\Model\DCUser::class);
        $adminDetails = $dcUsermodel->load($dcUserId,'id');
        $isAdmin=$adminDetails->getIsAdmin();
        if($isAdmin!=1)
        {
            $dcUserDetails = $this->dcUserroleMappingCollectionFactory->create();
            $dcUserDetails->addFieldToFilter('dc_id',$dcId);
            $dcUserDetails->addFieldToFilter('dc_user_id',$dcUserId); 
            $roleIds=$dcUserDetails->addFieldToSelect('role_id');
            $roles=$roleIds->getData();
            $roleIds=array_column($roles, 'role_id');
            $roleId= reset($roleIds);

            $dcRolePermissionMappings=$this->dcRolePermissionMappingRepositoryInterface->getDCRolePermissionMappings($roleId);
            if(count($dcRolePermissionMappings)>0)
            {
                $items=[];
                foreach($dcRolePermissionMappings as $key=>$permissionList)
                {
                    $isGranted=$permissionList->getIsGranted();
                    $isActive=$permissionList->getIsActive();
                    if(!$isGranted||!$isActive){
                        unset($dcRolePermissionMappings[$key]);
                    }
                    else
                    {
                        $permissionName=$permissionList->getPermissionName();   
                        $items[]=$permissionName;
                    }

                }
                if(!in_array($permission,$items))
                {
                    throw new AuthorizationException(
                        __("Access Denied.The DC user does not have permission to access this functionality")
                    );        
                }
            }
            else
            {
                throw new AuthorizationException(
                    __("Access Denied.The DC user does not have permission to access this functionality")
                );        
            }
        }
        return true;
    }
    
}