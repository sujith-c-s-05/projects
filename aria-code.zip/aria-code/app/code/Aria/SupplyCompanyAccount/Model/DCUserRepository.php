<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\DCUserRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCUserInterfaceFactory;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Customer\Model\AccountManagement;
use Aria\SupplyCompanyAccount\Api\Data\DCUserSearchResultsInterfaceFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUser as ResourceDCUser;
use Aria\SupplyCompanyAccount\Model\DCUserFactory as DCUserFactory;
use Aria\SupplyCompanyAccount\Model\DCUserroleMappingFactory as DCUserroleMappingFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserroleMapping as ResourceDCUserroleMapping;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUser\CollectionFactory as DCUserCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Aria\SupplyCompanyAccount\Model\DCUserroleMappingRepository as dcUserroleMappingRepository;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserroleMapping\CollectionFactory as DCUserroleMappingCollectionFactory;
use Aria\SupplyCompanyAccount\Api\DCRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Aria\AwsCognito\Helper\Data as HelperData;
use Magento\Customer\Model\CustomerFactory;



class DCUserRepository implements DCUserRepositoryInterface
{

    public $customerFactory;

    public $customerRepository;

    public $customerAccountManagement;

    protected $dcUserroleMappingRepository;

    protected $dCUserCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $dcUserroleMappingFactory;


    protected $extensibleDataObjectConverter;
    protected $dcUserFactory;

    protected $searchResultsFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataDCUserFactory;

    protected $dcUserRoleMappingCollectionFactory;

    /** @var  \Magento\Framework\DB\Adapter\AdapterInterface */
    protected $_conn;

    /** @var \Magento\Framework\App\ResourceConnection */
    protected $_resourceConnection;


    /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $_searchCriteria;

    /**
     * @var \Magento\Framework\Api\FilterBuilder
     */
    protected $filterBuilder;

    /**
     * @var Aria\SupplyCompanyAccount\Api\DCRepositoryInterface
     */
    protected $dCRepositoryInterface;

    /**
     * @var Aria\SupplyCompanyAccount\Api\DCUserroleMappingRepositoryInterface
     */
    protected $dCUserroleMappingRepositoryInterface;

    /**
     * @var Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface
     */
    protected $supplyCompanyRepositoryInterface;

    /**
     * @var HelperData
     */
    protected $helper;


    /**
     * @param ResourceDCUser $resource
     * @param ResourceDCUserroleMapping $resourceDCUserroleMapping
     * @param DCUserFactory $dcUserFactory
     * @param DCUserInterfaceFactory $dataDCUserFactory
     * @param DCUserroleMappingFactory $dcUserroleMappingFactory
     * @param DCUserInterfaceFactory $dataDCUserFactory
     * @param DCUserCollectionFactory $dCUserCollectionFactory
     * @param DCUserSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
     * @param \Magento\Framework\Api\FilterBuilder $filterBuilder
     * @param DCUserroleMappingCollectionFactory $dcUserroleMappingCollectionFactory
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param \Aria\SupplyCompanyAccount\Api\DCUserroleMappingRepositoryInterface $dCUserroleMappingRepositoryInterface
     * @param Aria\SupplyCompanyAccount\Api\DCRepositoryInterface $dCRepositoryInterface
     * @param Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface
     */
    public function __construct(
        ResourceDCUser $resource,
        ResourceDCUserroleMapping $resourceDCUserroleMapping,
        CustomerInterfaceFactory $customerInterfaceFactory,
        CustomerRepositoryInterface $customerRepository,
        \Magento\Customer\Api\AccountManagementInterface $customerAccountManagement,
        DCUserFactory $dcUserFactory,
        DCUserroleMappingFactory $dcUserroleMappingFactory,
        DCUserInterfaceFactory $dataDCUserFactory,
        dcUserroleMappingRepository $dcUserroleMappingRepository,
        DCUserCollectionFactory $dCUserCollectionFactory,
        DCUserroleMappingCollectionFactory $dcUserroleMappingCollectionFactory,
        DCUserSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\Api\FilterBuilder $filterBuilder,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Aria\SupplyCompanyAccount\Api\DCUserroleMappingRepositoryInterface $dCUserroleMappingRepositoryInterface,
        DCRepositoryInterface $dCRepositoryInterface,
        SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface,
        ScopeConfigInterface $scopeConfig,
        TransportBuilder $transportBuilder,
        StateInterface $state,
        HelperData $helper,
        CustomerFactory $customerFactory


    ) {
        $this->resource = $resource;
        $this->customerFactory = $customerFactory;
        $this->customerRepository = $customerRepository;
        $this->customerAccountManagement = $customerAccountManagement;
        $this->resourceDCUserroleMapping = $resourceDCUserroleMapping;
        $this->dcUserFactory = $dcUserFactory;
        $this->dcUserroleMappingFactory = $dcUserroleMappingFactory;
        $this->dCUserCollectionFactory = $dCUserCollectionFactory;
        $this->dcUserroleMappingCollectionFactory = $dcUserroleMappingCollectionFactory;
        $this->dcUserroleMappingRepository = $dcUserroleMappingRepository;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataDCUserFactory = $dataDCUserFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->_searchCriteria = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->_resourceConnection = $resourceConnection;
        $this->_conn = $resourceConnection->getConnection();
        $this->dCUserroleMappingRepositoryInterface = $dCUserroleMappingRepositoryInterface;
        $this->dCRepositoryInterface = $dCRepositoryInterface;
        $this->supplyCompanyRepositoryInterface = $supplyCompanyRepositoryInterface;
        $this->scopeConfig = $scopeConfig;
        $this->transportBuilder = $transportBuilder;
        $this->inlineTranslation = $state;
        $this->helper = $helper;
        $this->customerInterfaceFactory = $customerInterfaceFactory;

    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface $dcUser
    ) {
        try {
            $this->_conn->beginTransaction();
            $dcUserEntityId = $dcUser->getId();
            if ($dcUserEntityId != 0) {
                $customerEntity = $this->get($dcUserEntityId);
                $custId = $customerEntity->getDcUserId();
            }

            /**Aws Cognito code starts */
            if (!isset($dcUserEntityId)) {
                $isCustomerExistInCognito = $this->helper->checkUserExist($dcUser->getPhone());
                $isMagentoCustomerExist = $this->helper->checkMagentoCustomerExist($dcUser->getPhone());
                $isPasswordReset = 1;
                if (!$isCustomerExistInCognito) {
                    $isPasswordReset = 0;
                    $password = $this->helper->generateRandomPassword();
                    $this->registerInCognito($dcUser, $password);
                }
                $customer = $this->customerInterfaceFactory->create();

            }
            else
            {
                $customer = $this->customerFactory->create()->load($custId);
            }
            /**Aws Cognito code ends */

            $customer->setEmail($dcUser->getDcUserEmail());
            $customer->setFirstname($dcUser->getFirstName());
            $customer->setLastname($dcUser->getLastName());
            $customer->setGroupId(7);
            /**Aws Cognito code starts */
            if (!isset($dcUserEntityId)) {
                $customer->setCustomAttribute('aria_username', $dcUser->getPhone());
                $customer->setCustomAttribute('is_password_set', $isPasswordReset);
            }
            /**Aws Cognito code ends */
            $websiteId = $this->storeManager->getStore()->getWebsiteId()
                ?: $this->storeManager->getDefaultStoreView()->getWebsiteId();
            $customer->setWebsiteId($websiteId);
            if(!isset($dcUserEntityId))
            {
                $customerEntity=$this->customerRepository->save($customer);

            }
            else
            {
                $customerEntity = $customer->save();
            }
            $customerId = $customerEntity->getId();
            $dcUser->setDcUserId($customerId);


            $dcUserData = $this->extensibleDataObjectConverter->toNestedArray(
                $dcUser,
                [],
                \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface::class
            );

            $dcUserModel = $this->dcUserFactory->create()->setData($dcUserData);
            $dcUser = $dcUserModel->save();
            $id = $dcUser->getId();
            $this->dCUserroleMappingRepositoryInterface->deleteDCUserroleMapping($dcUserEntityId);

            $dcUserroleMap = $dcUser->getDcUserroleMapping();
            foreach ($dcUserroleMap as $dcList) {
                $dcUserroleMappingModel = $this->dcUserroleMappingFactory->create()->setData($dcList);

                $dcUserroleMappingModel->setDcUserId($id);
                $dcUserroleMappingModel->setCreatedBy($dcUser->getCreatedBy());
                $dcUserroleMappingModel->setCreatedAt($dcUser->getCreatedAt());
                $dcUserroleMappingModel->setUpdatedAt($dcUser->getUpdatedAt());
                $dcUserroleMappingModel->setUpdatedBy($dcUser->getUpdatedBy());
                $dcUserroleMappingModel->setIsActive($dcUser->getIsActive());
                $dcUserroleMappingModel->setIsDelete($dcUser->getIsDelete());
                $this->resourceDCUserroleMapping->save($dcUserroleMappingModel);
            }
            $dcId = $dcUserroleMappingModel->getDcId();
            $dcDetails = $this->dCRepositoryInterface->get($dcId);
            $supplyCompanyId = $dcDetails->getSupplyId();
            $supplyCompanyDetails = $this->supplyCompanyRepositoryInterface->get($supplyCompanyId);
            $supplyCompanyName = $supplyCompanyDetails->getCompanyName();
            $entityId = $supplyCompanyDetails->getCompanyAdmin();
            $customerEntityDetails = $this->customerRepository->getById($entityId);
            $customerName = $customerEntityDetails->getFirstName();

            if ($dcUserEntityId == 0) {
                $passwordText = "";

                if(isset($password) )
                {
                    $passwordText = "Your password is ". $password;
                }
                $this->sendEmail($customer, $customerName, $supplyCompanyName,$passwordText);
                
            }
            $this->_conn->commit();
        } catch (\Exception $exception) {
            $this->_conn->rollBack();
            throw new CouldNotSaveException(__(
                'Could not save the dc user: %1',
                $exception->getMessage()
            ));
        }
        return $dcUserModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function isPhoneExists($phone)
    {
        $isDCUserPhoneExists = false;
        $nameCollection = $this->dCUserCollectionFactory->create();
        $nameCollection->addFieldToFilter('phone', $phone);
        if ($nameCollection->count() > 0) {
            $isDCUserPhoneExists = true;
        }
        return $isDCUserPhoneExists;
    }
    
    /**
     * {@inheritdoc}
     */
    public function get($id)
    {
        $dCUser = $this->dcUserFactory->create();
        $this->resource->load($dCUser, $id);
        if (!$dCUser->getId()) {
            throw new NoSuchEntityException(__('dc user with id "%1" does not exist.', $id));
        }
        return $dCUser->getDataModel();
    }

    /**
     * @inheritdoc
     */
    public function deleteById($id)
    {
        try {
            $dCUser = $this->dcUserFactory->create();
            $this->resource->load($dCUser, $id);
            $dCUser->setIsDelete(1);
            $dCUser->setIsActive(0);
            $dCUser->save();
        } catch (\Exception $e) {

            throw new CouldNotDeleteException(__(
                'Could not delete the DC user',
                $e->getMessage()
            ));
        }
        return true;
    }

    /**
     * Check whether the DC's exist for adding dc user
     *
     * @return boolean
     */
    public function isActiveDCExists()
    {
        $isDCExists = true;
        $this->_searchCriteria->addFilter('is_delete', 0);
        $this->_searchCriteria->addFilter('is_active', 1);
        $searchCriteria = $this->_searchCriteria->create();
        $searchResults = $this->dCRepositoryInterface->getList($searchCriteria);

        if ($searchResults->getTotalCount() == 0) {

            $isDCExists = false;
            throw new \Magento\Framework\Webapi\Exception(
                __('Cannot add DC users without having at least one DC'),
                0,
                \Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR
            );
        } else {
            $isDCExists = true;
        }
        return $isDCExists;
    }
    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->dCUserCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {

            $items[] = $model->getDataModel();
        }
        foreach ($items as $item) {

            $dcUserId = $item->getId();
            $dcRoleMappings = $this->dCUserroleMappingRepositoryInterface->getDCUserroleMappings($dcUserId);
            $item->setDcUserroleMapping($dcRoleMappings);
        }
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }
    /**
     * {@inheritdoc}
     */
    public function activateDeactivateDCUser($dcUserId, $isActive)
    {
        try {
            $this->_conn->beginTransaction();
            $dCUser = $this->dcUserFactory->create();
            $dCUser->setData('is_active', $isActive);
            $dCUser->setData('id', $dcUserId);
            $this->resource->save($dCUser);
            $this->dCUserroleMappingRepositoryInterface->activateDeactivateDCUserRoleMapping($dcUserId, $isActive);
            $this->_conn->commit();
        } catch (\Exception $e) {
            $this->_conn->rollBack();
            throw new CouldNotSaveException(__(
                'Could not activate/deactivate the dc user',
                $e->getMessage()
            ));
        }

        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function getById($id)
    {
        $dCUser = $this->dcUserFactory->create();
        $this->resource->load($dCUser, $id);
        $dcRoleMappings = $this->dCUserroleMappingRepositoryInterface->getDCUserroleMappings($id);

        $dCUser->setDcUserroleMapping($dcRoleMappings);

        if (!$dCUser->getId()) {
            throw new NoSuchEntityException(__('Dc user with id "%1" does not exist.', $id));
        }
        return $dCUser;
    }

    /**
     * To register dc user in cognito
     * @param $venuedcUserUser
     * @param $password
     * @return bool
     */
    public function registerInCognito($dcUser, $password)
    {
        $attributes = [];
        $attributes['email'] = $dcUser->getDcUserEmail();
        $attributes['phone_number'] = $dcUser->getPhone();
        $attributes['given_name'] = $dcUser->getFirstName();
        $attributes['family_name'] = $dcUser->getLastName();

        return $this->helper->register($dcUser->getFirstName(), $password, $attributes);
    }

    public function sendEmail($customer, $customerName, $supplyCompanyName,$passwordText)
    {
        $loginUrl = $this->helper->getFrontEndLoginUrl();
        if($passwordText=="")
        {
            $loginUrlText = '<a href="'.$loginUrl.'">click here</a> to verify your email address and use your existing password in ARIA to continue with the login.';
        }
        else
        {
            $loginUrlText = '<a href="'.$loginUrl.'">click here</a> to verify your email address and set a password.';
        }

        $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId());
        $templateVars = array(
            'customerName' => $customer->getFirstName(),
            'adminName' =>  $customerName,
            'companyName' => $supplyCompanyName,
            'passwordText' => $passwordText,
            'loginText' => $loginUrlText

        );
        $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $sender_name  = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
        $from = ['email' => $email, 'name' => $sender_name];
        $this->inlineTranslation->suspend();
        $transport = $this->transportBuilder->setTemplateIdentifier('aria_dc_company_account_register_template', ScopeInterface::SCOPE_STORE)
            ->setTemplateOptions($templateOptions)
            ->setTemplateVars($templateVars)
            ->setFrom($from)
            ->addTo($customer->getEmail())
            ->getTransport();
        $transport->sendMessage();
        $this->inlineTranslation->resume();
    }
}
