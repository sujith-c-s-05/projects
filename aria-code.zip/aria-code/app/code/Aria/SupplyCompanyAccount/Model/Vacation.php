<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\Data\VacationInterface;
use Aria\SupplyCompanyAccount\Api\Data\VacationInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class Vacation extends \Magento\Framework\Model\AbstractModel
{

    protected $dataObjectHelper;

    protected $_eventPrefix = 'aria_dc_vacation';
    protected $vacationDataFactory;

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        VacationInterfaceFactory $vacationDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\Vacation $resource,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\Vacation\Collection $resourceCollection,
        array $data = []
    ) {
        $this->vacationDataFactory = $vacationDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve vacation model with vacation data
     * @return VacationInterface
     */
    public function getDataModel()
    {
        $vacationData = $this->getData();
        
        $vacationDataObject = $this->vacationDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $vacationDataObject,
            $vacationData,
            VacationInterface::class
        );
        
        return $vacationDataObject;
    }
}
