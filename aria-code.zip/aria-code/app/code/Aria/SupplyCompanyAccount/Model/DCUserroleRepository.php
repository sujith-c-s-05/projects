<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;
use Aria\SupplyCompanyAccount\Api\DCUserroleRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterfaceFactory;
use Aria\SupplyCompanyAccount\Api\Data\DCUserroleSearchResultsInterfaceFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserrole as ResourceDCUserrole;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserrole\CollectionFactory as DCUserroleCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Aria\SupplyCompanyAccount\Model\DCUserroleFactory as DCUserroleFactory;
use Aria\SupplyCompanyAccount\Model\DCRolePermissionMappingFactory as DCRolePermissionMappingFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCRolePermissionMapping as ResourceDCRolePermissionMapping;
use Aria\SupplyCompanyAccount\Model\DCRolePermissionMappingRepository as dcRolePermissionMappingRepository;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCRolePermissionMapping\CollectionFactory as DCRolePermissionMappingCollectionFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserroleMapping\CollectionFactory as DCUserroleMappingCollectionFactory;



class DCUserroleRepository implements DCUserroleRepositoryInterface
{

    protected $dCUserroleCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;
    protected $dCUserroleFactory;

    protected $searchResultsFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataDCUserroleFactory;

    protected $dcRolePermissionMappingFactory;

    protected $dcRolePermissionMappingRepository;

    /**
     * @var Aria\SupplyCompanyAccount\Api\DCRolePermissionMappingRepositoryInterface
     */
    protected $dCRolePermissionMappingRepositoryInterface;

    protected $dcRolePermissionMappingCollectionFactory;

     /** @var  \Magento\Framework\DB\Adapter\AdapterInterface */
     protected $_conn;

     /** @var \Magento\Framework\App\ResourceConnection */
     protected $_resourceConnection;
 
 
     /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
     protected $_searchCriteria;
 
     /**
      * @var \Magento\Framework\Api\FilterBuilder
      */
     protected $filterBuilder;

     protected $dCUserroleMappingCollectionFactory;



    /**
     * @param ResourceDCUserrole $resource
     * @param DCUserroleFactory $dCUserroleFactory
     * @param DCUserroleInterfaceFactory $dataDCUserroleFactory
     * @param DCUserroleCollectionFactory $dCUserroleCollectionFactory
     * @param DCUserroleSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param DCRolePermissionMappingFactory $dcRolePermissionMappingFactory
     * @param ResourceDCRolePermissionMapping $resourceDCRolePermissionMapping
     * @param \Aria\SupplyCompanyAccount\Api\DCRolePermissionMappingRepositoryInterface $dCRolePermisssionMappingRepositoryInterface
     * @param DCRolePermissionMappingCollectionFactory $dcRolePermissionMappingCollectionFactory
     * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
     * @param \Magento\Framework\Api\FilterBuilder $filterBuilder
     * @param DCUserroleMappingCollectionFactory $dCUserroleMappingCollectionFactory
     */
    public function __construct(
        ResourceDCUserrole $resource,
        DCUserroleFactory $dCUserroleFactory,
        DCUserroleInterfaceFactory $dataDCUserroleFactory,
        DCUserroleCollectionFactory $dCUserroleCollectionFactory,
        DCUserroleSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        DCRolePermissionMappingFactory $dcRolePermissionMappingFactory,
        ResourceDCRolePermissionMapping $resourceDCRolePermissionMapping,
        dcRolePermissionMappingRepository $dcRolePermissionMappingRepository,
        \Aria\SupplyCompanyAccount\Api\DCRolePermissionMappingRepositoryInterface $dCRolePermissionMappingRepositoryInterface,
        DCRolePermissionMappingCollectionFactory $dcRolePermissionMappingCollectionFactory,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\Api\FilterBuilder $filterBuilder,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
         DCUserroleMappingCollectionFactory $dCUserroleMappingCollectionFactory


    ) {
        $this->resource = $resource;
        $this->dCUserroleFactory = $dCUserroleFactory;
        $this->dCUserroleCollectionFactory = $dCUserroleCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataDCUserroleFactory = $dataDCUserroleFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->dcRolePermissionMappingFactory = $dcRolePermissionMappingFactory;
        $this->resourceDCRolePermissionMapping=$resourceDCRolePermissionMapping;
        $this->dcRolePermissionMappingRepository=$dcRolePermissionMappingRepository;
        $this->dCRolePermissionMappingRepositoryInterface=$dCRolePermissionMappingRepositoryInterface;
        $this->dcRolePermissionMappingCollectionFactory = $dcRolePermissionMappingCollectionFactory;
        $this->_searchCriteria = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->_resourceConnection = $resourceConnection;
        $this->_conn = $resourceConnection->getConnection(); 
        $this->dCUserroleMappingCollectionFactory = $dCUserroleMappingCollectionFactory;


    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface $dcUserrole
    ) { 
        try {
            $this->_conn->beginTransaction();
           
        $dcUserroleData = $this->extensibleDataObjectConverter->toNestedArray(
            $dcUserrole,
            [],
            \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface::class
        );
        $dcUserroleEntityId=$dcUserrole->getId();
        $dcUserroleModel = $this->dCUserroleFactory->create()->setData($dcUserroleData);
        $dcUserrole=$dcUserroleModel->save();
        $id=$dcUserrole->getId();

        $this->dCRolePermissionMappingRepositoryInterface->deleteDCRolePermissionMapping($dcUserroleEntityId);      

            $dcUserroleMap=$dcUserrole->getDcRolePermissionMapping();   
            foreach($dcUserroleMap as $dcList)
            {  
                $dcRolePermissionMappingModel = $this->dcRolePermissionMappingFactory->create()->setData($dcList);     

                $dcRolePermissionMappingModel->setRoleId($id);
                $dcRolePermissionMappingModel->setCreatedBy($dcUserrole->getCreatedBy());
                $dcRolePermissionMappingModel->setCreatedAt($dcUserrole->getCreatedAt());
                $dcRolePermissionMappingModel->setUpdatedAt($dcUserrole->getUpdatedAt());
                $dcRolePermissionMappingModel->setUpdatedBy($dcUserrole->getUpdatedBy());
                $dcRolePermissionMappingModel->setIsActive($dcUserrole->getIsActive());
                $this->resourceDCRolePermissionMapping->save($dcRolePermissionMappingModel);
            }
            $this->_conn->commit();

        } 
     
         catch (\Exception $exception) {
            $this->_conn->rollBack();
            throw new CouldNotSaveException(__(
                'Could not save the dc user role: %1',
                $exception->getMessage()
            ));
        }
        return $dcUserroleModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($Id)
    {
        $dCUserrole = $this->dCUserroleFactory->create();
        $this->resource->load($dCUserrole, $Id);
        if (!$dCUserrole->getId()) {
            throw new NoSuchEntityException(__('DC Userrole does not exist.', $dCId));
        }
        return $dCUserrole->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->dCUserroleCollectionFactory->create();
        
        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface::class
        );
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            
            $items[] = $model->getDataModel();
        }
        foreach($items as $item){

            $dcUserroleId=$item->getId();
            $dcRolePermissionMappings=$this->dCRolePermissionMappingRepositoryInterface->getDCRolePermissionMappings($dcUserroleId);
            $item->setDcRolePermissionMapping($dcRolePermissionMappings);  
        }
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }
    /**
     * @inheritdoc
     */
    public function deleteById($Id)
    {
       
        $dCUserrole = $this->dCUserroleFactory->create();
        $this->resource->load($dCUserrole, $Id);
        $dCUserrole->setIsDelete(1);
        $dCUserrole->setIsActive(0);
        $dcUser=$this->dCUserroleMappingCollectionFactory->create();
        $dcUser->addFieldToFilter('role_id', $Id);
        if($dcUser->count()==0)
        {
            $dCUserrole->save();
        }
        else
        {
        throw new \Magento\Framework\Webapi\Exception(    __('Roles cannot be deleted while assigned to one or more users'),
        0,\Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST
        );
        }     
        if($dCUserrole->save())
        {
            $this->dCRolePermissionMappingRepositoryInterface->deleteDCRolePermissionMapping($Id);      
        }         
        return true;
    }

     /**
     * {@inheritdoc}
     */
    public function getById($Id)
    {
        $dCUserrole = $this->dCUserroleFactory->create();
        $this->resource->load($dCUserrole, $Id);
        $dcRolePermissionMappings=$this->dCRolePermissionMappingRepositoryInterface->getDCRolePermissionDetails($Id);

        $dCUserrole->setDcRolePermissionMapping($dcRolePermissionMappings);       
         
        if (!$dCUserrole->getId()) {
            throw new NoSuchEntityException(__('Dc user role with id "%1" does not exist.', $Id));
        }
        return $dCUserrole;
    }

     /**
     * {@inheritdoc}
     */
    public function isRoleNameExists($roleName,$supplierid,$id=null)
    {
        $isRoleNameExists=false;
        $role = $this->dCUserroleCollectionFactory->create();
        if(is_numeric($id))
        {
            $DcRole=$this->get($id);
            $DcRoleName=$DcRole->getRoleName();
            if(strtolower($DcRoleName)!=strtolower($roleName))
            {
                $role->addFieldToFilter('role_name', $roleName);
                $role->addFieldToFilter('supply_id', $supplierid);
                $role->addFieldToFilter('is_delete',0);
                if($role->count()>0)
                {
                    $isRoleNameExists=true;
                }
            }
        }
        else
        {
            $role->addFieldToFilter('role_name', $roleName);
            $role->addFieldToFilter('supply_id', $supplierid);
            $role->addFieldToFilter('is_delete',0);
            if($role->count()>0)
            {
                $isRoleNameExists=true;
            }
        }
        return $isRoleNameExists;
     
    }
}