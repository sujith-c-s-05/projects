<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class DCRolePermissionMapping extends \Magento\Framework\Model\AbstractModel
{

    protected $dcRolePermissionMappingDataFactory;

    protected $_eventPrefix = 'aria_dc_role_permission_mapping';
    protected $dataObjectHelper;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param DCRolePermissionMappingInterfaceFactory $dcRolePermissionMappingDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\DCRolePermissionMapping $resource
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\DCRolePermissionMapping\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        DCRolePermissionMappingInterfaceFactory $dcRolePermissionMappingDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DCRolePermissionMapping $resource,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DCRolePermissionMapping\Collection $resourceCollection,
        array $data = []
    ) {
        $this->dcRolePermissionMappingDataFactory = $dcRolePermissionMappingDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve dc role permission model with user role data
     * @return DCRolePermissionMappingInterface
     */
    public function getDataModel()
    {
        $dcRolePermissionMappingData = $this->getData();
        
        $dcRolePermissionMappingDataObject = $this->dcRolePermissionMappingDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $dcRolePermissionMappingDataObject,
            $dcRolePermissionMappingData,
            DCRolePermissionMappingInterface::class
        );
        
        return $dcRolePermissionMappingDataObject;
    }


}
