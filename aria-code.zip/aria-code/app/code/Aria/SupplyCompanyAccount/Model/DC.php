<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\Data\DCInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class DC extends \Magento\Framework\Model\AbstractModel
{

    protected $dcDataFactory;

    protected $_eventPrefix = 'aria_supply_dc';
    protected $dataObjectHelper;
    protected $_orderCollectionFactory;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param DCInterfaceFactory $dcDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\DC $resource
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\DC\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        DCInterfaceFactory $dcDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DC $resource,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DC\Collection $resourceCollection,
        array $data = []
    ) {
        $this->dcDataFactory = $dcDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve dc model with dc data
     * @return DCInterface
     */
    public function getDataModel()
    {
        $dcData = $this->getData();
        
        $dcDataObject = $this->dcDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $dcDataObject,
            $dcData,
            DCInterface::class
        );
        
        return $dcDataObject;
    }
    /**
     * Retrieve OrderStatus count with Order data
     * @return Order
     */
    public function getOrderCount($dcId)
    {
        $collection = $this->_orderCollectionFactory->create();
        $collection->addAttributeToFilter('dcid', array('eq' => $dcId));
        $collection->addAttributeToFilter('status', array('in' => array('complete','closed','canceled')));
        return $collection->count();

    }

    /**
    * Retrieve DCCount with Order data
    * @return Order
    */
   public function getDCCount($dcId)
   {
    $collection = $this->_orderCollectionFactory->create();
    $collection->addAttributeToFilter('dcid', array('eq' => $dcId));
    return $collection->count();

   }
}

