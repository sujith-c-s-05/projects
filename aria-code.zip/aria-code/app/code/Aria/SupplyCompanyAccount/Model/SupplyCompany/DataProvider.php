<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model\SupplyCompany;

use Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Customer\Api\CustomerRepositoryInterfaceFactory;

class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{

    protected $collection;

    protected $dataPersistor;

    protected $loadedData;

    /**
     * Constructor
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        CustomerRepositoryInterfaceFactory $customerFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $collectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        $this->customerFactory = $customerFactory;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $model) {
            $this->loadedData[$model->getId()] = $model->getData();
            $customer = $this->customerFactory->create()->getById($model->getData('company_admin'));
            //$this->loadedData[$model->getId()]['job_title'] = $customer->getCustomAttribute('job_title')->getvalue();
            if ($ariaUserName = $customer->getCustomAttribute('aria_username')) {
                $this->loadedData[$model->getId()]['aria_username'] = $ariaUserName->getValue();
            }
            $this->loadedData[$model->getId()]['email'] = $customer->getEmail();
            $this->loadedData[$model->getId()]['prefix'] = $customer->getPrefix();
            $this->loadedData[$model->getId()]['first_name'] = $customer->getFirstName();
            $this->loadedData[$model->getId()]['middle_name'] = $customer->getMiddleName();
            $this->loadedData[$model->getId()]['last_name'] = $customer->getLastName();
            $this->loadedData[$model->getId()]['suffix'] = $customer->getSuffix();
            $this->loadedData[$model->getId()]['gender'] = $customer->getGender();
        }

        $data = $this->dataPersistor->get('aria_supplycompanyaccount_supplycompany');

        if (!empty($data)) {
            $model = $this->collection->getNewEmptyItem();
            $model->setData($data);
            $this->loadedData[$model->getId()] = $model->getData();
            $this->dataPersistor->clear('aria_supplycompanyaccount_supplycompany');
        }

        return $this->loadedData;
    }
}
