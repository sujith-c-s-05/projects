<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterfaceFactory;
use Aria\SupplyCompanyAccount\Api\Data\SupplyCompanySearchResultsInterfaceFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany as ResourceSupplyCompany;
use Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany\CollectionFactory as SupplyCompanyCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;

class SupplyCompanyRepository implements SupplyCompanyRepositoryInterface
{

    protected $resource;

    protected $supplyCompanyFactory;

    protected $supplyCompanyCollectionFactory;

    protected $searchResultsFactory;

    protected $dataObjectHelper;

    protected $dataObjectProcessor;

    //protected $dataCompanyFactory;

    protected $extensionAttributesJoinProcessor;

    private $storeManager;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;

    /**
     * @param ResourceSupplyCompany $resource
     * @param SupplyCompanyFactory $supplyCompanyFactory
     * @param SupplyCompanyInterfaceFactory $dataSupplyCompanyFactory
     * @param SupplyCompanyCollectionFactory $supplyCompanyCollectionFactory
     * @param SupplyCompanySearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     */
    public function __construct(
        ResourceSupplyCompany $resource,
        SupplyCompanyFactory $supplyCompanyFactory,
        SupplyCompanyInterfaceFactory $dataSupplyCompanyFactory,
        SupplyCompanyCollectionFactory $supplyCompanyCollectionFactory,
        SupplyCompanySearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter
    ) {
        $this->resource = $resource;
        $this->supplyCompanyFactory = $supplyCompanyFactory;
        $this->supplyCompanyCollectionFactory = $supplyCompanyCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        //$this->dataCompanyFactory = $dataCompanyFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface $supplyCompany
    ) {
        /* if (empty($company->getStoreId())) {
            $storeId = $this->storeManager->getStore()->getId();
            $company->setStoreId($storeId);
        } */
        
        $supplyCompanyData = $this->extensibleDataObjectConverter->toNestedArray(
            $supplyCompany,
            [],
            \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface::class
        );
        
        $supplyCompanyModel = $this->supplyCompanyFactory->create()->setData($supplyCompanyData);
        
        try {
            $this->resource->save($supplyCompanyModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the supply company: %1',
                $exception->getMessage()
            ));
        }
        return $supplyCompanyModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($supplyCompanyId)
    {
        $supplyCompany = $this->supplyCompanyFactory->create();
        $this->resource->load($supplyCompany, $supplyCompanyId);
        if (!$supplyCompany->getId()) {
            throw new NoSuchEntityException(__('Supply Company with id "%1" does not exist.', $supplyCompanyId));
        }
        return $supplyCompany->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->supplyCompanyCollectionFactory->create();
        
        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface::class
        );
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface $supplyCompany
    ) {
        try {
            $supplyCompanyModel = $this->supplyCompanyFactory->create();
            $this->resource->load($supplyCompanyModel, $supplyCompany->getSupplyCompanyId());
            $this->resource->delete($supplyCompanyModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Supply Company: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($supplyCompanyId)
    {
        return $this->delete($this->get($supplyCompanyId));
    }

    /**
     * {@inheritdoc}
     */
    public function setDeliveryCost($supplyCompanyId,$deliveryCost) {

        $supplyCompanyModel = $this->supplyCompanyFactory->create();
        $this->resource->load($supplyCompanyModel, $supplyCompanyId);
        if (!$supplyCompanyModel->getId()) {
            throw new NoSuchEntityException(__('Supply Company with id "%1" does not exist.', $supplyCompanyId));
        }
        $supplyCompanyModel->setData('delivery_cost', $deliveryCost);
        $supplyCompanyModel->setData('supplycompany_id',$supplyCompanyId);
        $this->resource->save($supplyCompanyModel);
        return true;
        
    }
}

