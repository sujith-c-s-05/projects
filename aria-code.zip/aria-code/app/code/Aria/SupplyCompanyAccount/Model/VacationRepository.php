<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\Data\VacationInterfaceFactory;
use Aria\SupplyCompanyAccount\Api\VacationRepositoryInterface;
use Aria\SupplyCompanyAccount\Model\ResourceModel\Vacation as ResourceVacation;
use Aria\SupplyCompanyAccount\Model\ResourceModel\Vacation\CollectionFactory as VacationCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;

class VacationRepository implements VacationRepositoryInterface
{

    protected $resource;

    protected $extensibleDataObjectConverter;
    protected $searchResultsFactory;

    protected $dataVacationFactory;

    protected $vacationFactory;

    private $storeManager;

    protected $vacationCollectionFactory;

    protected $dataObjectHelper;

    protected $dataObjectProcessor;

    protected $extensionAttributesJoinProcessor;

    private $collectionProcessor;

    public function __construct(
        ResourceVacation $resource,
        VacationFactory $vacationFactory,
        VacationInterfaceFactory $dataVacationFactory,
        VacationCollectionFactory $vacationCollectionFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter
    ) {
        $this->resource = $resource;
        $this->vacationFactory = $vacationFactory;
        $this->vacationCollectionFactory = $vacationCollectionFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataVacationFactory = $dataVacationFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\VacationInterface $vacation
    ) {
        /* if (empty($vacation->getStoreId())) {
            $storeId = $this->storeManager->getStore()->getId();
            $vacation->setStoreId($storeId);
        } */
        
        $vacationData = $this->extensibleDataObjectConverter->toNestedArray(
            $vacation,
            [],
            \Aria\SupplyCompanyAccount\Api\Data\VacationInterface::class
        );
        
        $vacationModel = $this->vacationFactory->create()->setData($vacationData);
        
        try {
            $this->resource->save($vacationModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the vacation: %1',
                $exception->getMessage()
            ));
        }
        return $vacationModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($vacationId)
    {
        $vacation = $this->vacationFactory->create();
        $this->resource->load($vacation, $vacationId);
        if (!$vacation->getId()) {
            throw new NoSuchEntityException(__('Vacation with id "%1" does not exist.', $vacationId));
        }
        return $vacation->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getDc($dcId)
    {
        $vacationCollection = $this->vacationCollectionFactory->create();
        $vacation = $vacationCollection->addFieldToFilter('dc_id',$dcId)->getFirstItem();
        return $vacation;
    }


    /**
     * {@inheritdoc}
     */
    public function delete(
        \Aria\SupplyCompanyAccount\Api\Data\VacationInterface $vacation
    ) {
        try {
            $vacationModel = $this->vacationFactory->create();
            $this->resource->load($vacationModel, $vacation->getVacationId());
            $this->resource->delete($vacationModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Vacation: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($vacationId)
    {
        return $this->delete($this->get($vacationId));
    }

    public function getDcVacation($dcId)
    {
        $collection = $this->vacationCollectionFactory->create();
        $collection->addFieldToFilter('dc_id', $dcId);
        $collection->setOrder('vacation_id','DESC');

        if(count($collection) >=1 )
        {
            $vacation = $collection->getFirstItem();
            
            return $vacation;
        }

        return [];
    }
}
