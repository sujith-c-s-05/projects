<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\Data\DCUserEditProfileInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCUserEditProfileInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class DCUserEditProfile extends \Magento\Framework\Model\AbstractModel
{

    protected $dcUserEditProfileDataFactory;

    protected $_eventPrefix = 'aria_dc_user';
    protected $dataObjectHelper;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param DCUserEditProfileInterfaceFactory $dcDataEditProfileFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserEditProfile $resource
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserEditProfile\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        DCUserEditProfileInterfaceFactory $dcUserEditProfileDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserEditProfile $resource,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserEditProfile\Collection $resourceCollection,
        array $data = []
    ) {
        $this->dcUserEditProfileDataFactory = $dcUserEditProfileDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve dc user  model with user role data
     * @return DCUserEditProfileInterface
     */
    public function getDataModel()
    {
        $dcUserEditProfileData = $this->getData();
        
        $dcUserEditProfileDataObject = $this->dcUserEditProfileDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $dcUserEditProfileDataObject,
            $dcUserEditProfileData,
            DCUserEditProfileInterface::class
        );
        
        return $dcUserEditProfileDataObject;
    }


}
