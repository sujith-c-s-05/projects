<?php
namespace Aria\SupplyCompanyAccount\Model;

class Salesrep implements \Magento\Framework\Data\OptionSourceInterface {
    /**
     * @var \Magento\User\Model\ResourceModel\User\CollectionFactory
     */
    protected $_collectionFactory;

    /**
     * @var array|null
     */
    protected $_options;

    public function __construct(
        \Magento\User\Model\ResourceModel\User\CollectionFactory $collectionFactory
    ) {
        $this->_collectionFactory = $collectionFactory;
    }

    /**
     * @return array
     */
    public function toOptionArray() {
        if ($this->_options === null) {
            $collection = $this->_collectionFactory->create();

            $this->_options = [['label' => '', 'value' => '']];

            foreach ($collection as $user) {
                $this->_options[] = [
                    'label' => $user->getUserName(),
                    'value' => $user->getId()
                ];
            }
        }

        return $this->_options;
    }
}