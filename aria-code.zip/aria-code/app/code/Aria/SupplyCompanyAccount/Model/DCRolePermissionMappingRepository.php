<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\DCRolePermissionMappingRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterfaceFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCRolePermissionMapping as ResourceDCRolePermissionMapping;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCRolePermissionMapping\CollectionFactory as DCRolePermissionMappingCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserPermission\CollectionFactory as DCUserPermissionCollectionFactory;

class DCRolePermissionMappingRepository implements DCRolePermissionMappingRepositoryInterface
{

    protected $dcRolePermissionMappingCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;

    protected $dcRolePermissionMappingFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataDCRolePermissionMappingFactory;

    protected $dcUserPermissionRepositoryInterface;

    protected $dcUserPermissionCollectionFactory;



    /**
     * @param ResourceDCRolePermissionMapping $resource
     * @param DCRolePermissionMappingFactory $dcRolePermissionMappingFactory
     * @param DCRolePermissionMappingInterfaceFactory $dataDCRolePermissionMappingFactory
     * @param DCRolePermissionMappingCollectionFactory $dcRolePermissionMappingCollectionFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param \Aria\SupplyCompanyAccount\Api\DCUserPermissionRepositoryInterface $dcUserPermissionRepositoryInterface
     * @param DCUserPermissionCollectionFactory $dcUserPermissionCollectionFactory
     */
    public function __construct(
        ResourceDCRolePermissionMapping $resource,
        DCRolePermissionMappingFactory $dcRolePermissionMappingFactory,
        DCRolePermissionMappingInterfaceFactory $dataDCRolePermissionMappingFactory,
        DCRolePermissionMappingCollectionFactory $dcRolePermissionMappingCollectionFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Aria\SupplyCompanyAccount\Api\DCUserPermissionRepositoryInterface $dcUserPermissionRepositoryInterface,
        DCUserPermissionCollectionFactory $dcUserPermissionCollectionFactory



    ) {
        $this->resource = $resource;
        $this->dcRolePermissionMappingFactory = $dcRolePermissionMappingFactory;
        $this->dcRolePermissionMappingCollectionFactory = $dcRolePermissionMappingCollectionFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataDCRolePermissionMappingFactory = $dataDCRolePermissionMappingFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->dcUserPermissionRepositoryInterface = $dcUserPermissionRepositoryInterface;
        $this->dcUserPermissionCollectionFactory = $dcUserPermissionCollectionFactory;


    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface $dcRolePermissionMapping
    ) {
        
        $dcRolePermissionMappingData = $this->extensibleDataObjectConverter->toNestedArray(
            $dcRolePermissionMapping,
            [],
            \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface::class
        );
        $dcRolePermissionMappingModel = $this->dcRolePermissionMappingFactory->create()->setData($dcRolePermissionMappingData);
        

        try {
            $this->resource->save($dcRolePermissionMappingModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the dc user role: %1',
                $exception->getMessage()
            ));
        }
        return $dcRolePermissionMappingModel->getDataModel();
    }

     /**
     * {@inheritdoc}
     */
    public function deleteDCRolePermissionMapping($roleId)
    { 
        $dCRolePermissionMapping = $this->dcRolePermissionMappingCollectionFactory->create();
        $dCRolePermissionMapping->addFieldToFilter('role_id',$roleId);
        foreach ($dCRolePermissionMapping as $rolePermission) {
            $this->resource->delete($rolePermission);
        }
        
        return true;
        
    }

    /**
     * {@inheritdoc}
     */
    public function getDCRolePermissionMappings($Id)
    { 
        $dCRole = $this->dcRolePermissionMappingCollectionFactory->create();
        $dCRole->addFieldToFilter('role_id',$Id);
        $items = [];
        foreach ($dCRole as $rolePermission) {
            $permissionId=$rolePermission->getPermissionId();
            $permissionEntity=$this->dcUserPermissionRepositoryInterface->get($permissionId);
            $rolePermission->setPermissionName($permissionEntity->getPermissionName());
            $items[] = $rolePermission->getDataModel();
        }
        return $items;
    }

     /**
     * {@inheritdoc}
     */
    public function getDCRolePermissionDetails($Id)
    { 
        $dcUserPermissions = $this->dcUserPermissionCollectionFactory->create();
        $dcUserPermissions->addFieldToFilter('main_table.is_active',1)->addFieldToFilter('main_table.is_delete',0);
        
        $dcRole = $this->dcRolePermissionMappingCollectionFactory->create();
       
        $dcUserPermissions->getSelect()->joinLeft(['aria_dc_role_permission_mapping'=>$dcRole->getTable('aria_dc_role_permission_mapping')], 
                                            'main_table.id = aria_dc_role_permission_mapping.permission_id AND aria_dc_role_permission_mapping.role_id='.$Id,
                                            ['role_id'=>'aria_dc_role_permission_mapping.role_id',
                                            'is_granted'=>'aria_dc_role_permission_mapping.is_granted',
                                            'is_active'=>'aria_dc_role_permission_mapping.is_active']);
        $items = [];
        foreach ($dcUserPermissions as $model) {
            if($model->getIsGranted() == NULL){
                    $model->setIsGranted(false);
            }
            if($model->getRoleId() == NULL){
                    $model->setRoleId(0);
            }
            if($model->getIsActive() == NULL){
                $model->setIsActive(false);
        }
            $items[] = $model->getDataModel();
        }

        return $items;
    }

}