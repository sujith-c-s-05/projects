<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class DCUserroleMapping extends \Magento\Framework\Model\AbstractModel
{

    protected $dcUserroleMappingDataFactory;

    protected $_eventPrefix = 'aria_user_dc_role_mapping';
    protected $dataObjectHelper;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param DCUserroleMappingInterfaceFactory $dcUserroleMappingDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserroleMapping $resource
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserroleMapping\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        DCUserroleMappingInterfaceFactory $dcUserroleMappingDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserroleMapping $resource,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserroleMapping\Collection $resourceCollection,
        array $data = []
    ) {
        $this->dcUserroleMappingDataFactory = $dcUserroleMappingDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve dc user role model with user role data
     * @return DCUserroleMappingInterface
     */
    public function getDataModel()
    {
        $dcUserroleMappingData = $this->getData();
        
        $dcUserroleMappingDataObject = $this->dcUserroleMappingDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $dcUserroleMappingDataObject,
            $dcUserroleMappingData,
            DCInterface::class
        );
        
        return $dcUserroleMappingDataObject;
    }


}
