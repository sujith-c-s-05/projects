<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\DCUserEditProfileRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCUserEditProfileInterfaceFactory;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Customer\Model\AccountManagement;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserEditProfile as ResourceDCUserEditProfile;
use Aria\SupplyCompanyAccount\Model\DCUserEditProfileFactory as DCUserEditProfileFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserEditProfile\CollectionFactory as DCUserEditProfileCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Aria\SupplyCompanyAccount\Api\DCRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface;




class DCUserEditProfileRepository implements DCUserEditProfileRepositoryInterface
{

    public $customerFactory;

    public $customerRepository;

    public $customerAccountManagement;


    protected $dCUserEditProfileCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;



    protected $extensibleDataObjectConverter;
    protected $dcUserEditProfileFactory;


    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataDCUserEditProfileFactory;


    /** @var  \Magento\Framework\DB\Adapter\AdapterInterface */
    protected $_conn;

    /** @var \Magento\Framework\App\ResourceConnection */
    protected $_resourceConnection;


    /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $_searchCriteria;

    /**
     * @var \Magento\Framework\Api\FilterBuilder
     */
    protected $filterBuilder;

    /**
     * @var Aria\SupplyCompanyAccount\Api\DCRepositoryInterface
     */
    protected $dCRepositoryInterface;

    

    /**
     * @var Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface
     */
    protected $supplyCompanyRepositoryInterface;

    /**
     * @var HelperData
     */
    protected $helper;


    /**
     * @param ResourceDCUserEditProfile $resource
     * @param DCUserEditProfileFactory $dcUserEditProfileFactory
     * @param DCUserEditProfileInterfaceFactory $dataDCUserEditProfileFactory
     * @param DCUserEditProfileCollectionFactory $dCUserEditProfileCollectionFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
     * @param \Magento\Framework\Api\FilterBuilder $filterBuilder
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param Aria\SupplyCompanyAccount\Api\DCRepositoryInterface $dCRepositoryInterface
     * @param Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface
     */
    public function __construct(
        ResourceDCUserEditProfile $resource,
        CustomerInterfaceFactory $customerFactory,
        CustomerRepositoryInterface $customerRepository,
        \Magento\Customer\Api\AccountManagementInterface $customerAccountManagement,
        DCUserEditProfileFactory $dcUserEditProfileFactory,
        DCUserEditProfileInterfaceFactory $dataDCUserEditProfileFactory,
        DCUserEditProfileCollectionFactory $dCUserEditProfileCollectionFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\Api\FilterBuilder $filterBuilder,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        DCRepositoryInterface $dCRepositoryInterface,
        SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface
        

    ) {
        $this->resource = $resource;
        $this->customerFactory = $customerFactory;
        $this->customerRepository = $customerRepository;
        $this->customerAccountManagement = $customerAccountManagement;
        $this->dcUserEditProfileFactory = $dcUserEditProfileFactory;
        $this->dCUserEditProfileCollectionFactory = $dCUserEditProfileCollectionFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataDCUserEditProfileFactory = $dataDCUserEditProfileFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->_searchCriteria = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->_resourceConnection = $resourceConnection;
        $this->_conn = $resourceConnection->getConnection();
        $this->dCRepositoryInterface = $dCRepositoryInterface;
        $this->supplyCompanyRepositoryInterface = $supplyCompanyRepositoryInterface;
        
    }
/**
     * {@inheritdoc}
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserEditProfileInterface $dCUserEditProfile
    ) {
        
        
        $dCUserEditProfileData = $this->extensibleDataObjectConverter->toNestedArray(
            $dCUserEditProfile,
            [],
            \Aria\SupplyCompanyAccount\Api\Data\DCUserEditProfileInterface::class
        );  
        
        $dCUserEditProfileModel = $this->dcUserEditProfileFactory->create()->setData($dCUserEditProfileData);
        
        try {
            $this->resource->save($dCUserEditProfileModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the dC User: %1',
                $exception->getMessage()
            ));
        }
        return $dCUserEditProfileModel->getDataModel();
    }

    

}
