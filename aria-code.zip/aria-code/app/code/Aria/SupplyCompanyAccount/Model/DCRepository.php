<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\DCRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCInterfaceFactory;
use Aria\SupplyCompanyAccount\Api\Data\DCSearchResultsInterfaceFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DC as ResourceDC;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DC\CollectionFactory as DCCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserroleMapping\CollectionFactory as DCUserroleMappingCollectionFactory;
use Magento\Framework\Exception\AuthorizationException;
use Aria\SupplyCompanyAccount\Helper\Data as HelperData;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCRolePermissionMapping\CollectionFactory as DCRolePermissionMappingCollectionFactory;
use Aria\SupplyCompanyAccount\Model\VacationFactory as VacationFactoryModel;
use Aria\SupplyCompanyAccount\Model\ResourceModel\Vacation as VacationResourceModel;
use Aria\SupplyCompanyAccount\Model\DCUserFactory as DCUserFactory;
use DateTime;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUser\CollectionFactory as DCUserCollectionFactory;
use Aria\SupplyCompanyAccount\Model\VacationRepository as DCVacationRepository;
use Aria\SupplyCompanyAccount\Api\VacationRepositoryInterface as VacationRepository;
use Aria\Venue\Api\VenueUserRoleMappingRepositoryInterface;
use Aria\Venue\Api\VenueRolePermissionMappingRepositoryInterface;
use Aria\Venue\Model\ResourceModel\VenueRolePermissionMapping\CollectionFactory as VenueRolePermissionMappingCollectionFactory;

class DCRepository implements DCRepositoryInterface
{

    protected $dCCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;
    protected $dCFactory;

    protected $searchResultsFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataDCFactory;

    protected $dcUserroleMappingCollectionFactory;

    protected $helper;

    protected $vacationRepository;

    protected $venueUserRoleMappingRepositoryInterface;
    protected $venueRolePermissionMappingRepositoryInterface;
    protected $_date;
    protected $venueRolePermissionMappingCollectionFactory;


    public function __construct(
        ResourceDC $resource,
        DCFactory $dCFactory,
        DCInterfaceFactory $dataDCFactory,
        DCCollectionFactory $dCCollectionFactory,
        DCSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        DCUserroleMappingCollectionFactory $dcUserroleMappingCollectionFactory,
        HelperData $helper,
        VacationFactoryModel $vacationFactoryModel,
        VacationResourceModel $vacationResourceModel,
        \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface,
        DCRolePermissionMappingCollectionFactory $dcRolePermissionMappingCollectionFactory,
        DCUserFactory $dcUserFactory,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        DCUserCollectionFactory $dCUserCollectionFactory,
        DCVacationRepository $dCVacationRepository,
        VacationRepository $vacationRepository,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory  $orderCollectionFactory,
        VenueUserRoleMappingRepositoryInterface $venueUserRoleMappingRepositoryInterface,
        VenueRolePermissionMappingRepositoryInterface $venueRolePermissionMappingRepositoryInterface,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $date,
        VenueRolePermissionMappingCollectionFactory $venueRolePermissionMappingCollectionFactory

    ) {
        $this->resource = $resource;
        $this->dCFactory = $dCFactory;
        $this->dCCollectionFactory = $dCCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataDCFactory = $dataDCFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->dcUserroleMappingCollectionFactory = $dcUserroleMappingCollectionFactory;
        $this->helper = $helper;
        $this->vacationFactoryModel = $vacationFactoryModel;
        $this->vacationResourceModel = $vacationResourceModel;
        $this->participantsRepositoryInterface = $participantsRepositoryInterface;
        $this->dcRolePermissionMappingCollectionFactory = $dcRolePermissionMappingCollectionFactory;
        $this->dcUserFactory = $dcUserFactory;
        $this->_resourceConnection = $resourceConnection;
        $this->_conn = $resourceConnection->getConnection();
        $this->dCUserCollectionFactory = $dCUserCollectionFactory;
        $this->dCVacationRepository = $dCVacationRepository;
        $this->vacationRepository = $vacationRepository;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->venueUserRoleMappingRepositoryInterface=$venueUserRoleMappingRepositoryInterface;
        $this->venueRolePermissionMappingRepositoryInterface=$venueRolePermissionMappingRepositoryInterface;
        $this->_date =  $date;
        $this->venueRolePermissionMappingCollectionFactory = $venueRolePermissionMappingCollectionFactory;


    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\DCInterface $dC
    ) {
        /* if (empty($dC->getStoreId())) {
            $storeId = $this->storeManager->getStore()->getId();
            $dC->setStoreId($storeId);
        } */

        $dCData = $this->extensibleDataObjectConverter->toNestedArray(
            $dC,
            [],
            \Aria\SupplyCompanyAccount\Api\Data\DCInterface::class
        );

        $dCModel = $this->dCFactory->create()->setData($dCData);

        try {
            $this->resource->save($dCModel);
            $dcId = $dC->getDcId();
            $dcUserId = $dC->getDcUserId();
            if ($dcId) {

                $vacation = $dC->getVacation();


                if ($vacation != null) {
                    $vacationDcId = $vacation->getDcId();
                    $vacationDetails = $this->vacationRepository->getDc($dcId);
                    $vacationId = $vacationDetails->getVacationId();
                    $this->helper->permissionCheck($dcId, $dcUserId, 'Vacation');
                    $vacationModel = $this->vacationFactoryModel->create();
                    $vacationModel->setData('vacation_id', $vacationId);
                    $vacationModel->setData('from', $vacation->getFrom());
                    $vacationModel->setData('to', $vacation->getTo());
                    $vacationModel->setData('comment', $vacation->getComment());
                    $vacationModel->setData('status', $vacation->getStatus());
                    $vacationModel->setData('is_delete', $vacation->getIsDelete());
                    $vacationModel->setData('dc_id', $dcId);

                    $this->vacationResourceModel->save($vacationModel);
                    $dateDifference = $this->getDateDifference(date("Y-m-d"), $vacationModel->getFrom());
                    if ($vacation->getStatus() == 1 ) {
                        $this->sendDcNotification($dCModel, $vacation, $dcUserId);

                        if($dateDifference < 7)
                        {
                            $this->sendVenueNotification($dCModel,$vacation);
                        }
                    }
                }
            }
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the dC: %1',
                $exception->getMessage()
            ));
        }
        return $dCModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($dCId)
    {
        $dC = $this->dCFactory->create();
        $this->resource->load($dC, $dCId);
        if (!$dC->getId()) {
            throw new NoSuchEntityException(__('DC with id "%1" does not exist.', $dCId));
        }
        $vacation = $this->dCVacationRepository->getDcVacation($dCId);

        $dC->setVacation($vacation);

        return $dC;
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->dCCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\SupplyCompanyAccount\Api\Data\DCInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($dCId)
    {
        $dCModel = $this->dCFactory->create();
        $dCModel->setData('is_delete', 1);
        $dCModel->setData('dc_id', $dCId);
        $orderCount = $dCModel->getOrderCount($dCId);
        $DCCount = $dCModel->getDCCount($dCId);
        if ($orderCount == $DCCount) {
            $dcUser = $this->dcUserroleMappingCollectionFactory->create();
            $dcUser->addFieldToFilter('dc_id', $dCId);
            foreach ($dcUser as $user) {
                $user->setIsDelete(1);
                $user->save();
            }
            $this->resource->save($dCModel);
        } else {
            throw new \Magento\Framework\Webapi\Exception(
                __('This distribution center cannot be deleted until all outstanding orders and returns have been processed'),
                0,
                \Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST
            );
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function setStatus($dCId, $isActive)
    {

        $dCModel = $this->dCFactory->create();
        $dCModel->setData('is_active', $isActive);
        $dCModel->setData('dc_id', $dCId);
        $orderCount = $dCModel->getOrderCount($dCId);
        $DCCount = $dCModel->getDCCount($dCId);
        if ($orderCount == $DCCount) {
            $this->resource->save($dCModel);
            return true;
        } else {
            throw new \Magento\Framework\Webapi\Exception(
                __('This distribution center cannot be activated/deactivated until all outstanding orders and returns have been processed'),
                0,
                \Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST
            );
        }
    }

    /**
     * {@inheritdoc}
     */
    public function isDCNameExists($name, $supplierid, $dcId = null)
    {
        $isDCnameExists = false;
        $nameCollection = $this->dCCollectionFactory->create();
        if (is_numeric($dcId)) {
            $DC = $this->get($dcId);
            $DCName = $DC->getName();
            if (strtolower($DCName) != strtolower($name)) {
                $nameCollection->addFieldToFilter('name', $name);
                $nameCollection->addFieldToFilter('supply_id', $supplierid);
                $nameCollection->addFieldToFilter('is_delete', 0);
                if ($nameCollection->count() > 0) {
                    $isDCnameExists = true;
                }
            }
            return $isDCnameExists;
        } else {
            $nameCollection->addFieldToFilter('name', $name);
            $nameCollection->addFieldToFilter('supply_id', $supplierid);
            $nameCollection->addFieldToFilter('is_delete', 0);
            if ($nameCollection->count() > 0) {
                $isDCnameExists = true;
            }
        }
        return $isDCnameExists;
    }

    public function sendDcNotification($dc, $vacation, $dcUserId)
    {
        $dCUser = $this->dcUserFactory->create();
        $dCUser->load($dcUserId, 'id');

        if ($dCUser->getIsAdmin() == 1) {
            $collection = $this->dcUserroleMappingCollectionFactory->create();
            $collection->addFieldToFilter('dc_id', $dc->getDcId());
            $collection->addFieldToFilter('is_active', 1);
            $collection->addFieldToFilter('is_delete', 0);
            $description = $dc->getName() . " will be on vacation from " .  $this->getFormattedDate($vacation->getFrom()) . " to " .  $this->getFormattedDate($vacation->getTo()) . ". No orders will be received during this period.";
            if (count($collection) >= 1) {
                foreach ($collection as $dcUser) {
                    $userId = $dcUser->getDcUserId();

                    $this->participantsRepositoryInterface->saveParticipantNotification(3, $dc->getDcId(), $userId, $description, 'dc_user', 'DC on vacation');
                }

                return true;
            }
        } else {
            $scId = $dCUser->getScId();
            $dcUserCollection = $this->dCUserCollectionFactory->create();
            $dcUserCollection->addFieldToFilter('sc_id', $scId);
            $dcUserCollection->addFieldToFilter('is_active', 1);
            $dcUserCollection->addFieldToFilter('is_delete', 0);
            $dcUserCollection->addFieldToFilter('is_admin', 1);

            $description = $dc->getName() . " will be on vacation from " .  $this->getFormattedDate($vacation->getFrom()) . " to " .  $this->getFormattedDate($vacation->getTo()) . ". No orders will be received during this period.";

            if (count($dcUserCollection) >= 1) {
                foreach ($dcUserCollection as $dcAdminUser) {
                    $adminUserId = $dcAdminUser->getId();

                    $this->participantsRepositoryInterface->saveParticipantNotification(3, $dc->getDcId(), $adminUserId, $description, 'dc_user', 'DC on vacation');
                }

                return true;
            }
        }

        return false;
    }

    public function getDateDifference($from, $to)
    {
        $from = new DateTime($from);
        $to = new DateTime($to);

        $diff = $to->diff($from)->format("%a");

        return (int)$diff;
    }

    public function sendVenueNotification($dc, $vacation)
    {
        $venueUserIdCollection=[];
        $startDate = $vacation->getFrom();
		$endDate = $vacation->getTo();
        $currentDate = $this->_date->date()->format('Y-m-d');
        $daylen = 60 * 60 * 24;
        $timestamp1 = strtotime($currentDate);
        $timestamp2 = strtotime($startDate);
        $duration = ($timestamp2 - $timestamp1) / $daylen;
        $salesOrderDetails = $this->_orderCollectionFactory->create();
        $orderDetails = $salesOrderDetails->addFieldToFilter('dcid', $dc->getDcId());
        $orderGroupIds = $orderDetails->addFieldToSelect('group_order_id');
        $orderGroupIdCollection = $orderGroupIds->getData();
        $ids = array_column($orderGroupIdCollection, 'group_order_id');
        $orderGroupIdList = array_unique($ids);

        foreach ($orderGroupIdList as $orderGroupId) {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $orderGroupmodel = $objectManager->create(\Aria\Order\Model\SalesOrderGroup::class);
            $orderGroupDetails = $orderGroupmodel->load($orderGroupId,'order_group_id');
            $createdDate = $orderGroupDetails->getCreatedAt();
            $createdDateTime = strtotime($createdDate);
            $currentYear = date('Y', $timestamp1);
            $orderYear = date('Y', $createdDateTime);
            $currentMonth = date('m', $timestamp1);
            $orderMonth = date('m', $createdDateTime);
            $monthDifference = (($currentYear - $orderYear) * 12) + ($currentMonth - $orderMonth);
            $venueUserId = $orderGroupDetails->getVenueUserId();
            $venueId = $orderGroupDetails->getVenueId();
            $roleId=$this->venueUserRoleMappingRepositoryInterface->getVenueUserRole($venueUserId,$venueId);
            if($roleId)
            {
                $venueRolePermissionMapping = $this->venueRolePermissionMappingCollectionFactory->create();
                $venueRolePermissionMapping->addFieldToFilter('role_id',$roleId,'permission_id',42);
                if(count($venueRolePermissionMapping)==0)
                {
                    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                    $venueUserRoleDetails = $objectManager->create('Aria\Venue\Api\Data\VenueRolePermissionMappingInterface');
                    $venueUserRoleDetails->setRoleId($roleId)
                    ->setPermissionId(42)
                    ->setParentId(0)
                    ->setIsActive(1)
                    ->setIsGranted(1);
                    $this->venueRolePermissionMappingRepositoryInterface->save($venueUserRoleDetails);
                }
            }
            if (abs($monthDifference) <= 6) {
                $venueUserIdCollection[] = $venueUserId;
            }
        }
        $description = $dc->getName() . " will be on vacation from " . $this->getFormattedDate($vacation->getFrom()) . " to " .  $this->getFormattedDate($vacation->getTo()) . ". Message from supplier: " .$vacation->getComment();
        $venueUserIdList = array_unique($venueUserIdCollection);
        foreach ($venueUserIdList as $venueuserIds) {
            $this->participantsRepositoryInterface->saveParticipantNotification(3, $venueId, $venueuserIds, $description, 'venue_user', 'DC on vacation');
        }

        return true;
    }

    public function getFormattedDate($date)
    {
        $date = date_create($date);
        return date_format($date,"d/m/Y");
    }
}
