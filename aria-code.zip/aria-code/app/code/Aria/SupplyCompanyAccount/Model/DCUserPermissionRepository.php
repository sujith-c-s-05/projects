<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;
use Aria\SupplyCompanyAccount\Api\DCUserPermissionRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterfaceFactory;
use Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionSearchResultsInterfaceFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserPermission as ResourceDCUserPermission;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserPermission\CollectionFactory as DCUserPermissionCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;

class DCUserPermissionRepository implements DCUserPermissionRepositoryInterface
{

    protected $dCUserPermissionCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;
    protected $dCUserPermissionFactory;

    protected $searchResultsFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataDCUserPermissionFactory;
   

    /**
     * @param ResourceDCUserPermission $resource
     * @param DCUserPermissionFactory $dCUserPermissionFactory
     * @param DCUserPermissionInterfaceFactory $dataDCUserPermissionFactory
     * @param DCUserPermissionCollectionFactory $dCUserPermissionCollectionFactory
     * @param DCUserPermissionSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     */
    public function __construct(
        ResourceDCUserPermission $resource,
        DCUserPermissionFactory $dCUserPermissionFactory,
        DCUserPermissionInterfaceFactory $dataDCUserPermissionFactory,
        DCUserPermissionCollectionFactory $dCUserPermissionCollectionFactory,
        DCUserPermissionSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter
    ) {
        $this->resource = $resource;
        $this->dCUserPermissionFactory = $dCUserPermissionFactory;
        $this->dCUserPermissionCollectionFactory = $dCUserPermissionCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataDCUserPermissionFactory = $dataDCUserPermissionFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
    }

   
    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->dCUserPermissionCollectionFactory->create();
        
        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface::class
        );
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function get($Id)
    {
        $dCPermission = $this->dCUserPermissionFactory->create();
        $this->resource->load($dCPermission, $Id);
        if (!$dCPermission->getId()) {
            throw new NoSuchEntityException(__('DC User Permission with id "%1" does not exist.', $Id));
        }
        return $dCPermission->getDataModel();
    }


}