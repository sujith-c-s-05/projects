<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\Data\DCUserInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCUserInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class DCUser extends \Magento\Framework\Model\AbstractModel
{

    protected $dcUserDataFactory;

    protected $_eventPrefix = 'aria_dc_user';
    protected $dataObjectHelper;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param DCUserInterfaceFactory $dcDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUser $resource
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUser\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        DCUserInterfaceFactory $dcUserDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUser $resource,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUser\Collection $resourceCollection,
        array $data = []
    ) {
        $this->dcUserDataFactory = $dcUserDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve dc user  model with user role data
     * @return DCUserInterface
     */
    public function getDataModel()
    {
        $dcUserData = $this->getData();
        
        $dcUserDataObject = $this->dcUserDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $dcUserDataObject,
            $dcUserData,
            DCUserInterface::class
        );
        
        return $dcUserDataObject;
    }


}
