<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\DCUserroleMappingRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterfaceFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserroleMapping as ResourceDCUserroleMapping;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserroleMapping\CollectionFactory as DCUserroleMappingCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;

class DCUserroleMappingRepository implements DCUserroleMappingRepositoryInterface
{

    protected $dcUserroleMappingCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;

    protected $dcUserroleMappingFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataDCUserroleMappingFactory;

    protected $dcUserroleRepositoryInterface;
    /**
     * @param ResourceDCUserroleMapping $resource
     * @param DCUserroleMappingFactory $dcUserroleMappingFactory
     * @param DCUserroleMappingInterfaceFactory $dataDCUserroleMappingFactory
     * @param DCUserroleMappingCollectionFactory $dcUserroleMappingCollectionFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param \Aria\SupplyCompanyAccount\Api\DCUserroleRepositoryInterface $dcUserroleRepositoryInterface
     */
    public function __construct(
        ResourceDCUserroleMapping $resource,
        DCUserroleMappingFactory $dcUserroleMappingFactory,
        DCUserroleMappingInterfaceFactory $dataDCUserroleMappingFactory,
        DCUserroleMappingCollectionFactory $dcUserroleMappingCollectionFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Aria\SupplyCompanyAccount\Api\DCUserroleRepositoryInterface $dcUserroleRepositoryInterface
    ) {
        $this->resource = $resource;
        $this->dcUserroleMappingFactory = $dcUserroleMappingFactory;
        $this->dcUserroleMappingCollectionFactory = $dcUserroleMappingCollectionFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataDCUserroleMappingFactory = $dataDCUserroleMappingFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->dcUserroleRepositoryInterface = $dcUserroleRepositoryInterface;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface $dcUserroleMapping
    ) {
        
        $dcUserroleMappingData = $this->extensibleDataObjectConverter->toNestedArray(
            $dcUserroleMapping,
            [],
            \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface::class
        );
        $dcUserroleMappingModel = $this->dcUserroleMappingFactory->create()->setData($dcUserroleMappingData);
        

        try {
            $this->resource->save($dcUserroleMappingModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the dc user role: %1',
                $exception->getMessage()
            ));
        }
        return $dcUserroleMappingModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function activateDeactivateDCUserRoleMapping($dcUserId,$isActive) {
        try {
                $dCUserRoleMappingCollection =$this->dcUserroleMappingCollectionFactory->create();
                $dCUserRoleMappingCollection->addFieldToFilter('dc_user_id',$dcUserId);
                foreach ($dCUserRoleMappingCollection as $model) {
                    $dCRoleMapping = $model->setIsActive($isActive);
                    $this->resource->save($dCRoleMapping);
                }
        }catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not activate the dc user role',
                $exception->getMessage()
            ));
        }
        return true;
    }
    
    /**
     * {@inheritdoc}
     */
    public function getDCUserroleMappings($id)
    { 
        $dCRole = $this->dcUserroleMappingCollectionFactory->create();
        $dCRole->addFieldToFilter('dc_user_id',$id);
        $items = [];
        foreach ($dCRole as $model) {
            $dcId=$model->getDcId();
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $dcmodel = $objectManager->create(\Aria\SupplyCompanyAccount\Model\DC::class);
            $dcEntity = $dcmodel->load($dcId,'dc_id');
            $roleId=$model->getRoleId();
            $dcUserRoleEntity=$this->dcUserroleRepositoryInterface->get($roleId);
            $model->setDcName($dcEntity->getName());
            $model->setRoleName($dcUserRoleEntity->getRoleName());
            $items[] = $model->getDataModel();
        }
        return $items;
    }

     /**
     * {@inheritdoc}
     */
    public function deleteDCUserroleMapping($dcUserId)
    { 
        $dCUserroleMapping = $this->dcUserroleMappingCollectionFactory->create();
        $dCUserroleMapping->addFieldToFilter('dc_user_id',$dcUserId);
        foreach ($dCUserroleMapping as $model) {
            $this->resource->delete($model);
        }
        
        return true;
        
    }

    public function getDCUserRole($dcUserId,$dc_id)
    {
        $dcRole = $this->dcUserroleMappingCollectionFactory->create();
        $dcRole->addFieldToFilter('dc_user_id',$dcUserId)->addFieldToFilter('dc_id',$dc_id);
        foreach ($dcRole as $model) {

            $roleId=$model->getRoleId();
            
        }
        return $roleId;
    }

    public function getDCUsers($dc_id){
        $dcRole = $this->dcUserroleMappingCollectionFactory->create();
        $dcRole->addFieldToFilter('dc_id',$dc_id);
        $dcusers =[];
        foreach ($dcRole as $model) {

            $dcusers[]=$model->getDcUserId();
            
        }
        return $dcusers;
    }
}