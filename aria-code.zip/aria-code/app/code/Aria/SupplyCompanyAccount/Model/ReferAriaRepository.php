<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\ReferAriaRepositoryInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;

class ReferAriaRepository implements ReferAriaRepositoryInterface
{
    /**
    * @var \Magento\Framework\Mail\Template\TransportBuilder
    */
    protected $_transportBuilder;

    /** 
    * @var \Magento\Framework\Translate\Inline\StateInterface
    */
    protected $inlineTranslation;

    /** 
    * @var \Magento\Framework\App\Config\ScopeConfigInterface
    */
    protected $scopeConfig;

    /**
    * @var \Magento\Store\Model\StoreManagerInterface
    */
    protected $storeManager;
    /**
    * @var \Magento\Framework\Escaper
    */
    protected $_escaper;

    public $customerRepository;

    protected $dCUserRepository;


    /**
     * Undocumented function
     *
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Escaper $escaper
     * @param CustomerRepositoryInterface $customerRepository
     * @param \Aria\SupplyCompanyAccount\Api\DCUserRepositoryInterface $dCUserRepository
     */
    public function __construct(
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Escaper $escaper,
        CustomerRepositoryInterface $customerRepository,
        \Aria\SupplyCompanyAccount\Api\DCUserRepositoryInterface $dCUserRepository

    ) {
        $this->_transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_escaper = $escaper;
        $this->customerRepository = $customerRepository;
        $this->dCUserRepository=$dCUserRepository;
    }

    /**
     * Refer Aria function
     *
     * @param \Aria\SupplyCompanyAccount\Api\Data\ReferAriaInterface $refer
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function referAria($referAria)
    {
        $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId());
        $dcUserId = $referAria->getUserId();
        $dcUserDetails=$this->dCUserRepository->get($dcUserId);
        $userId=$dcUserDetails->getDcUserId();
        $receiverEmail=$referAria->getReceiverEmail();
        $userDetails=$this->customerRepository->getById($userId);
        $senderName=$userDetails->getFirstName(). ' ' .$userDetails->getLastName();
        // $senderEmail=$userDetails->getEmail();
        $senderEmail = $this->scopeConfig->getValue('trans_email/ident_support/email',ScopeInterface::SCOPE_STORE);
        $url = $this->scopeConfig->getValue('url/general/base_url',ScopeInterface::SCOPE_STORE);
        $this->inlineTranslation->suspend();
        $templateVars = array(
             'senderName' => $senderName,
             'url'=>$url
         );  
         $from = [
            'email' => $senderEmail,
            'name' => $senderName
         ];
         $transport = $this->_transportBuilder->setTemplateIdentifier('aria_refer_register_template',ScopeInterface::SCOPE_STORE)
         ->setTemplateOptions($templateOptions)
         ->setTemplateVars($templateVars)
         ->setFrom($from)
         ->addTo($receiverEmail)

         ->getTransport();
         $transport->sendMessage();
         $this->inlineTranslation->resume();
         return true;

    }

}