<?php
namespace Aria\SupplyCompanyAccount\Model;

class Country implements \Magento\Framework\Data\OptionSourceInterface {
    /**
     * @var  \Magento\Directory\Model\ResourceModel\Country\CollectionFactory
     */
    protected $_collectionFactory;

    /**
     * @var array|null
     */
    protected $_options;

    public function __construct(
        \Magento\Directory\Model\ResourceModel\Country\CollectionFactory $collectionFactory
    ) {
        $this->_collectionFactory = $collectionFactory;
    }

    /**
     * @return array
     */
    public function toOptionArray() {
        if ($this->_options === null) {
            $collection = $this->_collectionFactory->create();

            $this->_options = [['label' => '', 'value' => '']];

            foreach ($collection as $country) {
                $this->_options[] = [
                    'label' => $country->getName(),
                    'value' => $country->getName()
                ];
            }
        }

        return $this->_options;
    }
}