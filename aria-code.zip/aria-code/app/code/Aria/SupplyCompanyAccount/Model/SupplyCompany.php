<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface;
use Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class SupplyCompany extends \Magento\Framework\Model\AbstractModel
{

    protected $supplycompanyDataFactory;

    protected $dataObjectHelper;

    protected $_eventPrefix = 'aria_supplycompanyaccount_supplycompany';

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param SupplyCompanyInterfaceFactory $supplycompanyDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany $resource
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        SupplyCompanyInterfaceFactory $supplycompanyDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany $resource,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany\Collection $resourceCollection,
        array $data = []
    ) {
        $this->supplycompanyDataFactory = $supplycompanyDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve supplycompany model with supply company data
     * @return SupplyCompanyInterface
     */
    public function getDataModel()
    {
        $supplycompanyData = $this->getData();
        
        $supplycompanyDataObject = $this->supplycompanyDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $supplycompanyDataObject,
            $supplycompanyData,
            SupplyCompanyInterface::class
        );
        
        return $supplycompanyDataObject;
    }
}

