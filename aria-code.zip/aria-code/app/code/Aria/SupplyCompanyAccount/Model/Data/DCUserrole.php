<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model\Data;

use Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface;

class DCUserrole extends \Magento\Framework\Api\AbstractExtensibleObject implements DCUserroleInterface
{

    /**
     * Get id
     * @return int|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param int $Id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setId($Id)
    {
        return $this->setData(self::ID, $Id);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserroleExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserroleExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

     /**
     * Get supply_id
     * @return int|null
     */
    public function getSupplyId()
    {
        return $this->_get(self::SUPPLY_ID);
    }

    /**
     * Set supply_id
     * @param int $supplyId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setSupplyId($supplyId)
    {
        return $this->setData(self::SUPPLY_ID, $supplyId);
    }

    /**
    * Get dc role permission mapping info
    * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface[]
    */
    public function getDcRolePermissionMapping()
    {
        return $this->_get('aria_dc_role_permission_mapping');
    }

    /**
    * Set dc role permission mapping info
    * @param \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface[] $dcRolePermissionMapping
    * @return \Aria\SupplyCompanyAccount\Api\Data\DCRolePermissionMappingInterface[]
    */
    public function setDcRolePermissionMapping(array $dcRolePermissionMapping = null)
    {   
        return $this->setData('aria_dc_role_permission_mapping',$dcRolePermissionMapping );  
    }
    /**
     * Get role_name
     * @return string|null
     */
    public function getRoleName()
    {
        return $this->_get(self::ROLE_NAME);
    }

    /**
     * Set role_name
     * @param string $rolename
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setRoleName($rolename)
    {
        return $this->setData(self::ROLE_NAME, $rolename);
    }

    /**
     * Get description
     * @return string|null
     */
    public function getDescription()
    {
        return $this->_get(self::DESCRIPTION);
    }

    /**
     * Set description
     * @param string $description
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }

    /**
     * Get is_delete
     * @return bool|null
     */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleInterface
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }

    
}