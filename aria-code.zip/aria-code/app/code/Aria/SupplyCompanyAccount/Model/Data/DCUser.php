<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model\Data;

use Aria\SupplyCompanyAccount\Api\Data\DCUserInterface;

class DCUser extends \Magento\Framework\Api\AbstractExtensibleObject implements DCUserInterface
{

    /**
     * Get id
     * @return int|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param int $Id
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setId($Id)
    {
        return $this->setData(self::ID, $Id);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplyCompanyAccount\Api\Data\DCUserExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
    * Get dc user role info
    * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface[]
    */
    public function getDcUserroleMapping()
    {
        return $this->_get('aria_user_dc_role_mapping');
    }

    /**
    * Set dc user role info
    * @param \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface[] $dcUserroleMapping
    * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserroleMappingInterface[]
    */
    public function setDcUserroleMapping(array $dcUserroleMapping = null)
    {   
        return $this->setData('aria_user_dc_role_mapping',$dcUserroleMapping );  
    }

     /**
     * Get dc_user_id
     * @return int|null
     */
    public function getDcUserId()
    {
        return $this->_get(self::DC_USER_ID);
    }

     /**
     * Set dc_user_id
     * @param int $getdcUserId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setDcUserId($dcUserId)
    {
        return $this->setData(self::DC_USER_ID, $dcUserId);
    }

    
     /**
     * Get first_name
     * @return string|null
     */
    public function getFirstName()
    {
        return $this->_get(self::FIRST_NAME);
    }

     /**
     * Set first_name
     * @param string $firstName
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setFirstName($firstName)
    {
        return $this->setData(self::FIRST_NAME, $firstName);
    }

     /**
     * Get last_name
     * @return string|null
     */
    public function getLastName()
    {
        return $this->_get(self::LAST_NAME);
    }

     /**
     * Set last_name
     * @param string $lastName
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setLastName($lastName)
    {
        return $this->setData(self::LAST_NAME, $lastName);
    }

     /**
     * Get dc_user_email
     * @return string|null
     */
    public function getDcUserEmail()
    {
        return $this->_get(self::DC_USER_EMAIL);
    }

     /**
     * Set dc_user_email
     * @param string $dcUserEmail
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setDcUserEmail($dcUserEmail)
    {
        return $this->setData(self::DC_USER_EMAIL, $dcUserEmail);
    }

     /**
     * Get phone
     * @return string|null
     */
    public function getPhone()
    {
        return $this->_get(self::PHONE);
    }

     /**
     * Set phone
     * @param string $phone
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setPhone($phone)
    {
        return $this->setData(self::PHONE, $phone);
    }

    /**
     * Get gender
     * @return string|null
     */
    public function getGender()
    {
        return $this->_get(self::GENDER);
    }

    /**
     * Set gender
     * @param string $gender
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setGender($gender)
    {
        return $this->setData(self::GENDER, $gender);
    }
    
     /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

     /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }

    /**
     * Get is_delete
     * @return bool|null
     */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }

    /**
     * Get sc_id
     * @return int|null
     */
    public function getScId()
    {
        return $this->_get(self::SC_ID);
    }

    /**
     * Set sc_id
     * @param int $scId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
     */
    public function setScId($scId)
    {
        return $this->setData(self::SC_ID, $scId);
    }

    /**
    * Get is_admin
    * @return int|null
    */
    public function getIsAdmin()
    {
        return $this->_get('is_admin');
    }
 
    /**
    * Set is_admin
    * @param string $isAdmin
    * @return \Aria\SupplyCompanyAccount\Api\Data\DCUserInterface
    */
    public function setIsAdmin($isAdmin)
    {
        return $this->setData('is_admin', $isAdmin);
    }
    
}