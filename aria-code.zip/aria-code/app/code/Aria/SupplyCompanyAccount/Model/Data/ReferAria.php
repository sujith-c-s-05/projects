<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model\Data;

use Aria\SupplyCompanyAccount\Api\Data\ReferAriaInterface;

class ReferAria extends \Magento\Framework\Api\AbstractExtensibleObject implements ReferAriaInterface
{

    /**
     * Get user id
     * @return int|null
     */
    public function getUserId()
    {
        return $this->_get(self::USER_ID);
    }

    /**
     * Set user id
     * @param int $userId
     * @return \Aria\SupplyCompanyAccount\Api\Data\ReferAriaInterface
     */
    public function setUserId($userId)
    {
        return $this->setData(self::USER_ID, $userId);
    }

    /**
     * Get Receiver Email
     * @return string|null
     */
    public function getReceiverEmail()
    {
        return $this->_get(self::RECEIVER);
    }

    /**
     * Set Receiver Email
     * @param string $receiverEmail
     * @return \Aria\SupplyCompanyAccount\Api\Data\ReferAriaInterface
     */
    public function setReceiverEmail($receiverEmail)
    {
        return $this->setData(self::RECEIVER, $receiverEmail);
    }
}