<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model\Data;

use Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface;

class SupplyCompany extends \Magento\Framework\Api\AbstractExtensibleObject implements SupplyCompanyInterface
{

    /**
     * Get supplycompany_id
     * @return string|null
     */
    public function getSupplycompanyId()
    {
        return $this->_get(self::SUPPLYCOMPANY_ID);
    }

    /**
     * Set supplycompany_id
     * @param string $supplycompanyId
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setSupplycompanyId($supplycompanyId)
    {
        return $this->setData(self::SUPPLYCOMPANY_ID, $supplycompanyId);
    }

    /**
     * Get company_name
     * @return string|null
     */
    public function getCompanyName()
    {
        return $this->_get(self::COMPANY_NAME);
    }

    /**
     * Set company_name
     * @param string $companyName
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCompanyName($companyName)
    {
        return $this->setData(self::COMPANY_NAME, $companyName);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get website_id
     * @return string|null
     */
    public function getWebsiteId()
    {
        return $this->_get(self::WEBSITE_ID);
    }

    /**
     * Set website_id
     * @param string $websiteId
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setWebsiteId($websiteId)
    {
        return $this->setData(self::WEBSITE_ID, $websiteId);
    }

    /**
     * Get website_url
     * @return string|null
     */
    public function getWebsiteUrl()
    {
        return $this->_get(self::WEBSITE_URL);
    }

    /**
     * Set website_url
     * @param string $websiteUrl
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setWebsiteUrl($websiteUrl)
    {
        return $this->setData(self::WEBSITE_URL, $websiteUrl);
    }


    /**
     * Get status
     * @return string|null
     */
    public function getStatus()
    {
        return $this->_get(self::STATUS);
    }

    /**
     * Set status
     * @param string $status
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * Get company_email
     * @return string|null
     */
    public function getCompanyEmail()
    {
        return $this->_get(self::COMPANY_EMAIL);
    }

    /**
     * Set company_email
     * @param string $companyEmail
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCompanyEmail($companyEmail)
    {
        return $this->setData(self::COMPANY_EMAIL, $companyEmail);
    }

    /**
     * Get sales_rep
     * @return string|null
     */
    public function getSalesRep()
    {
        return $this->_get(self::SALES_REP);
    }

    /**
     * Set sales_rep
     * @param string $salesRep
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setSalesRep($salesRep)
    {
        return $this->setData(self::SALES_REP, $salesRep);
    }

    /**
     * Get company_legal_name
     * @return string|null
     */
    public function getCompanyLegalName()
    {
        return $this->_get(self::COMPANY_LEGAL_NAME);
    }

    /**
     * Set company_legal_name
     * @param string $companyLegalName
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCompanyLegalName($companyLegalName)
    {
        return $this->setData(self::COMPANY_LEGAL_NAME, $companyLegalName);
    }

    /**
     * Get vat_id
     * @return string|null
     */
    public function getVatId()
    {
        return $this->_get(self::VAT_ID);
    }

    /**
     * Set vat_id
     * @param string $vatId
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setVatId($vatId)
    {
        return $this->setData(self::VAT_ID, $vatId);
    }

    /**
     * Get reseller_id
     * @return string|null
     */
    public function getResellerId()
    {
        return $this->_get(self::RESELLER_ID);
    }

    /**
     * Set reseller_id
     * @param string $resellerId
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setResellerId($resellerId)
    {
        return $this->setData(self::RESELLER_ID, $resellerId);
    }

    /**
     * Get comment
     * @return string|null
     */
    public function getComment()
    {
        return $this->_get(self::COMMENT);
    }

    /**
     * Set comment
     * @param string $comment
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setComment($comment)
    {
        return $this->setData(self::COMMENT, $comment);
    }

    /**
     * Get street_address
     * @return string|null
     */
    public function getStreetAddress()
    {
        return $this->_get(self::STREET_ADDRESS);
    }

    /**
     * Set street_address
     * @param string $streetAddress
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setStreetAddress($streetAddress)
    {
        return $this->setData(self::STREET_ADDRESS, $streetAddress);
    }

    /**
     * Get city
     * @return string|null
     */
    public function getCity()
    {
        return $this->_get(self::CITY);
    }

    /**
     * Set city
     * @param string $city
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCity($city)
    {
        return $this->setData(self::CITY, $city);
    }

    /**
     * Get country
     * @return string|null
     */
    public function getCountry()
    {
        return $this->_get(self::COUNTRY);
    }

    /**
     * Set country
     * @param string $country
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCountry($country)
    {
        return $this->setData(self::COUNTRY, $country);
    }
    
    /**
     * Get state
     * @return string|null
     */
    public function getState()
    {
        return $this->_get(self::STATE);
    }

    /**
     * Set state
     * @param string $state
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setState($state)
    {
        return $this->setData(self::STATE, $state);
    }

    /**
     * Get zip_code
     * @return string|null
     */
    public function getZipCode()
    {
        return $this->_get(self::ZIP_CODE);
    }

    /**
     * Set zip_code
     * @param string $zipCode
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setZipCode($zipCode)
    {
        return $this->setData(self::ZIP_CODE, $zipCode);
    }

    /**
     * Get phone_no
     * @return string|null
     */
    public function getPhoneNo()
    {
        return $this->_get(self::PHONE_NO);
    }

    /**
     * Set phone_no
     * @param string $phoneNo
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setPhoneNo($phoneNo)
    {
        return $this->setData(self::PHONE_NO, $phoneNo);
    }

    /**
     * Get job_title
     * @return string|null
     */
    public function getJobTitle()
    {
        return $this->_get(self::JOB_TITLE);
    }

    /**
     * Set job_title
     * @param string $jobTitle
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setJobTitle($jobTitle)
    {
        return $this->setData(self::JOB_TITLE, $jobTitle);
    }

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get mov
     * @return int|null
     */
    public function getMov()
    {
        return $this->_get(self::MOV);
    }

    /**
     * Set mov
     * @param int $mov
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setMov($mov)
    {
        return $this->setData(self::MOV, $mov);
    }

     /**
     * Get return_time_period
     * @return int|null
     */
    public function getReturnTimePeriod()
    {
        return $this->_get(self::RETURN_TIME_PERIOD);
    }

    /**
     * Set return_time_period
     * @param int $returnTimePeriod
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setReturnTimePeriod($returnTimePeriod)
    {
        return $this->setData(self::RETURN_TIME_PERIOD, $returnTimePeriod);
    }


    /**
     * Get is_active
     * @return string|null
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param string $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }
    
    /**
     * Get company admin
     *
     * @return int
     */
    public function getCompanyAdmin()
    {
        return $this->_get(self::COMPANY_ADMIN);
    }

    /**
     * Undocumented function
     *
     * @param int $companyAdmin
     * @return int
     */
    public function setCompanyAdmin($companyAdmin)
    {
        return $this->setData(self::COMPANY_ADMIN, $companyAdmin);
    }

     /**
     * Get countdown_timer
     * @return string|null
     */
    public function getCountdownTimer()
    {
        return $this->_get(self::COUNTDOWN_TIMER);
    }

    /**
     * Set countdown_timer
     * @param string $countdownTimer
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setCountdownTimer($countdownTimer)
    {
        return $this->setData(self::COUNTDOWN_TIMER, $countdownTimer);
    }

    /**
     * Get delivery_cost
     * @return bool|null
     */
    public function getDeliveryCost()
    {
        return $this->_get(self::DELIVERY_COST);
    }

    /**
     * Set delivery_cost
     * @param bool $deliveryCost
     * @return \Aria\SupplyCompanyAccount\Api\Data\SupplyCompanyInterface
     */
    public function setDeliveryCost($deliveryCost)
    {
        return $this->setData(self::DELIVERY_COST, $deliveryCost);
    }
}