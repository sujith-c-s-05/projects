<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model\Data;

use Aria\SupplyCompanyAccount\Api\Data\DCInterface;

class DC extends \Magento\Framework\Api\AbstractExtensibleObject implements DCInterface
{

    /**
     * Get dc_id
     * @return int|null
     */
    public function getDcId()
    {
        return $this->_get(self::DC_ID);
    }

    /**
     * Set dc_id
     * @param int $dcId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setDcId($dcId)
    {
        return $this->setData(self::DC_ID, $dcId);
    }

    /**
     * Get supply_id
     * @return int|null
     */
    public function getSupplyId()
    {
        return $this->_get(self::SUPPLY_ID);
    }

    /**
     * Set supply_id
     * @param int $supplyId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setSupplyId($supplyId)
    {
        return $this->setData(self::SUPPLY_ID, $supplyId);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\SupplyCompanyAccount\Api\Data\DCExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\SupplyCompanyAccount\Api\Data\DCExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get name
     * @return string|null
     */
    public function getName()
    {
        return $this->_get(self::NAME);
    }

    /**
     * Set name
     * @param string $name
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     * Get description
     * @return string|null
     */
    public function getDescription()
    {
        return $this->_get(self::DESCRIPTION);
    }

    /**
     * Set description
     * @param string $description
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }

    /**
     * Get address
     * @return string|null
     */
    public function getAddress()
    {
        return $this->_get(self::ADDRESS);
    }

    /**
     * Set address
     * @param string $address
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setAddress($address)
    {
        return $this->setData(self::ADDRESS, $address);
    }

    /**
     * Get email
     * @return string|null
     */
    public function getEmail()
    {
        return $this->_get(self::EMAIL);
    }

    /**
     * Set email
     * @param string $email
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setEmail($email)
    {
        return $this->setData(self::EMAIL, $email);
    }

    /**
     * Get phone
     * @return string|null
     */
    public function getPhone()
    {
        return $this->_get(self::PHONE);
    }

    /**
     * Set phone
     * @param string $phone
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setPhone($phone)
    {
        return $this->setData(self::PHONE, $phone);
    }

    /**
     * Get zip_code
     * @return string|null
     */
    public function getZipCode()
    {
        return $this->_get(self::ZIP_CODE);
    }

    /**
     * Set zip_code
     * @param string $zipCode
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setZipCode($zipCode)
    {
        return $this->setData(self::ZIP_CODE, $zipCode);
    }

    /**
     * Get latitude
     * @return float|null
     */
    public function getLatitude()
    {
        return $this->_get(self::LATITUDE);
    }

    /**
     * Set latitude
     * @param float $latitude
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setLatitude($latitude)
    {
        return $this->setData(self::LATITUDE, $latitude);
    }

    /**
     * Get longitude
     * @return float|null
     */
    public function getLongitude()
    {
        return $this->_get(self::LONGITUDE);
    }

    /**
     * Set longitude
     * @param float $longitude
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setLongitude($longitude)
    {
        return $this->setData(self::LONGITUDE, $longitude);
    }

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }

    /**
     * Get store_id
     * @return int|null
     */
    public function getStoreId()
    {
        return $this->_get(self::STORE_ID);
    }

    /**
     * Set store_id
     * @param int $storeId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setStoreId($storeId)
    {
        return $this->setData(self::STORE_ID, $storeId);
    }
     /**
     * Get is_delete
     * @return bool|null
     */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }

    /**
     * Get contact_name
     * @return string|null
     */
    public function getContactName()
    {
        return $this->_get(self::CONTACT_NAME);
    }

    /**
     * Set contact_name
     * @param string $contact_name
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setContactName($contact_name)
    {
        return $this->setData(self::CONTACT_NAME, $contact_name);
    }

    /**
     * Get city
     * @return string|null
     */
    public function getCity()
    {
        return $this->_get(self::CITY);
    }

    /**
     * Set city
     * @param string $city
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setCity($city)
    {
        return $this->setData(self::CITY, $city);
    }

    /**
     * Get state
     * @return string|null
     */
    public function getState()
    {
        return $this->_get(self::STATE);
    }

    /**
     * Set state
     * @param string $state
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setState($state)
    {
        return $this->setData(self::STATE, $state);
    }

    /**
     * Get country
     * @return string|null
     */
    public function getCountry()
    {
        return $this->_get(self::COUNTRY);
    }

    /**
     * Set country
     * @param string $country
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setCountry($country)
    {
        return $this->setData(self::COUNTRY, $country);
    }

    /**
     * Get contact_person_phone
     * @return string|null
     */
    public function getContactPersonPhone()
    {
        return $this->_get(self::CONTACT_PERSON_PHONE);
    }

    /**
     * Set contact_person_phone
     * @param string $contact_person_phone
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setContactPersonPhone($contact_person_phone)
    {
        return $this->setData(self::CONTACT_PERSON_PHONE, $contact_person_phone);
    }

    /**
     * Get delivery_location
     * @return string|null
     */
    public function getDeliveryLocation()
    {
        return $this->_get(self::DELIVERY_LOCATION);
    }

    /**
     * Set delivery_location
     * @param string $delivery_location
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setDeliveryLocation($delivery_location)
    {
        return $this->setData(self::DELIVERY_LOCATION, $delivery_location);
    }

    /**
    * Get dc vacation
    * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface|null
    */
    public function getVacation()
    {
        return $this->_get('vacation');
    }

    /**
    * Set dc vacation
    * @param \Aria\SupplyCompanyAccount\Api\Data\VacationInterface $vacation
    * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface $vacation
    */
    public function setVacation(\Aria\SupplyCompanyAccount\Api\Data\VacationInterface $vacation = null)
    {   
        return $this->setData('vacation',$vacation );  
    }

    /**
     * Get dc_user_id
     * @return int|null
     */
    public function getDcUserId()
    {
        return $this->_get(self::DC_USER_ID);
    }

    /**
     * Set dc_user_id
     * @param int $dcUserId
     * @return \Aria\SupplyCompanyAccount\Api\Data\DCInterface
     */
    public function setDcUserId($dcUserId)
    {
        return $this->setData(self::DC_USER_ID, $dcUserId);
    }


}