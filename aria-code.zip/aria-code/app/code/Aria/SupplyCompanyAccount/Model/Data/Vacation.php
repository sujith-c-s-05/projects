<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model\Data;

use Aria\SupplyCompanyAccount\Api\Data\VacationInterface;

class Vacation extends \Magento\Framework\Api\AbstractExtensibleObject implements VacationInterface
{

    /**
     * Get vacation_id
     * @return string|null
     */
    public function getVacationId()
    {
        return $this->_get(self::VACATION_ID);
    }

    /**
     * Set vacation_id
     * @param string $vacationId
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setVacationId($vacationId)
    {
        return $this->setData(self::VACATION_ID, $vacationId);
    }

    /**
     * Get from
     * @return string|null
     */
    public function getFrom()
    {
        return $this->_get(self::FROM);
    }

    /**
     * Set from
     * @param string $from
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setFrom($from)
    {
        return $this->setData(self::FROM, $from);
    }

    /**
     * Get to
     * @return string|null
     */
    public function getTo()
    {
        return $this->_get(self::TO);
    }

    /**
     * Set to
     * @param string $to
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setTo($to)
    {
        return $this->setData(self::TO, $to);
    }

    /**
     * Get comment
     * @return string|null
     */
    public function getComment()
    {
        return $this->_get(self::COMMENT);
    }

    /**
     * Set comment
     * @param string $comment
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setComment($comment)
    {
        return $this->setData(self::COMMENT, $comment);
    }

    /**
     * Get status
     * @return string|null
     */
    public function getStatus()
    {
        return $this->_get(self::STATUS);
    }

    /**
     * Set status
     * @param string $status
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * Get is_delete
     * @return string|null
     */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }

    /**
     * Set is_delete
     * @param string $isDelete
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }

    /**
     * Get dc_id
     * @return string|null
     */
    public function getDcId()
    {
        return $this->_get(self::DC_ID);
    }

    /**
     * Set dc_id
     * @param string $dcId
     * @return \Aria\SupplyCompanyAccount\Api\Data\VacationInterface
     */
    public function setDcId($dcId)
    {
        return $this->setData(self::DC_ID, $dcId);
    }
}
