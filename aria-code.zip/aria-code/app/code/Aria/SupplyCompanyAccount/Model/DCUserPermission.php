<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\SupplyCompanyAccount\Model;

use Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterface;
use Aria\SupplyCompanyAccount\Api\Data\DCUserPermissionInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class DCUserPermission extends \Magento\Framework\Model\AbstractModel
{

    protected $dcUserPermissionDataFactory;

    protected $_eventPrefix = 'aria_dc_user_permissions';
    protected $dataObjectHelper;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param DCUserPermissionInterfaceFactory $dcUserPermissionDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserPermission $resource
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserPermission\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        DCUserPermissionInterfaceFactory $dcUserPermissionDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserPermission $resource,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserPermission\Collection $resourceCollection,
        array $data = []
    ) {
        $this->dcUserPermissionDataFactory = $dcUserPermissionDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve dc user permission model with user role data
     * @return DCUserPermissionInterface
     */
    public function getDataModel()
    {
        $dcUserPermissionData = $this->getData();
        
        $dcUserPermissionDataObject = $this->dcUserPermissionDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $dcUserPermissionDataObject,
            $dcUserPermissionData,
            DCUserPermissionInterface::class
        );
        
        return $dcUserPermissionDataObject;
    }


}
