<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductWatch\Cron;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface;
use Aria\ProductWatch\Model\ResourceModel\ProductWatch\CollectionFactory as ProductWatchCollectionFactory;

class ProductNotification
{
	protected $_pageFactory;
    protected $multiSellerProductRepositoryInterface;
    protected $participantsRepositoryInterface;
    protected $productRepositoryInterface;
    protected $productWatchCollectionFactory;

    /**
     * constructor function
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param TransportBuilder $transportBuilder
     * @param StateInterface $state
     * @param ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory
     * @param \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepositoryInterface
     * @param \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface
     * @param ProductWatchCollectionFactory $productWatchCollectionFactory
     */
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		TransportBuilder $transportBuilder,
        ScopeConfigInterface $scopeConfig,
        StateInterface $state,
        \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepositoryInterface,
        \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        ProductWatchCollectionFactory $productWatchCollectionFactory
        )
	{
		$this->_pageFactory = $pageFactory;
		$this->transportBuilder = $transportBuilder;
        $this->scopeConfig = $scopeConfig;
        $this->inlineTranslation = $state;
        $this->multiSellerProductRepositoryInterface=$multiSellerProductRepositoryInterface;
        $this->participantsRepositoryInterface=$participantsRepositoryInterface;
        $this->productRepositoryInterface=$productRepositoryInterface;
        $this->productWatchCollectionFactory = $productWatchCollectionFactory;
	}

	public function execute()
	{
		$productWatchCollection = $this->productWatchCollectionFactory->create();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        foreach($productWatchCollection as $productWatch){

            $sku = $productWatch->getSku();
            $venueUserId = $productWatch->getVenueUserId();
            $venueId = $productWatch->getVenueId();
            $productWatchPrice = $productWatch->getPrice();
            $productWatchIsInStock = $productWatch->getIsInStock();
            $productWatchStatus = $productWatch->getStatus();

            $multiSellerProductDetail=$this->multiSellerProductRepositoryInterface->getProduct($sku);
            $isDelete=$multiSellerProductDetail->getIsDelete();
            
            $productId = $objectManager->get('Magento\Catalog\Model\Product')->getIdBySku($sku);
            $productDetail = $this->productRepositoryInterface->getById($productId);
            $name=$productDetail->getName();
            $stockItem = $productDetail->getExtensionAttributes()->getStockItem();
            $isInStock=$stockItem->getIsInStock();
            $price=$productDetail->getPrice();
            $status=$productDetail->getStatus();
            $finalPrice=$productDetail->getFinalPrice();

            //When the product is out of stock
            if($productWatchIsInStock && !$isInStock){

                $outOfStockDes = $name." is Out of Stock";
                $this->participantsRepositoryInterface->saveParticipantNotification(4,$venueId,$venueUserId,$outOfStockDes,'venue_user','product out of stock',$sku);
            }
            //When the product is back in stock
            if(!$productWatchIsInStock && $isInStock){

                $inStockDes = $name." is Back in Stock";
                $this->participantsRepositoryInterface->saveParticipantNotification(4,$venueId,$venueUserId,$inStockDes,'venue_user','product in stock',$sku);
            }
            //When the product price increases
            if($productWatchPrice<$finalPrice){
                $priceDecreaseDes = "The price of ".$name." has increased";
                $this->participantsRepositoryInterface->saveParticipantNotification(4,$venueId,$venueUserId,$priceDecreaseDes,'venue_user','product price increased',$sku);
            }
            //When the product price decreases
            if($productWatchPrice>$finalPrice){
                $priceIncreaseDes = "The price of ".$name." has decreased";
                $this->participantsRepositoryInterface->saveParticipantNotification(4,$venueId,$venueUserId,$priceIncreaseDes,'venue_user','product price decreased',$sku);
            }
            //When the supplier inactivates the product or the supplier removes the product from the system
            if( ($productWatchStatus==1 && $status==2 )|| $isDelete){
                $unavailableDes = $name." is unavailable";
                $this->participantsRepositoryInterface->saveParticipantNotification(4,$venueId,$venueUserId,$unavailableDes,'venue_user','product unavailable',$sku);
            }
            if($isDelete)
            {
                $productWatch->Delete();
            }
            else
            {
                $productWatch->setIsInStock($isInStock);
                $productWatch->setPrice($finalPrice);
                $productWatch->setStatus($status);
            }
            $productWatch->save();
        }

		return $this;
	}
}