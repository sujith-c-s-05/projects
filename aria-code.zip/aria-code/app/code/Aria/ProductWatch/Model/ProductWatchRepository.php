<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\ProductWatch\Model;

use Aria\ProductWatch\Api\Data\ProductWatchInterfaceFactory;
use Aria\ProductWatch\Api\Data\ProductWatchSearchResultsInterfaceFactory;
use Aria\ProductWatch\Api\ProductWatchRepositoryInterface;
use Aria\ProductWatch\Model\ResourceModel\ProductWatch as ResourceProductWatch;
use Aria\ProductWatch\Model\ResourceModel\ProductWatch\CollectionFactory as ProductWatchCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Exception\AuthorizationException;
use Aria\Notifications\Model\ResourceModel\Participants\CollectionFactory as ParticipantsCollectionFactory;

class ProductWatchRepository implements ProductWatchRepositoryInterface
{

    protected $resource;

    protected $extensibleDataObjectConverter;
    protected $searchResultsFactory;

    protected $dataProductWatchFactory;

    protected $productWatchCollectionFactory;

    private $storeManager;

    protected $dataObjectHelper;

    protected $dataObjectProcessor;

    protected $productWatchFactory;

    protected $extensionAttributesJoinProcessor;

    private $collectionProcessor;

    protected $venueUserRepositoryInterface;


    /**
     * @param ResourceProductWatch $resource
     * @param ProductWatchFactory $productWatchFactory
     * @param ProductWatchInterfaceFactory $dataProductWatchFactory
     * @param ProductWatchCollectionFactory $productWatchCollectionFactory
     * @param ProductWatchSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param Aria\Venue\Api\VenueUserRepositoryInterface $venueUserRepositoryInterface
     */
    public function __construct(
        ResourceProductWatch $resource,
        ProductWatchFactory $productWatchFactory,
        ProductWatchInterfaceFactory $dataProductWatchFactory,
        ProductWatchCollectionFactory $productWatchCollectionFactory,
        ProductWatchSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        ParticipantsCollectionFactory $participantsCollectionFactory,
        \Aria\Venue\Api\VenueUserRepositoryInterface $venueUserRepositoryInterface
    ) {
        $this->resource = $resource;
        $this->productWatchFactory = $productWatchFactory;
        $this->productWatchCollectionFactory = $productWatchCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataProductWatchFactory = $dataProductWatchFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->venueUserRepositoryInterface=$venueUserRepositoryInterface;
        $this->participantsCollectionFactory = $participantsCollectionFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        $customerId,\Aria\ProductWatch\Api\Data\ProductWatchInterface $productWatch
    ) {
        $venueUserId=$productWatch->getVenueUserId();
        $venueUserDetails = $this->venueUserRepositoryInterface->get($venueUserId);
        $entityId=$venueUserDetails->getMagentoUserId();
        if($customerId!=$entityId)
        {
            throw new AuthorizationException(
                __("Access Denied.The consumer isn't authorized")
            );
        }

        $productWatchData = $this->extensibleDataObjectConverter->toNestedArray(
            $productWatch,
            [],
            \Aria\ProductWatch\Api\Data\ProductWatchInterface::class
        );

        $productWatchModel = $this->productWatchFactory->create()->setData($productWatchData);
        $productWatchObject=$this->getProductWatch($productWatchModel->getVenueId(),$productWatchModel->getVenueUserId()
                                ,$productWatchModel->getSku());
        $productWatchModel->setProductwatchId($productWatchObject->getProductwatchId());         
        try {
            $this->resource->save($productWatchModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the productWatch: %1',
                $exception->getMessage()
            ));
        }
        return $productWatchModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($productWatchId)
    {
        $productWatch = $this->productWatchFactory->create();
        $this->resource->load($productWatch, $productWatchId);
        if (!$productWatch->getId()) {
            throw new NoSuchEntityException(__('ProductWatch with id "%1" does not exist.', $productWatchId));
        }
        return $productWatch->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->productWatchCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\ProductWatch\Api\Data\ProductWatchInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \Aria\ProductWatch\Api\Data\ProductWatchInterface $productWatch
    ) {
        try {
            $productWatchModel = $this->productWatchFactory->create();
            $this->resource->load($productWatchModel, $productWatch->getProductwatchId());
            $this->resource->delete($productWatchModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the ProductWatch: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteBySku($customerId,$venueId,$venueUserId,$sku)
    {
        $venueUserDetails = $this->venueUserRepositoryInterface->get($venueUserId);
        $entityId=$venueUserDetails->getMagentoUserId();
        if($customerId!=$entityId)
        {
            throw new AuthorizationException(
                __("Access Denied.The consumer isn't authorized")
            );
        }
        try 
        {
            $collection = $this->productWatchCollectionFactory->create();
            $productWatch=$collection->addFieldToFilter('sku',$sku)
                        ->addFieldToFilter('venue_user_id',$venueUserId)
                        ->addFieldToFilter('venue_id',$venueId)
                        ->getFirstItem();
            $productWatch->Delete();
            $productWatch->save();
        } 
        catch (\Exception $exception) 
        {
            throw new CouldNotDeleteException(__(
                'Could not delete the ProductWatch: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function getNotifications($participantId, $userId, $customerId)
    {
        $venueUserDetails = $this->venueUserRepositoryInterface->get($userId);
        $entityId=$venueUserDetails->getMagentoUserId();
        if($customerId!=$entityId)
        {
            throw new AuthorizationException(
                __("Access Denied.The consumer isn't authorized")
            );
        }

        $userType = 'venue_user';

        $participants = $this->participantsCollectionFactory->create();
        if ($userType == 'venue_user') {
            $participants->addFieldToFilter('participant_id', $participantId)->addFieldToFilter('user_type', $userType);
            $result = [];
            $i = 0;

            $participants = $this->participantsCollectionFactory->create();
            $participants->addFieldToFilter('notification_type',array('in'=>array(4,5)))
                ->addFieldToFilter('participant_id', $participantId)
                ->addFieldToFilter('user_id', $userId)
                ->addFieldToFilter('user_type', $userType)
                ->setOrder('participants_id', 'DESC');
            foreach ($participants as $object) {
                $result[$i]['id'] = $object['participants_id'];
                $result[$i]['title'] = $object['title'];
                $result[$i]['date_time'] = $object['date_time'];
                $result[$i]['mark_read'] = $object['mark_read'];
                $result[$i]['description'] = $object['description'];
                $result[$i]['sku'] = $object['sku'];
                $i++;
            }

            return $result;
        }
    }

    /**
     * {@inheritdoc}
     */
    public function checkProductIsOnWatch($participantId,$userId,$sku,$customerId)
    {
        $venueUserDetails = $this->venueUserRepositoryInterface->get($userId);
        $entityId=$venueUserDetails->getMagentoUserId();
        if($customerId!=$entityId)
        {
            throw new AuthorizationException(
                __("Access Denied.The consumer isn't authorized")
            );
        }
        $collection = $this->productWatchCollectionFactory->create();
        $collection->addFieldToFilter('venue_user_id', $userId);
        $collection->addFieldToFilter('venue_id', $participantId);
        $collection->addFieldToFilter('sku', $sku);

        if(count($collection) >= 1)
        {
            return true;
        }

        return false;
        
    }

    /**
     * {@inheritdoc}
     */
    public function getProductWatch($venueId,$venueUserId,$sku)
    {
        $collection = $this->productWatchCollectionFactory->create();
        $productWatch=$collection->addFieldToFilter('sku',$sku)
                    ->addFieldToFilter('venue_user_id',$venueUserId)
                    ->addFieldToFilter('venue_id',$venueId)
                    ->getFirstItem();
        return $productWatch;
    }
}
