<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductWatch\Model;

use Aria\ProductWatch\Api\Data\ProductWatchInterface;
use Aria\ProductWatch\Api\Data\ProductWatchInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class ProductWatch extends \Magento\Framework\Model\AbstractModel
{

    protected $productwatchDataFactory;

    protected $dataObjectHelper;

    protected $_eventPrefix = 'aria_product_watch';

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param ProductWatchInterfaceFactory $productwatchDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\ProductWatch\Model\ResourceModel\ProductWatch $resource
     * @param \Aria\ProductWatch\Model\ResourceModel\ProductWatch\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        ProductWatchInterfaceFactory $productwatchDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\ProductWatch\Model\ResourceModel\ProductWatch $resource,
        \Aria\ProductWatch\Model\ResourceModel\ProductWatch\Collection $resourceCollection,
        array $data = []
    ) {
        $this->productwatchDataFactory = $productwatchDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve productwatch model with productwatch data
     * @return ProductWatchInterface
     */
    public function getDataModel()
    {
        $productwatchData = $this->getData();
        
        $productwatchDataObject = $this->productwatchDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $productwatchDataObject,
            $productwatchData,
            ProductWatchInterface::class
        );
        
        return $productwatchDataObject;
    }
}

