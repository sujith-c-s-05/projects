<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductWatch\Model\Data;

use Aria\ProductWatch\Api\Data\ProductWatchInterface;

class ProductWatch extends \Magento\Framework\Api\AbstractExtensibleObject implements ProductWatchInterface
{

    /**
     * Get productwatch_id
     * @return int|null
     */
    public function getProductwatchId()
    {
        return $this->_get(self::PRODUCTWATCH_ID);
    }

    /**
     * Set productwatch_id
     * @param int $productwatchId
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setProductwatchId($productwatchId)
    {
        return $this->setData(self::PRODUCTWATCH_ID, $productwatchId);
    }

    /**
     * Get venue_user_id
     * @return int|null
     */
    public function getVenueUserId()
    {
        return $this->_get(self::VENUE_USER_ID);
    }

    /**
     * Set venue_user_id
     * @param int $venueUserId
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setVenueUserId($venueUserId)
    {
        return $this->setData(self::VENUE_USER_ID, $venueUserId);
    }

    /**
     * Get venue_id
     * @return int|null
     */
    public function getVenueId()
    {
        return $this->_get(self::VENUE_ID);
    }

    /**
     * Set venue_id
     * @param int $venueId
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setVenueId($venueId)
    {
        return $this->setData(self::VENUE_ID, $venueId);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\ProductWatch\Api\Data\ProductWatchExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\ProductWatch\Api\Data\ProductWatchExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\ProductWatch\Api\Data\ProductWatchExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get sku
     * @return string|null
     */
    public function getSku()
    {
        return $this->_get(self::SKU);
    }

    /**
     * Set sku
     * @param string $sku
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setSku($sku)
    {
        return $this->setData(self::SKU, $sku);
    }

    /**
     * Get price
     * @return string|null
     */
    public function getPrice()
    {
        return $this->_get(self::PRICE);
    }

    /**
     * Set price
     * @param string $price
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setPrice($price)
    {
        return $this->setData(self::PRICE, $price);
    }

    /**
     * Get is_in_stock
     * @return bool
     */
    public function getIsInStock()
    {
        return $this->_get(self::IS_IN_STOCK);
    }

    /**
     * Set is_in_stock
     * @param bool $isInStock
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setIsInStock($isInStock)
    {
        return $this->setData(self::IS_IN_STOCK, $isInStock);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get status
     * @return int|null
     */
    public function getStatus()
    {
        return $this->_get(self::STATUS);
    }

    /**
     * Set status
     * @param int $status
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }
}

