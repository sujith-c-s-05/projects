<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductWatch\Api\Data;

interface ProductWatchInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const STATUS = 'status';
    const CREATED_AT = 'created_at';
    const PRICE = 'price';
    const PRODUCTWATCH_ID = 'productwatch_id';
    const SKU = 'sku';
    const IS_IN_STOCK = 'is_in_stock';
    const VENUE_USER_ID = 'venue_user_id';
    const VENUE_ID = 'venue_id';
    const UPDATED_AT = 'updated_at';

    /**
     * Get productwatch_id
     * @return int|null
     */
    public function getProductwatchId();

    /**
     * Set productwatch_id
     * @param int $productwatchId
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setProductwatchId($productwatchId);

    /**
     * Get venue_user_id
     * @return int|null
     */
    public function getVenueUserId();

    /**
     * Set venue_user_id
     * @param int $venueUserId
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setVenueUserId($venueUserId);

    /**
     * Get venue_id
     * @return int|null
     */
    public function getVenueId();

    /**
     * Set venue_id
     * @param int $venueId
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setVenueId($venueId);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\ProductWatch\Api\Data\ProductWatchExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\ProductWatch\Api\Data\ProductWatchExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\ProductWatch\Api\Data\ProductWatchExtensionInterface $extensionAttributes
    );

    /**
     * Get sku
     * @return string|null
     */
    public function getSku();

    /**
     * Set sku
     * @param string $sku
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setSku($sku);

    /**
     * Get price
     * @return string|null
     */
    public function getPrice();

    /**
     * Set price
     * @param string $price
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setPrice($price);

    /**
     * Get is_in_stock
     * @return bool
     */
    public function getIsInStock();

    /**
     * Set is_in_stock
     * @param bool $isInStock
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setIsInStock($isInStock);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get status
     * @return int|null
     */
    public function getStatus();

    /**
     * Set status
     * @param int $status
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     */
    public function setStatus($status);
}

