<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductWatch\Api\Data;

interface ProductWatchSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get ProductWatch list.
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface[]
     */
    public function getItems();

    /**
     * Set venue_user_id list.
     * @param \Aria\ProductWatch\Api\Data\ProductWatchInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

