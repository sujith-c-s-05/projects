<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductWatch\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface ProductWatchRepositoryInterface
{

    /**
     * Save ProductWatch
     * @param int $customerId
     * @param \Aria\ProductWatch\Api\Data\ProductWatchInterface $productWatch
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        $customerId,\Aria\ProductWatch\Api\Data\ProductWatchInterface $productWatch
    );

    /**
     * Retrieve ProductWatch
     * @param string $productwatchId
     * @return \Aria\ProductWatch\Api\Data\ProductWatchInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($productwatchId);

    /**
     * Retrieve ProductWatch matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\ProductWatch\Api\Data\ProductWatchSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete ProductWatch
     * @param \Aria\ProductWatch\Api\Data\ProductWatchInterface $productWatch
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Aria\ProductWatch\Api\Data\ProductWatchInterface $productWatch
    );

    /**
     * Delete ProductWatch by Sku
     * @param int $customerId
     * @param int $venueId
     * @param int $venueUserId
     * @param string $sku
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteBySku($customerId,$venueId,$venueUserId,$sku);

    /**
     * Retrieve Notifications.
     * @param int $participantId
     * @param string $userId
     * @param int $customerId
     * @return mixed[]
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getNotifications($participantId,$userId,$customerId);

    /**
     * Check Wether product is on watch
     * @param int $participantId
     * @param int $userId
     * @param string $sku
     * @param int $customerId
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function checkProductIsOnWatch($participantId,$userId,$sku,$customerId);
}

