<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ReviewRatings\Ui\Component\Listing\Column;

class SupplierReviewActions extends \Magento\Ui\Component\Listing\Columns\Column
{

    const URL_PATH_EDIT = 'aria_reviewratings/supplierreviews/edit';
    const URL_PATH_DISABLE = 'aria_reviewratings/supplierreviews/disable';
    const URL_PATH_ENABLE = 'aria_reviewratings/supplierreviews/enable';
    protected $urlBuilder;

    /**
     * @param \Magento\Framework\View\Element\UiComponent\ContextInterface $context
     * @param \Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\UiComponent\ContextInterface $context,
        \Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory,
        \Magento\Framework\UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                if (isset($item['id'])) {
                    $deleteStatus = $item['is_delete'];

                   if($deleteStatus !=1)
                   {
                        $item[$this->getData('name')] = [
                            'edit' => [
                                'href' => $this->urlBuilder->getUrl(
                                    static::URL_PATH_EDIT,
                                    [
                                        'id' => $item['id']
                                    ]
                                ),
                                'label' => __('Edit')
                            ],
                            'disable' => [
                                'href' => $this->urlBuilder->getUrl(
                                    static::URL_PATH_DISABLE,
                                    [
                                        'id' => $item['id']
                                    ]
                                ),
                                'label' => __('Disable')
                                
                            ],
                            'enable' => [
                                'href' => $this->urlBuilder->getUrl(
                                    static::URL_PATH_ENABLE,
                                    [
                                        'id' => $item['id']
                                    ]
                                ),
                                'label' => __('Enable')
                            ]

                        ];                 
                        
                    }  
                }            
            }
        }
        
        return $dataSource;
    }
}

