<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ReviewRatings\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface SupplierReviewsRepositoryInterface
{

    /**
     * Save ReviewRatings
     * @param \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface $supplierReviews
     * @param int $customerId
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface $ReviewRatings,$customerId=null
    );

    /**
     * Retrieve ReviewRatings
     * @param int $Id
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($Id);
    /**
     * Retrieve ReviewRatings of a supplier
     * @param int $Id
     * @param int $customerId
     * @return Aria\ReviewRatings\Api\Data\AssociativeArrayItemInterface[]
     */
    public function getSupplierReview($Id,$customerId=null);
    /**
     * Retrieve ReviewRatings of a supplier on a venue
     * @param int $customerId
     * @param int $venueId
     * @return Aria\ReviewRatings\Api\Data\SupplierVenueArrayItemInterface[]
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getSupplierReviewByVenue($customerId=null,$venueId);
    /**
     * Retrieve ReviewRatings matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );
    /**
     * Retrieve ReviewRatings per venue.
     * @param int $customerId
     * @param int $supplierId
     * @return Aria\ReviewRatings\Api\Data\VenueReviewsArrayItemInterface[]
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getSupplierReviewsPerVenue($customerId=null,$supplierId=null);
    
    /**
     * delete Schedule Order
     * @param int $customerId
     * @param int id
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteSupplierReview($customerId=null,$id);

    /**
     * remove Schedule Order
     * @param int id
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function removeSupplierReview($id);
   
}
