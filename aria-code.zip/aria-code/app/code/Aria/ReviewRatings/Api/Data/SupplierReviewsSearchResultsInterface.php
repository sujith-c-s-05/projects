<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ReviewRatings\Api\Data;

interface SupplierReviewsSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get ScheduleOrder list.
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface[]
     */
    public function getItems();

    /**
     * Set ScheduleOrder list.
     * @param \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
