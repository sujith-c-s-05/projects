<?php
namespace Aria\ReviewRatings\Api\Data;

/**
 * Interface which represents associative array item.
 */
interface AssociativeArrayItemInterface
{
    /**
     * Get key
     * 
     * @return string
     */
    public function getAvailable();

    /**
     * Get value
     * 
     * @return float
     */
    public function getOverallRatings();
    /**
     * Get value
     * 
     * @return int
     */
    public function getTotalReviews();
    /**
     * Get value
     * 
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface[]
     */
    public function getReviews();
}