<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ReviewRatings\Api\Data;

interface SupplierReviewsInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const ID = 'id';
    const VENUE_USER_ID = 'venue_user_id';
    const VENUE_ID = 'venue_id';
    const SUPPLIER_ID = 'supplier_id';
    const REVIEW = 'review';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const RATING = 'rating';
    const TITLE = 'title';
    const VERIFIED_CUSTOMER = 'verified_customer';
    const IS_DELETE = 'is_delete';
    const STATUS = 'status';
    const VENUE_USER_NAME = 'venue_user_name';
    const ORDER_ID = 'order_id';
    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param int $Id
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setId($Id);
    
    /**
     * Get venue_user_id
     * @return int|null
     */
    public function getVenueUserId();

    /**
     * Set venue_user_id
     * @param int $venueuserId
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setVenueUserId($venueuserId);
    /**
     * Get venue_user_name
     * @return string
     */
    public function getVenueUserName();

    /**
     * Set venue_user_name
     * @param string $venueuserName
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setVenueUserName($venueuserName);
    /**
     * Get venue_id
     * @return int|null
     */
    public function getVenueId();

    /**
     * Set venue_id
     * @param int $venueId
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setVenueId($venueId);
    /**
     * Get supplier_id
     * @return int|null
     */
    public function getSupplierId();

    /**
     * Set supplier_id
     * @param int $supplierId
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setSupplierId($supplierId);
    /**
     * Get title
     * @return string|null
     */
    public function getTitle();

    /**
     * Set title
     * @param string $title
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setTitle($title);
    /**
     * Get review
     * @return string|null
     */
    public function getReview();

    /**
     * Set review
     * @param string $review
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setReview($review);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setUpdatedAt($updatedAt);
    /**
     * Get verified_customer
     * @return bool
     */
    public function getVerifiedCustomer();

    /**
     * Set verified_customer
     * @param bool $verifiedCustomer
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setVerifiedCustomer($verifiedCustomer); 
    /**
     * Get rating
     * @return int|null
     */
    public function getRating();

    /**
     * Set rating
     * @param int $rating
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setRating($rating); 
    /**
     * Get is_delete
     * @return bool
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setIsDelete($isDelete); 
    /**
     * Get status
     * @return bool
     */
    public function getStatus();

    /**
     * Set status
     * @param bool $status
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setStatus($status);  

    /**
     * Get order_id
     * @return int|null
     */
    public function getOrderId();

    /**
     * Set order_id
     * @param int $orderId
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setOrderId($orderId);

}
