<?php
namespace Aria\ReviewRatings\Api\Data;

/**
 * Interface which represents associative array item.
 */
interface VenueReviewsArrayItemInterface
{
    /**
     * Get key
     * 
     * @return int
     */
    public function getVenueId();

    /**
     * Get value
     * 
     * @return int
     */
    public function getSupplierId();
    /**
     * Get value
     * 
     * @return string
     */
    public function getVenueName();
    /**
     * Get value
     * 
     * @return float
     */
    public function getOverallRatings();
}