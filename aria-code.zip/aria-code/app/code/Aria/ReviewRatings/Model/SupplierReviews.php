<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ReviewRatings\Model;

use Aria\ReviewRatings\Api\Data\SupplierReviewsInterface;
use Aria\ReviewRatings\Api\Data\SupplierReviewsInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class SupplierReviews extends \Magento\Framework\Model\AbstractModel
{

    protected $supplierReviewsInterfaceFactory;
    protected $_eventPrefix = 'supplier_reviews';
    protected $dataObjectHelper;
    protected $_orderCollectionFactory;



    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param SupplierReviewsInterfaceFactory $supplierReviewsInterfaceFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\ReviewRatings\Model\ResourceModel\SupplierReviews $resource
     * @param \Aria\ReviewRatings\Model\ResourceModel\SupplierReviews\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        SupplierReviewsInterfaceFactory $supplierReviewsInterfaceFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\ReviewRatings\Model\ResourceModel\SupplierReviews $resource,
        \Aria\ReviewRatings\Model\ResourceModel\SupplierReviews\Collection $resourceCollection,
        array $data = []
    ) {
        $this->supplierReviewsInterfaceFactory = $supplierReviewsInterfaceFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve SupplierReviews model with SupplierReviews data
     * @return SupplierReviewsInterface
     */
    public function getDataModel()
    {
        $supplierReviewsData = $this->getData();

        $supplierReviewsDataObject = $this->supplierReviewsInterfaceFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $supplierReviewsDataObject,
            $supplierReviewsData,
            ScheduleOrderInterface::class
        );

        return $supplierReviewsDataObject;
    }    

}