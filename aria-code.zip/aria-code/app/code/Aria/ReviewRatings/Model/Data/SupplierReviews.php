<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ReviewRatings\Model\Data;

class SupplierReviews extends \Magento\Framework\Api\AbstractExtensibleObject implements \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
{
    /**
     * Get id
     * @return int|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }
    /**
     * Set id
     * @param int $Id
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setId($Id)
    {
        return $this->setData(self::ID, $Id);
    }
    /**
     * Get venue_user_id
     * @return int|null
     */
    public function getVenueUserId()
    {
        return $this->_get(self::VENUE_USER_ID);
    }
    /**
     * Set venue_user_id
     * @param int $venueuserId
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setVenueUserId($venueuserId)
    {
        return $this->setData(self::VENUE_USER_ID, $venueuserId);
    }
    /**
     * Get venue_user_name
     * @return string
     */
    public function getVenueUserName()
    {
        return $this->_get(self::VENUE_USER_NAME);
    }
    /**
     * Set venue_user_name
     * @param string $venueuserName
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setVenueUserName($venueuserName)
    {
        return $this->setData(self::VENUE_USER_NAME, $venueuserName);
    }
    /**
     * Get venue_id
     * @return int|null
     */
    public function getVenueId()
    {
        return $this->_get(self::VENUE_ID);
    }
    /**
     * Set venue_id
     * @param int $venueId
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setVenueId($venueId)
    {
        return $this->setData(self::VENUE_ID, $venueId);
    }
    /**
     * Get supplier_id
     * @return int|null
     */
    public function getSupplierId()
    {
        return $this->_get(self::SUPPLIER_ID);
    }
    /**
     * Set supplier_id
     * @param int $supplierId
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setSupplierId($supplierId)
    {
        return $this->setData(self::SUPPLIER_ID, $supplierId);
    }
    /**
     * Get title
     * @return string|null
     */
    public function getTitle()
    {
        return $this->_get(self::TITLE);
    }
    /**
     * Set title
     * @param string $title
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setTitle($title)
    {
        return $this->setData(self::TITLE, $title);
    }
    /**
     * Get review
     * @return string|null
     */
    public function getReview()
    {
        return $this->_get(self::REVIEW);
    }
    /**
     * Set review
     * @param string $review
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setReview($review)
    {
        return $this->setData(self::REVIEW, $review);
    }
    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }
    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }
    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }
    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }
    /**
     * Get rating
     * @return int|null
     */
    public function getRating()
    {
        return $this->_get(self::RATING);
    }
    /**
     * Set rating
     * @param int $rating
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setRating($rating)
    {
        return $this->setData(self::RATING, $rating);
    }
    /**
     * Get verified_customer
     * @return bool
     */
    public function getVerifiedCustomer()
    {
        return $this->_get(self::VERIFIED_CUSTOMER);
    }
    /**
     * Set verified_customer
     * @param bool $verifiedCustomer
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setVerifiedCustomer($verifiedCustomer)  
    {
        return $this->setData(self::VERIFIED_CUSTOMER, $verifiedCustomer);
    }
    /**
     * Get is_delete
     * @return bool
     */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }
    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setIsDelete($isDelete)  
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }
    /**
     * Get status
     * @return bool
     */
    public function getStatus()
    {
        return $this->_get(self::STATUS);
    }

    /**
     * Set status
     * @param bool $status
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }

    /**
     * Get order_id
     * @return int|null
     */
    public function getOrderId()
    {
        return $this->_get(self::ORDER_ID);
    }
    /**
     * Set order_id
     * @param int $orderId
     * @return \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface
     */
    public function setOrderId($orderId)
    {
        return $this->setData(self::ORDER_ID, $orderId);
    }
}
