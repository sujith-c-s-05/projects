<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ReviewRatings\Model;

use Magento\Framework\Exception\AuthorizationException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception;
use Magento\Framework\Exception\CouldNotDeleteException;

class SupplierReviewsRepository implements \Aria\ReviewRatings\Api\SupplierReviewsRepositoryInterface
{

    
    public function __construct(
       SupplierReviewsFactory $reviewRatingsFactory,
       \Magento\Framework\Api\ExtensibleDataObjectConverter $extensibleDataObjectConverter,
       \Aria\ReviewRatings\Model\ResourceModel\SupplierReviews $supplierReviewsresource,
       \Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany $supplyCompanyResource,
       \Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface $collectionProcessor,
       \Aria\ReviewRatings\Model\ResourceModel\SupplierReviews\CollectionFactory $supplierReviewsCollectionFactory,
       \Aria\ReviewRatings\Api\Data\SupplierReviewsSearchResultsInterfaceFactory $searchResultsFactory,
       \Aria\Venue\Api\VenueRepositoryInterface $venueRepositoryInterface,
       \Aria\Venue\Model\ResourceModel\VenueUser\CollectionFactory $venueUserCollectionFactory,
       \Aria\SupplyCompanyAccount\Model\ResourceModel\DCUser\CollectionFactory $dcUserCollectionFactory,
       \Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany\CollectionFactory $supplierCollectionFactory,
       \Aria\SupplyCompanyAccount\Model\DCUserFactory $dcUserFactory,
       \Aria\SupplyCompanyAccount\Model\SupplyCompanyFactory $supplyCompany,
       \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
       \Aria\SupplyCompanyAccount\Model\ResourceModel\DC\CollectionFactory $supplyDcCollectionFactory,
       \Aria\Venue\Api\VenueRepositoryInterface $venueRepository
    ) {
        $this->reviewRatingsFactory = $reviewRatingsFactory;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->supplierReviewsCollectionFactory = $supplierReviewsCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->supplierReviewsresource = $supplierReviewsresource;
        $this->supplyCompanyResource = $supplyCompanyResource;
        $this->collectionProcessor = $collectionProcessor;
        $this->venueRepositoryInterface=$venueRepositoryInterface;
        $this->venueUserCollectionFactory = $venueUserCollectionFactory;
        $this->dcUserCollectionFactory = $dcUserCollectionFactory;
        $this->dcUserFactory = $dcUserFactory;
        $this->supplyCompany = $supplyCompany;
        $this->supplierCollectionFactory =$supplierCollectionFactory;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->supplyDcCollectionFactory = $supplyDcCollectionFactory;
        $this->venueRepository = $venueRepository;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface $supplierReviews, $customerId=null
    ) {
        $updateId = false;
        if($customerId == null){
            throw new AuthorizationException(
                __("Access Denied.The consumer isn't authorized!")
            );
        } 
        $venueUserId = $this->getVenueUserByCustomerId($customerId)->getId();
        $supplierReviewsData = $this->extensibleDataObjectConverter->toNestedArray(
            $supplierReviews,
            [],
            \Aria\ReviewRatings\Api\Data\SupplierReviewsInterface::class
        );
        if(!isset($supplierReviewsData['id']) && $this->getRow($venueUserId,$supplierReviews->getSupplierId())){
            throw new AuthorizationException(
                __("review exists")
            );
        }
        if(isset($supplierReviewsData['id'])){
            $this->checkOwner($supplierReviewsData['id'],$venueUserId);
            $updateId = true;
        } else {
            $supplierReviewsData['verified_customer'] = $this->getVerifiedUser($customerId,$supplierReviewsData['supplier_id']);
            $supplierReviewsData['venue_user_id'] = $venueUserId;
            $venueUserData = $this->getVenueUserById($venueUserId);
            $supplierReviewsData['venue_user_name'] = $venueUserData->getFirstName()." ".$venueUserData->getLastName();
            $supplierReviewsData['is_delete'] = 0;
            $supplierReviewsData['status'] = 1;
            $venueId = $supplierReviews->getVenueId();
            $venueModel =  $this->venueRepository->get($venueId);
            if(!$venueId || !$venueModel->getId()){
                throw new \Magento\Framework\Webapi\Exception(    __('Venue does not exist!'),
                 0,\Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST );
            }
        }
        try {  
            $reviewRatingsModel = $this->reviewRatingsFactory->create()->setData($supplierReviewsData); 
            $this->supplierReviewsresource->save($reviewRatingsModel);
            $dataModel = $reviewRatingsModel->getDataModel();
            $review = $this->get($dataModel->getId());
            $this->setOverAllRatingsSupplier($review->getSupplierId(),$review->getVenueId());
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the item:',
                $exception->getMessage()
            ));
        }
        return $review;
    }
    /**
     * {@inheritdoc}
     */
    public function get($Id)
    { 
        $reviewRatings = $this->reviewRatingsFactory->create();
        $this->supplierReviewsresource->load($reviewRatings, $Id);
        if (!$reviewRatings->getId()) {
            throw new NoSuchEntityException(__('reviewRatings with id "%1" does not exist.', $Id));
        }
        return $reviewRatings->getDataModel();
    }
    public function getRow($venueUserId,$supplierId){
        $collection = $this->supplierReviewsCollectionFactory->create();
        $collection->addFieldToFilter('supplier_id',['eq' => $supplierId])
            ->addFieldToFilter('venue_user_id',['eq' => $venueUserId])
            ->addFieldToFilter('is_delete',['eq' => 0]);
        return count($collection->getData());
    }
    /**
     * {@inheritdoc}
     */
    public function getSupplierReview($supplierId,$customerId=null)
    { 
        $currentReviews = [];
        $supplierReviews = [];
        $reviewsData = [];
        $reviewAvailable = false;
        if($customerId==null){
            throw new AuthorizationException(
                __("Access Denied.The consumer isn't authorized!")
            );
        }
        $venueUserId = $this->getVenueUserByCustomerId($customerId)->getId();
        $collection = $this->supplierReviewsCollectionFactory->create();
        $collection->addFieldToFilter('supplier_id',['eq' => $supplierId])
            ->addFieldToFilter('is_delete',['eq' => 0])
            ->setOrder('updated_at','DESC');
        if(!empty($collection->getData())){
            foreach($collection as $key=>$review){
                if($review->getVenueUserId() == $venueUserId){
                    $currentReviews[] = $review->getData();
                    $reviewAvailable = true;
                }
                else {
                    $supplierReviews[] = $review->getData();
                }
            }
            $result=[];
            $reviewsData['available'] = $reviewAvailable;
            $reviewsData['overall_ratings'] = $this->getOverAllRatings($supplierId);
            $reviewsData['total_reviews'] = count($collection);
            foreach($currentReviews as $currentReview){
                array_unshift($supplierReviews,$currentReview);
            }
            $reviewsData['reviews'] = $supplierReviews;
            $result['supplier_reviews']=$reviewsData;
            return $result;
        } else {
            throw new NoSuchEntityException(__('reviews are not availalbe for the supplier "%1"',$supplierId));
        }
    }


/**
     * {@inheritdoc}
     */
    public function getSupplierReviewsPerVenue($customerId=null,$supplierId=null)
    {
        if($supplierId==null || $customerId==null ){
             throw new AuthorizationException(
                __("Access Denied.The consumer isn't authorized!")
            );
        }
        $supplierIdByCustomerId = $this->getSupplyCompanyByCustomerId($customerId)->getId();
        if($supplierIdByCustomerId!=$supplierId){
          throw new AuthorizationException(
                __("Access Denied.The consumer isn't authorized!")
            );  
        }
        $veunes = [];
        $venueData = [];
        $collection = $this->supplierReviewsCollectionFactory->create();
        $collection->addFieldToFilter('supplier_id',['eq' => $supplierId])
                ->addFieldToFilter('is_delete',['eq' => 0]);
        if(!empty($collection->getData())){
            foreach($collection as $review){
                $veunes[] = $review->getVenueId();
            }
            $venuesAvialable = array_unique($veunes);
            if(!empty($venuesAvialable)){
                foreach($venuesAvialable as $venueId){
                    $venueDetails['venue_id'] = $venueId;
                    $venueDetails['supplier_id'] = $supplierId;
                    $venueModel =  $this->venueRepository->get($venueId);
                    $venueDetails['venue_name'] = $venueModel->getName();
                    $venueDetails['overall_ratings'] = $this->getVenueOverAllRatings($supplierId,$venueId);
                    $venueData[] = $venueDetails;
                }
                return $venueData;
            } else{
                throw new NoSuchEntityException(__('venues not found'));
            }

        } else{
            throw new NoSuchEntityException(__('reviews not found'));
        }
    }





    /**
     * {@inheritdoc}
     */
    public function getSupplierReviewByVenue($customerId=null,$venueId)
    { 
        
        $supplierId = $this->getSupplyCompanyByCustomerId($customerId)->getId();
        $currentReview = false;
        $reviewsData = [];
        if($customerId==null){
            throw new AuthorizationException(
                __("Access Denied.The consumer isn't authorized!")
            );
        }
        $collection = $this->supplierReviewsCollectionFactory->create();
        $collection->addFieldToFilter('supplier_id',['eq' => $supplierId])
            ->addFieldToFilter('venue_id',['eq'=>$venueId])
            ->addFieldToFilter('is_delete',['eq' => 0])
            ->setOrder('updated_at','DESC');
        if(!empty($collection->getData())){
            $result=[];
            $venueModel =  $this->venueRepository->get($venueId);
            $reviewsData['venue_name'] = $venueModel->getName();
            $reviewsData['overall_ratings'] = $this->getVenueOverAllRatings($supplierId,$venueId);
            $reviewsData['total_reviews'] = count($collection);
            $reviewsData['reviews'] = $collection->getData();
            $result['supplier_reviews']=$reviewsData;
            return $result;
        } else {
            throw new NoSuchEntityException(__('reviews are not availalbe for the supplier "%1"',$supplierId));
        }
    }
    /**
     * {@inheritdoc}
     */
    public function getActiveDCs($zipCode)
    {    
        $dcCollection = $this->dCCollectionFactory->create();
        $dcCollection->addFieldToFilter('is_delete', 0);

        $items = [];
        foreach ($dcCollection as $model) {
            $zipCodes=$model->getDeliveryLocation();
            $zipCodeList=explode (",", $zipCodes);
            if (in_array($zipCode, $zipCodeList, TRUE)){
                $items[] = $model->getData();

            }
            
        }
        return $items;
    }

    /**
     * {@inheritdoc}
     */
    public function getVerifiedUser($customerId,$supplierId)
    {    
        $status = ['confirmed','delivered','disputed'];
        $orderCollection = $this->orderCollectionFactory->create();
        $orderCollection->addFieldToFilter('customer_id', ['eq' => $customerId])
                        ->addFieldToFilter('status', ['in' => $status]);
        foreach($orderCollection as $order){
            $supplyDcId = $order->getDcid();
            $supplyDcCollection = $this->supplyDcCollectionFactory->create();
            $supplyDc = $supplyDcCollection->addFieldToFilter('dc_id', ['eq' => $supplyDcId])
                        ->getFirstItem();
            if($supplyDcCollection->count() && $supplyDc->getSupplyId()== $supplierId){
                return 1;
            }
        }
        return 0;
    }
    

    /**
     * {@inheritdoc}
     */
    public function getSuppliers($venueId)
    { 
        $venue = $this->venueRepositoryInterface->get($venueId);
        $venueZipCode = $venue->getZipCode();
        $activeDcs = $this->getActiveDCs($zipCode);
        $suppliers = [];
        foreach($activeDcs as $dc){
            $suppliers[] = $dc->getSupplyId();
        }
        return $suppliers;
    }
    /**
     * {@inheritdoc}
     */
    public function getVenueUserByCustomerId($customerId)
    { 
        $venueUsers = $this->venueUserCollectionFactory->create();
        $venueUser = $venueUsers->addFieldToFilter('magento_user_id', ['eq' => $customerId])->getFirstItem();
        return $venueUser;
    }
    /**
     * {@inheritdoc}
     */
    public function getVenueUserById($userId)
    { 
        $venueUsers = $this->venueUserCollectionFactory->create();
        $venueUser = $venueUsers->addFieldToFilter('id', ['eq' => $userId])->getFirstItem();
        if($venueUser->getData()){
            return $venueUser;
        }
        else{
            throw new NoSuchEntityException(__('Venue user with id "%1" does not exist.', $userId));
        }   
    }
    
    /**
     * {@inheritdoc}
     */
    public function getSupplyCompanyByCustomerId($customerId)
    { 
        $companies = $this->supplierCollectionFactory->create();
        $company = $companies->addFieldToFilter('company_admin', ['eq' => $customerId])->getFirstItem();
        return $company;
    }
    /**
     * {@inheritdoc}
     */
    public function getOverAllRatings($supplierId)
    {   
        $sum =0;
        $collection = $this->supplierReviewsCollectionFactory->create();
        $collection->addFieldToFilter('supplier_id',['eq' => $supplierId])
            ->addFieldToFilter('is_delete',['eq' => 0]);
        foreach($collection as $review){
            $sum +=$review->getRating();
        }
        if($sum){
            $avg = (int)$sum/((int)count($collection));
            return $avg;
        }
    }
    /**
     * {@inheritdoc}
     */
    public function getVenueOverAllRatings($supplierId,$venueId)
    {   
        $sum =0;
        $collection = $this->supplierReviewsCollectionFactory->create();
        $collection->addFieldToFilter('venue_id',['eq' => $venueId])
        ->addFieldToFilter('is_delete',['eq' => 0])
        ->addFieldToFilter('supplier_id',['eq' => $supplierId]);
        foreach($collection as $review){
            $sum +=$review->getRating();
        }
        if($sum){
            $avg = (int)$sum/((int)count($collection));
            return $avg;
        }
    }

    /**
     * {@inheritdoc}
     */
    public function setOverAllRatingsSupplier($supplierId,$venueId)
    { 
        try {
        
            $supplier = $this->supplyCompany->create();
            $this->supplyCompanyResource->load($supplier, $supplierId);
            if (!$supplier->getId()) {
                throw new NoSuchEntityException(__('dcUser  with id "%1" does not exist.', $supplierId));
            }
            $supplier->setRating($this->getOverAllRatings($supplierId));
            $supplier->save();
        } catch (\Exception $e) {
            throw new CouldNotDeleteException(__(
                    'Could not update the DC user',
                    $e->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function getSuppliersByVenueUser($venueUserId,$venueId)
    { 
        $venue = $this->venueRepositoryInterface->get($venueId);
        $venueZipCode = $venue->getZipCode();
        $activeDcs = $this->getActiveDCs($zipCode);
        $suppliers = [];
        foreach($activeDcs as $dc){
            $suppliers[] = $dc->getSupplyId();
        }
        $collection = $this->supplierReviewsCollectionFactory->create();
        $collection->addFieldToFilter('supplier_id',['in' => [$suppliers]])
            ->addFieldToFilter('venue_user_id',['eq'=>$venueUserId])
            ->addFieldToFilter('is_delete',['eq' => 0]);
        return $collection->getData();
    }


    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->supplierReviewsCollectionFactory->create();
        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }
         
    /**
     * @inheritdoc
     */
    public function deleteSupplierReview($customerId=null,$id)
    {
        try {
                $venueUserId = $this->getVenueUserByCustomerId($customerId)->getId();
                $this->checkOwner($id,$venueUserId);
                $reviewRatings = $this->reviewRatingsFactory->create();
                $this->supplierReviewsresource->load($reviewRatings, $id);
                if (!$reviewRatings->getId()) {
                    throw new NoSuchEntityException(__('reviewRatings Order  with id "%1" does not exist.', $id));
                }
                $this->setOverAllRatingsSupplier($reviewRatings->getSupplierId(),$reviewRatings->getVenueId());
                $reviewRatings->setIsDelete(1);
                $reviewRatings->save();
            } catch (\Exception $e) {
                throw new CouldNotDeleteException(__(
                    'Could not delete the supplier review',
                    $e->getMessage()
                ));
            }
        return true;
    }

    /**
     * @inheritdoc
     */
    public function removeSupplierReview($id)
    {
        try {
                $reviewRatings = $this->reviewRatingsFactory->create();
                $this->supplierReviewsresource->load($reviewRatings, $id);
                if (!$reviewRatings->getId()) {
                    throw new NoSuchEntityException(__('reviewRatings Order  with id "%1" does not exist.', $id));
                }
                $reviewRatings->delete();
            } catch (\Exception $e) {
                throw new CouldNotDeleteException(__(
                    'Could not delete the supplier review',
                    $e->getMessage()
                ));
            }
        return true;
    }

    /**
     * @inheritdoc
     */
    public function checkOwner($id,$customerId)
    {
        $reviewRatings = $this->reviewRatingsFactory->create();
        $this->supplierReviewsresource->load($reviewRatings, $id);
        if (!$reviewRatings->getId()) {
            throw new NoSuchEntityException(__('reviewRatings Order  with id "%1" does not exist.', $id));
        }
        else if($reviewRatings->getVenueUserId()!=$customerId) {
            throw new \Magento\Framework\Webapi\Exception(    __('current user does not own the review!'),
             0,\Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST );
        } else{
            return true; 
        } 
    }
    
    
}