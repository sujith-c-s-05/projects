<?php

namespace Aria\Venue\Helper;
use Magento\Framework\App\Helper\AbstractHelper;
use  Aria\Venue\Model\ResourceModel\VenueUserRoleMapping\CollectionFactory;
use  Aria\Venue\Api\VenueRolePermissionMappingRepositoryInterface;
use Magento\Framework\Exception\AuthorizationException;


class Data extends \Magento\Framework\App\Helper\AbstractHelper
{

    protected $venueUserroleMappingCollectionFactory;

    protected $venueRolePermissionMappingRepositoryInterface;


    public function __construct(
        CollectionFactory $venueUserroleMappingCollectionFactory,
        VenueRolePermissionMappingRepositoryInterface $venueRolePermissionMappingRepositoryInterface,
        \Magento\Framework\App\Helper\Context $context       
    ) {
        $this->venueUserroleMappingCollectionFactory = $venueUserroleMappingCollectionFactory;
        $this->venueRolePermissionMappingRepositoryInterface=$venueRolePermissionMappingRepositoryInterface;
        parent::__construct($context);
    }

     /**
     * To Check permission
     */
    public function permissionCheck($venueId,$venueUserId,$permission)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $venueUsermodel = $objectManager->create(\Aria\Venue\Model\VenueUser::class);
        $adminDetails = $venueUsermodel->load($venueUserId,'id');
        $isAdmin=$adminDetails->getIsAdmin();
        if($isAdmin!=1)
        {
            $venueUserDetails = $this->venueUserroleMappingCollectionFactory->create();
            $venueUserDetails->addFieldToFilter('venue_id',$venueId);
            $venueUserDetails->addFieldToFilter('venue_user_id',$venueUserId); 
            $roleIds=$venueUserDetails->addFieldToSelect('role_id');
            $roles=$roleIds->getData();
            $roleIds=array_column($roles, 'role_id');
            $roleId= reset($roleIds);

            $venueRolePermissionMappings=$this->venueRolePermissionMappingRepositoryInterface->getVenueRolePermissionMappings($roleId);
            if(count($venueRolePermissionMappings)>0)
            {
                $items=[];
                foreach($venueRolePermissionMappings as $key=>$permissionList)
                {
                    $isGranted=$permissionList->getIsGranted();
                    $isActive=$permissionList->getIsActive();
                    if(!$isGranted||!$isActive){
                        unset($venueRolePermissionMappings[$key]);
                    }
                    else
                    {
                        $permissionName=$permissionList->getPermissionName();   
                        $items[]=$permissionName;
                    }

                }
                if(!in_array($permission,$items))
                {
                    throw new AuthorizationException(
                        __("Access Denied.The Venue user does not have permission to access this module")
                    );        
                }
            }
            else
            {
                throw new AuthorizationException(
                    __("Access Denied.The Venue user does not have permission to access this module")
                );        
            }
        }
        return true;
    }
    
}