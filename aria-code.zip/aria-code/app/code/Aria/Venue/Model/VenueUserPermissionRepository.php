<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;
use Aria\Venue\Api\VenueUserPermissionRepositoryInterface;
use Aria\Venue\Api\Data\VenueUserPermissionInterfaceFactory;
use Aria\Venue\Api\Data\VenueUserPermissionSearchResultsInterfaceFactory;
use Aria\Venue\Model\ResourceModel\VenueUserPermission as ResourceVenueUserPermission;
use Aria\Venue\Model\ResourceModel\VenueUserPermission\CollectionFactory as VenueUserPermissionCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;

class VenueUserPermissionRepository implements VenueUserPermissionRepositoryInterface
{

    protected $venueUserPermissionCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;
    protected $venueUserPermissionFactory;

    protected $searchResultsFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataVenueUserPermissionFactory;
   

    /**
     * @param ResourceVenueUserPermission $resource
     * @param VenueUserPermissionFactory $venueUserPermissionFactory
     * @param VenueUserPermissionInterfaceFactory $dataVenueUserPermissionFactory
     * @param VenueUserPermissionCollectionFactory $venueUserPermissionCollectionFactory
     * @param VenueUserPermissionSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     */
    public function __construct(
        ResourceVenueUserPermission $resource,
        VenueUserPermissionFactory $venueUserPermissionFactory,
        VenueUserPermissionInterfaceFactory $dataVenueUserPermissionFactory,
        VenueUserPermissionCollectionFactory $venueUserPermissionCollectionFactory,
        VenueUserPermissionSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter
    ) {
        $this->resource = $resource;
        $this->venueUserPermissionFactory = $venueUserPermissionFactory;
        $this->venueUserPermissionCollectionFactory = $venueUserPermissionCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataVenueUserPermissionFactory = $dataVenueUserPermissionFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
    }

   
    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->venueUserPermissionCollectionFactory->create();
        
        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\Venue\Api\Data\VenueUserPermissionInterface::class
        );
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function get($Id)
    {
        $venuePermission = $this->venueUserPermissionFactory->create();
        $this->resource->load($venuePermission, $Id);
        if (!$venuePermission->getId()) {
            throw new NoSuchEntityException(__('Veue User Permission with id "%1" does not exist.', $Id));
        }
        return $venuePermission->getDataModel();
    }

     /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\Venue\Api\Data\VenueUserPermissionInterface $venuePermission
    ) {
        
        $venueUserPermissionData = $this->extensibleDataObjectConverter->toNestedArray(
            $venuePermission,
            [],
            \Aria\Venue\Api\Data\VenueUserPermissionInterface::class
        );
        $venueUserPermissionModel = $this->venueUserPermissionFactory->create()->setData($venueUserPermissionData);
        

        try {
            $this->resource->save($venueUserPermissionModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the venue user role: %1',
                $exception->getMessage()
            ));
        }
        return $venueUserPermissionModel->getDataModel();
    }

}