<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\Data\VenueUserInterface;
use Aria\Venue\Api\Data\VenueUserInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class VenueUser extends \Magento\Framework\Model\AbstractModel
{

    protected $venueUserDataFactory;
    protected $_eventPrefix = 'aria_venue_user';
    protected $dataObjectHelper;



    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param VenueUserInterfaceFactory $venueUserDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\Venue\Model\ResourceModel\VenueUser $resource
     * @param \Aria\Venue\Model\ResourceModel\VenueUser\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        VenueUserInterfaceFactory $venueUserDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\Venue\Model\ResourceModel\VenueUser $resource,
        \Aria\Venue\Model\ResourceModel\VenueUser\Collection $resourceCollection,
        array $data = []
    ) {
        $this->venueUserDataFactory = $venueUserDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve venue user model with venue user data
     * @return VenueUserInterface
     */
    public function getDataModel()
    {
        $venueUserData = $this->getData();

        $venueUserDataObject = $this->venueUserDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $venueUserDataObject,
            $venueUserData,
            VenueUserInterface::class
        );

        return $venueUserDataObject;
    }



}