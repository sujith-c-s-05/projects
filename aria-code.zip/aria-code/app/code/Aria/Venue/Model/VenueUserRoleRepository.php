<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\VenueUserRoleRepositoryInterface;
use Aria\Venue\Api\Data\VenueUserRoleInterfaceFactory;
use Aria\Venue\Api\Data\VenueUserRoleSearchResultsInterfaceFactory;
use Aria\Venue\Model\ResourceModel\VenueUserRole as ResourceVenueUserRole;
use Aria\Venue\Model\ResourceModel\VenueUserRole\CollectionFactory as VenueUserRoleCollectionFactory;
use Aria\Venue\Model\ResourceModel\VenueUserRoleMapping\CollectionFactory as VenueUserRoleMappingCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Aria\Venue\Model\VenueUserRoleFactory as VenueUserRoleFactory;
use Aria\Venue\Model\VenueRolePermissionMappingFactory as VenueRolePermissionMappingFactory;
use Aria\Venue\Model\ResourceModel\VenueRolePermissionMapping as ResourceVenueRolePermissionMapping;
use Aria\Venue\Model\VenueRolePermissionMappingRepository as venueRolePermissionMappingRepository;
use Aria\Venue\Model\ResourceModel\VenueRolePermissionMapping\CollectionFactory as VenueRolePermissionMappingCollectionFactory;

class VenueUserRoleRepository implements VenueUserRoleRepositoryInterface
{

    protected $venueUserRoleCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;

    protected $venueUserRoleFactory;

    protected $searchResultsFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataVenueUserRoleFactory;
    protected $venueUserRoleMappingCollectionFactory;

    protected $venueRolePermissionMappingFactory;

    protected $venueRolePermissionMappingRepository;

    /**
     * @var Aria\Venue\Api\VenueRolePermissionMappingRepositoryInterface
     */
    protected $venueRolePermissionMappingRepositoryInterface;

    protected $venueRolePermissionMappingCollectionFactory;

     /** @var  \Magento\Framework\DB\Adapter\AdapterInterface */
     protected $_conn;

     /** @var \Magento\Framework\App\ResourceConnection */
     protected $_resourceConnection;


     /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
     protected $_searchCriteria;

     /**
      * @var \Magento\Framework\Api\FilterBuilder
      */
     protected $filterBuilder;

    



    /**
     * @param ResourceVenueUserRole $resource
     * @param VenueUserRoleFactory $venueUserRoleFactory
     * @param VenueUserRoleMappingCollectionFactory $venueUserRoleMappingCollectionFactory
     * @param VenueUserRoleInterfaceFactory $dataVenueUserRoleFactory
     * @param VenueUserRoleCollectionFactory $venueUserRoleCollectionFactory
     * @param VenueUserRoleSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param VenueRolePermissionMappingFactory $venueRolePermissionMappingFactory
     * @param ResourceVenueRolePermissionMapping $resourceVenueRolePermissionMapping
     * @param \Aria\Venue\Api\VenueRolePermissionMappingRepositoryInterface $venueRolePermisssionMappingRepositoryInterface
     * @param VenueRolePermissionMappingCollectionFactory $venueRolePermissionMappingCollectionFactory
     * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
     * @param \Magento\Framework\Api\FilterBuilder $filterBuilder
     * @param VenueUserRoleMappingCollectionFactory $venueUserRoleMappingCollectionFactory
     */

    public function __construct(
        ResourceVenueUserRole $resource,
        VenueUserRoleFactory $venueUserRoleFactory,
        VenueUserRoleInterfaceFactory $dataVenueUserRoleFactory,
        VenueUserRoleCollectionFactory $venueUserRoleCollectionFactory,
        VenueUserRoleMappingCollectionFactory $venueUserRoleMappingCollectionFactory,
        VenueUserRoleSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        VenueRolePermissionMappingFactory $venueRolePermissionMappingFactory,
        ResourceVenueRolePermissionMapping $resourceVenueRolePermissionMapping,
        venueRolePermissionMappingRepository $venueRolePermissionMappingRepository,
        \Aria\Venue\Api\VenueRolePermissionMappingRepositoryInterface $venueRolePermissionMappingRepositoryInterface,
        VenueRolePermissionMappingCollectionFactory $venueRolePermissionMappingCollectionFactory,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\Api\FilterBuilder $filterBuilder,
        \Magento\Framework\App\ResourceConnection $resourceConnection
    ) 
    {
        $this->resource = $resource;
        $this->venueUserRoleFactory = $venueUserRoleFactory;
        $this->venueUserRoleCollectionFactory = $venueUserRoleCollectionFactory;
        $this->venueUserRoleMappingCollectionFactory = $venueUserRoleMappingCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataVenueUserRoleFactory = $dataVenueUserRoleFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->venueRolePermissionMappingFactory = $venueRolePermissionMappingFactory;
        $this->resourceVenueRolePermissionMapping=$resourceVenueRolePermissionMapping;
        $this->venueRolePermissionMappingRepository=$venueRolePermissionMappingRepository;
        $this->venueRolePermissionMappingRepositoryInterface=$venueRolePermissionMappingRepositoryInterface;
        $this->venueRolePermissionMappingCollectionFactory = $venueRolePermissionMappingCollectionFactory;
        $this->_searchCriteria = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->_resourceConnection = $resourceConnection;
        $this->_conn = $resourceConnection->getConnection(); 
        
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\Venue\Api\Data\VenueUserRoleInterface $venueUserrole
    ) { 
        try {
            $this->_conn->beginTransaction();
           
        $venueUserroleData = $this->extensibleDataObjectConverter->toNestedArray(
            $venueUserrole,
            [],
            \Aria\Venue\Api\Data\VenueUserRoleInterface::class
        );
        $venueUserroleEntityId=$venueUserrole->getId();
        $venueUserroleModel = $this->venueUserRoleFactory->create()->setData($venueUserroleData);
        $venueUserrole=$venueUserroleModel->save();
        $id=$venueUserrole->getId();

        $this->venueRolePermissionMappingRepositoryInterface->deleteVenueRolePermissionMapping($venueUserroleEntityId);      

            $venueUserroleMap=$venueUserrole->getVenueRolePermissionMapping();   
            foreach($venueUserroleMap as $venueList)
            {  
                $venueRolePermissionMappingModel = $this->venueRolePermissionMappingFactory->create()->setData($venueList);     

                $venueRolePermissionMappingModel->setRoleId($id);
                $venueRolePermissionMappingModel->setCreatedBy($venueUserrole->getCreatedBy());
                $venueRolePermissionMappingModel->setCreatedAt($venueUserrole->getCreatedAt());
                $venueRolePermissionMappingModel->setUpdatedAt($venueUserrole->getUpdatedAt());
                $venueRolePermissionMappingModel->setUpdatedBy($venueUserrole->getUpdatedBy());
                $venueRolePermissionMappingModel->setIsActive($venueUserrole->getIsActive());

                $this->resourceVenueRolePermissionMapping->save($venueRolePermissionMappingModel);
            }
            $this->_conn->commit();

        } 
     
         catch (\Exception $exception) {
            $this->_conn->rollBack();
            throw new CouldNotSaveException(__(
                'Could not save the venue user role: %1',
                $exception->getMessage()
            ));
        }
        return $venueUserroleModel->getDataModel();
    }

    /**
     * {@inheritdoc}
    */
    public function isRoleNameExists($roleName,$hgid,$id=null)
    {
      $isRoleNameExists=false;
      $role = $this->venueUserRoleCollectionFactory->create();
        if(is_numeric($id))
        {
            $venueRole=$this->getById($id);
            $venueRoleName=$venueRole->getRoleName();
            if(strtolower($venueRoleName)!=strtolower($roleName))
            {
                $role->addFieldToFilter('role_name', $roleName);
                $role->addFieldToFilter('hg_admin_id', $hgid);
                $role->addFieldToFilter('is_delete',0);
                if($role->count()>0)
                {
                    $isRoleNameExists=true;
                }
            }
        }
        else
        {
            $role->addFieldToFilter('role_name', $roleName);
            $role->addFieldToFilter('hg_admin_id', $hgid);
            $role->addFieldToFilter('is_delete',0);
            if($role->count()>0)
            {
                $isRoleNameExists=true;
            }
    
         }
      return $isRoleNameExists;
     
     
    }

     /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->venueUserRoleCollectionFactory->create();
        
        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\Venue\Api\Data\VenueUserRoleInterface::class
        );
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            
            $items[] = $model->getDataModel();
        }
        foreach($items as $item){

            $venueUserroleId=$item->getId();
            $venueRolePermissionMappings=$this->venueRolePermissionMappingRepositoryInterface->getVenueRolePermissionMappings($venueUserroleId);
            $item->setVenueRolePermissionMapping($venueRolePermissionMappings);  
        }
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function getById($Id)
    {
        $venueUserrole = $this->venueUserRoleFactory->create();
        $this->resource->load($venueUserrole, $Id);
        $venueRolePermissionMappings=$this->venueRolePermissionMappingRepositoryInterface->getVenueRolePermissionMappingsDetails($Id);

        $venueUserrole->setVenueRolePermissionMapping($venueRolePermissionMappings);       
         
        if (!$venueUserrole->getId()) {
            throw new NoSuchEntityException(__('Venue user role with id "%1" does not exist.', $Id));
        }
        return $venueUserrole;
    }

   /**
     * {@inheritdoc}
     */
    public function deleteVenueUserRole($id)
    {
             
        $venueUserRole = $this->venueUserRoleFactory->create();
        $this->resource->load($venueUserRole, $id);
        $venueUserRole->setIsDelete(1);
        $venueUserRole->setIsActive(0);
        $venueUser=$this->venueUserRoleMappingCollectionFactory->create();
        $venueUser->addFieldToFilter('role_id', $id);
        if($venueUser->count()==0)
        {
            $venueUserRole->save();
        }
        else
        {
        throw new \Magento\Framework\Webapi\Exception(    __('Roles cannot be deleted while assigned to one or more venue users'),
        0,\Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST
        );
        } 
        if($venueUserRole->save())
        {
            $this->venueRolePermissionMappingRepositoryInterface->deleteVenueRolePermissionMapping($id);      
        }                      
        return true;
    }
}
