<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\Data\VenueUserRoleInterface;
use Aria\Venue\Api\Data\VenueUserRoleInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class VenueUserRole extends \Magento\Framework\Model\AbstractModel
{

    protected $venueUserRoleDataFactory;
    protected $_eventPrefix = 'aria_venue_user_role';
    protected $dataObjectHelper;
   

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param VenueUserRoleInterfaceFactory $venueUserRoleDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\Venue\Model\ResourceModel\VenueUserRole $resource
     * @param \Aria\Venue\Model\ResourceModel\VenueUserRole\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        VenueUserRoleInterfaceFactory $venueUserRoleDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\Venue\Model\ResourceModel\VenueUserRole $resource,
        \Aria\Venue\Model\ResourceModel\VenueUserRole\Collection $resourceCollection,
        array $data = []
    ) {
        $this->venueUserRoleDataFactory = $venueUserRoleDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve venue user role model with venue user data
     * @return VenueUserRoleInterface
     */
    public function getDataModel()
    {
        $venueUserRoleData = $this->getData();

        $venueUserRoleDataObject = $this->venueUserRoleDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $venueUserRoleDataObject,
            $venueUserRoleData,
            VenueUserRoleInterface::class
        );

        return $venueUserRoleDataObject;
    }


}