<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\Data\VenueUserEditProfileInterface;
use Aria\Venue\Api\Data\VenueUserEditProfileInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class VenueUserEditProfile extends \Magento\Framework\Model\AbstractModel
{

    protected $venueUserEditProfileDataFactory;
    protected $_eventPrefix = 'aria_venue_user';
    protected $dataObjectHelper;



    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param VenueUserEditProfileInterfaceFactory $venueUserEditProfileDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\Venue\Model\ResourceModel\VenueUserEditProfile $resource
     * @param \Aria\Venue\Model\ResourceModel\VenueUserEditProfile\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        VenueUserEditProfileInterfaceFactory $venueUserEditProfileDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\Venue\Model\ResourceModel\VenueUserEditProfile $resource,
        \Aria\Venue\Model\ResourceModel\VenueUserEditProfile\Collection $resourceCollection,
        array $data = []
    ) {
        $this->venueUserEditProfileDataFactory = $venueUserEditProfileDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve venue user model with venue user data
     * @return VenueUserEditProfileInterface
     */
    public function getDataModel()
    {
        $venueUserEditProfileData = $this->getData();

        $venueUserEditProfileDataObject = $this->venueUserEditProfileDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $venueUserEditProfileDataObject,
            $venueUserEditProfileData,
            VenueUserEditProfileInterface::class
        );

        return $venueUserEditProfileDataObject;
    }



}