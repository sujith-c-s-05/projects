<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\ReferAriaRepositoryInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;

class ReferAriaRepository implements ReferAriaRepositoryInterface
{
    /**
    * @var \Magento\Framework\Mail\Template\TransportBuilder
    */
    protected $_transportBuilder;

    /** 
    * @var \Magento\Framework\Translate\Inline\StateInterface
    */
    protected $inlineTranslation;

    /** 
    * @var \Magento\Framework\App\Config\ScopeConfigInterface
    */
    protected $scopeConfig;

    /**
    * @var \Magento\Store\Model\StoreManagerInterface
    */
    protected $storeManager;
    /**
    * @var \Magento\Framework\Escaper
    */
    protected $_escaper;

    public $customerRepository;

    protected $venueUserRepository;

    /**
     * Undocumented function
     *
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Escaper $escaper
     * @param CustomerRepositoryInterface $customerRepository
     * @param \Aria\Venue\Api\VenueUserRepositoryInterface $venueUserRepository
     */
    public function __construct(
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Escaper $escaper,
        CustomerRepositoryInterface $customerRepository,
        \Aria\Venue\Api\VenueUserRepositoryInterface $venueUserRepository


    ) {
        $this->_transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_escaper = $escaper;
        $this->customerRepository = $customerRepository;
        $this->venueUserRepository = $venueUserRepository;
    }

    /**
     * Refer Aria function
     *
     * @param \Aria\Venue\Api\Data\ReferAriaInterface $refer
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function referAria($referAria)
    {
        $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId());
        $venueUserId = $referAria->getUserId();
        $venueUserDetails = $this->venueUserRepository->get($venueUserId);
        $receiverEmail=$referAria->getReceiverEmail();
        $senderName = $venueUserDetails->getFirstName(). ' ' .$venueUserDetails->getLastName();
        $senderEmail = $this->scopeConfig->getValue('trans_email/ident_support/email',ScopeInterface::SCOPE_STORE);
        $url = $this->scopeConfig->getValue('url/general/base_url',ScopeInterface::SCOPE_STORE);
        $this->inlineTranslation->suspend();
        $templateVars = array(
             'senderName' => $senderName,
             'url'=>$url
         );  
         $from = [
            'email' => $senderEmail,
            'name' => $senderName
         ];
         $transport = $this->_transportBuilder->setTemplateIdentifier('aria_refer_register_template',ScopeInterface::SCOPE_STORE)
         ->setTemplateOptions($templateOptions)
         ->setTemplateVars($templateVars)
         ->setFrom($from)
         ->addTo($receiverEmail)

         ->getTransport();
         $transport->sendMessage();
         $this->inlineTranslation->resume();
         return true;

    }

}