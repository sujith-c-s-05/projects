<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\VenueUserRoleMappingRepositoryInterface;
use Aria\Venue\Api\Data\VenueUserRoleMappingInterfaceFactory;
use Aria\Venue\Api\Data\VenueUserRoleMappingSearchResultsInterfaceFactory;
use Aria\Venue\Model\ResourceModel\VenueUserRoleMapping as ResourceVenueUserRoleMapping;
use Aria\Venue\Model\ResourceModel\VenueUserRoleMapping\CollectionFactory as VenueUserRoleMappingCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Aria\Venue\Helper\Data as HelperData;

class VenueUserRoleMappingRepository implements VenueUserRoleMappingRepositoryInterface
{

    protected $venueUserRoleMappingCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;

    protected $venueUserRoleMappingFactory;

    protected $searchResultsFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataVenueUserRoleMappingFactory;
    protected  $venueRepositoryInterface;
    protected $venueUserRoleRepositoryInterface;
    /**
     * @var HelperData
     */
    protected $helper;

    /**
     * @param ResourceVenueUserRoleMapping $resource
     * @param VenueUserRoleMappingFactory $venueUserRoleMappingFactory
     * @param VenueUserRoleMappingInterfaceFactory $dataVenueUserRoleMappingFactory
     * @param VenueUserRoleMappingCollectionFactory $venueUserRoleMappingCollectionFactory
     * @param VenueUserRoleMappingSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param \Aria\Venue\Api\VenueRepositoryInterface $venueRepositoryInterface
     * @param \Aria\Venue\Api\VenueUserRoleRepositoryInterface $venueUserRoleRepositoryInterface
     * @param HelperData $helper
     */
    public function __construct(
        ResourceVenueUserRoleMapping $resource,
        VenueUserRoleMappingFactory $venueUserRoleMappingFactory,
        VenueUserRoleMappingInterfaceFactory $dataVenueUserRoleMappingFactory,
        VenueUserRoleMappingCollectionFactory $venueUserRoleMappingCollectionFactory,
        VenueUserRoleMappingSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Aria\Venue\Api\VenueRepositoryInterface $venueRepositoryInterface,
        \Aria\Venue\Api\VenueUserRoleRepositoryInterface $venueUserRoleRepositoryInterface,
        HelperData $helper
        ) {
        $this->resource = $resource;
        $this->venueUserRoleMappingFactory = $venueUserRoleMappingFactory;
        $this->venueUserRoleMappingCollectionFactory = $venueUserRoleMappingCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataVenueUserRoleMappingFactory = $dataVenueUserRoleMappingFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->venueRepositoryInterface = $venueRepositoryInterface;
        $this->venueUserRoleRepositoryInterface = $venueUserRoleRepositoryInterface;
        $this->helper = $helper;

    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\Venue\Api\Data\VenueUserRoleMappingInterface $venueUserRoleMapping
    ) {
        
        $venueUserRoleMappingData = $this->extensibleDataObjectConverter->toNestedArray(
            $venueUserRoleMapping,
            [],
            \Aria\Venue\Api\Data\VenueUserRoleMappingInterface::class
        );
  $venueUserRoleMappingModel = $this->venueUserRoleMappingFactory->create()->setData($venueUserRoleMappingData);
        

        try {
            $this->resource->save($venueUserRoleMappingModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the venue user role: %1',
                $exception->getMessage()
            ));
        }
        return $venueUserRoleMappingModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function deleteVenueUserRoleMapping($venueUserId)
    { 
        $venueUserRoleMapping = $this->venueUserRoleMappingCollectionFactory->create();
        $venueUserRoleMapping->addFieldToFilter('venue_user_id',$venueUserId);
        foreach ($venueUserRoleMapping as $model) {
            $this->resource->delete($model);
        }
        
        return true;
        
    }
    
     /**
     * {@inheritdoc}
     */
    public function getVenueUserRoleMappings($Id)
    { 
        $venueRole = $this->venueUserRoleMappingCollectionFactory->create();
        $venueRole->addFieldToFilter('venue_user_id',$Id);
        $items = [];
        foreach ($venueRole as $model) {
            $venueId=$model->getVenueId();
            $venueEntity=$this->venueRepositoryInterface->get($venueId);
            $roleId=$model->getRoleId();
            $venueUserRoleEntity=$this->venueUserRoleRepositoryInterface->getById($roleId);
            $model->setVenueName($venueEntity->getName());
            $model->setOrderCostLimit($venueEntity->getOrderCostLimit());
            $model->setRoleName($venueUserRoleEntity->getRoleName());
            $items[] = $model->getDataModel();
        }
        return $items;
    }

    /**
     * {@inheritdoc}
     */
    public function setStatusUserRoleMapping($Id,$isActive) {
        try {
                $venueUserRoleMappingCollection =$this->venueUserRoleMappingCollectionFactory->create();
                $venueUserRoleMappingCollection->addFieldToFilter('venue_user_id',$Id);
                foreach ($venueUserRoleMappingCollection as $model) {
                    $venueRoleMapping = $model->setIsActive($isActive);
                    $this->resource->save($venueRoleMapping);
                }
        }catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not activate the venue user role',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function getVenues($Id)
    {
        $venueRole = $this->venueUserRoleMappingCollectionFactory->create();
        $venueRole->addFieldToFilter('venue_user_id',$Id);
        $items = [];
        foreach ($venueRole as $model) {

            $venueId=$model->getVenueId();
            $venueEntity=$this->venueRepositoryInterface->get($venueId);
            $venueName = $venueEntity->getName();

            $venue['id'] = $model->getVenueId();
            $venue['name'] = $venueName;
            $items[] = $venue;
        }
        return $items;
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->venueUserRoleMappingCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\Venue\Api\Data\VenueUserRoleMappingInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    public function getVenueUserRole($venue_user_id,$venue_id)
    {
        $venueRole = $this->venueUserRoleMappingCollectionFactory->create();
        $venueRole->addFieldToFilter('venue_user_id',$venue_user_id)->addFieldToFilter('venue_id',$venue_id);
        $roleId='';
        foreach ($venueRole as $model) {

            $roleId=$model->getRoleId();
            
        }
        return $roleId;
    }

    public function getVenueUsers($venue_id){
        
        $venueRole = $this->venueUserRoleMappingCollectionFactory->create();
        $venueRole->addFieldToFilter('venue_id',$venue_id);
        $venueusers =[];
        foreach ($venueRole as $model) {

            $venueusers[]=$model->getVenueUserId();
            
        }
        return $venueusers;
       
        }    
    public function isPermissionAppproved($venueUserId,$venueId,$permission)
    {
        $this->helper->permissionCheck($venueId,$venueUserId,$permission);
        return true;
    }
}