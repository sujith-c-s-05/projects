<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\Data\VenueUserPermissionInterface;
use Aria\Venue\Api\Data\VenueUserPermissionInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class VenueUserPermission extends \Magento\Framework\Model\AbstractModel
{

    protected $venueUserPermissionDataFactory;

    protected $_eventPrefix = 'aria_venue_user_permissions';
    protected $dataObjectHelper;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param VenueUserPermissionInterfaceFactory $venueUserPermissionDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\Venue\Model\ResourceModel\VenueUserPermission $resource
     * @param \Aria\Venue\Model\ResourceModel\VenueUserPermission\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        VenueUserPermissionInterfaceFactory $venueUserPermissionDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\Venue\Model\ResourceModel\VenueUserPermission $resource,
        \Aria\Venue\Model\ResourceModel\VenueUserPermission\Collection $resourceCollection,
        array $data = []
    ) {
        $this->venueUserPermissionDataFactory = $venueUserPermissionDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve venue user permission model with user role data
     * @return VenueUserPermissionInterface
     */
    public function getDataModel()
    {
        $venueUserPermissionData = $this->getData();
        
        $venueUserPermissionDataObject = $this->venueUserPermissionDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $venueUserPermissionDataObject,
            $venueUserPermissionData,
            VenueUserPermissionInterface::class
        );
        
        return $venueUserPermissionDataObject;
    }


}
