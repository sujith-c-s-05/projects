<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\Data\VenueUserRoleMappingInterface;
use Aria\Venue\Api\Data\VenueUserRoleMappingInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class VenueUserRoleMapping extends \Magento\Framework\Model\AbstractModel
{

    protected $venueUserRoleMappingDataFactory;
    protected $_eventPrefix = 'aria_venue_user_role_mapping';
    protected $dataObjectHelper;
   

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param VenueUserRoleMappingInterfaceFactory $venueUserRoleMappingDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\Venue\Model\ResourceModel\VenueUserRoleMapping $resource
     * @param \Aria\Venue\Model\ResourceModel\VenueUserRoleMapping\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        VenueUserRoleMappingInterfaceFactory $venueUserRoleMappingDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\Venue\Model\ResourceModel\VenueUserRoleMapping $resource,
        \Aria\Venue\Model\ResourceModel\VenueUserRoleMapping\Collection $resourceCollection,
        array $data = []
    ) {
        $this->venueUserRoleMappingDataFactory = $venueUserRoleMappingDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve venue user role model with venue user data
     * @return VenueUserRoleMappingInterface
     */
    public function getDataModel()
    {
        $venueUserRoleMappingData = $this->getData();

        $venueUserRoleMappingDataObject = $this->venueUserRoleMappingDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $venueUserRoleMappingDataObject,
            $venueUserRoleMappingData,
            VenueUserRoleMappingInterface::class
        );

        return $venueUserRoleMappingDataObject;
    }


}