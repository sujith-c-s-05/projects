<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\VenueRepositoryInterface;
use Aria\Venue\Api\Data\VenueInterfaceFactory;
use Aria\Venue\Model\ResourceModel\VenueUserRoleMapping\CollectionFactory as VenueUserRoleMappingCollectionFactory;
use Aria\Venue\Api\Data\VenueSearchResultsInterfaceFactory;
use Aria\Venue\Model\ResourceModel\Venue as ResourceVenue;
use Aria\Venue\Model\ResourceModel\Venue\CollectionFactory as VenueCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;

class VenueRepository implements VenueRepositoryInterface
{

    protected $venueCollectionFactory;

    protected $venueUserRoleMappingCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;
    protected $venueFactory;

    protected $searchResultsFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataVenueFactory;


    /**
     * @param ResourceVenue $resource
     * @param VenueFactory $venueFactory
     * @param VenueInterfaceFactory $dataVenueFactory
     * @param VenueCollectionFactory $venueCollectionFactory
     * @param VenueSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param VenueUserRoleMappingCollectionFactory $venueUserRoleMappingCollectionFactory
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     */
    public function __construct(
        ResourceVenue $resource,
        VenueFactory $venueFactory,
        VenueInterfaceFactory $dataVenueFactory,
        VenueCollectionFactory $venueCollectionFactory,
        VenueSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        VenueUserRoleMappingCollectionFactory $venueUserRoleMappingCollectionFactory,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter
    ) {
        $this->resource = $resource;
        $this->venueFactory = $venueFactory;
        $this->venueCollectionFactory = $venueCollectionFactory;
        $this->venueUserRoleMappingCollectionFactory = $venueUserRoleMappingCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataVenueFactory = $dataVenueFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\Venue\Api\Data\VenueInterface $venue
    ) {
        
        $venueData = $this->extensibleDataObjectConverter->toNestedArray(
            $venue,
            [],
            \Aria\Venue\Api\Data\VenueInterface::class
        );

        $venueModel = $this->venueFactory->create()->setData($venueData);

        try {
            $this->resource->save($venueModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the venue: %1',
                $exception->getMessage()
            ));
        }
        return $venueModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($Id)
    { 
        $venue = $this->venueFactory->create();
        $this->resource->load($venue, $Id);
        if (!$venue->getId()) {
            throw new NoSuchEntityException(__('Venue with id "%1" does not exist.', $Id));
        }
        return $venue->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->venueCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\Venue\Api\Data\VenueInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }
    
    /**
     * {@inheritdoc}
     */
    public function setStatus($Id,$isActive) {

        $venue = $this->venueFactory->create();
        $venue->setData('is_active', $isActive);
        $venue->setData('id',$Id);
        $orderCount = $venue->getOrderCount($Id);
        $venueCount = $venue->getVenueCount($Id);
        if($orderCount == $venueCount)
        {
        $this->resource->save($venue);
        return true;
        }
        else
        {
           throw new \Magento\Framework\Webapi\Exception(    __('This Venue cannot be activated/deactivated until all outstanding orders and returns have been processed'),
           0,\Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST
           );
        }
    }
    /**
     * {@inheritdoc}
     */
    public function deleteByIds(array $Id)
    {  
        foreach ($Id as $i) 
        {  $isDeleted=false;
            $venue = $this->venueFactory->create();
            $orderCount = $venue->getOrderCount($i);
            $venueCount = $venue->getVenueCount($i);
            $venue->setData('is_delete',1);
            $venue->setData('id',$i);
            if($orderCount == $venueCount)
            { 
                
                $venueUser=$this->venueUserRoleMappingCollectionFactory->create();
                $venueUser->addFieldToFilter('venue_id', $i);
                foreach($venueUser as $user)
                {
                  $user->setIsDelete(1);
                  $user->save();
                }
              $this->resource->save($venue);
              $isDeleted=true;
            }
            else
             {
                
                throw new \Magento\Framework\Webapi\Exception( __('This venue cannot be deleted until all outstanding orders and returns have been processed'),
                0,\Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST
                );           
                
            }
        }    
          return $isDeleted;      
    }      

    /**
     * {@inheritdoc}
     */
   
    public function isVenueNameExists($name,$hgid,$id = null)
    {
        $isVenueNameExists=false;
        $nameCollection = $this->venueCollectionFactory->create();
        if(is_numeric($id))
        {   
            $venue=$this->get($id);
            $venueName=$venue->getName();
            if(strtolower($venueName)!=strtolower($name))
            {
                $nameCollection->addFieldToFilter('name', $name); 
                $nameCollection->addFieldToFilter('hosp_id', $hgid);
                $nameCollection->addFieldToFilter('is_delete',0);
                if($nameCollection->count()>0)
                {
                    $isVenueNameExists=true;
                }
            
            }
        }
        else
        {    
            $nameCollection->addFieldToFilter('name', $name); 
            $nameCollection->addFieldToFilter('hosp_id', $hgid);
            $nameCollection->addFieldToFilter('is_delete',0);
            if($nameCollection->count()>0)
            {
                $isVenueNameExists=true;
            }
            
        }
        return $isVenueNameExists;
    }

}    