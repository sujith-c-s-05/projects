<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\Data\VenueRolePermissionMappingInterface;
use Aria\Venue\Api\Data\VenueRolePermissionMappingInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class VenueRolePermissionMapping extends \Magento\Framework\Model\AbstractModel
{

    protected $venueRolePermissionMappingDataFactory;

    protected $_eventPrefix = 'aria_venue_role_permission_mapping';
    protected $dataObjectHelper;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param VenueRolePermissionMappingInterfaceFactory $venueRolePermissionMappingDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\Venue\Model\ResourceModel\VenueRolePermissionMapping $resource
     * @param \Aria\Venue\Model\ResourceModel\VenueRolePermissionMapping\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        VenueRolePermissionMappingInterfaceFactory $venueRolePermissionMappingDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\Venue\Model\ResourceModel\VenueRolePermissionMapping $resource,
        \Aria\Venue\Model\ResourceModel\VenueRolePermissionMapping\Collection $resourceCollection,
        array $data = []
    ) {
        $this->venueRolePermissionMappingDataFactory = $venueRolePermissionMappingDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve venue role permission model with user role data
     * @return VenueRolePermissionMappingInterface
     */
    public function getDataModel()
    {
        $venueRolePermissionMappingData = $this->getData();
        
        $venueRolePermissionMappingDataObject = $this->venueRolePermissionMappingDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $venueRolePermissionMappingDataObject,
            $venueRolePermissionMappingData,
            VenueRolePermissionMappingInterface::class
        );
        
        return $venueRolePermissionMappingDataObject;
    }


}
