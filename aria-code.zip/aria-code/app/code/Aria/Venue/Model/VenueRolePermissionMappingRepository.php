<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\VenueRolePermissionMappingRepositoryInterface;
use Aria\Venue\Api\Data\VenueRolePermissionMappingInterfaceFactory;
use Aria\Venue\Model\ResourceModel\VenueRolePermissionMapping as ResourceVenueRolePermissionMapping;
use Aria\Venue\Model\ResourceModel\VenueRolePermissionMapping\CollectionFactory as VenueRolePermissionMappingCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Aria\Venue\Model\ResourceModel\VenueUserPermission\CollectionFactory as VenueUserPermissionCollectionFactory;

class VenueRolePermissionMappingRepository implements VenueRolePermissionMappingRepositoryInterface
{

    protected $venueRolePermissionMappingCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;

    protected $venueRolePermissionMappingFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataVenueRolePermissionMappingFactory;

    protected $venueUserPermissionRepositoryInterface;

    protected $venueUserPermissionCollectionFactory;

    /**
     * @param ResourceVenueRolePermissionMapping $resource
     * @param VenueRolePermissionMappingFactory $venueRolePermissionMappingFactory
     * @param VenueRolePermissionMappingInterfaceFactory $dataVenueRolePermissionMappingFactory
     * @param VenueRolePermissionMappingCollectionFactory $venueRolePermissionMappingCollectionFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param \Aria\Venue\Api\VenueUserPermissionRepositoryInterface $venueUserPermissionRepositoryInterface
     * @param VenueUserPermissionCollectionFactory $venueUserPermissionCollectionFactory
     */
    public function __construct(
        ResourceVenueRolePermissionMapping $resource,
        VenueRolePermissionMappingFactory $venueRolePermissionMappingFactory,
        VenueRolePermissionMappingInterfaceFactory $dataVenueRolePermissionMappingFactory,
        VenueRolePermissionMappingCollectionFactory $venueRolePermissionMappingCollectionFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Aria\Venue\Api\VenueUserPermissionRepositoryInterface $venueUserPermissionRepositoryInterface,
        VenueUserPermissionCollectionFactory $venueUserPermissionCollectionFactory
    ) {
        $this->resource = $resource;
        $this->venueRolePermissionMappingFactory = $venueRolePermissionMappingFactory;
        $this->venueRolePermissionMappingCollectionFactory = $venueRolePermissionMappingCollectionFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataVenueRolePermissionMappingFactory = $dataVenueRolePermissionMappingFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->venueUserPermissionRepositoryInterface = $venueUserPermissionRepositoryInterface;
        $this->venueUserPermissionCollectionFactory = $venueUserPermissionCollectionFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\Venue\Api\Data\VenueRolePermissionMappingInterface $venueRolePermissionMapping
    ) {
        
        $venueRolePermissionMappingData = $this->extensibleDataObjectConverter->toNestedArray(
            $venueRolePermissionMapping,
            [],
            \Aria\Venue\Api\Data\VenueRolePermissionMappingInterface::class
        );
        $venueRolePermissionMappingModel = $this->venueRolePermissionMappingFactory->create()->setData($venueRolePermissionMappingData);
        
        try {
            $this->resource->save($venueRolePermissionMappingModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the dc user role: %1',
                $exception->getMessage()
            ));
        }
        return $venueRolePermissionMappingModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function deleteVenueRolePermissionMapping($roleId)
    { 
        $venueRolePermissionMapping = $this->venueRolePermissionMappingCollectionFactory->create();
        $venueRolePermissionMapping->addFieldToFilter('role_id',$roleId);
        foreach ($venueRolePermissionMapping as $model) {
            $this->resource->delete($model);
        }

        return true;

    }

    /**
     * {@inheritdoc}
     */
    public function getVenueRolePermissionMappingsDetails($Id)
    { 
        $venueUserPermissions = $this->venueUserPermissionCollectionFactory->create();
        $venueUserPermissions->addFieldToFilter('main_table.is_active',1)->addFieldToFilter('main_table.is_delete',0);
        
        $venueRole = $this->venueRolePermissionMappingCollectionFactory->create();
       
        $venueUserPermissions->getSelect()->joinLeft(['aria_venue_role_permission_mapping'=>$venueRole->getTable('aria_venue_role_permission_mapping')], 
                                            'main_table.id = aria_venue_role_permission_mapping.permission_id AND aria_venue_role_permission_mapping.role_id='.$Id,
                                            ['role_id'=>'aria_venue_role_permission_mapping.role_id',
                                            'is_granted'=>'aria_venue_role_permission_mapping.is_granted',
                                            'is_active'=>'aria_venue_role_permission_mapping.is_active']);
        $items = [];
        foreach ($venueUserPermissions as $model) {
            if($model->getIsGranted() == NULL){
                    $model->setIsGranted(false);
            }
            if($model->getRoleId() == NULL){
                    $model->setRoleId(0);
            }
            if($model->getIsActive() == NULL){
                    $model->setIsActive(false);
            }
            $items[] = $model->getDataModel();
        }

        return $items;
    }

    /**
     * {@inheritdoc}
     */
    public function getVenueRolePermissionMappings($Id)
    { 
        $venueRole = $this->venueRolePermissionMappingCollectionFactory->create();
        $venueRole->addFieldToFilter('role_id',$Id);
        $items = [];
        foreach ($venueRole as $model) {
            $permissionId=$model->getPermissionId();
            $permissionEntity=$this->venueUserPermissionRepositoryInterface->get($permissionId);
            $model->setPermissionName($permissionEntity->getPermissionName());
            $items[] = $model->getDataModel();
        }

        return $items;
    }
}