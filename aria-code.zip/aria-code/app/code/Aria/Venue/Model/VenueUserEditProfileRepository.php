<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\VenueUserEditProfileRepositoryInterface;
use Aria\Venue\Api\Data\VenueUserEditProfileInterfaceFactory;
use Aria\Venue\Api\VenueRepositoryInterface;
use Aria\HospitalityGroup\Api\HospitalityGroupRepositoryInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Customer\Model\AccountManagement;
use Aria\Venue\Model\ResourceModel\VenueUserEditProfile as ResourceVenueUserEditProfile;
use Aria\Venue\Model\VenueUserEditProfileFactory as VenueUserEditProfileFactory;
use Aria\Venue\Model\ResourceModel\VenueUserEditProfile\CollectionFactory as venueUserEditProfileCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;


class VenueUserEditProfileRepository implements VenueUserEditProfileRepositoryInterface
{
    public $customerFactory;

    public $customerRepository;

    public $customerAccountManagement;


    protected $venueUserEditProfileCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $hospitalityGroupRepositoryInterface;

    protected $extensibleDataObjectConverter;

    protected $venueUserEditProfileFactory;



    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataVenueUserEditProfileFactory;

    /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $_searchCriteria;
    /**
     * @var \Magento\Framework\Api\FilterBuilder
     */
    protected $filterBuilder;
    /**
     * @var Aria\Venue\Api\VenueRepositoryInterface
     */
    protected $venueRepositoryInterface;

    /** @var  \Magento\Framework\DB\Adapter\AdapterInterface */
    protected $_conn;

    /** @var \Magento\Framework\App\ResourceConnection */
    protected $_resourceConnection;
    

    /**
     * @var HelperData
     */
    protected $helper;

    /**
     * @param ResourceVenueUserEditProfile $resource
     * @param VenueUserEditProfileFactory $venueUserEditProfileFactory
     * @param HospitalityGroupRepositoryInterface $hospitalityGroupRepositoryInterface
     * @param VenueUserEditProfileInterfaceFactory $dataVenueUserEditProfileFactory
     * @param VenueUserEditProfileCollectionFactory $venueUserEditProfileCollectionFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
     * @param \Magento\Framework\Api\FilterBuilder $filterBuilder
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param Aria\Venue\Api\VenueRepositoryInterface $venueRepositoryInterface
     * @param HelperData $helper

     */
    public function __construct(
        ResourceVenueUserEditProfile $resource,
        CustomerInterfaceFactory $customerFactory,
        CustomerRepositoryInterface $customerRepository,
        \Magento\Customer\Api\AccountManagementInterface $customerAccountManagement,
        VenueUserEditProfileFactory $venueUserEditProfileFactory,
        HospitalityGroupRepositoryInterface $hospitalityGroupRepositoryInterface,
        VenueUserEditProfileInterfaceFactory $dataVenueUserEditProfileFactory,
        VenueUserEditProfileCollectionFactory $venueUserEditProfileCollectionFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\Api\FilterBuilder $filterBuilder,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        VenueRepositoryInterface $venueRepositoryInterface
        
    ) {
        $this->resource = $resource;
        $this->customerFactory = $customerFactory;
        $this->customerRepository = $customerRepository;
        $this->hospitalityGroupRepositoryInterface = $hospitalityGroupRepositoryInterface;
        $this->customerAccountManagement = $customerAccountManagement;
        $this->venueUserEditProfileFactory = $venueUserEditProfileFactory;
        $this->venueUserEditProfileCollectionFactory = $venueUserEditProfileCollectionFactory;      
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataVenueUserEditProfileFactory = $dataVenueUserEditProfileFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->_resourceConnection = $resourceConnection;
        $this->_searchCriteria = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->venueRepositoryInterface = $venueRepositoryInterface;
        $this->_conn = $resourceConnection->getConnection();
    }



    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\Venue\Api\Data\VenueUserEditProfileInterface $venueUserEditProfile
    ) {
        
        $venueUserEditProfileData = $this->extensibleDataObjectConverter->toNestedArray(
            $venueUserEditProfile,
            [],
            \Aria\Venue\Api\Data\VenueUserEditProfileInterface::class
        );

        $venueUserEditProfileModel = $this->venueUserEditProfileFactory->create()->setData($venueUserEditProfileData);

        try {
            $this->resource->save($venueUserEditProfileModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the venue User: %1',
                $exception->getMessage()
            ));
        }
        return $venueUserEditProfileModel->getDataModel();
    }

   
}
