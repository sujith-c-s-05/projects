<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\Data\VenueInterface;
use Aria\Venue\Api\Data\VenueInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class Venue extends \Magento\Framework\Model\AbstractModel
{

    protected $venueDataFactory;
    protected $_eventPrefix = 'aria_venue';
    protected $dataObjectHelper;
    protected $_orderCollectionFactory;



    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param VenueInterfaceFactory $venueDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\Venue\Model\ResourceModel\Venue $resource
     * @param \Aria\Venue\Model\ResourceModel\Venue\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        VenueInterfaceFactory $venueDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\Venue\Model\ResourceModel\Venue $resource,
        \Aria\Venue\Model\ResourceModel\Venue\Collection $resourceCollection,
        array $data = []
    ) {
        $this->venueDataFactory = $venueDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve venue model with venue data
     * @return VenueInterface
     */
    public function getDataModel()
    {
        $venueData = $this->getData();

        $venueDataObject = $this->venueDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $venueDataObject,
            $venueData,
            VenueInterface::class
        );

        return $venueDataObject;
    }

    /**
     * Retrieve OrderStatus count with Order data
     * @return Order
     */
    public function getOrderCount($Id)
    {
        $collection = $this->_orderCollectionFactory->create();
        $collection->addAttributeToFilter('Venueid', array('eq' => $Id));
        $collection->addAttributeToFilter('status', array('in' => array('complete','closed','canceled')));
        return $collection->count();

    }

    /**
    * Retrieve VenueCount with Order data
    * @return Order
    */
   public function getVenueCount($Id)
   {
       $collection = $this->_orderCollectionFactory->create();
       $collection->addAttributeToFilter('Venueid', array('eq' => $Id));
       return $collection->count();

   }

}