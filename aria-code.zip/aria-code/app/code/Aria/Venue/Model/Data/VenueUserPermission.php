<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model\Data;

use Aria\Venue\Api\Data\VenueUserPermissionInterface;

class VenueUserPermission extends \Magento\Framework\Api\AbstractExtensibleObject implements VenueUserPermissionInterface
{

    /**
     * Get id
     * @return int|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param int $Id
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     */
    public function setId($Id)
    {
        return $this->setData(self::ID, $Id);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\Venue\Api\Data\VenueUserPermissionExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\Venue\Api\Data\VenueUserPermissionExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\Venue\Api\Data\VenueUserPermissionExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get permission_name
     * @return string|null
     */
    public function getPermissionName()
    {
        return $this->_get(self::PERMISSION_NAME);
    }

    /**
     * Set permission_name
     * @param string $permissionName
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     */
    public function setPermissionName($permissionName)
    {
        return $this->setData(self::PERMISSION_NAME, $permissionName);
    }

    /**
     * Get description
     * @return string|null
     */
    public function getDescription()
    {
        return $this->_get(self::DESCRIPTION);
    }

    /**
     * Set description
     * @param string $description
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     */
    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }

     /**
     * Get parent_id
     * @return int|null
     */
    public function getParentId()
    {
        return $this->_get(self::PARENT_ID);
    }

    /**
     * Set parent_id
     * @param int $parentId
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     */
    public function setParentId($parentId)
    {
        return $this->setData(self::PARENT_ID, $parentId);
    }
    
    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    } 

    /**
     * Get is_granted
     * @return bool|null
     */
    public function getIsGranted()
    {
        return $this->_get(self::IS_GRANTED);
    }

    /**
     * Set is_granted
     * @param bool $isGranted
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     */
    public function setIsGranted($isGranted)
    {
        return $this->setData(self::IS_GRANTED, $isGranted??false);
    } 

    /**
     * Get role_id
     * @return int|null
     */
    public function getRoleId()
    {
        return $this->_get(self::ROLE_ID);
    }

    /**
     * Set role_id
     * @param int $roleId
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     */
    public function setRoleId($roleId)
    {
        return $this->setData(self::ROLE_ID??0, $roleId);
    } 

    /**
     * Get permission_id
     * @return int|null
     */
    public function getPermissionId()
    {
        return $this->_get(self::PERMISSION_ID);
    }

    /**
     * Set permission_id
     * @param int $permissionId
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     */
    public function setPermissionId($permissionId)
    {
        return $this->setData(self::PERMISSION_ID, $permissionId);
    }

}