<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model\Data;

use Aria\Venue\Api\Data\VenueInterface;

class Venue extends \Magento\Framework\Api\AbstractExtensibleObject implements VenueInterface
{

    /**
     * Get id
     * @return int|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param int $Id
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setId($Id)
    {
        return $this->setData(self::ID, $Id);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\Venue\Api\Data\VenueExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\Venue\Api\Data\VenueExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\Venue\Api\Data\VenueExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get name
     * @return string|null
     */
    public function getName()
    {
        return $this->_get(self::NAME);
    }

    /**
     * Set name
     * @param string $name
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     * Get hosp_id
     * @return int|null
     */
    public function getHospId()
    {
        return $this->_get(self::HOSP_ID);
    }

    /**
     * Set hosp_id
     * @param int $hospId
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setHospId($hospId)
    {
        return $this->setData(self::HOSP_ID, $hospId);
    }

    /**
     * Get venueemail
     * @return string|null
     */
    public function getVenueEmail()
    {
        return $this->_get(self::VENUE_EMAIL);
    }

    /**
     * Set venueemail
     * @param string $venueemail
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setVenueEmail($venueemail)
    {
        return $this->setData(self::VENUE_EMAIL, $venueemail);
    }

    /**
     * Get description
     * @return string|null
     */
    public function getDescription()
    {
        return $this->_get(self::DESCRIPTION);
    }

    /**
     * Set description
     * @param string $description
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }

    /**
     * Get address
     * @return string|null
     */
    public function getAddress()
    {
        return $this->_get(self::ADDRESS);
    }

    /**
     * Set address
     * @param string $address
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setAddress($address)
    {
        return $this->setData(self::ADDRESS, $address);
    }

    /**
     * Get zip_code
     * @return string|null
     */
    public function getZipCode()
    {
        return $this->_get(self::ZIP_CODE);
    }

    /**
     * Set zip_code
     * @param string $zipCode
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setZipCode($zipCode)
    {
        return $this->setData(self::ZIP_CODE, $zipCode);
    }
   

    /**
     * Get phone
     * @return string|null
     */
    public function getPhone()
    {
        return $this->_get(self::PHONE);
    }

    /**
     * Set phone
     * @param string $phone
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setPhone($phone)
    {
        return $this->setData(self::PHONE, $phone);
    }



    /**
     * Get latitude
     * @return float|null
     */
    public function getLatitude()
    {
        return $this->_get(self::LATITUDE);
    }

    /**
     * Set latitude
     * @param float $latitude
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setLatitude($latitude)
    {
        return $this->setData(self::LATITUDE, $latitude);
    }

    /**
     * Get longitude
     * @return float|null
     */
    public function getLongitude()
    {
        return $this->_get(self::LONGITUDE);
    }

    /**
     * Set longitude
     * @param float $longitude
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setLongitude($longitude)
    {
        return $this->setData(self::LONGITUDE, $longitude);
    }

      /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_By
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_active
     * @return bool|true
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }
    /**
     * Get is_delete
     * @return bool|false
     */
     public function getIsDelete()
     {
         return $this->_get(self::IS_DELETE);
     }
 
    /**
      * Set is_delete
      * @param bool $isDelete
      * @return \Aria\Venue\Api\Data\VenueInterface
      */
     public function setIsDelete($isDelete)
     {
         return $this->setData(self::IS_DELETE, $isDelete);
     }

    /**
     * Get contact_name
     * @return string|null
     */
    public function getContactName()
    {
        return $this->_get(self::CONTACT_NAME);
    }

    /**
     * Set contact_name
     * @param string $contactname
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setContactName($contactname)
    {
        return $this->setData(self::CONTACT_NAME, $contactname);
    }

    /**
     * Get city
     * @return string|null
     */
    public function getCity()
    {
        return $this->_get(self::CITY);
    }

    /**
     * Set city
     * @param string $city
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setCity($city)
    {
        return $this->setData(self::CITY, $city);
    }

    /**
     * Get state
     * @return string|null
     */
    public function getState()
    {
        return $this->_get(self::STATE);
    }

    /**
     * Set state
     * @param string $state
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setState($state)
    {
        return $this->setData(self::STATE, $state);
    }

    /**
     * Get country
     * @return string|null
     */
    public function getCountry()
    {
        return $this->_get(self::COUNTRY);
    }

    /**
     * Set country
     * @param string $country
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setCountry($country)
    {
        return $this->setData(self::COUNTRY, $country);
    }

    /**
     * Get number_of_parked_orders
     * @return int|null
     */
    public function getNumberOfParkedOrders()
    {
        return $this->_get(self::NUMBER_OF_PARKED_ORDERS);
    }

    /**
     * Set number_of_parked_orders
     * @param int $number_of_parked_orders
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setNumberOfParkedOrders($number_of_parked_orders)
    {
        return $this->setData(self::NUMBER_OF_PARKED_ORDERS, $number_of_parked_orders);
    }

    /**
     * Get order_cost_limit
     * @return int|null
     */
    public function getOrderCostLimit()
    {
        return $this->_get(self::ORDER_COST_LIMIT);
    }

    /**
     * Set order_cost_limit
     * @param int $order_cost_limit
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setOrderCostLimit($order_cost_limit)
    {
        return $this->setData(self::ORDER_COST_LIMIT, $order_cost_limit);
    }

    /**
     * Get contact_person_phone
     * @return string|null
     */
    public function getContactPersonPhone()
    {
        return $this->_get(self::CONTACT_PERSON_PHONE);
    }

    /**
     * Set contact_person_phone
     * @param string $contact_person_phone
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setContactPersonPhone($contact_person_phone)
    {
        return $this->setData(self::CONTACT_PERSON_PHONE, $contact_person_phone);
    }
}