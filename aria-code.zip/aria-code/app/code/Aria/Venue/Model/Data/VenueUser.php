<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model\Data;

use Aria\Venue\Api\Data\VenueUserInterface;

class VenueUser extends \Magento\Framework\Api\AbstractExtensibleObject implements VenueUserInterface
{

    /**
     * Get id
     * @return string|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param string $Id
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     */
    public function setId($Id)
    {
        return $this->setData(self::ID, $Id);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\Venue\Api\Data\VenueUserExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\Venue\Api\Data\VenueUserExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\Venue\Api\Data\VenueUserExtensionInterface $extensionAttributes
    ) {
        
        return $this->_setExtensionAttributes($extensionAttributes);
    }
     
    /**
    * Get venue user role info
    * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface[]
    */
    public function getVenueUserRoleMapping()
    {
        //  return $this->_getVenueUserRoleMapping();
        return $this->_get('venue_user_role_mapping');
    }

    /**
    * Set venue user role info
    * @param \Aria\Venue\Api\Data\VenueUserRoleMappingInterface[] $venueUserRoleMapping
    * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface[]
    */
    public function setVenueUserRoleMapping(array $venueUserRoleMapping = null)
    {   
        return $this->setData('venue_user_role_mapping',$venueUserRoleMapping );  
    }

     /**
     * Get first name
     * @return string|null
     */
    public function getFirstName()
    {
        return $this->_get(self::FIRST_NAME);
    }

    /**
     * Set first name
     * @param string $firstName
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     */
    public function setFirstName($firstName)
    {
        return $this->setData(self::FIRST_NAME, $firstName);
    }
    /**
     * Get last name
     * @return string|null
     */
    public function getLastName()
    {
        return $this->_get(self::LAST_NAME);
    }

    /**
     * Set last name
     * @param string $lastName
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     */
    public function setLastName($lastName)
    {
        return $this->setData(self::LAST_NAME, $lastName);
    }
    

   

    /**
     * Get Magento_user_id
     * @return int|null
     */
    public function getMagentoUserId()
    {
        return $this->_get(self::MAGENTO_USER_ID );
    }

    /**
     * Set Magento_user_id
     * @param int $magentoUserId
     * @return \Aria\Venue\Api\Data\VenueUserMappingInterface
     */
    public function setMagentoUserId($magentoUserId)
    {
        return $this->setData(self::MAGENTO_USER_ID , $magentoUserId);
    }

    /**
     * Get venue_user_email
     * @return string|null
     */
    public function getVenueUserEmail()
    {
        return $this->_get(self::VENUE_USER_EMAIL);
    }

    /**
     * Set venue_user_email
     * @param string $venueUserEmail
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     */
    public function setVenueUserEmail($venueUserEmail)
    {
        return $this->setData(self::VENUE_USER_EMAIL, $venueUserEmail);
    }

    /**
     * Get phone
     * @return string|null
     */
    public function getPhone()
    {
        return $this->_get(self::PHONE);
    }

    /**
     * Set phone
     * @param string $phone
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     */
    public function setPhone($phone)
    {
        return $this->setData(self::PHONE, $phone);
    }

    /**
     * Get gender
     * @return string|null
     */
    public function getGender()
    {
        return $this->_get(self::GENDER);
    }

    /**
     * Set gender
     * @param string $gender
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     */
    public function setGender($gender)
    {
        return $this->setData(self::GENDER, $gender);
    }

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_By
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }

    /**
    * Get is_delete
    * @return bool|false
    */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }
 
    /**
    * Set is_delete
    * @param int $isDelete
    * @return \Aria\Venue\Api\Data\VenueUserInterface
    */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }

    /**
    * Get HgId
    * @return string|null
    */
    public function getHgId()
    {
        return $this->_get('hg_id');
    }
 
    /**
    * Set hgid
    * @param string $hgId
    * @return \Aria\Venue\Api\Data\VenueUserInterface
    */
    public function setHgId($hgId)
    {
        return $this->setData('hg_id', $hgId);
    }

    /**
    * Get is_admin
    * @return int|null
    */
    public function getIsAdmin()
    {
        return $this->_get('is_admin');
    }
 
    /**
    * Set is_admin
    * @param string $isAdmin
    * @return \Aria\Venue\Api\Data\VenueUserInterface
    */
    public function setIsAdmin($isAdmin)
    {
        return $this->setData('is_admin', $isAdmin);
    }
}