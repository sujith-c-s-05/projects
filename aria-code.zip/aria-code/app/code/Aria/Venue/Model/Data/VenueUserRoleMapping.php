<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model\Data;

use Aria\Venue\Api\Data\VenueUserRoleMappingInterface;

class VenueUserRoleMapping extends \Magento\Framework\Api\AbstractExtensibleObject implements VenueUserRoleMappingInterface
{

    /**
     * Get id
     * @return string|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param string $Id
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setId($Id)
    {
        return $this->setData(self::ID, $Id);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\Venue\Api\Data\VenueUserRoleMappingExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\Venue\Api\Data\VenueUserRoleMappingExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }  

    /**
     * Get venue_id
     * @return int|null
     */
    public function getVenueId()
    {
        return $this->_get(self:: VENUE_ID );
    }

    /**
     * Set venue_id
     * @param int $venueId
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setVenueId($venueId)
    {
        return $this->setData(self:: VENUE_ID , $venueId);
    }
    
    /**
     * Get role_id
     * @return int|null
     */
    public function getRoleId()
    {
        return $this->_get(self::ROLE_ID );
    }

    /**
     * Set role_id
     * @param int $roleId
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setRoleId($roleId)
    {
        return $this->setData(self::ROLE_ID , $roleId);
    }

    /**
     * Get Venue_user_id
     * @return int|null
     */
    public function getVenueUserId()
    {
        return $this->_get(self::VENUE_USER_ID );
    }

    /**
     * Set Venue_user_id
     * @param int $venueUserId
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setVenueUserId($venueUserId)
    {
        return $this->setData(self::VENUE_USER_ID , $venueUserId);
    }


    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_By
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }
    /**
     * Get is_delete
     * @return bool
     */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }

   /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }
   
    /**
     * Get venue_name
     * @return string|null
     */
    public function getVenueName()
    {
        return $this->_get('venue_name');
    }

    /**
     * Set venueName
     * @param string $venueName
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setVenueName($venueName)
    {
        return $this->setData('venue_name', $venueName);
    }
  
    /**
     * Get roleName
     * @return string|null
     */
    public function getRoleName()
    {
        return $this->_get('role_name');
    }

    /**
     * Set roleName
     * @param string $roleName
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setRoleName($roleName)
    {
        return $this->setData('role_name', $roleName);
    }

    /**
     * Get order_cost_limit
     * @return int|null
     */
    public function getOrderCostLimit()
    {
        return $this->_get(self::ORDER_COST_LIMIT );
    }

    /**
     * Set order_cost_limit
     * @param int $orderCostLimit
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     */
    public function setOrderCostLimit($orderCostLimit)
    {
        return $this->setData(self::ORDER_COST_LIMIT , $orderCostLimit);
    }
        
}