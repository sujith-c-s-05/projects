<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Model\Data;

use Aria\Venue\Api\Data\VenueUserRoleInterface;

class VenueUserRole extends \Magento\Framework\Api\AbstractExtensibleObject implements VenueUserRoleInterface
{

    /**
     * Get id
     * @return string|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param string $Id
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setId($Id)
    {
        return $this->setData(self::ID, $Id);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\Venue\Api\Data\VenueUserRoleExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\Venue\Api\Data\VenueUserRoleExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\Venue\Api\Data\VenueUserRoleExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }
    
       
    /**
     * Get role_name
     * @return string|null
     */
    public function getRoleName()
    {
        return $this->_get(self::ROLE_NAME);
    }

    /**
     * Set role_name
     * @param string $RoleName
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setRoleName($RoleName)
    {
        return $this->setData(self::ROLE_NAME, $RoleName);
    }

  /**
     * Get description
     * @return string|null
     */
    public function getDescription()
    {
        return $this->_get(self::DESCRIPTION);
    }

    /**
     * Set description
     * @param string $description
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }


    /**
     * Get hg_admin_id
     * @return string|null
     */
    public function getHgAdminId()
    {
        return $this->_get(self::HG_ADMIN_ID);
    }

    /**
     * Set hg_admin_id
     * @param string $hgAdminId
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setHgAdminId($hgAdminId)
    {
        return $this->setData(self::HG_ADMIN_ID, $hgAdminId);
    }

   
    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_By
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_active
     * @return bool|true
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }
    
    /**
    * Get venue role permission mapping info
    * @return \Aria\SupplyCompanyAccount\Api\Data\VenueRolePermissionMappingInterface[]
    */
    public function getVenueRolePermissionMapping()
    {
        return $this->_get('aria_venue_role_permission_mapping');
    }

    /**
    * Set Venue role permission mapping info
    * @param \Aria\SupplyCompanyAccount\Api\Data\VenueRolePermissionMappingInterface[] $venueRolePermissionMapping
    * @return \Aria\SupplyCompanyAccount\Api\Data\VenueRolePermissionMappingInterface[]
    */
    public function setVenueRolePermissionMapping(array $venueRolePermissionMapping = null)
    {   
        return $this->setData('aria_venue_role_permission_mapping',$venueRolePermissionMapping );  
    }
    /**
     * Get is_delete
     *  @return bool
     */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }

   /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }
    
}