<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\Venue\Model;

use Aria\Venue\Api\VenueUserRepositoryInterface;
use Aria\Venue\Api\Data\VenueUserInterfaceFactory;
use Aria\Venue\Api\VenueRepositoryInterface;
use Aria\HospitalityGroup\Api\HospitalityGroupRepositoryInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\AccountManagement;
use Aria\Venue\Api\Data\VenueUserSearchResultsInterfaceFactory;
use Aria\Venue\Model\ResourceModel\VenueUser as ResourceVenueUser;
use Aria\Venue\Model\VenueUserFactory as VenueUserFactory;
use Aria\Venue\Model\VenueUserRoleMappingFactory as VenueUserRoleMappingFactory;
use Aria\Venue\Model\ResourceModel\VenueUserRoleMapping as ResourceVenueUserRoleMapping;
use Aria\Venue\Model\ResourceModel\VenueUser\CollectionFactory as venueUserCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Aria\Venue\Model\VenueUserRoleMappingRepository as venueUserRoleMappingRepository;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Aria\Venue\Model\ResourceModel\VenueUserRoleMapping\CollectionFactory as VenueUserRoleMappingCollectionFactory;
use Aria\AwsCognito\Helper\Data as HelperData;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;

class VenueUserRepository implements VenueUserRepositoryInterface
{
    public $customerFactory;

    public $customerRepository;

    public $customerAccountManagement;

    protected $venueUserRoleMappingRepository;

    protected $venueUserCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $hospitalityGroupRepositoryInterface;

    protected $extensibleDataObjectConverter;

    protected $venueUserFactory;

    protected $venueUserRoleMappingFactory;

    protected $searchResultsFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataVenueUserFactory;
    protected $venueUserRoleMappingCollectionFactory;

    /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $_searchCriteria;
    /**
     * @var \Magento\Framework\Api\FilterBuilder
     */
    protected $filterBuilder;
    /**
     * @var Aria\Venue\Api\VenueRepositoryInterface
     */
    protected $venueRepositoryInterface;

    /** @var  \Magento\Framework\DB\Adapter\AdapterInterface */
    protected $_conn;

    /** @var \Magento\Framework\App\ResourceConnection */
    protected $_resourceConnection;
    /**
     * @var Aria\Venue\Api\VenueUserRoleMappingRepositoryInterface
     */
    protected $venueUserRoleMappingRepositoryInterface;

    /**
     * @var HelperData
     */
    protected $helper;
 
    /**
     * @param ResourceVenueUser $resource
     * @param ResourceVenueUserRoleMapping $resourceVenueUserRoleMapping
     * @param VenueUserFactory $venueUserFactory
     * @param HospitalityGroupRepositoryInterface $hospitalityGroupRepositoryInterface
     * @param VenueUserRoleMappingFactory $venueUserMappingRoleFactory
     * @param VenueUserRoleMappingRepository  $venueUserRoleMappingRepository
     * @param VenueUserInterfaceFactory $dataVenueUserFactory
     * @param VenueUserCollectionFactory $venueUserCollectionFactory
     * @param VenueUserSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
     * @param \Magento\Framework\Api\FilterBuilder $filterBuilder
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param VenueUserRoleMappingCollectionFactory $venueUserRoleMappingCollectionFactory
     * @param VenueUserRoleMappingRepositoryInterface $venueUserRoleMappingRepositoryInterface
     * @param Aria\Venue\Api\VenueRepositoryInterface $venueRepositoryInterface
     * @param HelperData $helper

     */
    public function __construct(
        ResourceVenueUser $resource,
        ResourceVenueUserRoleMapping $resourceVenueUserRoleMapping,
        CustomerFactory $customerFactory,
        CustomerRepositoryInterface $customerRepository,
        \Magento\Customer\Api\AccountManagementInterface $customerAccountManagement,
        VenueUserFactory $venueUserFactory,
        HospitalityGroupRepositoryInterface $hospitalityGroupRepositoryInterface,
        VenueUserRoleMappingFactory $venueUserRoleMappingFactory,
        VenueUserInterfaceFactory $dataVenueUserFactory,
        venueUserRoleMappingRepository $venueUserRoleMappingRepository,
        VenueUserCollectionFactory $venueUserCollectionFactory,
        VenueUserRoleMappingCollectionFactory $venueUserRoleMappingCollectionFactory,
        VenueUserSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Framework\Api\FilterBuilder $filterBuilder,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        VenueRepositoryInterface $venueRepositoryInterface,
        TransportBuilder $transportBuilder,
        StateInterface $state,
        \Aria\Venue\Api\VenueUserRoleMappingRepositoryInterface $venueUserRoleMappingRepositoryInterface,
        HelperData $helper,
        CustomerInterfaceFactory $customerInterfaceFactory

    ) {
        $this->resource = $resource;
        $this->customerFactory = $customerFactory;
        $this->customerRepository = $customerRepository;
        $this->hospitalityGroupRepositoryInterface = $hospitalityGroupRepositoryInterface;
        $this->customerAccountManagement = $customerAccountManagement;
        $this->resourceVenueUserRoleMapping = $resourceVenueUserRoleMapping;
        $this->venueUserFactory = $venueUserFactory;
        $this->venueUserRoleMappingFactory = $venueUserRoleMappingFactory;
        $this->venueUserCollectionFactory = $venueUserCollectionFactory;
        $this->venueUserRoleMappingCollectionFactory = $venueUserRoleMappingCollectionFactory;
        $this->venueUserRoleMappingRepository = $venueUserRoleMappingRepository;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataVenueUserFactory = $dataVenueUserFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->_resourceConnection = $resourceConnection;
        $this->_searchCriteria = $searchCriteriaBuilder;
        $this->filterBuilder = $filterBuilder;
        $this->transportBuilder = $transportBuilder;
        $this->inlineTranslation = $state;
        $this->venueRepositoryInterface = $venueRepositoryInterface;
        $this->_conn = $resourceConnection->getConnection();
        $this->venueUserRoleMappingRepositoryInterface = $venueUserRoleMappingRepositoryInterface;
        $this->helper = $helper;
        $this->customerInterfaceFactory = $customerInterfaceFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\Venue\Api\Data\VenueUserInterface $venueUser
    ) {

        try {
            $this->_conn->beginTransaction();
            $venueUserEntityId = $venueUser->getId();
            if ($venueUserEntityId != 0) {
                $customerEntity = $this->get($venueUserEntityId);
                $custId = $customerEntity->getMagentoUserId();
            }
            
            /**Aws Cognito code starts */
            if (!isset($venueUserEntityId)) {
                $isCustomerExistInCognito = $this->helper->checkUserExist($venueUser->getPhone());
                $isMagentoCustomerExist = $this->helper->checkMagentoCustomerExist($venueUser->getPhone());
                $isPasswordReset = 1;
                if (!$isCustomerExistInCognito) {
                    $isPasswordReset = 0;
                    $password = $this->helper->generateRandomPassword();
                    $this->registerInCognito($venueUser,$password);
                }
                $customer = $this->customerInterfaceFactory->create();

            }
            else
            {
                $customer = $this->customerFactory->create()->load($custId);
            }
            /**Aws Cognito code ends */

            $customer->setEmail($venueUser->getVenueUserEmail());
            $customer->setFirstname($venueUser->getFirstName());
            $customer->setLastname($venueUser->getLastName());
            $customer->setGroupId(6);

            /**Aws Cognito code starts */
            if (!isset($venueUserEntityId)){
                $customer->setCustomAttribute('aria_username',$venueUser->getPhone());
                $customer->setCustomAttribute('is_password_set', $isPasswordReset);
            }
            /**Aws Cognito code ends */

            $websiteId = $this->storeManager->getStore()->getWebsiteId()
                ?: $this->storeManager->getDefaultStoreView()->getWebsiteId();
            $customer->setWebsiteId($websiteId);
            if(!isset($venueUserEntityId))
            {
                $customerEntity=$this->customerRepository->save($customer);

            }
            else
            {
                $customerEntity = $customer->save();
            }
            $customerId = $customerEntity->getId();
            $venueUser->setMagentoUserId($customerId);

            $venueUserData = $this->extensibleDataObjectConverter->toNestedArray(
                $venueUser,
                [],
                \Aria\Venue\Api\Data\VenueUserInterface::class
            );
            $venueUserModel = $this->venueUserFactory->create()->setData($venueUserData);
            $venueUser = $venueUserModel->save();
            $id = $venueUser->getId();


            $this->venueUserRoleMappingRepositoryInterface->deleteVenueUserRoleMapping($venueUserEntityId);
            $venueUserRoleMap = $venueUser->getVenueUserRoleMapping();
        
            foreach ($venueUserRoleMap as $venueList) {
                $venueUserRoleMappingModel = $this->venueUserRoleMappingFactory->create()->setData($venueList);

                $venueUserRoleMappingModel->setVenueUserId($id);
                $venueUserRoleMappingModel->setCreatedBy($venueUser->getCreatedBy());
                $venueUserRoleMappingModel->setCreatedAt($venueUser->getCreatedAt());
                $venueUserRoleMappingModel->setUpdatedAt($venueUser->getUpdatedAt());
                $venueUserRoleMappingModel->setUpdatedBy($venueUser->getUpdatedBy());
                $venueUserRoleMappingModel->setIsActive($venueUser->getIsActive());
                $venueUserRoleMappingModel->setIsDelete($venueUser->getIsDelete());
                $this->resourceVenueUserRoleMapping->save($venueUserRoleMappingModel);
            }
        
            $venueId = $venueUserRoleMappingModel->getVenueId();
            $venueDetails = $this->venueRepositoryInterface->get($venueId);
            $hospitalityGroupId = $venueDetails->getHospId();
            $hospitalityGroupDetails = $this->hospitalityGroupRepositoryInterface->get($hospitalityGroupId);
            $hospitalityGroupName = $hospitalityGroupDetails->getCompanyName();
            $entityId = $hospitalityGroupDetails->getCompanyAdmin();
            $customerEntityDetails = $this->customerRepository->getById($entityId);
            $customerName = $customerEntityDetails->getFirstName();

            if ($venueUserEntityId == 0) {
                $passwordText = "";

                if(isset($password) )
                {
                    $passwordText = "Your password is ". $password;
                }
                $this->sendEmail($customer,$passwordText,$customerName,$hospitalityGroupName);

            }
            $this->_conn->commit();
        } catch (\Exception $exception) {
            $this->_conn->rollBack();
            throw new CouldNotSaveException(__(
                'Could not save the venue user: %1',
                $exception->getMessage()
            ));
        }

        return $venueUserModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($Id)
    {
        $venueUser = $this->venueUserFactory->create();
        $this->resource->load($venueUser, $Id);

        if (!$venueUser->getId()) {
            throw new NoSuchEntityException(__('Venue user with id "%1" does not exist.', $Id));
        }
        return $venueUser->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->venueUserCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\Venue\Api\Data\VenueUserInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }
        foreach ($items as $item) {

            $venueUserId = $item->getId();
            $venueRoleMappings = $this->venueUserRoleMappingRepositoryInterface->getVenueUserRoleMappings($venueUserId);
            $item->setVenueUserRoleMapping($venueRoleMappings);
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }
    /**
     * Check whether the Venue's exist for adding venue user
     *
     * @return boolean
     */
    public function isActiveVenueExists()
    {
        $isVenueExists = true;
        $this->_searchCriteria->addFilter('is_delete', 0);
        $this->_searchCriteria->addFilter('is_active', 1);
        $searchCriteria = $this->_searchCriteria->create();
        $searchResults = $this->venueRepositoryInterface->getList($searchCriteria);

        if ($searchResults->getTotalCount() == 0) {

            $isVenueExists = false;
            throw new \Magento\Framework\Webapi\Exception(
                __('Cannot add Venue users without having at least one Venue'),
                0,
                \Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR
            );
        } else {
            $isVenueExists = true;
        }
        return $isVenueExists;
    }


    /**
     * {@inheritdoc}
     */
    public function setStatus($Id, $isActive)
    {
        try {
            $this->_conn->beginTransaction();
            $venueUser = $this->venueUserFactory->create();
            $venueUser->setData('is_active', $isActive);
            $venueUser->setData('id', $Id);
            $this->resource->save($venueUser);
            $this->venueUserRoleMappingRepositoryInterface->setStatusUserRoleMapping($Id, $isActive);
            $this->_conn->commit();
        } catch (\Exception $e) {
            $this->_conn->rollBack();
            throw new CouldNotSaveException(__(
                'Could not activate/deactivate the venue user',
                $e->getMessage()
            ));
        }

        return true;
    }


    /**
     * {@inheritdoc}
     */
    public function deleteVenueUser($id)
    {
        try {
            $venueUser = $this->venueUserFactory->create();
            $this->resource->load($venueUser, $id);
            if (!$venueUser->getId()) {
                throw new NoSuchEntityException(__('Venue user with id "%1" does not exist.', $id));
            }

            $venueUser->setIsDelete(1);
            $venueUser->save();
            return true;
        } catch (\Exception $exception) {
            return false;
        }
    }

    /**
     * {@inheritdoc}
     */
    public function deleteMultipleVenueUsers(array $id)
    {
        if (empty($id)) {
            return false;
        }
        foreach ($id as $venueId) {
            try {
                $venueUser = $this->venueUserFactory->create();
                $this->resource->load($venueUser, $venueId);

                if (!$venueUser->getId()) {
                    throw new NoSuchEntityException(__('Venue user with id "%1" does not exist.', $id));
                }
                $venueUser->setIsDelete(1);
                $venueUser->save();
            } catch (\Exception $exception) {
                return false;
            }
        }

        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isPhoneNumberExists($phone)
    {
        $isPhoneNumberExists = false;
        $phoneCollection = $this->venueUserCollectionFactory->create();
        $phoneCollection->addFieldToFilter('phone', $phone);
        if ($phoneCollection->count() > 0) {
            $isPhoneNumberExists = true;
        }
        return $isPhoneNumberExists;
    }

    /**
     * {@inheritdoc}
     */
    public function getById($Id)
    {
        $venueUser = $this->venueUserFactory->create();
        $this->resource->load($venueUser, $Id);
        $venueRoleMappings = $this->venueUserRoleMappingRepositoryInterface->getVenueUserRoleMappings($Id);

        $venueUser->setVenueUserRoleMapping($venueRoleMappings);

        if (!$venueUser->getId()) {
            throw new NoSuchEntityException(__('Venue user with id "%1" does not exist.', $Id));
        }
        return $venueUser;
    }

    /**
     * To register venue user in cognito
     * @param $venueUser
     * @param $password
     * @return bool
     */
    public function registerInCognito($venueUser, $password)
    {
        $attributes = [];
        $attributes['email'] = $venueUser->getVenueUserEmail();
        $attributes['phone_number'] = $venueUser->getPhone();
        $attributes['given_name'] = $venueUser->getFirstName();
        $attributes['family_name'] = $venueUser->getLastName();

        return $this->helper->register($venueUser->getFirstName(), $password, $attributes);
    }

   
    public function sendEmail($customer,$passwordText,$customerName,$hospitalityGroupName)
    {
        
                $loginUrl = $this->helper->getFrontEndLoginUrl();
                if($passwordText=="")
                {
                    $loginUrlText = '<a href="'.$loginUrl.'">click here</a> to verify your email address and use your existing password in ARIA to continue with the login.';
                }
                else
                {
                    $loginUrlText = '<a href="'.$loginUrl.'">click here</a> to verify your email address and set a password.';
                }
                 //Send Venue User active mail to the admin
                $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId());
                $templateVars = array(
                    'customerName' => $customer->getFirstName(),
                    'adminName' =>  $customerName,
                    'companyName' => $hospitalityGroupName,
                    'passwordText' => $passwordText,
                    'loginText' => $loginUrlText
                );
                $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
                $sender_name  = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
                $from = ['email' => $email, 'name' => $sender_name];
                $this->inlineTranslation->suspend();
                $transport = $this->transportBuilder->setTemplateIdentifier('aria_venue_user_register_template', ScopeInterface::SCOPE_STORE)
                    ->setTemplateOptions($templateOptions)
                    ->setTemplateVars($templateVars)
                    ->setFrom($from)
                    ->addTo($customer->getEmail())
                    ->getTransport();
                $transport->sendMessage();
                $this->inlineTranslation->resume();
            }

      public function isVenueAdmin($Id){
          
        $venue_user = $this->getById($Id);
        if($venue_user->getIsAdmin() == 1)
          return true;
        else
            return false;
        }

        public function getVenueAdminId($Id){
            $venueUser = $this->venueUserCollectionFactory->create();
            $venue_user = $this->getById($Id);
            $hg_id = $venue_user->getHgId();
            $venueUser->addFieldToFilter('hg_id',$hg_id)->addFieldToFilter('is_admin',1);
            foreach($venueUser as $user){
                $venueAdminId = $user->getId();
                return $venueAdminId;
            }
            return 0;
        }
}
