<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\Venue\Setup\Patch\Data;


use Magento\Eav\Model\Entity\Attribute\Backend\DefaultBackend;
use Magento\Framework\Module\Setup\Migration;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Framework\Setup\Patch\PatchVersionInterface;

/**
 * Class default groups and attributes for customer
 */
class AddVenueUserPermissionV01 implements DataPatchInterface, PatchVersionInterface
{

    /**
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    /**
     * @param ModuleDataSetupInterface $moduleDataSetup
     */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
    }

    /**
     * @inheritdoc
     *
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function apply()
    {
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 1, 'permission_name' => 'Profile Management', 'description' => 'Profile Management Permission','parent_id' =>0,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 2, 'permission_name' => 'Change password', 'description' => 'Profile Management Change Password Permission','parent_id' =>1,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 3, 'permission_name' => 'User Role Management', 'description' => 'User Role Management Permission','parent_id' =>0,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 4, 'permission_name' => 'User Role Management View', 'description' => 'User Role Management View Permission','parent_id' =>3,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 5, 'permission_name' => 'User Role Management Add', 'description' => 'User Role Management Add Permission','parent_id' =>3,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 6, 'permission_name' => 'User Role Management Edit', 'description' => 'User Role Management Edit Permission','parent_id' =>3,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 7, 'permission_name' => 'User Role Management Delete', 'description' => 'User Role Management Delete Permission','parent_id' =>3,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 8, 'permission_name' => 'My Orders', 'description' => 'My Orders Permission','parent_id' =>0,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 9, 'permission_name' => 'My Orders View', 'description' => 'My Orders View Permission','parent_id' =>8,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 10, 'permission_name' => 'My Orders Cancel', 'description' => 'My Orders Cancel Permission','parent_id' =>8,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 11, 'permission_name' => 'My Orders Delete', 'description' => 'My Orders Delete Permission','parent_id' =>8,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 12, 'permission_name' => 'Admin', 'description' => 'Admin Permission','parent_id' =>8,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 13, 'permission_name' => 'Download PDF', 'description' => 'Pdf Download Permission','parent_id' =>8,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 14, 'permission_name' => 'Parked Orders', 'description' => 'Parked Orders Permission','parent_id' =>0,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 15, 'permission_name' => 'Parked Orders View', 'description' => 'Parked Orders View Permission','parent_id' =>14,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 16, 'permission_name' => 'Parked Orders Add', 'description' => 'Parked Orders Add Permission','parent_id' =>14,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 17, 'permission_name' => 'Parked Orders Edit', 'description' => 'Parked Orders Edit Permission','parent_id' =>14,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 18, 'permission_name' => 'Parked Orders Delete', 'description' => 'Parked Orders Delete Permission','parent_id' =>14,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 19, 'permission_name' => 'Admin', 'description' => 'Admin Permission','parent_id' =>14,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 20, 'permission_name' => 'Quick Orders', 'description' => 'Quick Orders Permission','parent_id' =>0,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 21, 'permission_name' => 'Quick Orders View', 'description' => 'Quick Orders View Permission','parent_id' =>20,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 22, 'permission_name' => 'Quick Orders Add', 'description' => 'Quick Orders Add Permission','parent_id' =>20,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 23, 'permission_name' => 'Quick Orders Edit', 'description' => 'Quick Orders Edit Permission','parent_id' =>20,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 24, 'permission_name' => 'Quick Orders Delete', 'description' => 'Quick Orders Delete Permission','parent_id' =>20,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 25, 'permission_name' => 'Quick Access Buttons', 'description' => 'Quick Access Buttons Permission','parent_id' =>0,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 26, 'permission_name' => 'Quick Access Buttons View', 'description' => 'Quick Access Buttons View Permission','parent_id' =>25,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 27, 'permission_name' => 'Quick Access Buttons Add', 'description' => 'Quick Access Buttons Add Permission','parent_id' =>25,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 28, 'permission_name' => 'Quick Access Buttons Edit', 'description' => 'Quick Access Buttons Edit Permission','parent_id' =>25,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 29, 'permission_name' => 'Quick Access Buttons Delete', 'description' => 'Quick Access Buttons Delete Permission','parent_id' =>25,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 30, 'permission_name' => 'Manage Orders', 'description' => 'Manage Orders Permission','parent_id' =>0,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 31, 'permission_name' => 'Place Order', 'description' => 'Place Order Permission','parent_id' =>30,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 32, 'permission_name' => 'Admin', 'description' => 'Admin Permission','parent_id' =>30,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 33, 'permission_name' => 'Cart Management', 'description' => 'Cart Management Permission','parent_id' =>0,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 34, 'permission_name' => 'Manage Products in Cart', 'description' => 'Manage Products in Cart Permission','parent_id' =>33,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 35, 'permission_name' => 'Favorite Order', 'description' => 'Favorite Order Permission','parent_id' =>0,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 36, 'permission_name' => 'Favorite Order View', 'description' => 'Favorite Order View Permission','parent_id' =>35,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 37, 'permission_name' => 'Favorite Order Add', 'description' => 'Favorite Order Add Permission','parent_id' =>35,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 38, 'permission_name' => 'Favorite Order Edit', 'description' => 'Favorite Order Edit Permission','parent_id' =>35,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 39, 'permission_name' => 'Favorite Order Delete', 'description' => 'Favorite Order Delete Permission','parent_id' =>35,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 40, 'permission_name' => 'Schedule Order from Favorite Order', 'description' => 'Schedule Order from Favorite Order Permission','parent_id' =>35,'is_active'=>1]
        );
        $this->moduleDataSetup->getConnection()->insertForce(
            $this->moduleDataSetup->getTable('aria_venue_user_permissions'),
            ['id' => 41, 'permission_name' => 'Delivery Confirmation', 'description' => 'Delivery Confirmation Permission','parent_id' =>0,'is_active'=>1]
        );
        return $this;
    }

    /**
     * @inheritdoc
     */
    public static function getDependencies()
    {
        return [];
    }

    /**
     * @inheritdoc
     */
    public static function getVersion()
    {
        return '2.0.0';
    }

    /**
     * @inheritdoc
     */
    public function getAliases()
    {
        return [];
    }
}
