<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface VenueUserRoleMappingRepositoryInterface
{

    /**
     * Save Venue User Role
     * @param \Aria\Venue\Api\Data\VenueUserRoleMappingInterface $venueUserRoleMapping
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\Venue\Api\Data\VenueUserRoleMappingInterface $venueUserRoleMapping
    );

    /**
     * Get Venue User Role mapping
     * @param int Id
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getVenueUserRoleMappings($Id);
    
    /**
     * delete Venue User Role mapping
     * @param int venueUserId
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteVenueUserRoleMapping($venueUserId);

    /**
     * Get Venue User Role mapping
     * @param int Id
     * @return mixed[]
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getVenues($Id);

    /**
     * Get Venue User Role 
     * @param int $venue_user_id
     * @param int $venue_id
     * @return int $roleId
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getVenueUserRole($venue_user_id,$venue_id);

     /**
     * Retrieve Venue  user matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\Venue\Api\Data\VenueUserRoleMappingSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Get Venue Users 
     * @param int $venue_id
     * @return mixed[]
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getVenueUsers($venue_id);

    /**
     * Retrieve Permission Details
     * @param int $venueUserId
     * @param int $venueId
     * @param string $permisison
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */

    public function isPermissionAppproved($venueUserId,$venueId,$permission);
   
}
