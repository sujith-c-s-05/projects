<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface VenueUserRoleRepositoryInterface
{

    /**
     * Save Venue User Role
     * @param \Aria\Venue\Api\Data\VenueUserRoleInterface $venueUserRole
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\Venue\Api\Data\VenueUserRoleInterface $venueUserRole
    );

    /**
     * Retrieve Venue user role name
     * @param string $roleName
     * @param int $hgid
     * @param int|null $id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function isRoleNameExists($roleName,$hgid,$id=null);

    /**
     * Retrieve Venue User Role matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\Venue\Api\Data\VenueUserRoleSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

  

    /**
     * Retrieve Venue User Role
     * @param int $Id
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($id);
 
   /**
     * Delete Venue User Role by id
     * @param int $id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteVenueUserRole($id);
}
