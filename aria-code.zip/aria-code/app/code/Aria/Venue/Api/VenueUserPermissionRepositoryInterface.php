<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface VenueUserPermissionRepositoryInterface
{
    /**
     * Retrieve DC User Permission matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\Venue\Api\Data\VenueUserPermissionSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

     /**
     * Retrieve Venue User Permission
     * @param int $Id
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($Id);

    /**
     * Save Venue User Permission
     * @param \Aria\Venue\Api\Data\VenueUserPermissionInterface $venuePermission
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\Venue\Api\Data\VenueUserPermissionInterface $venuePermission
    );
}

