<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface VenueRepositoryInterface
{

    /**
     * Save Venue
     * @param \Aria\Venue\Api\Data\VenueInterface $venue
     * @return \Aria\Venue\Api\Data\VenueInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\Venue\Api\Data\VenueInterface $venue
    );

    /**
     * Retrieve Venue
     * @param int $Id
     * @return \Aria\Venue\Api\Data\VenueInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($Id);

    /**
     * Retrieve Venue matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\Venue\Api\Data\VenueSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );
   
    /**
     * @param int $Id
     * @param bool $isActive
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function setStatus($Id,$isActive);
    
/**
* Delete Venue by ID
* @api
* @param int[] $Id
* @return bool Will return True if deleted.
* @throws \Magento\Framework\Exception\NoSuchEntityException
* @throws \Magento\Framework\Exception\LocalizedException
* @throws \Magento\Framework\Exception\CouldNotDeleteException
*/
public function deleteByIds(array $Id);
   
     /**
     * Retrieve Venue name
     * @param string $name
     * @param int $hgid
     * @param int|null $id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function isVenueNameExists($name,$hgid,$id = null);

   
}
