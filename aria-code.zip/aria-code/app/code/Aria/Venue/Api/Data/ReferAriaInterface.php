<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api\Data;

interface ReferAriaInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const USER_ID = 'user_id';
    const RECEIVER = 'receiver_email';

    /**
     * Get user id
     * @return int|null
     */
    public function getUserId();

    /**
     * Set user id
     * @param int $userId
     * @return \Aria\Venue\Api\Data\ReferAriaInterface
     */
    public function setUserId($userId);

    /**
     * Get Receiver Email
     * @return string|null
     */
    public function getReceiverEmail();

    /**
     * Set Receiver Email
     * @param string $receiverEmail
     * @return \Aria\Venue\Api\Data\ReferAriaInterface
     */
    public function setReceiverEmail($receiverEmail);
}