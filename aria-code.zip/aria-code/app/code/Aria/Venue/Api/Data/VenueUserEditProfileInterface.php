<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api\Data;

interface VenueUserEditProfileInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const ID = 'id';
    const MAGENTO_USER_ID = 'magento_user_id';
    const FIRST_NAME = 'first_name';
    const LAST_NAME = 'last_name';
    // const VENUE_USER_EMAIL = 'venue_user_email';
    // const PHONE = 'phone';
    const GENDER ='gender';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const IS_DELETE = 'is_delete';

    /**
     * Get id
     * @return string|null
     */
    public function getId();

    /**
     * Set id
     * @param string $Id
     * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
     */
    public function setId($Id);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\Venue\Api\Data\VenueUserEditProfileExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\Venue\Api\Data\VenueUserEditProfileExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\Venue\Api\Data\VenueUserEditProfileExtensionInterface $extensionAttributes
    );
   
    
    /**
     * Get first name
     * @return string|null
     */
    public function getFirstName();

    /**
     * Set first name
     * @param string $firstName
     * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
     */
    public function setFirstName($firstName);

    /**
     * Get last name
     * @return string|null
     */
    public function getLastName();

    /**
     * Set last name
     * @param string $lastName
     * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
     */
    public function setLastName($lastName);

   
    // /**
    //  * Get venue_user_email
    //  * @return string|null
    //  */
    // public function getVenueUserEmail();

    // /**
    //  * Set venue_user_email
    //  * @param string $venueUserEmail
    //  * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
    //  */
    // public function setVenueUserEmail($venueUserEmail);
    

   /**
     * Get magento_user_id
     * @return int|null
     */
    public function getMagentoUserId();

    /**
     * Set magento_user_id
     * @param int $magentoUserId
     * @return \Aria\Venue\Api\Data\VenueUserMappingInterface
     */
    public function setMagentoUserId($magentoUserId);
    

    // /**
    //  * Get phone
    //  * @return string|null
    //  */
    // public function getPhone();

    // /**
    //  * Set phone
    //  * @param string $phone
    //  * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
    //  */
    // public function setPhone($phone);

    /**
     * Get gender
     * @return string|null
     */
    public function getGender();

    /**
     * Set gender
     * @param string $gender
     * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
     */
    public function setGender($gender);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
     */
    public function setUpdatedBy($updatedBy);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
     */
    public function setUpdatedAt($updatedAt);
     /**
     * Get is_active
     * @return bool|true
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
     */
    public function setIsActive($isActive);

    /**
     * Get is_delete
     * @return int
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param int $isDelete
     * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
     */
    public function setIsDelete($isDelete);

}
