<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api\Data;

interface VenueUserRoleSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get VenueUser list.
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface[]
     */
    public function getItems();

    /**
     * Set Venue user list.
     * @param \Aria\Venue\Api\Data\VenueUserRoleInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
