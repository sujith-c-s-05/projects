<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api\Data;

interface VenueUserPermissionSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get DC User Permission list.
     * @return \Aria\Venue\Api\Data\VenueUserPermissionInterface[]
     */
    public function getItems();

    /**
     * Set supply_id list.
     * @param \Aria\Venue\Api\Data\VenueUserPermissionInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

