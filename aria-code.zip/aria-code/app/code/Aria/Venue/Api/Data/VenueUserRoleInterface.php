<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api\Data;

interface VenueUserRoleInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const ID = 'id';
    const ROLE_NAME='role_name';
    const DESCRIPTION = 'description'; 
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const HG_ADMIN_ID = 'hg_admin_id';
    const IS_DELETE = 'is_delete';
    
    /**
     * Get id
     * @return string|null
     */
    public function getId();

    /**
     * Set id
     * @param string $Id
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setId($Id);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\Venue\Api\Data\VenueUserRoleExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\Venue\Api\Data\VenueUserRoleExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\Venue\Api\Data\VenueUserRoleExtensionInterface $extensionAttributes
    );
    
    /**
     * Get description
     * @return string|null
     */
    public function getDescription();

    /**
     * Set description
     * @param string $description
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setDescription($description);   
     /**
     * Get venue_role_name
     * @return string|null
     */
     public function getRoleName();

    /**
     * Set role_name
     * @param string $RoleName
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setRoleName($RoleName); 

    /**
     * Get hg_admin_id
     * @return string|null
     */
    public function getHgAdminId();

    /**
     * Set hg_admin_id
     * @param string $hgAdminId
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setHgAdminId($hgAdminId);

   
    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setUpdatedBy($updatedBy);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_active
     * @return bool|true
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setIsActive($isActive);
    /**
     * Get is_delete
     * @return bool
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\Venue\Api\Data\VenueUserRoleInterface
     */
    public function setIsDelete($isDelete);
     
    

    /**
    * Get venue role permission mapping info
    *
    * @return \Aria\Venue\Api\Data\VenueRolePermissionMappingInterface[]|null
    */
    public function getVenueRolePermissionMapping();

    /**
    * Set dc role permission mapping info
    *
    * @param \Aria\Venue\Api\Data\VenueRolePermissionMappingInterface[] $venueRolePermissionMapping
    * @return $this
    */
    public function setVenueRolePermissionMapping(array $venueRolePermissionMapping = null);

}
