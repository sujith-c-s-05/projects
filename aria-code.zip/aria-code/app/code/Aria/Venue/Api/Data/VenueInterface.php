<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api\Data;

interface VenueInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const ID = 'id';
    const NAME = 'name';
    const HOSP_ID = 'hosp_id';
    const VENUE_EMAIL = 'venue_email';
    const DESCRIPTION = 'description';
    const ADDRESS = 'address';
    const ZIP_CODE = 'zip_code';
    const PHONE = 'phone';
    const LATITUDE = 'latitude';
    const LONGITUDE = 'longitude';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const IS_DELETE = 'is_delete';
    const CONTACT_NAME = 'contact_name';
    const CITY = 'city';
    const STATE = 'state';
    const COUNTRY = 'country';
    const NUMBER_OF_PARKED_ORDERS = 'number_of_parked_orders';
    const ORDER_COST_LIMIT = 'order_cost_limit';
    const CONTACT_PERSON_PHONE = 'contact_person_phone';

    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param int $Id
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setId($Id);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\Venue\Api\Data\VenueExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\Venue\Api\Data\VenueExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\Venue\Api\Data\VenueExtensionInterface $extensionAttributes
    );

    /**
     * Get name
     * @return string|null
     */
    public function getName();

    /**
     * Set name
     * @param string $name
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setName($name);

     /**
     * Get hosp_id
     * @return int|null
     */
    public function getHospId();

    /**
     * Set hosp_id
     * @param int $hospId
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setHospId($hospId);

    /**
     * Get venueemail
     * @return string|null
     */
    public function getVenueEmail();

    /**
     * Set venueemail
     * @param string $venueemail
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setVenueEmail($venueemail);
    /**
     * Get description
     * @return string|null
     */
    public function getDescription();

    /**
     * Set description
     * @param string $description
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setDescription($description);

    /**
     * Get address
     * @return string|null
     */
    public function getAddress();

    /**
     * Set address
     * @param string $address
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setAddress($address);

    /**
     * Get zip_code
     * @return string|null
     */
    public function getZipCode();

    /**
     * Set zip_code
     * @param string $zipCode
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setZipCode($zipCode);
    

    /**
     * Get phone
     * @return string|null
     */
    public function getPhone();

    /**
     * Set phone
     * @param string $phone
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setPhone($phone);

    

    /**
     * Get latitude
     * @return float|null
     */
    public function getLatitude();

    /**
     * Set latitude
     * @param float $latitude
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setLatitude($latitude);

    /**
     * Get longitude
     * @return float|null
     */
    public function getLongitude();

    /**
     * Set longitude
     * @param float $longitude
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setLongitude($longitude);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setUpdatedBy($updatedBy);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_active
     * @return bool|true
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setIsActive($isActive);
    /**
     * Get is_delete
     * @return bool|null
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setIsDelete($isDelete);
  
     /**
     * Get contact_name
     * @return string|null
     */
    public function getContactName();

    /**
     * Set contact_name
     * @param string $contact_name
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setContactName($contactname);
 
     /**
     * Get city
     * @return string|null
     */
    public function getCity();

    /**
     * Set city
     * @param string $city
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setCity($city);

    /**
     * Get state
     * @return string|null
     */
    public function getState();

    /**
     * Set state
     * @param string $state
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setState($state);

    /**
     * Get country
     * @return string|null
     */
    public function getCountry();

    /**
     * Set country
     * @param string $country
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setCountry($country);

     /**
     * Get number_of_parked_orders
     * @return int|null
     */
    public function getNumberOfParkedOrders();

    /**
     * Set number_of_parked_orders
     * @param int $number_of_parked_orders
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setNumberOfParkedOrders($number_of_parked_orders);

    /**
     * Get order_cost_limit
     * @return int|null
     */
    public function getOrderCostLimit();

    /**
     * Set order_cost_limit
     * @param int $order_cost_limit
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setOrderCostLimit($order_cost_limit);

     /**
     * Get contact_person_phone
     * @return string|null
     */
    public function getContactPersonPhone();

    /**
     * Set contact_person_phone
     * @param string $contact_person_phone
     * @return \Aria\Venue\Api\Data\VenueInterface
     */
    public function setContactPersonPhone($contact_person_phone);
    

}
