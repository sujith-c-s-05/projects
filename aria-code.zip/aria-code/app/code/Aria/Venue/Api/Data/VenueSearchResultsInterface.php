<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api\Data;

interface VenueSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Venue list.
     * @return \Aria\Venue\Api\Data\VenueInterface[]
     */
    public function getItems();

    /**
     * Set Venue list.
     * @param \Aria\Venue\Api\Data\VenueInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
