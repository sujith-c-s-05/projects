<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface VenueRolePermissionMappingRepositoryInterface
{

    /**
     * Save Venue User Role Permission
     * @param \Aria\Venue\Api\Data\VenueRolePermissionMappingInterface $venueRolePermissionMapping
     * @return \Aria\Venue\Api\Data\VenueRolePermissionMappingInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\Venue\Api\Data\VenueRolePermissionMappingInterface $venueRolePermissionMapping
    );

     /**
     * delete Venue Role Permission mapping
     * @param int roleId
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteVenueRolePermissionMapping($roleId);

    /**
     * Get Venue Role Permission mapping
     * @param int Id
     * @return \Aria\Venue\Api\Data\VenueRolePermissionMappingInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getVenueRolePermissionMappings($Id);

    /**
     * Get Venue Role Permission mapping
     * @param int Id
     * @return \Aria\Venue\Api\Data\VenueRolePermissionMappingInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getVenueRolePermissionMappingsDetails($Id);

    
}