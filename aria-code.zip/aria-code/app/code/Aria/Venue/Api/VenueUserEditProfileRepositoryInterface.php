<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface VenueUserEditProfileRepositoryInterface
{

    /**
     * Save Venue User
     * @param \Aria\Venue\Api\Data\VenueUserEditProfileInterface $venueUser
     * @return \Aria\Venue\Api\Data\VenueUserEditProfileInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\Venue\Api\Data\VenueUserEditProfileInterface $venueUserEditProfile
    );

}
