<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Venue\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface VenueUserRepositoryInterface
{

    /**
     * Save Venue User
     * @param \Aria\Venue\Api\Data\VenueUserInterface $venueUser
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\Venue\Api\Data\VenueUserInterface $venueUser
    );

   

    /**
     * Retrieve Venue User matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\Venue\Api\Data\VenueUserSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * @param int $Id
     * @param bool $isActive
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function setStatus($Id,$isActive);

    /**
     * Retrieve Venue user phone number
     * @param int $phone
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function isPhoneNumberExists($phone);

    /**
     * Delete Venue User by id
     * @param int $id
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteVenueUser($id);
     
    /**
     * Check whether the Venue's exist for adding venue user
     *
     * @return boolean
     */
    public function isActiveVenueExists();

    /**
     * Retrieve Venue User
     * @param int $Id
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($id);
     
      /**
     * Retrieve Venue User
     * @param int $Id
     * @return \Aria\Venue\Api\Data\VenueUserInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($id);
 

    /**
    * Delete Multiple Venue User
    * @api
    * @param int[] $id
    * @return bool Will return True if deleted.
    * @throws \Magento\Framework\Exception\NoSuchEntityException
    * @throws \Magento\Framework\Exception\LocalizedException
    * @throws \Magento\Framework\Exception\CouldNotDeleteException
    */
    public function deleteMultipleVenueUsers(array $id);

    /**
     * Check whether venue user is venue admin
     * @param int $Id
     * @return boolean
     */
    public function isVenueAdmin($Id);

    /**
     * Retrieve Venue Admin for Venue User
     * @param int $Id
     * @return int $venueAdminId
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getVenueAdminId($Id);

}
