<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Aria\ProductManagement\Setup\Patch\Data;

use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;
use Aria\ProductManagement\Model\Product\Link;

/**
 * Class Install substitution product link type data patch.
 *
 * @package Magento\Catalog\Setup\Patch
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class InstallCustomProductLinks implements DataPatchInterface
{
    const LINK_TYPE_SUBSTITUTION = 6;

    /**
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    /**
     * PatchInitial constructor.
     * @param ModuleDataSetupInterface $moduleDataSetup
     */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function apply()
    {
        /**
         * Install product link types in table (catalog_product_link_type)
         */
        $catalogProductLinkTypeData = [
            ['link_type_id' => self::LINK_TYPE_SUBSTITUTION, 'code' => 'substitution'],

        ];

        foreach ($catalogProductLinkTypeData as $bind) {
            $this->moduleDataSetup->getConnection()->insertOnDuplicate(
                $this->moduleDataSetup->getTable(
                    'catalog_product_link_type'
                ),
                $bind
            );
        }

        /**
         * install product link attributes position in table catalog_product_link_attribute
         */
        $catalogProductLinkAttributeData = [
            [
                'link_type_id' => self::LINK_TYPE_SUBSTITUTION,
                'product_link_attribute_code' => 'position',
                'data_type' => 'int',
            ]
        ];

        $this->moduleDataSetup->getConnection()->insertMultiple(
            $this->moduleDataSetup->getTable('catalog_product_link_attribute'),
            $catalogProductLinkAttributeData
        );
    }

    /**
     * {@inheritdoc}
     */
    public static function getDependencies()
    {
        return [];
    }


    /**
     * {@inheritdoc}
     */
    public function getAliases()
    {
        return [];
    }
}
