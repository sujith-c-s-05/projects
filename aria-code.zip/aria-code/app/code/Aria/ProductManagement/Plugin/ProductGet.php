<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Plugin;

use Magento\Catalog\Api\Data\ProductInterface;
use Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface;
use Aria\ProductManagement\Api\VenueCreditstatusRepositoryInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface;
use Magento\InventorySalesAdminUi\Model\GetSalableQuantityDataBySku;
use Magento\Framework\Exception\NoSuchEntityException;


class ProductGet
{
    /**
     * @var \Magento\Catalog\Api\Data\ProductExtensionFactory 
     */
    protected $productExtensionFactory;
    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $productFactory;
    /**
     * @var \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface 
     */
    protected $multiSellerProductRepositoryInterface;
    /**
     * @var \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory
     */
    protected $_categoryCollectionFactory; 
    /**
     * @var \Magento\Catalog\Api\CategoryRepositoryInterface
     */
    protected $categoryRepository;
    /**
     * @var \Magento\Eav\Model\Config
     */
    protected $eavConfig;

    /**
     * @var \Aria\ProductManagement\Model\SupplierProducts
     */
    protected $supplierProduct;
    /**
     * @var \Aria\ProductManagement\Api\VenueCreditstatusRepositoryInterface 
     */
    protected $venueCreditstatusRepositoryInterface;

    protected $date;
    
    protected $currency;
    /**
     * @var \Magento\Store\Model\App\Emulation
     */
    protected $appEmulation;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var \Magento\Catalog\Helper\Image
     */
    protected $imageHelper;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface
     */
    protected $supplyCompanyRepositoryInterface;
    
    protected $getSalableQuantityDataBySku;

    /**
     * constructor for search product function
     *
     * @param \Magento\Catalog\Api\Data\ProductExtensionFactory $productExtensionFactory
     * @param \Magento\Catalog\Model\ProductFactory $productFactory
     * @param \Magento\CatalogInventory\Api\StockStateInterface $stockItem
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryInterface $mediaGallery
     * @param \Magento\Eav\Model\Config $eavConfig
     * @param \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory
     * @param \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository
     * @param \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepositoryInterface
     * @param \Magento\Eav\Model\Config $eavConfig
     * @param \Aria\ProductManagement\Model\SupplierProducts $supplierProduct
     * @param \Aria\ProductManagement\Api\VenueCreditstatusRepositoryInterface $venueCreditstatusRepositoryInterface
     * @param \Magento\Store\Model\App\Emulation $appEmulation
     * @param \Magento\Catalog\Helper\Image   
     * @param \Magento\Catalog\Api\ProductRepositoryInterface
     * @param Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface
     * @param \Magento\InventorySalesAdminUi\Model\GetSalableQuantityDataBySku $getSalableQuantityDataBySku
     */
    public function __construct(
        \Magento\Catalog\Api\Data\ProductExtensionFactory $productExtensionFactory,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\CatalogInventory\Api\StockStateInterface $stockItem,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Catalog\Api\Data\ProductAttributeMediaGalleryEntryInterface $mediaGallery,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory,
        \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository,
        \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepositoryInterface,
        \Aria\ProductManagement\Api\VenueCreditstatusRepositoryInterface $venueCreditstatusRepositoryInterface,
        \Aria\ProductManagement\Model\SupplierProducts $supplierProduct,
        \Magento\Catalog\Model\Category $categoryFactory,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Directory\Model\Currency $currency,
        \Magento\Store\Model\App\Emulation $appEmulation,
        \Magento\Catalog\Helper\Image $imageHelper,
        ScopeConfigInterface $scopeConfig,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface,
        GetSalableQuantityDataBySku $getSalableQuantityDataBySku,
        \Aria\OrderProcessingTime\Api\OrderProcessingTimeRepositoryInterfaceFactory $orderProcessingTimeRepository
    )
    {
        $this->_categoryCollectionFactory = $categoryCollectionFactory;
        $this->categoryRepository = $categoryRepository;
        $this->productFactory = $productFactory;
        $this->storeManager = $storeManager;
        $this->logger = $logger;
        $this->stockItem = $stockItem;
        $this->productExtensionFactory = $productExtensionFactory;
        $this->eavConfig = $eavConfig;
        $this->mediaGallery = $mediaGallery;
        $this->multiSellerProductRepositoryInterface=$multiSellerProductRepositoryInterface;
        $this->venueCreditstatusRepositoryInterface=$venueCreditstatusRepositoryInterface;
        $this->supplierProduct = $supplierProduct;
        $this->_categoryFactory = $categoryFactory;
        $this->date = $date;
        $this->currency = $currency; 
        $this->appEmulation = $appEmulation;
        $this->imageHelper = $imageHelper;
        $this->scopeConfig = $scopeConfig;
        $this->productRepositoryInterface = $productRepositoryInterface;
        $this->supplyCompanyRepositoryInterface = $supplyCompanyRepositoryInterface;
        $this->getSalableQuantityDataBySku = $getSalableQuantityDataBySku;
        $this->orderProcessingTimeRepository = $orderProcessingTimeRepository;
    }
    /**
     * Get product
     *
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $subject
     * @param \Magento\Catalog\Api\Data\ProductInterface $product
     * @return void
     */
    public function afterGet
    (
        \Magento\Catalog\Api\ProductRepositoryInterface $subject,
        \Magento\Catalog\Api\Data\ProductInterface $product
    ) 
    {
        $extensionattributes = $product->getExtensionAttributes(); /** get current extension attributes from entity **/
        $sellerId=$product->getResource()->getAttributeRawValue($product->getId(),'seller_id',$product->getStore()->getWebsiteId());
        $brand=$product->getResource()->getAttributeRawValue($product->getId(),'brand',$product->getStore()->getWebsiteId());
        //Get details from multi seller product table
        $multiSellerProduct=$this->multiSellerProductRepositoryInterface->getMultiSellerProductByProductIdAndSellerId($product->getId(), $sellerId);
        $minOrderQty=$multiSellerProduct->getMinSaleQty();
        $qty=$multiSellerProduct->getQty();
        $maxOrderQty=$multiSellerProduct->getMaxSaleQty();
        
        //Get supplier name
        if(is_numeric($sellerId))
        {
        $supplyCompany=$this->supplierProduct->getSupplyCompanyByCompanyAdmin($sellerId);
        $supplierName=$supplyCompany->getCompanyName();
        $supplierId=$supplyCompany->getSupplycompanyId();
        }
        
        //get substitution product
        $subProducts=$this->getSubstitutionProducts($product);

        //Get allergens names
        $allergenNames=array();
        $allergens=$product->getResource()->getAttributeRawValue($product->getId(),'allergens',$product->getStore()->getWebsiteId());
        if(!empty($allergens)) {

             $allergenIds=explode (",", $allergens);
             foreach ($allergenIds as $allergenId) {
                 $attribute = $this->eavConfig->getAttribute('catalog_product', 'allergens');
                 $option_Text = $attribute->getSource()->getOptionText($allergenId);
                 array_push($allergenNames,$option_Text);
             }
        } 
        
        //Get other supplier name
        if(is_numeric($sellerId))
        {
            $otherSupplyCompany=$this->supplierProduct->getSupplyCompanyByCompanyAdmin(array('nin' => $sellerId));
            $otherMultiSellerProduct=$this->multiSellerProductRepositoryInterface->getMultiSellerProduct($product->getId(), $sellerId);
            $otherSupplierName[] = array('name'=>$otherSupplyCompany->getCompanyName(),'SupplierId'=>$otherSupplyCompany->getSupplycompanyId(),'unitcost'=>$product->getPrice()); 
            $otherSupplier= json_encode($otherSupplierName,true);
        }
         //Get category names
         $categoryNames=array();
         foreach ($product->getCategoryIds() as $categoryId) {
             array_push($categoryNames,$this->getCategoryNameById($categoryId));
         }
         //Get subcategory names
         $subcategoryName=array();
         foreach ($product->getCategoryIds() as $categoryId) {
             array_push($subcategoryName,$this->getSubCategoryNameById($categoryId));
             $subcategoryNames = json_encode($subcategoryName,true);
         }
        
         //Get details from Venue Credit Status table
         $venueCreditStatus=$this->venueCreditstatusRepositoryInterface->getVenueCreditstatusbySellerId($sellerId);
         
        
         //Get product image from s3 bucket
         $productImages=$this->getProductImageUrl($product,$extensionattributes);

        //Get supplier details
        if(is_numeric($sellerId))
        {
            $supplyCompanyDetails=$this->supplierProduct->getSupplyCompanyByCompanyAdmin($sellerId);
            $supplierId=$supplyCompany->getSupplycompanyId();
            $supplyCompanyDetails = $this->supplyCompanyRepositoryInterface->get($supplierId);
            $mov = $supplyCompanyDetails->getMov();
            // Countdown Timer
            $processTime = [];
            $nextProcessingTime = false;
            if (!array_key_exists($supplierId, $processTime)) {
                $orderProcessingTime = $this->orderProcessingTimeRepository->create();
                try {
                    $nextProcessingTime = $orderProcessingTime->getNextAvaliableDay($supplierId);
                } catch (NoSuchEntityException $e) {
                    $nextProcessingTime = false;
                }
                $processTime[$supplierId] = $nextProcessingTime;
            }
            if (isset($processTime[$supplierId]) && $processTime[$supplierId]) {
                $extensionattributes->setOrderProcessTime($processTime[$supplierId] ?? '');
            }
            
            $supplierDetails[] = array('name'=>$supplyCompanyDetails->getCompanyName(),
                                'supplierLogo'=>'',
                                'supplierDescription'=>$supplyCompanyDetails->getComment(),
                                'SupplierAddress'=>$supplyCompanyDetails->getStreetAddress(),
                                'MOV'=>$mov); 
            $supplier = json_encode($supplierDetails);
                    
        }

        //Get unit of measurement names
        
        $uom=$product->getResource()->getAttributeRawValue($product->getId(),'uom',$product->getStore()->getWebsiteId());
        if(!empty($uom)) {

                 $attribute = $this->eavConfig->getAttribute('catalog_product', 'uom');
                 $uomName = $attribute->getSource()->getOptionText($uom);            
        } 
        //Get store currency
        $currencyCode =  $this->storeManager->getStore()->getDefaultCurrencyCode();
        $currencySymbol =  $this->currency->getCurrencySymbol();
        $currencyList = $this->storeManager->getStore()->getAllowedCurrencies();

         //Get supplier tier price
         if(is_numeric($sellerId))
         {
             $supplierTierPrice[] = array("qty"=>2,"value"=> 0,"percentage_value"=>10); 
             $supplierTierPrice[] = array("qty"=>5,"value"=> 20,"percentage_value"=>0); 
         }

        //Get salable qty
        $stockItem = $product->getExtensionAttributes()->getStockItem();
        $stockItemQty=$stockItem->getQty();
        if(is_numeric($stockItemQty)&&$stockItemQty>0)
        {
            $salableQty=$this->getSalableQty($product->getSku());
        }
        //adding extentions
        $extensionattributes->setMultiSellerProductSpecialPrice($multiSellerProduct->getSpecialPrice()??'');
        $extensionattributes->setMultiSellerProductSpecialFromDate($multiSellerProduct->getSpecialFromDate()??'');
        $extensionattributes->setMultiSellerProductSpecialToDate($multiSellerProduct->getSpecialToDate()??'');
        $extensionattributes->setStatus($multiSellerProduct->getStatus()??'0');
        $extensionattributes->setIsActive($multiSellerProduct->getIsActive()??'0');
        $extensionattributes->setIsDelete($multiSellerProduct->getIsDelete()??'0');
        $extensionattributes->setIsOwner($multiSellerProduct->getIsOwner()??'0');
        $extensionattributes->setMinOrderQty($multiSellerProduct->getMinSaleQty()??'0');
        $extensionattributes->setQty($qty??'');
        $extensionattributes->setSalableQty($salableQty??0);
        $extensionattributes->setMultiSellerProductPrice($multiSellerProduct->getPrice()??'');
        $extensionattributes->setsupplierName($supplierName??'');
        $extensionattributes->setbrandName($brand==false ? '': $brand);
        $extensionattributes->setAllergenNames($allergenNames);
        $extensionattributes->setOtherSuppliername($otherSupplier??[]);
        $extensionattributes->setProductcatagoryName($categoryNames??'');
        $extensionattributes->setProductSubcatagoryName($subcategoryNames??[]);
        $extensionattributes->setCreditStatus($venueCreditStatus??'');
        $extensionattributes->setMaxOrderQty($multiSellerProduct->getMaxSaleQty()??'0');
        if (isset($processTime[$supplierId]) && $processTime[$supplierId]) {
            $extensionattributes->setOrderProcessTime($processTime[$supplierId] ?? '');
        }
        $extensionattributes->setSupplierId($supplierId??'');
        $extensionattributes->setSupplierDetails($supplierDetails??'');
        $extensionattributes->setUomName($uomName??'');
        $extensionattributes->setCurrencyCode($currencyCode);
        $extensionattributes->setCurrencySymbol($currencySymbol);
        $extensionattributes->setCurrencyList($currencyList);
        $extensionattributes->setSupplierTierPrice($supplierTierPrice??[]);
        $product->setExtensionAttributes($extensionattributes);
        return $product;


    }
    /**
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $subject
     * @param \Magento\Catalog\Model\ResourceModel\Product\Collection $products
     * @return \Magento\Catalog\Model\ResourceModel\Product\Collection
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterGetList(
        \Magento\Catalog\Api\ProductRepositoryInterface $subject,
        $products
    ) {
        $productList=$products->getItems();
        foreach ($products->getItems() as $key => $product) {
            $extensionattributes = $product->getExtensionAttributes();
            $sellerId=$product->getResource()->getAttributeRawValue($product->getId(),'seller_id',$product->getStore()->getWebsiteId());
            $brand=$product->getResource()->getAttributeRawValue($product->getId(),'brand',$product->getStore()->getWebsiteId());
            
            //Get category names
            $categoryNames=array();
            foreach ($product->getCategoryIds() as $categoryId) {
                array_push($categoryNames,$this->getCategoryNameById($categoryId));
            }

            //Get supplier name
            if(is_numeric($sellerId))
            {
                $supplyCompany=$this->supplierProduct->getSupplyCompanyByCompanyAdmin($sellerId);
                $SupplierName=$supplyCompany->getCompanyName();
                $supplierId=$supplyCompany->getSupplycompanyId();
            }


            //Get uom name
           
            $prod_uom=$product->getResource()->getAttributeRawValue($product->getId(),'uom',$product->getStore()->getWebsiteId());
            if(!empty($prod_uom)) {
    
                $attribute = $this->eavConfig->getAttribute('catalog_product', 'uom');
                $uomNam = $attribute->getSource()->getOptionText($prod_uom);            
            } 
            

            //Get allergens names
            $allergenNames=array();
            $allergens=$product->getResource()->getAttributeRawValue($product->getId(),'allergens',$product->getStore()->getWebsiteId());
            if(!empty($allergens)) {

                $allergenIds=explode (",", $allergens);
                foreach ($allergenIds as $allergenId) {
                    $attribute = $this->eavConfig->getAttribute('catalog_product', 'allergens');
                    $option_Text = $attribute->getSource()->getOptionText($allergenId);
                    array_push($allergenNames,$option_Text);
                }
            } 

            //Get details from Venue Credit Status table
            $venueCreditStatus=$this->venueCreditstatusRepositoryInterface->getVenueCreditstatusbySellerId($sellerId);
            
            //Get product image from s3 bucket
            $productImages=$this->getProductImageUrl($product,$extensionattributes);

            //Get details from multi seller product table
            $multiSellerProduct=$this->multiSellerProductRepositoryInterface->getMultiSellerProductByProductIdAndSellerId($product->getId(), $sellerId);
            $unitCost=$multiSellerProduct->getPrice();
            $minOrderQty=$multiSellerProduct->getMinSaleQty();
            $qty=$multiSellerProduct->getQty();
            $productEntity=$this->productRepositoryInterface->getById($product->getId());
            $stockItem = $productEntity->getExtensionAttributes()->getStockItem();

            //Get salable qty
            $stockItemQty=$stockItem->getQty();
            $salableQty=0;
            if(is_numeric($stockItemQty)&&$stockItemQty>0){
                $salableQty=$this->getSalableQty($product->getSku());
            }
            
            //adding extentions
            $extensionattributes->setIsDelete($multiSellerProduct->getIsDelete()??'0');
        
            $extensionattributes->setbrandName($brand==false ? '': $brand);
            $extensionattributes->setsupplierName($SupplierName??'');
            $extensionattributes->setSupplierId($supplierId??'');
            $extensionattributes->setProductCategories($categoryNames);
            $extensionattributes->setMultiSellerProductSpecialPrice($multiSellerProduct->getSpecialPrice()??'');
            $extensionattributes->setMultiSellerProductSpecialFromDate($multiSellerProduct->getSpecialFromDate()??'');
            $extensionattributes->setMultiSellerProductSpecialToDate($multiSellerProduct->getSpecialToDate()??'');
            $extensionattributes->setUnitCost($product->getPrice()??'');
            $extensionattributes->setUomname($uomNam??'');
            $extensionattributes->setCreditStatus($venueCreditStatus??'');
            $extensionattributes->setMinOrderQty($stockItem->getMinSaleQty()??'');
            $extensionattributes->setQty($salableQty??'');
            $extensionattributes->setAllergenNames($allergenNames);
            $product->setExtensionAttributes($extensionattributes);
            $isDeleted=$product->getExtensionAttributes()->getIsDelete();          
        }
        $products->setItems($productList);
        return $products;
    }

    /**
     * @param int $id
     * @param null $storeId
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getCategoryNameById($id, $storeId = null)
    {
        $categoryInstance = $this->categoryRepository->get($id, $storeId);
        return $categoryInstance->getName();
    }
    protected function getSubCategoryNameById($categoryId)
    {
         $catagory = $this->_categoryFactory->load($categoryId);
         $subcatagory = $catagory->getChildren();
         $subcategories = array();
         foreach(explode(',',$subcatagory) as $subCatagoryid){
         $_subCategory = $this->_categoryFactory->load($subCatagoryid);
         if($_subCategory->getIsActive()) {
            $subcategories = array('id'=>$_subCategory->getId(),'name'=>$_subCategory->getName()); 
            
         }

        }
        return $subcategories; 

    }

    /**
     * Get image url
     *
     * @param \Magento\Catalog\Api\Data\ProductInterface $product
     * @param \Magento\Catalog\Api\Data\ProductExtensionInterface $extensionattributes
     * @return void
     */
    public function getProductImageUrl($product,$extensionattributes)
    {
        $awsUrl = $this->scopeConfig->getValue('productmanagement/general/display_text',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $storeId = $this->storeManager->getStore()->getId();
        $this->appEmulation->startEnvironmentEmulation($storeId, \Magento\Framework\App\Area::AREA_FRONTEND, true);
        $images=$product->getMediaGalleryEntries();
        $awsImageUrl="";
        foreach($images as $image){
            $imagePath=$image->getFile();
            $headers = @get_headers($imagePath);
            if(!$headers || $headers[0] == 'HTTP/1.1 404 Not Found') {
                $path =preg_replace('#/+#','/',$imagePath);
                $awsImageUrl=$awsUrl.$path;
                $image->setFile($awsImageUrl);
            }
        }
        $product->setMediaGalleryEntries($images);
        $smallImage=$product->getResource()->getAttributeRawValue($product->getId(),'image',$product->getStore()->getWebsiteId());
        $baseImage=$product->getResource()->getAttributeRawValue($product->getId(),'small_image',$product->getStore()->getWebsiteId());
        $thumbnailImage=$product->getResource()->getAttributeRawValue($product->getId(),'thumbnail',$product->getStore()->getWebsiteId());
        $swatchImage=$product->getResource()->getAttributeRawValue($product->getId(),'swatch_image',$product->getStore()->getWebsiteId());

        $baseImageUrl = $this->imageHelper->init($product, 'product_base_image')->getUrl();
        $pos = strpos($baseImageUrl, "cache");
        $baseUrl = substr_replace($baseImageUrl,$awsUrl.'/',0,$pos);

        $thumbnailImageUrl = $this->imageHelper->init($product, 'product_thumbnail_image')->getUrl();
        $posTumbImage = strpos($thumbnailImageUrl, "cache");
        $thumbNailUrl = substr_replace($thumbnailImageUrl,$awsUrl.'/',0,$posTumbImage);

        $smallImageUrl = $this->imageHelper->init($product, 'product_small_image')->getUrl();
        $posSmallImage = strpos($smallImageUrl, "cache");
        $smallUrl = substr_replace($smallImageUrl,$awsUrl.'/',0,$posSmallImage);

        $swatchImageUrl = $this->imageHelper->init($product, 'swatch_image')->getUrl();
        $posSwatchImage = strpos($swatchImageUrl, "cache");
        $swatchUrl = substr_replace($swatchImageUrl,$awsUrl.'/',0,$posSwatchImage);

        $extensionattributes->setBaseImage($baseImage=='no_selection'?'':$baseUrl??'');
        $extensionattributes->setSmallImage($smallImage=='no_selection'?'':$smallUrl??'');
        $extensionattributes->setThumbnailImage($thumbnailImage=='no_selection'?'':$thumbNailUrl??'');
        $extensionattributes->setSwatchImage($swatchImage=='no_selection'?'':$swatchUrl??'');

        $this->appEmulation->stopEnvironmentEmulation();
    }

    /**
     * Get substitution product details
     *
     * @param \Magento\Catalog\Api\Data\ProductInterface $product
     * @return void
     */
    public function getSubstitutionProducts($product)
    {
        $productLinks=$product->getProductLinks();
        if(!is_null($productLinks)){
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            foreach($productLinks as $productLink){

                $extensionattributes=$productLink->getExtensionAttributes();
                $linkedProductSku=$productLink->getLinkedProductSku();
                $productId = $objectManager->get('Magento\Catalog\Model\Product')->getIdBySku($linkedProductSku);
                $productDetails = $this->productRepositoryInterface->getById($productId);
                $name=$productDetails->getName();
                $brand=$productDetails->getResource()
                                ->getAttributeRawValue(
                                    $productDetails->getId(),'brand',$productDetails->getStore()->getWebsiteId()
                                );
                $unitCost=$productDetails->getPrice();
    
                //Get unit of measurement names
                $uom=$productDetails->getResource()
                            ->getAttributeRawValue(
                                $productDetails->getId(),'uom',$productDetails->getStore()->getWebsiteId()
                            );
                if(!empty($uom)) {
    
                        $attribute = $this->eavConfig->getAttribute('catalog_product', 'uom');
                        $uomName = $attribute->getSource()->getOptionText($uom);            
                } 
                $stockItem = $productDetails->getExtensionAttributes()->getStockItem();
                $minOrderQty=$stockItem->getMinSaleQty();
                $isInStock=$stockItem->getIsInStock();
                $images=$productDetails->getMediaGalleryEntries();
                $awsUrl = $this->scopeConfig->getValue('productmanagement/general/display_text',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                $s3ImageUrl="";
                foreach($images as $image){
                    $imagePath=$image->getFile();
                    $path =preg_replace('#/+#','/',$imagePath);
                    $s3ImageUrl=$awsUrl.$path;
                    break;
                }
    
                $extensionattributes->setBrand($brand==false ? '': $brand);
                $extensionattributes->setName($name??'');
                $extensionattributes->setUnitCost($unitCost??'');
                $extensionattributes->setMinOrderQty($minOrderQty??'');
                $extensionattributes->setUom($uomName??'');
                $extensionattributes->setImage($s3ImageUrl??'');
                $extensionattributes->setIsInStock($isInStock??false);
                $productLink->setExtensionAttributes($extensionattributes);
            }

        }
    }

    /**
     * get product salable qty
     *
     * @param string $sku
     * @return int
     */
    public function getSalableQty($sku)
    {
        $salable = $this->getSalableQuantityDataBySku->execute($sku);
        $salableQty=$salable[0]['qty'];
        return $salableQty;
    }
}