<?php
namespace Aria\ProductManagement\Plugin;

/**
 * Class is used for setting nearest dc condition in product list
 */
class CollectionPlugin
{
    /**
     * @var \Aria\ProductManagement\Api\MultiSellerProductRepository 
     */
    protected $multiSellerProductRepository;
    /**
     * constructor for search product function
     *
     * @param \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepository
     */
    public function __construct(

        \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepository
    )
    {
        $this->multiSellerProductRepository=$multiSellerProductRepository;
    }
   
    public function beforeGetList(\Magento\Catalog\Api\ProductRepositoryInterface $subject,
    \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        try{
            foreach ($searchCriteria->getFilterGroups() as $filterGroup) {
                foreach ($filterGroup->getFilters() as $filter) {
                    $field = $filter->getField();
                    if($field=='venue_id')
                    {
                        $value=$filter->getValue();
                        $venueId=$value;
                        //get seller id for venue id
                        $sellerId= $this->multiSellerProductRepository->getNearestDCSellerId($venueId);
                        $filter->setValue($sellerId);
                        $filter->setField('seller_id');
                        $filter->setConditionType('in');
                    }
                }
            }
        }catch (CouldNotSaveException $e) {
            echo $e->getMessage();
        }
    }
}