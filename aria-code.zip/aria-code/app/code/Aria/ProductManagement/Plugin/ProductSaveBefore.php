<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Plugin;


use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\App\Config\ScopeConfigInterface;

/**
 * Class ProductSaveBefore
 */
class ProductSaveBefore 
{
   
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    
    protected $supplierProduct;
    /**
     * @var \Magento\Eav\Model\Config
     */
    protected $eavConfig;
    /**
     * @var \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface 
     */
    protected $multiSellerProductRepositoryInterface;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface 
     */
    protected $productRepositoryInterface;
    private $logger;

    protected $_productCollectionFactory;


    /**
     * constructor function
     *
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Aria\ProductManagement\Model\SupplierProducts $supplierProduct
     * @param \Magento\Eav\Model\Config $eavConfig
     * @param \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepositoryInterface,
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface
     */

    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Aria\ProductManagement\Model\SupplierProducts $supplierProduct,
        \Magento\Eav\Model\Config $eavConfig,
        \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepositoryInterface,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        \Psr\Log\LoggerInterface $logger,
        ScopeConfigInterface $scopeConfig,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory

    ) {
        $this->_storeManager = $storeManager;
        $this->supplierProduct = $supplierProduct;
        $this->eavConfig = $eavConfig;
        $this->multiSellerProductRepositoryInterface=$multiSellerProductRepositoryInterface;
        $this->productRepositoryInterface=$productRepositoryInterface;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_productCollectionFactory = $productCollectionFactory;   
 
    }
    /**
     * before save function
     *
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $subject
     * @param \Magento\Catalog\Api\Data\ProductInterface $_product
     * @return void
     */
    public function beforeSave(\Magento\Catalog\Api\ProductRepositoryInterface $subject,
                                \Magento\Catalog\Api\Data\ProductInterface $_product)
    {
        try {
            $bulk=$_product->getIsBulk();
            $sellerId=$_product->getSellerId();
            $supplierSku=$_product->getSupplierSku();
            $productId=$_product->getId();
            $supplierCollection = $this->_productCollectionFactory->create();
            $supplierCollection->addFieldToFilter('seller_id',$sellerId)
            ->addFieldToFilter('supplier_sku',$supplierSku);
            $name=$_product->getName();
            if(count($supplierCollection)==0 && !$_product->getSku())
            {

                $currentTime=time();
                $microTime=round(microtime(true)*1000);
                $microTimeResult= substr($microTime, -3);
                $skuMask = $this->scopeConfig->getValue('productmanagement/general/display_text1',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                $skuValue=''.$skuMask.''.$sellerId.''.$currentTime.''.$microTimeResult.'';
                $_product->setSku($skuValue);
                foreach($_product->getProductLinks() as $link)
                {
                    $link->setData('sku',$skuValue);
                    if($bulk)
                    {
                        $linkedSupplierSku=$link->getData('linked_product_sku');
                        $linkedCollection=$this->_productCollectionFactory->create();
                        $linkedCollection->addFieldToFilter('seller_id',$sellerId)
                        ->addFieldToFilter('supplier_sku',$linkedSupplierSku);
                        $linkedDetails=$linkedCollection->getFirstItem();
                        $linkedSkuField=$linkedDetails->getSku();
                        $link->setData('linked_product_sku',$linkedSkuField);                    
                    }
                }
                
            }
            else if(!$_product->getSku())
            {
                if(count($supplierCollection)>0)
                {
                    throw new \Magento\Framework\Webapi\Exception(    __('Supplier sku :'.$supplierSku.' already Exist '),
                    0,\Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST
                    );
                }
                $collectionItem = $supplierCollection->getFirstItem();
                $ItemData=$collectionItem->getData();
                $sku=$ItemData['sku'];
                $_product->setSku($sku);

            }
            
             

            //Set images for bulk product import
            if($productId==null||$productId=0){
                $images=$_product->getMediaGalleryEntries();
                $imagePath="";
                if(!empty($images))
                {
                    foreach($images as $key =>$image){
                        $imagePath=$image->getFile();
                        if(isset($imagePath)&&!empty($imagePath)){
                            try{
                                $imageData = file_get_contents($imagePath);
                                if ($image !== false){
                                    $baseContent= base64_encode($imageData??'');
                                    $content=$image->getContent();
                                    $content->setBase64EncodedData($baseContent);
                                    $content->setType('image/jpeg');
                                    $fileName=basename($imagePath);
                                    $content->setName($fileName);
                                }
                            }
                            catch (\Exception $e) {
                                unset($images[$key]);
                            }
                        }
                    }
                }
                
                if(!empty($imagePath)){
                    $_product->setMediaGalleryEntries($images);
                }
            }
            if(is_numeric($sellerId))
            {
                $supplyCompany=$this->supplierProduct->getSupplyCompanyByCompanyAdmin($sellerId);
                $_product->setData('supplier_name', $supplyCompany->getCompanyName());
                $attribute = $this->eavConfig->getAttribute('catalog_product', 'supply_company_name');
                $optionId = $attribute->getSource()->getOptionId($supplyCompany->getCompanyName());
                $_product->setData('supply_company_name', $optionId);
            }
            $extensionattributes = $_product->getExtensionAttributes();
            $categoryLinks=$extensionattributes->getCategoryLinks();
            $categoryIds=[];
            if(!is_null($categoryLinks)){
                foreach($categoryLinks as $categoryLink)
                {
                    $categoryId=$categoryLink->getCategoryId();
                    $categoryIds[]=$categoryId;
                }
                $_product->setData('category_ids', $categoryIds);
            }
            
            
        }catch (CouldNotSaveException $e) {
            throw new \Magento\Framework\Webapi\Exception(    __($e->getMessage()),
                    0,\Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST
                    );
        }
    }
}
