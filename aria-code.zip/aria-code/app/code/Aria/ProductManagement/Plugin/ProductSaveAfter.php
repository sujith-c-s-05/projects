<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Plugin;

use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Catalog\Api\Data\ProductInterface;
use Aria\SupplierWatch\Model\ResourceModel\SupplierWatchScheduler\CollectionFactory as SupplierWatchSchedulerCollectionFactory;

/**
 * Class ProductSaveAfter
 */
class ProductSaveAfter 
{
    /**
     * @var \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface
     */
    protected $multiSellerProductRepository;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * ProductSaveAfter constructor.
     * @param \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $MultiSellerProductRepositoryInterface
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
        \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $MultiSellerProductRepositoryInterface,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Aria\SupplierWatch\Api\SupplierWatchSchedulerRepositoryInterface $schedulerRepositoryInterface,
        \Aria\ProductManagement\Model\SupplierProducts $supplierProduct,
        SupplierWatchSchedulerCollectionFactory $supplierWatchSchedulerCollectionFactory
    ) {
        $this->multiSellerProductRepository = $MultiSellerProductRepositoryInterface;
        $this->_storeManager = $storeManager;
        $this->schedulerRepositoryInterface=$schedulerRepositoryInterface;
        $this->supplierProduct = $supplierProduct;
        $this->supplierWatchSchedulerCollectionFactory=$supplierWatchSchedulerCollectionFactory;
    }

   /**
    * after save function
    *
    * @param \Magento\Catalog\Api\ProductRepositoryInterface $subject
    * @param \Magento\Catalog\Api\Data\ProductInterface $_product
    * @return void
    */
    public function afterSave(\Magento\Catalog\Api\ProductRepositoryInterface $subject,
    \Magento\Catalog\Api\Data\ProductInterface $_product)
    {
        $currentWebsiteId = $this->_storeManager->getStore()->getWebsiteId();
        //$_product = $observer->getProduct();  // you will get product object
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $multiSellerProductObject = $objectManager->create('Aria\ProductManagement\Api\Data\MultiSellerProductInterface');

        try {
            $stockItem = $_product->getExtensionAttributes()->getStockItem();

             if(!$_product->getSpecialPrice())
                 $spcl_price = NULL;
             else
                 $spcl_price = $_product->getSpecialPrice();
            $prod = $multiSellerProductObject->load($_product->getEntityId(),'product_id');
            if($prod->gettId()){
                $prod->setSellerId($_product->getSellerId())
                ->setWebsiteId($currentWebsiteId)
                ->setPrice($_product->getPrice())
                ->setQty($stockItem->getQty())
                ->setStatus($_product->getStatus())
                ->setIsOwner(1)
                ->setUpdatedAt($_product->getUpdatedAt())
                ->setIsActive(1)
                ->setSpecialPrice($spcl_price)
                ->setSpecialFromDate($_product->getSpecialFromDate())
                ->setSpecialToDate($_product->getSpecialToDate())
                ->setSku($_product->getSku())
                ->setProductName($_product->getName())
                ->setMinSaleQty($stockItem->getMinSaleQty())
                ->setMaxSaleQty($stockItem->getMaxSaleQty());


            }
            else{
                $multiSellerProductObject->setProductId($_product->getEntityId())
                ->setSellerId($_product->getSellerId())
                ->setWebsiteId($currentWebsiteId)
                ->setPrice($_product->getPrice())
                ->setQty($stockItem->getQty())
                ->setStatus($_product->getStatus())
                ->setIsOwner(1)
                ->setCreatedAt($_product->getCreatedAt())
                ->setUpdatedAt($_product->getUpdatedAt())
                ->setIsActive(1)
                ->setSpecialPrice($spcl_price)
                ->setSpecialFromDate($_product->getSpecialFromDate())
                ->setSpecialToDate($_product->getSpecialToDate())
                ->setSku($_product->getSku())
                ->setProductName($_product->getName())
                ->setMinSaleQty($stockItem->getMinSaleQty())
                ->setMaxSaleQty($stockItem->getMaxSaleQty())
                ->setMaxSaleQty($stockItem->getMaxSaleQty());

                if(is_numeric($_product->getSellerId()))
                {
                    $multiSellerProduct = $this->multiSellerProductRepository->save($multiSellerProductObject);
                }
            }
            //save to scheduler table when supplier adds a new product /tatus if supplier record exists
            $bulk=$_product->getIsBulk();
            if(!$bulk)
            {
                $supplyCompany=$this->supplierProduct->getSupplyCompanyByCompanyAdmin($_product->getSellerId());
                $supplierId=$supplyCompany->getSupplycompanyId();
                $supplierWatchSchedulerCollection = $this->supplierWatchSchedulerCollectionFactory->create();
                $supplierWatchSchedulerCollection->addFieldToFilter('supplier_id', $supplierId)->addFieldToFilter('sku',$_product->getSku());
                if(count($supplierWatchSchedulerCollection) == 0){
                    $supplierWatchScheduler = $objectManager->create('Aria\SupplierWatch\Api\Data\SupplierWatchSchedulerInterface');
                    $supplierWatchScheduler->setSupplierId($supplierId)
                    ->setSku($_product->getSku())
                    ->setStatus(1);
                $this->schedulerRepositoryInterface->save($supplierWatchScheduler);
            }
        }
            return $_product; 
           
        } catch (CouldNotSaveException $e) {
            echo $e->getMessage();
        }
    }
}
