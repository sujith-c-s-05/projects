<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\CouldNotSaveException;

/**
 * Class ProductSaveBefore
 * @package Aria\ProductManagement\Observer
 */
class ProductSaveBefore implements ObserverInterface
{
   
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    
    protected $supplierProduct;
    /**
     * @var \Magento\Eav\Model\Config
     */
    protected $eavConfig;
    /**
     * @var \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface 
     */
    protected $multiSellerProductRepositoryInterface;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface 
     */
    protected $productRepositoryInterface;

    /**
     * Undocumented function
     *
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Aria\ProductManagement\Model\SupplierProducts $supplierProduct
     * @param \Magento\Eav\Model\Config $eavConfig
     * @param \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepositoryInterface,
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface
     */
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Aria\ProductManagement\Model\SupplierProducts $supplierProduct,
        \Magento\Eav\Model\Config $eavConfig,
        \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepositoryInterface,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface
    ) {
        $this->_storeManager = $storeManager;
        $this->supplierProduct = $supplierProduct;
        $this->eavConfig = $eavConfig;
        $this->multiSellerProductRepositoryInterface=$multiSellerProductRepositoryInterface;
        $this->productRepositoryInterface=$productRepositoryInterface;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        try {
            $_product = $observer->getProduct();  // you will get product object
            $sellerId=$_product->getSellerId();
            
            $supplyCompany=$this->supplierProduct->getSupplyCompanyByCompanyAdmin($sellerId);
            $_product->setData('supplier_name', $supplyCompany->getCompanyName());
            $categoryLinks=$_product->getCategoryLinks();
            $ids = array_column($categoryLinks, 'category_id');
            $_product->setData('category_ids', $ids);
            
        }catch (CouldNotSaveException $e) {
            echo $e->getMessage();
        }
    }
}
