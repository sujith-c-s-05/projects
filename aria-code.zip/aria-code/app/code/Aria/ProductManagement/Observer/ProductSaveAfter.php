<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\CouldNotSaveException;

/**
 * Class ProductSaveAfter
 * @package Aria\ProductManagement\Observer
 */
class ProductSaveAfter implements ObserverInterface
{
    /**
     * @var \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface
     */
    protected $multiSellerProductRepository;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * ProductSaveAfter constructor.
     * @param \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $MultiSellerProductRepositoryInterface
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
        \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $MultiSellerProductRepositoryInterface,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->multiSellerProductRepository = $MultiSellerProductRepositoryInterface;
        $this->_storeManager = $storeManager;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $currentWebsiteId = $this->_storeManager->getStore()->getWebsiteId();
        $_product = $observer->getProduct();  // you will get product object
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $multiSellerProductObject = $objectManager->create('Aria\ProductManagement\Api\Data\MultiSellerProductInterface');
        try {
            $stockItem = $_product->getExtensionAttributes()->getStockItem();

             if(!$_product->getSpecialPrice())
                 $spcl_price = NULL;
             else
                 $spcl_price = $_product->getSpecialPrice();
            $prod = $multiSellerProductObject->load($_product->getEntityId(),'product_id');
            if($prod->gettId()){
                $prod->setSellerId($_product->getSellerId())
                ->setWebsiteId($currentWebsiteId)
                ->setPrice($_product->getPrice())
                ->setQty($stockItem->getQty())
                ->setStatus($_product->getStatus())
                ->setIsOwner(1)
                ->setUpdatedAt($_product->getUpdatedAt())
                ->setIsActive(1)
                ->setSpecialPrice($spcl_price)
                ->setSpecialFromDate($_product->getSpecialFromDate())
                ->setSpecialToDate($_product->getSpecialToDate())
                ->setSku($_product->getSku())
                ->setProductName($_product->getName())
                ->setMinSaleQty($stockItem->getMinSaleQty())
                ->setMaxSaleQty($stockItem->getMaxSaleQty());


            }
            else{
                $multiSellerProductObject->setProductId($_product->getEntityId())
                ->setSellerId($_product->getSellerId())
                ->setWebsiteId($currentWebsiteId)
                ->setPrice($_product->getPrice())
                ->setQty($stockItem->getQty())
                ->setStatus($_product->getStatus())
                ->setIsOwner(1)
                ->setCreatedAt($_product->getCreatedAt())
                ->setUpdatedAt($_product->getUpdatedAt())
                ->setIsActive(1)
                ->setSpecialPrice($spcl_price)
                ->setSpecialFromDate($_product->getSpecialFromDate())
                ->setSpecialToDate($_product->getSpecialToDate())
                ->setSku($_product->getSku())
                ->setProductName($_product->getName())
                ->setMinSaleQty($stockItem->getMinSaleQty())
                ->setMaxSaleQty($stockItem->getMaxSaleQty())
                ->setMaxSaleQty($stockItem->getMaxSaleQty());


                $multiSellerProduct = $this->multiSellerProductRepository->save($multiSellerProductObject);
            }
           
        } catch (CouldNotSaveException $e) {
            echo $e->getMessage();
        }
    }
}
