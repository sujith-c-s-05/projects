<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductManagement\Api;

interface ProductFavoriteRepositoryInterface
{

     /**
     * Save product favorite
     * @param \Aria\ProductManagement\Api\Data\ProductFavoriteInterface $favorite
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface 
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\ProductManagement\Api\Data\ProductFavoriteInterface $favorite
    );

    /**
     * Retrieve favorite name
     * @param string $name
     * @param int $venueUserId
     * @param int|null $id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function isFavoriteNameExists($name,$venueUserId,$id = null);


    /**
     * Retrieve favorite matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Save order favorite
     * @param \Aria\ProductManagement\Api\Data\ProductFavoriteInterface $favoriteOrder
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface 
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function saveFavoriteOrder(
        \Aria\ProductManagement\Api\Data\ProductFavoriteInterface $favoriteOrder
    );
    
    /**
     * Delete favorite Order
     *
     * @param int $id
     * @return bool
     */
    public function deleteById($id);

     /**
     * get order favorite order based on  id
     *
     * @param int $id
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function getFavoriteOrder($id);

    /**
     * @param int $id
     * @param string $favoriteName
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function setFavoriteName($id,$favoriteName);

    /**
     * get  favorite list based on product id
     *
     * @param int $productId
     * @param int $venueUserId
     * @return mixed[]
     */
    public function getFavoriteList($productId,$venueUserId); 

    /**
     * Check whether the product is on favorite
     *
     * @param int $customerId
     * @param int $venueId
     * @param int $venueUserId
     * @param int $productId
     * @return bool
     */
    public function checkProductIsOnFavourite($customerId,$venueId,$venueUserId,$productId); 
}

