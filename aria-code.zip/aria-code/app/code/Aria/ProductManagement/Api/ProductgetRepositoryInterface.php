<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Aria\ProductManagement\Api;

/**
 * @api
 * @since 100.0.2
 */
interface ProductgetRepositoryInterface
{

    /**
     * Get product list
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Magento\Catalog\Api\Data\ProductSearchResultsInterface
     */
    public function getLists(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria);

    
}
