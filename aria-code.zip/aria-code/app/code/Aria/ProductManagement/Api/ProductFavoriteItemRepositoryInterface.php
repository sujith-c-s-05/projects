<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductManagement\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface ProductFavoriteItemRepositoryInterface
{

     /**
     * Save product favorite item
     * @param \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface $productFavoriteItem
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface $productFavoriteItem
    );

    /**
     * delete favorite items against favorite id
     *
     * @param int $favoriteId
     * @return bool
     */
    public function deleteFavoriteItems($favoriteId);
    
    /**
     * delete product from favorite list
     *
     * @param int $favoriteId
     * @param int $productId
     * @return bool
     */
    public function deleteFavoriteListItem($favoriteId,$productId);

    /**
     * get order favorite items based on favorite id
     *
     * @param int $favoriteId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function getFavoriteOrderItems($favoriteId);
}

