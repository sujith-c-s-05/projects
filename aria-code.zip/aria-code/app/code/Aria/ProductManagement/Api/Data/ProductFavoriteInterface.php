<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductManagement\Api\Data;


interface ProductFavoriteInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const ID = 'id';
    const VENUE_USER_ID = 'venue_user_id';
    const VENUE_ID = 'venue_id';
    const FAVORITE_NAME = 'favorite_name';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const IS_DELETE = 'is_delete';
    const IS_SCHEDULE = 'is_schedule';
 
    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param int $Id
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setId($Id);
       
    /**
     * Get venue user id
     * @return int|null
     */
    public function getVenueUserId();

    /**
     * Set venue user id
     * @param int $venueUserId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setVenueUserId($venueUserId);

    /**
     * Get favorite_name
     * @return string|null
     */
    public function getFavoriteName();

    /**
     * Set favorite_name
     * @param string $favoriteName
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setFavoriteName($favoriteName);

    /**
     * Get product_id
     * @return int|null
     */
    public function getProductId();

    /**
     * Set product id
     * @param int $productId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setProductId($productId);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\ProductFavoriteInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedby
     * @return \Aria\SupplyCompanyAccount\Api\Data\ProductFavoriteInterface
     */
    public function setUpdatedBy($updatedBy);


    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\ProductFavoriteInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\ProductFavoriteInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_active
     * @return bool
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\ProductFavoriteInterface
     */
    public function setIsActive($isActive);

    /**
     * Get venue  id
     * @return int|null
     */
    public function getVenueId();

    /**
     * Set venue  id
     * @param int $venueId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setVenueId($venueId);

    /**
     * Get is_delete
     * @return bool
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setIsDelete($isDelete);

    /**
    * Get venue user role info
    *
    * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface[]|null
    */
    public function getFavoriteItems();

    /**
    * Set venue user role info
    *
    * @param \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface[] $favoriteItems
    * @return $this
    */
    public function setFavoriteItems(array $favoriteItems = null);

    /**
     * Product total cost
     *
     * @return float|null
     */
    public function getTotalCost();

    /**
     * Set product total cost
     *
     * @param float $totalCost
     * @return $this
     */
    public function setTotalCost($totalCost);
    /**
     * Get is_schedule
     * @return bool
     */
    public function getIsSchedule();

    /**
     * Set is_schedule
     * @param bool $isSchedule
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setIsSchedule($isSchedule);
    
}
