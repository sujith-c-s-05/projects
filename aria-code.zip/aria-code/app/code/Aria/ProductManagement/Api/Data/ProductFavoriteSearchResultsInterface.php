<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductManagement\Api\Data;

interface ProductFavoriteSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get favorite list.
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface[]
     */
    public function getItems();

    /**
     * Set favorite list.
     * @param \Aria\ProductManagement\Api\Data\ProductFavoriteInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
