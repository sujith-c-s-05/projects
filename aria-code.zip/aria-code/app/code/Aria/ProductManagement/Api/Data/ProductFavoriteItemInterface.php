<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Aria\ProductManagement\Api\Data;

/**
 * @api
 * @since 100.0.2
 */
interface ProductFavoriteItemInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const ID = 'id';
    const FAVORITE_ID = 'favorite_id';
    const PRODUCT_ID = 'product_id';
    const STORE_ID = 'store_id';
    const QTY = 'qty';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const IS_DELETE = 'is_delete';

    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param int $Id
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setId($Id);
       
    /**
     * Get favorite id
     * @return int|null
     */
    public function getFavoriteId();

    /**
     * Set favorite id
     * @param int $favoriteId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setFavoriteId($favoriteId);

    /**
     * Get product id
     * @return int|null
     */
    public function getProductId();

    /**
     * Set product id
     * @param int $productId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setProductId($productId);

    /**
     * Get store_id
     * @return int|null
     */
    public function getStoreId();

    /**
     * Set store Id
     * @param int $storeId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setStoreId($storeId);

    /**
     * Get qty
     * @return int|null
     */
    public function getQty();

    /**
     * Set qty
     * @param int $qty
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setQty($qty);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdAt
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedby
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setUpdatedBy($updatedBy);


    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_active
     * @return bool
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setIsActive($isActive);

    /**
     * Get is_delete
     * @return bool
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setIsDelete($isDelete);

    /**
     * Get product_name
     * @return string|null
     */
    public function getProductName();

    /**
     * Set product_name
     * @param string $productName
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setProductName($productName);

    /**
     * Get product_catagory
     * @return string|null
     */
    public function getProductCatagory();

    /**
     * Set product_catagory
     * @param string $productCatagory
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setProductCatagory($productCatagory);

    /**
     * Get unit_cost
     * @return float|null
     */
    public function getUnitCost();

    /**
     * Set unit_cost
     * @param float $unitCost
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setUnitCost($unitCost);

    /**
     * Get total_cost
     * @return float|null
     */
    public function getTotalCost();

    /**
     * Set total_cost
     * @param float $totalCost
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setTotalCost($totalCost);

    /**
     * Get supplier_name
     * @return string|null
     */
    public function getSupplierName();
    
    /**
     * Set supplier_name
     * @param string $supplierName
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setSupplierName($supplierName);

    /**
     * Get uom_name
     * @return string|null
     */
    public function getUomName();
    
    /**
     * Set uom_name
     * @param string $uomName
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setUomName($uomName);

    /**
     * Get image
     * @return string|null
     */
    public function getImage();
    
    /**
     * Set image
     * @param string $image
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setImage($image);
    
}
