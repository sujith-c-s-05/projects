<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Aria\ProductManagement\Api\Data;

/**
 * @api
 * @since 100.0.2
 */
interface MultiSellerProductInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**
     * @return mixed
     */
    public function getId();

    /**
     * @param $id
     * @return mixed
     */
    public function setId($id); 

    /**
     * @return mixed
     */
    public function getProductId();

    /**
     * @param $productId
     * @return mixed
     */
    public function setProductId($productId);

    /**
     * @return mixed
     */
    public function getSellerId();

    /**
     * @param $sellerId
     * @return mixed
     */
    public function setSellerId($sellerId);

    /**
     * @return mixed
     */
    public function getWebsiteId();

    /**
     * @param $websiteId
     * @return mixed
     */
    public function setWebsiteId($websiteId);

    /**
     * @return mixed
     */
    public function getPrice();

    /**
     * @param $position
     * @return mixed
     */
    public function setPrice($position);

    /**
     * @return mixed
     */
    public function getQty();

    /**
     * @param $qty
     * @return mixed
     */
    public function setQty($qty);

    /**
     * @return mixed
     */
    public function getStatus();

    /**
     * @param $status
     * @return mixed
     */
    public function setStatus($status);

    /**
     * @return mixed
     */
    public function getIsOwner();

    /**
     * @param $isOwner
     * @return mixed
     */
    public function setIsOwner($isOwner);

    /**
     * @return mixed
     */
    public function getCreatedAt();

    /**
     * @param $createdAt
     * @return mixed
     */
    public function setCreatedAt($createdAt);

    /**
     * @return mixed
     */
    public function getUpdatedAt();

    /**
     * @param $updatedAt
     * @return mixed
     */
    public function setUpdatedAt($updatedAt);

    /**
     * @return mixed
     */
    public function getCreatedBy();

    /**
     * @param $createdBy
     * @return mixed
     */
    public function setCreatedBy($createdBy);

    /**
     * @return mixed
     */
    public function getUpdatedBy();

    /**
     * @param $updatedBy
     * @return mixed
     */
    public function setUpdatedBy($updatedBy);

    /**
     * @return mixed
     */
    public function getIsActive();

    /**
     * @param $isActive
     * @return mixed
     */
    public function setIsActive($isActive);

    /**
     * @return mixed
     */
    public function getIsDelete();

    /**
     * @param $isDelete
     * @return mixed
     */
    public function setIsDelete($isDelete);
    /**
     * @return mixed
     */
    public function getSpecialPrice();

    /**
     * @param $specialPrice
     * @return mixed
     */
    public function setSpecialPrice($specialPrice);

    /**
     * @return mixed
     */
    public function getSpecialFromDate();

    /**
     * @param $specialFromDate
     * @return mixed
     */
    public function setSpecialFromDate($specialFromDate);

    /**
     * @return mixed
     */
    public function getSpecialToDate();

    /**
     * @param $specialToDate
     * @return mixed
     */
    public function setSpecialToDate($specialToDate);

    /**
     * @return mixed
     */
    public function getSku();

    /**
     * @param $sku
     * @return mixed
     */
    public function setSku($sku);

    /**
     * @return mixed
     */
    public function getProductName();

    /**
     * @param $productName
     * @return mixed
     */
    public function setProductName($productName);

    /**
     * @return mixed
     */
    public function getMinSaleQty();

    /**
     * @param $minSaleQty
     * @return mixed
     */
    public function setMinSaleQty($minSaleQty);

     /**
     * @return mixed
     */
    public function getMaxSaleQty();

    /**
     * @param $maxSaleQty
     * @return mixed
     */
    public function setMaxSaleQty($maxSaleQty);
}
