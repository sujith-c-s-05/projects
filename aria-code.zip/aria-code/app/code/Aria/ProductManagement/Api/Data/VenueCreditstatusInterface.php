<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\ProductManagement\Api\Data;

interface VenueCreditstatusInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param int $Id
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setId($id);

    /**
     * Get seller id
     * @return int|null
     */
    public function getSellerId();

    /**
     * Set seller id
     * @param int $sellerId
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setSellerId($sellerId);

    /**
     * Get dc user id
     * @return int|null
     */
    public function getDcUserId();

    /**
     * Set dcUser id
     * @param int $dcUserId
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setDcUserId($dcUserId);

    /**
     * Get venue id
     * @return int|null
     */
    public function getVenueId();

     /**
     * Set venue id
     * @param int $venueId
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setVenueId($venueId);

    /**
     * Get status
     * @return int|null
     */
    public function getStatus();

    /**
     * Set status
     * @param int $status
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setStatus($status);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\VenueCreditstatusInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedby
     * @return \Aria\SupplyCompanyAccount\Api\Data\VenueCreditstatusInterface
     */
    public function setUpdatedBy($updatedBy);


    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\VenueCreditstatusInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\SupplyCompanyAccount\Api\Data\VenueCreditstatusInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_active
     * @return bool
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\SupplyCompanyAccount\Api\Data\VenueCreditstatusInterface
     */
    public function setIsActive($isActive);
   
}
