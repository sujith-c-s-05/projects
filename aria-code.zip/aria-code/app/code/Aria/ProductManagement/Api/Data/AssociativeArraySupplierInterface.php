<?php
namespace Aria\ProductManagement\Api\Data;

/**
 * Interface which represents associative array item.
 */
interface AssociativeArraySupplierInterface
{
    /**
     * Get SellerId
     * 
     * @return int
     */
    public function getSellerId();

    /**
     * Get SupplierName
     * 
     * @return string
     */
    public function getSupplierName();

    /**
     * Get SupplierId
     * 
     * @return int
     */
    public function getSupplierId();

    /**
     * Get SupplierAttributeId
     * 
     * @return int
     */
    public function getSupplierAttributeId();
   
}