<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Aria\ProductManagement\Api;

/**
 * Interface Venue Credits status Table   handling interface
 * @api
 * @since 100.0.2
 */
interface VenueCreditstatusRepositoryInterface
{
    /**
     *Get details from Venue Credit Status Table
     *
     * @param [type] $sellerId
     * @return void
     */
    public function getVenueCreditstatusbySellerId($sellerId);

    /**
     * Update venue credit status
     *
     * @param \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface $venueCreditStatus
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function save(\Aria\ProductManagement\Api\Data\VenueCreditstatusInterface $venueCreditStatus);
    
    /**
     * get credit status details
     *
     * @param int $dcId
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function getCreditStatusList($dcId);
}
