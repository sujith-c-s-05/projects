<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Aria\ProductManagement\Api;

/**
 * Interface multi seller product handling interface
 * @api
 * @since 100.0.2
 */
interface MultiSellerProductRepositoryInterface
{
    /**
     * Save multi seller product
     *
     * @param \Aria\ProductManagement\Api\Data\MultiSellerProductInterface $multiSellerProduct
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     * @return \Aria\ProductManagement\Api\Data\MultiSellerProductInterface
     */
    public function save(\Aria\ProductManagement\Api\Data\MultiSellerProductInterface $multiSellerProduct);

    /**
     * Get All Products of a supplier
     * @param int $sellerId
	 * @return \Aria\ProductManagement\Api\Data\MultiSellerProductInterface
	 */

    public function getSellerProducts($sellerId);

    /**
     *Get details from Multi  Seller product Table
     *
     * @param [type] $productId
     * @param [type] $sellerId
     * @return void
     */
    public function getMultiSellerProductByProductIdAndSellerId($productId, $sellerId);

    /**
     * Delete Product of a supplier by Id
     * @param int $sellerId
     * @param int $productId
     * @return bool true on success
	 * @return \Aria\ProductManagement\Api\Data\MultiSellerProductInterface
	 */
    public function deleteProductById($sellerId,$productId);

    /**
     * Get nearest DC's seller Id
     *
     * @param int $venueId
     * @return int
     */
    public function getNearestDCSellerId($venueId);

     /**
     * Get All Products of a supplier
     * @param int $sellerId
	 * @return \Aria\ProductManagement\Api\Data\MultiSellerProductInterface
	 */


    public function getSellerRelatedProduct($sellerId);

    /**
     *Get details from Multi  Seller product Table
     *
     * @param [type] $productId
     * @param [type] $sellerId
     * @return void
     */
    public function getMultiSellerProduct($productId, $sellerId);

    /**
     *Get details from Multi  Seller product Table
     *
     * @param [type] $sku
	 * @return \Aria\ProductManagement\Api\Data\MultiSellerProductInterface
     */
    public function getProduct($sku);

    /**
     * Get nearest dc against supplier
     *
     * @param int $supplierId
     * @param int $venueId
     * @return int
     */
    public function getDCId($supplierId,$venueId);

    /**
     * Get nearest DC seller
     * @param int $venueId
     * @return mixed[]
     */

    public function getNearestDCSeller($venueId);

    /**
     * Get nearest DC Supplier
     * @param int $venueId
     * @return Aria\ProductManagement\Api\Data\AssociativeArraySupplierInterface[]
     * @throws \Magento\Framework\Exception\LocalizedException
     */

    public function getNearestSupplier($venueId);

}
