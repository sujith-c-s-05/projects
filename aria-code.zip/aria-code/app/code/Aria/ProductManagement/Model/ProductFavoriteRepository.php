<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductManagement\Model;
use Aria\ProductManagement\Api\ProductFavoriteRepositoryInterface;
use Aria\ProductManagement\Model\ResourceModel\ProductFavorite as ResourceProductFavorite;
use Aria\ProductManagement\Model\ResourceModel\ProductFavorite\CollectionFactory as ProductFavoriteCollectionFactory;
use Aria\ProductManagement\Model\ResourceModel\ProductFavoriteItem\CollectionFactory as ProductFavoriteItemCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Aria\ProductManagement\Api\Data\ProductFavoriteSearchResultsInterfaceFactory;
use Magento\Catalog\Model\ProductRepository as productRepository;
use Magento\Framework\Exception\AuthorizationException;

class ProductFavoriteRepository implements ProductFavoriteRepositoryInterface
{

    protected $productFavoriteCollectionFactory;

    protected $productFavoriteItemCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;

    protected $productFavoriteFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $productFavoriteItemRepositoryInterface;

    /** @var  \Magento\Framework\DB\Adapter\AdapterInterface */
    protected $_conn;

    /** @var \Magento\Framework\App\ResourceConnection */
    protected $_resourceConnection;

    protected $searchResultsFactory;
    /**
     * @var Aria\Venue\Api\VenueRepositoryInterface
     */
    protected $venueRepositoryInterface;

    /**
     * @var Aria\Venue\Api\VenueUserRepositoryInterface
     */
    protected $venueUserRepositoryInterface;

    protected $productRepository;

    /**
     * constructor function
     *
     * @param ResourceProductFavorite $resource
     * @param ProductFavoriteFactory $productFavoriteFactory
     * @param ProductFavoriteCollectionFactory $productFavoriteCollectionFactory
     * @param ProductFavoriteItemCollectionFactory $productFavoriteItemCollectionFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param \Aria\ProductManagement\Api\ProductFavoriteItemRepositoryInterface $productFavoriteItemRepositoryInterface
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param ProductFavoriteSearchResultsInterfaceFactory $searchResultsFactory
     * @param Aria\Venue\Api\VenueRepositoryInterface $venueRepositoryInterface
     * @param Aria\Venue\Api\VenueUserRepositoryInterface $venueUserRepositoryInterface
     * @param productRepository $productRepository
     */
    public function __construct(
        ResourceProductFavorite $resource,
        ProductFavoriteFactory $productFavoriteFactory,
        ProductFavoriteCollectionFactory $productFavoriteCollectionFactory,
        ProductFavoriteItemCollectionFactory $productFavoriteItemCollectionFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Aria\ProductManagement\Api\ProductFavoriteItemRepositoryInterface $productFavoriteItemRepositoryInterface,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        ProductFavoriteSearchResultsInterfaceFactory $searchResultsFactory,
        \Aria\Venue\Api\VenueRepositoryInterface $venueRepositoryInterface,
        \Aria\Venue\Api\VenueUserRepositoryInterface $venueUserRepositoryInterface,
        productRepository $productRepository
    ) {
        $this->resource = $resource;
        $this->productFavoriteFactory = $productFavoriteFactory;
        $this->productFavoriteCollectionFactory = $productFavoriteCollectionFactory;
        $this->productFavoriteItemCollectionFactory = $productFavoriteItemCollectionFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->productFavoriteItemRepositoryInterface = $productFavoriteItemRepositoryInterface;
        $this->_resourceConnection = $resourceConnection;
        $this->_conn = $resourceConnection->getConnection();
        $this->searchResultsFactory = $searchResultsFactory;
        $this->venueRepositoryInterface=$venueRepositoryInterface;
        $this->venueUserRepositoryInterface=$venueUserRepositoryInterface;
        $this->productRepository    = $productRepository;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\ProductManagement\Api\Data\ProductFavoriteInterface $favorite
    ) {
        $productFavoriteData = $this->extensibleDataObjectConverter->toNestedArray(
            $favorite,
            [],
            \Aria\ProductManagement\Api\Data\ProductFavoriteInterface::class
        );  
        
        $productFavoriteModel = $this->productFavoriteFactory->create()->setData($productFavoriteData);
        
        try {
            $this->_conn->beginTransaction();
            $favoriteEntity=$productFavoriteModel->save();
            $product=$this->productRepository->getById($favoriteEntity->getProductId());
            $stockItem = $product->getExtensionAttributes()->getStockItem();
            $minSaleQty=$stockItem->getMinSaleQty();
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $productFavoriteItemObject = $objectManager->create('Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface');
            $productFavoriteItemObject->setFavoriteId($favoriteEntity->getId())
            ->setProductId($favoriteEntity->getProductId())
            ->setQty($minSaleQty)
            ->setStoreId($this->storeManager->getStore()->getId())
            ->setCreatedBy($favoriteEntity->getCreatedBy())
            ->setUpdatedBy($favoriteEntity->getUpdatedBy())
            ->setCreatedAt($favoriteEntity->getCreatedAt())
            ->setUpdatedAt($favoriteEntity->getUpdatedAt())
            ->setIsActive($favoriteEntity->getIsActive());
            $this->productFavoriteItemRepositoryInterface->save($productFavoriteItemObject);
            $this->_conn->commit();
        } catch (\Exception $exception) {
            $this->_conn->rollBack();
            throw new CouldNotSaveException(__(
                'Could not save the product favorite',
                $exception->getMessage()
            ));
        }
        return $productFavoriteModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function isFavoriteNameExists($name,$venueUserId,$id = null)
    {
        $isFavoriteNameExists=false;
        $nameCollection = $this->productFavoriteCollectionFactory->create();
        if(is_numeric($id))
        {
            $favorite=$this->getFavoriteOrder($id);
            $favoriteName=$favorite->getFavoriteName();
            if(strtolower($favoriteName)!=strtolower($name))
            {
                $nameCollection->addFieldToFilter('favorite_name', $name); 
                $nameCollection->addFieldToFilter('is_delete', 0); 
                $nameCollection->addFieldToFilter('venue_user_id', $venueUserId);
                if($nameCollection->count()>0)
                {
                    $isFavoriteNameExists=true;
                }
            }
        }
        else
        {
            $nameCollection->addFieldToFilter('favorite_name', $name); 
            $nameCollection->addFieldToFilter('is_delete', 0); 
            $nameCollection->addFieldToFilter('venue_user_id', $venueUserId);
            if($nameCollection->count()>0)
            {
                $isFavoriteNameExists=true;
            }
        }
        
        return $isFavoriteNameExists;
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->productFavoriteCollectionFactory->create();

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }
        foreach($items as $item){
            $favoriteId=$item->getId();
            $favoriteItems=$this->productFavoriteItemRepositoryInterface->getFavoriteOrderItems($favoriteId);
            $totalCost=0;
            foreach($favoriteItems as $favItem){
                $product=$this->productRepository->getById($favItem->getProductId());
                $price=$product->getPrice();
                $qty=$favItem->getQty();
                $cost=$price*$qty;
                $totalCost += $cost;
            }
            $item->setTotalCost($totalCost);
            $item->setFavoriteItems($favoriteItems);
        }
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function saveFavoriteOrder(
        \Aria\ProductManagement\Api\Data\ProductFavoriteInterface $favoriteOrder
    ) {
        $favoriteItems=$favoriteOrder->getFavoriteItems();
        $orderFavoriteData = $this->extensibleDataObjectConverter->toNestedArray(
            $favoriteOrder,
            [],
            \Aria\ProductManagement\Api\Data\ProductFavoriteInterface::class
        );  
        
        $orderFavoriteModel = $this->productFavoriteFactory->create()->setData($orderFavoriteData);
        
        try {
            $this->_conn->beginTransaction();
            $favoriteEntity=$orderFavoriteModel->save();
            $favoriteItems=$favoriteOrder->getFavoriteItems();
            foreach($favoriteItems as $favoriteItem){
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $productFavoriteItemObject = $objectManager->create('Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface');
                $id=$favoriteEntity->getId();
                $productFavoriteItemObject->setFavoriteId($id)
                ->setProductId($favoriteItem->getProductId())
                ->setStoreId($this->storeManager->getStore()->getId())
                ->setQty($favoriteItem->getQty())
                ->setCreatedBy($favoriteEntity->getCreatedBy())
                ->setUpdatedBy($favoriteEntity->getUpdatedBy())
                ->setCreatedAt($favoriteEntity->getCreatedAt())
                ->setUpdatedAt($favoriteEntity->getUpdatedAt())
                ->setIsActive($favoriteEntity->getIsActive())
                ->setIsDelete($favoriteEntity->getIsDelete());
                $this->productFavoriteItemRepositoryInterface->save($productFavoriteItemObject);
            }
            
            $this->_conn->commit();
        } catch (\Exception $exception) {
            $this->_conn->rollBack();
            throw new CouldNotSaveException(__(
                'Could not save the product favorite',
                $exception->getMessage()
            ));
        }
        return $orderFavoriteModel->getDataModel();
    }

    /**
     * @inheritdoc
     */
    public function deleteById($id)
    {
        try {
                $this->_conn->beginTransaction();
                $favoriteOrder = $this->productFavoriteFactory->create();
                $this->resource->load($favoriteOrder, $id);
                $favoriteOrder->Delete();
                $favoriteOrder->setIsActive(0);
                $favoriteOrderEntity=$favoriteOrder->save();
                $this->productFavoriteItemRepositoryInterface->deleteFavoriteItems($favoriteOrderEntity->getId());
                $this->_conn->commit();
            } catch (\Exception $e) {
                $this->_conn->rollBack();
                throw new CouldNotDeleteException(__(
                    'Could not delete the favorite order',
                    $e->getMessage()
                ));
            }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function getFavoriteOrder($id)
    { 
        $favoriteOrder = $this->productFavoriteFactory->create();
        $this->resource->load($favoriteOrder, $id);

        $favotiteOrderItem=$this->productFavoriteItemRepositoryInterface->getFavoriteOrderItems($id);
        $totalCost=0;
        foreach($favotiteOrderItem as $favItem){
            $product=$this->productRepository->getById($favItem->getProductId());
            $price=$product->getPrice();
            $qty=$favItem->getQty();
            $cost=$price*$qty;
            $totalCost += $cost;
        }
        $favoriteOrder->setFavoriteItems($favotiteOrderItem);
        $favoriteOrder->setTotalCost($totalCost);

        if (!$favoriteOrder->getId()) {
            throw new NoSuchEntityException(__('order with id "%1" does not exist.', $id));
        }
        return $favoriteOrder;
     
    }

    /**
     * {@inheritdoc}
     */
    public function setFavoriteName($id,$favoriteName) {

        $favoriteOrder = $this->productFavoriteFactory->create();
        $favoriteOrder->setData('favorite_name', $favoriteName);
        $favoriteOrder->setData('id',$id);      
        $this->resource->save($favoriteOrder);
  
        return true;
       
    }

     /**
     * {@inheritdoc}
     */
    public function getFavoriteList($productId,$venueUserId)
    { 
        
        $favItems = $this->productFavoriteItemCollectionFactory->create();
        $fav=$this->productFavoriteCollectionFactory->create();
        
        $fav->addFieldToFilter('venue_user_id',$venueUserId);
        $fav->getSelect()->joinLeft(['favorite_item'=>'aria_product_favorite_item'], 
                                      'main_table.id= favorite_item.favorite_id' ,
                                       ['*'
                                       ]);
        $fav->addFieldToFilter('product_id',$productId);

        $items = [];
            foreach ($fav as $model) {
            $items[] = $model->getData();
            }
            
        return $items;
    }

    /**
     * Check whether the product is on favorite
     *
     * @param int $customerId
     * @param int $venueId
     * @param int $venueUserId
     * @param int $productId
     * @return bool
     */
    public function checkProductIsOnFavourite($customerId,$venueId,$venueUserId,$productId)
    {
        $venueUserDetails = $this->venueUserRepositoryInterface->get($venueUserId);
        $entityId=$venueUserDetails->getMagentoUserId();
        if($customerId!=$entityId)
        {
            throw new AuthorizationException(
                __("Access Denied.The consumer isn't authorized")
            );
        }

        $favouriteCollection=$this->productFavoriteCollectionFactory->create();
        $favouriteCollection->addFieldToFilter('venue_user_id',$venueUserId);
        $favouriteCollection->addFieldToFilter('venue_id',$venueId);

        $favouriteCollection->getSelect()->joinLeft(['favorite_item'=>'aria_product_favorite_item'], 
                                      'main_table.id= favorite_item.favorite_id' ,
                                       ['*'
                                       ]);
        $favouriteCollection->addFieldToFilter('product_id',$productId);

        if(count($favouriteCollection) >= 1)
        {
            return true;
        }

        return false;
    }

}