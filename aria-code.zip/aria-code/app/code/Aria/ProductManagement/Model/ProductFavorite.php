<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductManagement\Model;

use Aria\ProductManagement\Api\Data\ProductFavoriteInterface;
use Aria\ProductManagement\Api\Data\ProductFavoriteInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class ProductFavorite extends \Magento\Framework\Model\AbstractModel
{

    protected $productFavoriteDataFactory;

    protected $_eventPrefix = 'aria_product_favorite';
    protected $dataObjectHelper;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param ProductFavoriteInterfaceFactory $productFavoriteDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\ProductManagement\Model\ResourceModel\ProductFavorite $resource
     * @param \Aria\ProductManagement\Model\ResourceModel\ProductFavorite\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        ProductFavoriteInterfaceFactory $productFavoriteDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\ProductManagement\Model\ResourceModel\ProductFavorite $resource,
        \Aria\ProductManagement\Model\ResourceModel\ProductFavorite\Collection $resourceCollection,
        array $data = []
    ) {
        $this->productFavoriteDataFactory = $productFavoriteDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve product favorite  model with user role data
     * @return ProductFavoriteInterface
     */
    public function getDataModel()
    {
        $productFavoriteData = $this->getData();
        
        $productFavoriteDataObject = $this->productFavoriteDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $productFavoriteDataObject,
            $productFavoriteData,
            ProductFavoriteInterface::class
        );
        
        return $productFavoriteDataObject;
    }


}
