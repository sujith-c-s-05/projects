<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Model;

use Aria\ProductManagement\Api\Data\MultiSellerProductInterface;
use Aria\ProductManagement\Model\ResourceModel\MultiSellerProducts as ResourceModel;
use Magento\Framework\DataObject\IdentityInterface;
use Magento\Framework\Model\AbstractModel;

/**
 * Class MultiSellerProduct
 */
class MultiSellerProducts extends AbstractModel implements MultiSellerProductInterface, IdentityInterface
{
    const CACHE_TAG = 'aria_multi_seller_product';

    /**
     * Init
     */
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }

    /**
     * @inheritDoc
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    /**
     * @return array|mixed|null
     */
    public function getId()
    {
        return $this->getData('id');
    }

    /**
     * @param mixed $car_id
     * @return MultiSellerProducts|mixed
     */
    public function setId($car_id)
    {
        return $this->setData('id', $car_id);
    }

    /**
     * @return array|mixed|null
     */
    public function getProductId()
    {
        return $this->getData('product_id');
    }

    /**
     * @param $productId
     * @return MultiSellerProducts|mixed
     */
    public function setProductId($productId)
    {
        return $this->setData('product_id', $productId);
    }

    /**
     * @return array|mixed|null
     */
    public function getSellerId()
    {
        return $this->getData('seller_id');
    }

    /**
     * @param $sellerId
     * @return MultiSellerProducts|mixed
     */
    public function setSellerId($sellerId)
    {
        return $this->setData('seller_id', $sellerId);
    }

    /**
     * @return array|mixed|null
     */
    public function getWebsiteId()
    {
        return $this->getData('website_id');
    }

    /**
     * @param $websiteId
     * @return MultiSellerProducts|mixed
     */
    public function setWebsiteId($websiteId)
    {
        return $this->setData('website_id', $websiteId);
    }

    /**
     * @return array|mixed|null
     */
    public function getPrice()
    {
        return $this->getData('price');
    }

    /**
     * @param $price
     * @return MultiSellerProducts|mixed
     */
    public function setPrice($price)
    {
        return $this->setData('price', $price);
    }

    /**
     * @return array|mixed|null
     */
    public function getQty()
    {
        return $this->getData('qty');
    }

    /**
     * @param $qty
     * @return MultiSellerProducts|mixed
     */
    public function setQty($qty)
    {
        return $this->setData('qty', $qty);
    }

    /**
     * @return array|mixed|null
     */
    public function getStatus()
    {
        return $this->getData('status');
    }

    /**
     * @param $status
     * @return MultiSellerProducts|mixed
     */
    public function setStatus($status)
    {
        return $this->setData('status', $status);
    }

    /**
     * @return array|mixed|null
     */
    public function getIsOwner()
    {
        return $this->getData('is_owner');
    }

    /**
     * @param $isOwner
     * @return MultiSellerProducts|mixed
     */
    public function setIsOwner($isOwner)
    {
        return $this->setData('is_owner', $isOwner);
    }

    /**
     * @return array|mixed|null
     */
    public function getCreatedAt()
    {
        return $this->getData('created_at');
    }

    /**
     * @param $createdAt
     * @return MultiSellerProducts|mixed
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData('created_at', $createdAt);
    }

    /**
     * @return array|mixed|null
     */
    public function getUpdatedAt()
    {
        return $this->getData('updated_at');
    }

    /**
     * @param $updatedAt
     * @return MultiSellerProducts|mixed
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData('updated_at', $updatedAt);
    }

    /**
     * @return array|mixed|null
     */
    public function getCreatedBy()
    {
        return $this->getData('created_by');
    }

    /**
     * @param $createdBy
     * @return MultiSellerProducts|mixed
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData('created_by', $createdBy);
    }

    /**
     * @return array|mixed|null
     */
    public function getUpdatedBy()
    {
        return $this->getData('updated_by');
    }

    /**
     * @param $updatedBy
     * @return MultiSellerProducts|mixed
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData('updated_by', $updatedBy);
    }

    /**
     * @return array|mixed|null
     */
    public function getIsActive()
    {
        return $this->getData('is_active');
    }

    /**
     * @param $isActive
     * @return MultiSellerProducts|mixed
     */
    public function setIsActive($isActive)
    {
        return $this->setData('is_active', $isActive);
    }
    /**
     * @return array|mixed|null
     */
    public function getIsDelete()
    {
        return $this->getData('is_delete');
    }

    /**
     * @param $isDelete
     * @return MultiSellerProducts|mixed
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData('is_delete', $isDelete);
    }
    /**
     * @return array|mixed|null
     */
    public function getSpecialPrice()
    {
        return $this->getData('special_price');
    }

    /**
     * @param $specialPrice
     * @return MultiSellerProducts|mixed
     */
    public function setSpecialPrice($specialPrice)
    {
        return $this->setData('special_price', $specialPrice);
    }

    /**
     * @return array|mixed|null
     */
    public function getSpecialFromDate()
    {
        return $this->getData('special_from_date');
    }

    /**
     * @param $specialFromDate
     * @return MultiSellerProducts|mixed
     */
    public function setSpecialFromDate($specialFromDate)
    {
        return $this->setData('special_from_date', $specialFromDate);
    }

    /**
     * @return array|mixed|null
     */
    public function getSpecialToDate()
    {
        return $this->getData('special_to_date');
    }

    /**
     * @param $specialToDate
     * @return MultiSellerProducts|mixed
     */
    public function setSpecialToDate($specialToDate)
    {
        return $this->setData('special_to_date', $specialToDate);
    }

    /**
     * @return array|mixed|null
     */
    public function getSku()
    {
        return $this->getData('sku');
    }

    /**
     * @param $sku
     * @return MultiSellerProducts|mixed
     */
    public function setSku($sku)
    {
        return $this->setData('sku', $sku);
    }

    /**
     * @return array|mixed|null
     */
    public function getProductName()
    {
        return $this->getData('product_name');
    }

    /**
     * @param $productName
     * @return MultiSellerProducts|mixed
     */
    public function setProductName($productName)
    {
        return $this->setData('product_name', $productName);
    }

    /**
     * @return array|mixed|null
     */
    public function getMinSaleQty()
    {
        return $this->getData('min_sale_qty');
    }

    /**
     * @param $minSaleQty
     * @return MultiSellerProducts|mixed
     */
    public function setMinSaleQty($minSaleQty)
    {
        return $this->setData('min_sale_qty', $minSaleQty);
    }

    /**
     * @return array|mixed|null
     */
    public function getMaxSaleQty()
    {
        return $this->getData('max_sale_qty');
    }

    /**
     * @param $maxSaleQty
     * @return MultiSellerProducts|mixed
     */
    public function setMaxSaleQty($maxSaleQty)
    {
        return $this->setData('max_sale_qty', $maxSaleQty);
    }
}
