<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Model\ResourceModel;

/**
 * Class MultiSellerProducts
 */
class MultiSellerProducts extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Init
     */
    protected function _construct()
    {
        $this->_init('aria_multi_seller_product', 'id');
    }
}
