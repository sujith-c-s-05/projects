<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Model\ResourceModel\MultiSellerProducts;

use Aria\ProductManagement\Model\MultiSellerProducts as Model;
use Aria\ProductManagement\Model\ResourceModel\MultiSellerProducts as ResourceModel;

/**
 * Class Collection
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Init
     */
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}
