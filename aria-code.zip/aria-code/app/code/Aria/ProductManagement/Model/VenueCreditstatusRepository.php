<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Model;

use Aria\ProductManagement\Api\Data\VenueCreditstatusInterface;
use Aria\ProductManagement\Api\VenueCreditstatusRepositoryInterface;
use Aria\ProductManagement\Model\ResourceModel\VenueCreditstatus as ObjectResourceModel;
use Aria\ProductManagement\Model\ResourceModel\VenueCreditstatus\CollectionFactory;
use Magento\Framework\Api\SearchResultsInterfaceFactory;
use Magento\Framework\Exception\CouldNotSaveException;
use Aria\Venue\Api\VenueRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\DCRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Reflection\DataObjectProcessor;
use Aria\SupplyCompanyAccount\Model\DCUserFactory as DCUserFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUserroleMapping\CollectionFactory as DCUserroleMappingCollectionFactory;
use Aria\SupplierWatch\Model\ResourceModel\SupplierWatch\CollectionFactory as SupplierWatchCollectionFactory;
use Aria\Venue\Model\ResourceModel\VenueUser\CollectionFactory as venueUserCollectionFactory;

/**
 * Class Venue Credit status Repository
 */
class VenueCreditstatusRepository implements VenueCreditstatusRepositoryInterface
{
    protected $objectResourceModel;
    protected $collectionFactory;
    protected $searchResultsFactory;
    protected $venueCreditstatusFactory;
    protected $dCUserRepository;
    protected $_orderCollectionFactory;
    protected $venueRepositoryInterface;
    protected $dcRepositoryInterface;
    protected $supplyCompanyRepositoryInterface;
    protected $extensibleDataObjectConverter;
    protected $dataObjectHelper;
    protected $dataObjectProcessor;
    protected $dcUserFactory;
    protected $dcUserroleMappingCollectionFactory;
    protected $venueUserCollectionFactory;

    /**
     * Undocumented function
     *
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param ObjectResourceModel $objectResourceModel
     * @param CollectionFactory $collectionFactory
     * @param SearchResultsInterfaceFactory $searchResultsFactory
     * @param VenueCreditstatusFactory $venueCreditstatusFactory
     * @param \Aria\SupplyCompanyAccount\Api\DCUserRepositoryInterface $dCUserRepository
     * @param \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
     * @param VenueRepositoryInterface $venueRepositoryInterface
     * @param DCRepositoryInterface $dCRepositoryInterface
     * @param SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param DCUserFactory $dcUserFactory
     * @param DCUserroleMappingCollectionFactory $dcUserroleMappingCollectionFactory
     * @param VenueUserCollectionFactory $venueUserCollectionFactory
     */
    public function __construct(
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        ObjectResourceModel $objectResourceModel,
        CollectionFactory $collectionFactory,
        SearchResultsInterfaceFactory $searchResultsFactory,
        VenueCreditstatusFactory $venueCreditstatusFactory,
        \Aria\SupplyCompanyAccount\Api\DCUserRepositoryInterface $dCUserRepository,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory  $orderCollectionFactory,
        VenueRepositoryInterface $venueRepositoryInterface,
        DCRepositoryInterface $dCRepositoryInterface,
        SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface,
        \Aria\Notifications\Api\NotificationsRepositoryInterface $notificationsInterface,
        DCUserFactory $dcUserFactory,
        DCUserroleMappingCollectionFactory $dcUserroleMappingCollectionFactory,
        \Aria\Venue\Api\VenueUserRoleMappingRepositoryInterface $venueuserrole,
        SupplierWatchCollectionFactory $supplierWatchCollectionFactory,
        \Aria\Venue\Api\VenueRepositoryInterface $VenueRepositoryInterface,
        VenueUserCollectionFactory $venueUserCollectionFactory
    ) {
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->objectResourceModel  = $objectResourceModel;
        $this->collectionFactory    = $collectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->venueCreditstatusFactory = $venueCreditstatusFactory;
        $this->dCUserRepository=$dCUserRepository;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->venueRepositoryInterface=$venueRepositoryInterface;
        $this->dCRepositoryInterface = $dCRepositoryInterface;
        $this->supplyCompanyRepositoryInterface=$supplyCompanyRepositoryInterface;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->participantsRepositoryInterface=$participantsRepositoryInterface;
        $this->notificationsRepositoryInterface=$notificationsInterface;
        $this->dcUserFactory = $dcUserFactory;
        $this->dcUserroleMappingCollectionFactory = $dcUserroleMappingCollectionFactory;
        $this->venueuserrole = $venueuserrole;
        $this->supplierWatchCollectionFactory=$supplierWatchCollectionFactory;
        $this->venueInterface = $VenueRepositoryInterface;
        $this->venueUserCollectionFactory = $venueUserCollectionFactory;

    }
    
     /**
     *Get details from Venue Credit status  Table.
     * @param $sellerId
     * @return \Magento\Framework\DataObject
     */
    public function getVenueCreditstatusbySellerId($sellerId)
    {
        $creditStatusCollection = $this->collectionFactory->create();
        $creditStatus = $creditStatusCollection ->addFieldToFilter('seller_Id', ['eq' => $sellerId])
                        ->addFieldToFilter('status', 0);
        $venueIds=$creditStatus->addFieldToSelect('venue_id');
        $stopedVenueList=$venueIds->getData();
        $ids = array_column($stopedVenueList, 'venue_id');
        return $ids;
    }
    
    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface $venueCreditStatus
    ) {
        try {
           
            $venueCreditStatusData = $this->extensibleDataObjectConverter->toNestedArray(
                $venueCreditStatus,
                [],
                \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface::class
            );  
            
            $venueCreditStatusModel = $this->venueCreditstatusFactory->create()->setData($venueCreditStatusData);
            $dcUserId=$venueCreditStatusModel->getDcUserId();
            $credt_stats = $venueCreditStatusModel->getStatus();
            $dCUser = $this->dcUserFactory->create();
            $dCUserDetails = $dCUser->load($dcUserId,'id');
            $supplyCompanyId=$dCUserDetails->getScId();
            $supplyCompanyDetails=$this->supplyCompanyRepositoryInterface-> get($supplyCompanyId); 
            $sellerId=$supplyCompanyDetails->getCompanyAdmin();

            $venueCreditStatusModel->setSellerId($sellerId);
            $venueId=$venueCreditStatusModel->getVenueId();
            //Check whether the credict status already existing.Then set the id for updation.
            $creditStatus=$this->getCreditStatus($sellerId, $venueId);
            $id=$creditStatus->getId();
            $venueCreditStatusModel->setId($id);
            
            $this->objectResourceModel->save($venueCreditStatusModel);

            //Save notification to participants table.
            $supplierWatchCollection = $this->supplierWatchCollectionFactory->create();
            $venueDetails=$this->venueRepositoryInterface->get($venueId);
            $hospId=$venueDetails->getHospId();
            $venueUserDetails = $this->venueUserCollectionFactory->create();
            $venueUserDetails->addFieldToFilter('hg_id',$hospId);

           // $venueUsers = $this->venueuserrole->getVenueUsers($venueId);
            foreach($venueUserDetails as $venueUser){

                $supplierWatchCollection->addFieldToFilter('supplier_id', $supplyCompanyId)->addFieldToFilter('venue_user_id', $venueUser->getId())->addFieldToFilter('status', 1);
                if(count($supplierWatchCollection) == 0){
                    if($credt_stats == 0){
                        $desc = "Credit status of venue changed to Stop";
                    }
                    else{
                        $desc = "Credit status of venue changed to Go";
                    }
                    $this->participantsRepositoryInterface->saveParticipantNotification(2,$venueId,$venueUser->getId(),$desc,'venue_user','Credit status changed');
                }
                else{
                    if($credt_stats == 0){
                        $venue = $this->venueInterface->get($venueId);
                        $venueName = $venue->getName();
                        $desc = $venueName." is Inactive";
                        $this->participantsRepositoryInterface->saveParticipantNotification(5,$venueId,$venueUser->getId(),$desc,'venue_user','Venue is inactive');
                    }
                }    
            }     
            
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the venue credict status: %1',
                $exception->getMessage()
            ));
        }
        return $venueCreditStatusModel->getDataModel();
    }

    /**
     * get credit status against venue id and seller id
     *
     * @param int $sellerId
     * @param int $venueId
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function getCreditStatus($sellerId, $venueId)
    {
        $creditStatusCollection = $this->collectionFactory->create();
        $creditStatus = $creditStatusCollection ->addFieldToFilter('seller_Id',$sellerId)
                                                ->addFieldToFilter('venue_id',$venueId)
                                                ->getFirstItem();
        return $creditStatus;
    }

    /**
     * @inheritDoc
     *
     */
    public function getCreditStatusList($dcId)
    {
        $salesOrderDetails = $this->_orderCollectionFactory->create();
        $orderDetails=$salesOrderDetails->addFieldToFilter('dcid',$dcId);
        
        $venueIds=$orderDetails->addFieldToSelect('Venueid');
        $venueIdCollection=$venueIds->getData();
        $ids=array_column($venueIdCollection, 'Venueid');
        $venueIdList=array_unique($ids);
        if (count($venueIdList) >=1) {
            $venueDetails=[];
            foreach($venueIdList as $venueId){
                if(is_numeric($venueId)&&$venueId!=0){

                    $venue=$this->venueRepositoryInterface->get($venueId);
                    $dcDetails=$this->dCRepositoryInterface->get($dcId);
                    $supplyCompanyId=$dcDetails->getSupplyId();
                    $supplyCompanyDetails=$this->supplyCompanyRepositoryInterface-> get($supplyCompanyId); 
                    $sellerId=$supplyCompanyDetails->getCompanyAdmin();
                    $creditStatus=$this->getCreditStatus($sellerId, $venueId);
                    $status=$creditStatus->getStatus();  
                    
                    $creditStatusDetail['venue_id'] = $venue->getId();
                    $creditStatusDetail['venue_name'] = $venue->getName();
                    $creditStatusDetail['venue_description'] = $venue->getDescription();
                    $creditStatusDetail['email'] = $venue->getVenueEmail();
                    $creditStatusDetail['phone'] = $venue->getPhone();
                    $creditStatusDetail['contact_name'] = $venue->getContactName();
                    $creditStatusDetail['contact_person_phone'] = $venue->getContactPersonPhone();
                    $creditStatusDetail['status'] = $status??1;
                    $venueDetails[] = $creditStatusDetail;
                }
            }
            $venueList  = array_column($venueDetails, 'venue_name');
            array_multisort($venueList, SORT_ASC, $venueDetails);
            return $venueDetails;
        }

    }
}
