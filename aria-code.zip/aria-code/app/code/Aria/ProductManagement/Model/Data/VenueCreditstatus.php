<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductManagement\Model\Data;

use Aria\ProductManagement\Api\Data\VenueCreditstatusInterface;

class VenueCreditstatus extends \Magento\Framework\Api\AbstractExtensibleObject implements VenueCreditstatusInterface
{

    /**
     * Get id
     * @return int|null
     */
    public function getId()
    {
        return $this->_get('id');
    }

    /**
     * Set Id
     * @param int id
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setId($id)
    {
        return $this->setData('id', $id);
    }

    /**
     * Get Seller Id
     * @return int|null
     */
    public function getSellerId()
    {
        return $this->_get('seller_id');
    }

    /**
     * Set seller id
     * @param int $sellerId
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setSellerId($sellerId)
    {
        return $this->setData('seller_id', $sellerId);
    }
/**
     * Get dc user Id
     * @return int|null
     */
    public function getDcUserId()
    {
        return $this->_get('dc_user_id');
    }

    /**
     * Set dc user id
     * @param int $dcUserId
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setDcUserId($dcUserId)
    {
        return $this->setData('dc_user_id', $dcUserId);
    }
    /**
     * Get venue id
     * @return int|null
     */
    public function getVenueId()
    {
        return $this->_get('venue_id');
    }

    /**
     * Set venue id
     * @param int $venueId
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setVenueId($venueId)
    {
        return $this->setData('venue_id',$venueId);
    }

    /**
     * Get status 
     * @return int|null
     */
    public function getStatus()
    {
        return $this->_get('status');
    }

    /**
     * Set status
     * @param int $status
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setStatus($status)
    {
        return $this->setData('status', $status);
    }

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get('created_by');
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData('created_by', $createdBy);
    }

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get('updated_by');
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData('updated_by', $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get('created_at');
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData('created_at', $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get('updated_at');
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData('updated_at', $updatedAt);
    }

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive()
    {
        return $this->_get('is_active');
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\ProductManagement\Api\Data\VenueCreditstatusInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData('is_active', $isActive);
    }
}