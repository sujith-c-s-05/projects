<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductManagement\Model\Data;

use Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface;

class ProductFavoriteItem extends \Magento\Framework\Api\AbstractExtensibleObject implements ProductFavoriteItemInterface
{

    /**
     * Get id
     * @return int|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param int Id
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setId($Id)
    {
        return $this->setData(self::ID, $Id);
    }

    /**
     * Get venue_user_id
     * @return int|null
     */
    public function getFavoriteId()
    {
        return $this->_get(self::FAVORITE_ID);
    }

    /**
     * Set favorite item id
     * @param int $favoriteId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setFavoriteId($favoriteId)
    {
        return $this->setData(self::FAVORITE_ID, $favoriteId);
    }

    /**
     * Get Product id
     * @return int|null
     */
    public function getProductId()
    {
        return $this->_get(self::PRODUCT_ID);
    }

    /**
     * Set product id
     * @param string $productId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setProductId($productId)
    {
        return $this->setData(self::PRODUCT_ID, $productId);
    }

    /**
     * Get store id
     * @return int|null
     */
    public function getStoreId()
    {
        return $this->_get('store_id');
    }

    /**
     * Set store id
     * @param int $storeId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setStoreId($storeId)
    {
        return $this->setData('store_id', $storeId);
    }

    /**
     * Get qty
     * @return int|null
     */
    public function getQty()
    {
        return $this->_get('qty');
    }

    /**
     * Set store id
     * @param int $storeId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setQty($qty)
    {
        return $this->setData('qty', $qty);
    }

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_active
     * @return bool
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }
    
    /**
     * Get is_delete
     * @return bool
     */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }

   /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }

     /**
     * Get product_name
     * @return string
     */
    public function getProductName()
    {
        return $this->_get('product_name');
    }

   /**
     * Set product_name
     * @param string $productName
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setProductName($productName)
    {
        return $this->setData('product_name', $productName);
    }

     /**
     * Get product_catagory
     * @return string
     */
    public function getProductCatagory()
    {
        return $this->_get('product_catagory');
    }

   /**
     * Set product_catagory
     * @param string $productCatagory
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setProductCatagory($productCatagory)
    {
        return $this->setData('product_catagory', $productCatagory);
    }

     /**
     * Get unit_cost
     * @return float
     */
    public function getUnitCost()
    {
        return $this->_get('unit_cost');
    }

   /**
     * Set unit_cost
     * @param float $unitCost
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setUnitCost($unitCost)
    {
        return $this->setData('unit_cost', $unitCost);
    }

     /**
     * Get total_cost
     * @return float
     */
    public function getTotalCost()
    {
        return $this->_get('total_cost');
    }

   /**
     * Set total_cost
     * @param float $totalCost
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setTotalCost($totalCost)
    {
        return $this->setData('total_cost', $totalCost);
    }

     /**
     * Get supplier_name
     * @return string
     */
    public function getSupplierName()
    {
        return $this->_get('supplier_name');
    }

    /**
     * Set supplier_name
     * @param string $supplierName
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setSupplierName($supplierName)
    {
        return $this->setData('supplier_name', $supplierName);
    }

     /**
     * Get uom_name
     * @return string
     */
    public function getUomName()
    {
        return $this->_get('uom_name');
    }

    /**
     * Set uom_name
     * @param string $uomName
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setUomName($uomName)
    {
        return $this->setData('uom_name', $uomName);
    }

    /**
     * Get image
     * @return string
     */
    public function getImage()
    {
        return $this->_get('image');
    }

    /**
     * Set image
     * @param string $image
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function setImage($image)
    {
        return $this->setData('image', $image);
    }
    
}