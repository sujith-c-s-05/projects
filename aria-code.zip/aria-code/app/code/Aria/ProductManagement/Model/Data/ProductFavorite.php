<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductManagement\Model\Data;

use Aria\ProductManagement\Api\Data\ProductFavoriteInterface;

class ProductFavorite extends \Magento\Framework\Api\AbstractExtensibleObject implements ProductFavoriteInterface
{

    /**
     * Get id
     * @return int|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param int Id
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setId($Id)
    {
        return $this->setData(self::ID, $Id);
    }

    /**
     * Get venue_user_id
     * @return int|null
     */
    public function getVenueUserId()
    {
        return $this->_get(self::VENUE_USER_ID);
    }

    /**
     * Set venue user id
     * @param int $venueUserId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setVenueUserId($venueUserId)
    {
        return $this->setData(self::VENUE_USER_ID, $venueUserId);
    }

    /**
     * Get favorite name
     * @return string|null
     */
    public function getFavoriteName()
    {
        return $this->_get(self::FAVORITE_NAME);
    }

    /**
     * Set favorite name
     * @param string $favoriteName
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setFavoriteName($favoriteName)
    {
        return $this->setData(self::FAVORITE_NAME, $favoriteName);
    }

    /**
     * Get product id
     * @return int|null
     */
    public function getProductId()
    {
        return $this->_get('product_id');
    }

    /**
     * Set product id
     * @param int $productId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setProductId($productId)
    {
        return $this->setData('product_id', $productId);
    }

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }

    /**
     * Get venue id
     * @return int|null
     */
    public function getVenueId()
    {
        return $this->_get(self::VENUE_ID);
    }

    /**
     * Set venue id
     * @param int $venueId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setVenueId($venueId)
    {
        return $this->setData(self::VENUE_ID, $venueId);
    }
    
    /**
     * Get is_delete
     * @return bool|false
     */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }

   /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }
    /**
    * Get venue user role info
    * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface[]
    */
    public function getFavoriteItems()
    {
        return $this->_get('favorite_items');
    }

    /**
    * Set venue user role info
    * @param \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface[] $favoriteItems
    * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface[]
    */
    public function setFavoriteItems(array $favoriteItems = null)
    {   
        return $this->setData('favorite_items',$favoriteItems );  
    }

   /**
     * Product total cost
     *
     * @return float|null
     */
    public function getTotalCost()
    {
        return $this->_get('total_cost');
    }

    /**
     * Set product total cost
     *
     * @param float $totalCost
     * @return $this
     */
    public function setTotalCost($totalCost)
    {
        return $this->setData('total_cost', $totalCost);
    }
    /**
     * Get is_schedule
     * @return bool|false
     */
    public function getIsSchedule()
    {
        return $this->_get(self::IS_SCHEDULE);
    }

   /**
     * Set is_schedule
     * @param bool $isSchedule
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteInterface
     */
    public function setIsSchedule($isSchedule)
    {
        return $this->setData(self::IS_SCHEDULE, $isSchedule);
    }
}