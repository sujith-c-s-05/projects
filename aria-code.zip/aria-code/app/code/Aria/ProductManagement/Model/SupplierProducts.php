<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Model;

use Aria\ProductManagement\Model\ResourceModel\MultiSellerProducts\CollectionFactory;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DC\CollectionFactory as DCCollectionFactory;

class SupplierProducts extends \Magento\Framework\Model\AbstractModel
{

    protected $_supplyCompanyCollectionFactory;
    protected $dCCollectionFactory;
    
    /**
     * Undocumented function
     *
     * @param \Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany\CollectionFactory $supplyCompanyCollectionFactory
     * @param DCCollectionFactory $dCCollectionFactory
     */
    public function __construct(
        \Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany\CollectionFactory $supplyCompanyCollectionFactory,
        DCCollectionFactory $dCCollectionFactory
    ) {
        
        $this->_supplyCompanyCollectionFactory = $supplyCompanyCollectionFactory;
        $this->dCCollectionFactory = $dCCollectionFactory;
    }

    /**
     * Get active supplier based on company admin
     *
     * @return \Aria\SupplyCompanyAccount\Model\Data\SupplyCompany
     */
    public function getSupplyCompanyByCompanyAdmin($companyAdmin)
    {    
        $supplyCompany = $this->_supplyCompanyCollectionFactory->create();
        $supplyCompany->addFieldToFilter('company_admin', $companyAdmin);
        $supplyCompany->addFieldToFilter('is_delete', 0);
        return $supplyCompany->getFirstItem();
    }
    
    /**
     * Get list of active DC's
     *
     * @return \Aria\SupplyCompanyAccount\Model\ResourceModel\DC\Collection
     */
    public function getActiveDCs($zipCode)
    {    
        $dcCollection = $this->dCCollectionFactory->create();
        $dcCollection->addFieldToFilter('is_delete', 0);

        $items = [];
        foreach ($dcCollection as $model) {
            $zipCodes=$model->getDeliveryLocation();
            $zipCodeList=explode (",", $zipCodes);
            if (in_array($zipCode, $zipCodeList, TRUE)){
                $items[] = $model->getData();

            }
            
        }

        return $items;
    }

    /**
     * Get list supplier dcs
     *
     * @return \Aria\SupplyCompanyAccount\Model\ResourceModel\DC\Collection
     */
    public function getSupplierDCs($supplierId)
    {    
        $dcCollection = $this->dCCollectionFactory->create();
        $dcCollection->addFieldToFilter('is_delete', 0);
        $dcCollection->addFieldToFilter('supply_id', $supplierId);
        $items = [];
        foreach ($dcCollection as $model) {
                $items[] = $model->getDataModel();
        }

        return $items;
    }

    /**
     * Get nearest dc against supplier
     *
     * @return \Aria\SupplyCompanyAccount\Model\ResourceModel\DC\Collection
     */
    public function getSupplierDCByVenueId($supplierId,$venueZipCode)
    {    
        $dcCollection = $this->dCCollectionFactory->create();
        $dcCollection->addFieldToFilter('is_delete', 0);
        $dcCollection->addFieldToFilter('supply_id', $supplierId);
        $items = [];
        foreach ($dcCollection as $model) {
            $zipCodes=$model->getDeliveryLocation();
            $zipCodeList=explode (",", $zipCodes);
            if (in_array($venueZipCode, $zipCodeList, TRUE)){
                $items[] = $model->getDataModel();
            }
        }
        return $items;
    }
}

