<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductManagement\Model;

use Aria\ProductManagement\Api\Data\VenueCreditstatusInterface;
use Aria\ProductManagement\Api\Data\VenueCreditstatusInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class VenueCreditstatus extends \Magento\Framework\Model\AbstractModel
{

    protected $venueCreditstatusDataFactory;

    protected $_eventPrefix = 'aria_venue_credit_status';
    protected $dataObjectHelper;


    /**
     * constructor function
     *
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param VenueCreditstatusInterfaceFactory $venueCreditstatusDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\ProductManagement\Model\ResourceModel\VenueCreditstatus $resource
     * @param \Aria\ProductManagement\Model\ResourceModel\VenueCreditstatus\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        VenueCreditstatusInterfaceFactory $venueCreditstatusDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\ProductManagement\Model\ResourceModel\VenueCreditstatus $resource,
        \Aria\ProductManagement\Model\ResourceModel\VenueCreditstatus\Collection $resourceCollection,
        array $data = []
    ) {
        $this->venueCreditstatusDataFactory = $venueCreditstatusDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve venue credit status model
     * @return VenueCreditstatusInterface
     */
    public function getDataModel()
    {
        $venueCreditstatusData = $this->getData();
        
        $venueCreditstatusDataObject = $this->venueCreditstatusDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $venueCreditstatusDataObject,
            $venueCreditstatusData,
            VenueCreditstatusInterface::class
        );
        
        return $venueCreditstatusDataObject;
    }


}
