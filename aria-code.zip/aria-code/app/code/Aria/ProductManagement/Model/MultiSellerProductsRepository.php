<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Model;

use Aria\ProductManagement\Api\Data\MultiSellerProductInterface;
use Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface;
use Aria\ProductManagement\Model\ResourceModel\MultiSellerProducts as ObjectResourceModel;
use Aria\ProductManagement\Model\ResourceModel\MultiSellerProducts\CollectionFactory;
use Magento\Catalog\Model\ProductRepository as productRepository;
use Magento\Framework\Api\SearchResultsInterfaceFactory;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Sales\Model\ResourceModel\Order\Item\CollectionFactory as OrderItemCollectionFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany\CollectionFactory as SupplyCompanyCollectionFactory;


/**
 * Class Multi seller product Repository
 */
class MultiSellerProductsRepository implements MultiSellerProductRepositoryInterface
{
    protected $objectFactory;
    protected $objectResourceModel;
    protected $collectionFactory;
    protected $searchResultsFactory;
    protected $productRepository;
    protected $orderItemCollectionFactory;
    protected $supplyCompanyCollectionFactory;

    /**
     * @var \Aria\SupplyCompanyAccount\Api\DCRepositoryInterface
     */
    protected $dCRepository;

    /**
     * @var \Aria\Venue\Api\VenueRepositoryInterface
     */
    protected $venueRepository;

    /**
     * @var \Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface
     */
    protected $supplyCompanyRepository;

    /**
     * @var \Aria\ProductManagement\Model\SupplierProducts
     */
    protected $supplierProduct;
    /** @var  \Magento\Framework\DB\Adapter\AdapterInterface */
    protected $_conn;

    /** @var \Magento\Framework\App\ResourceConnection */
    protected $_resourceConnection;

    protected $_productCollectionFactory;


    /**
     * Multi seller product Repository constructor.
     * @param MultiSellerProductsFactory $objectFactory
     * @param ObjectResourceModel $objectResourceModel
     * @param CollectionFactory $collectionFactory
     * @param SearchResultsInterfaceFactory $searchResultsFactory
     * @param productRepository $productRepository
     * @param OrderItemCollectionFactory $orderItemCollectionFactory
     * @param \Aria\SupplyCompanyAccount\Api\DCRepositoryInterface $dCRepository
     * @param \Aria\Venue\Api\VenueRepositoryInterface $venueRepository
     * @param \Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface $supplyCompanyRepository
     * @param \Aria\ProductManagement\Model\SupplierProducts $supplierProduct
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param SupplyCompanyCollectionFactory $supplyCompanyCollectionFactory
     */
    public function __construct(
        MultiSellerProductsFactory $objectFactory,
        ObjectResourceModel $objectResourceModel,
        CollectionFactory $collectionFactory,
        SearchResultsInterfaceFactory $searchResultsFactory,
        productRepository $productRepository,
        OrderItemCollectionFactory $orderItemCollectionFactory,
        \Aria\SupplyCompanyAccount\Api\DCRepositoryInterface $dCRepository,
        \Aria\Venue\Api\VenueRepositoryInterface $venueRepository,
        \Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface $supplyCompanyRepository,
        \Aria\ProductManagement\Model\SupplierProducts $supplierProduct,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        ScopeConfigInterface $scopeConfig,
        \Magento\Eav\Model\Config $eavConfig,
        SupplyCompanyCollectionFactory $supplyCompanyCollectionFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
    ) {
        $this->objectFactory        = $objectFactory;
        $this->objectResourceModel  = $objectResourceModel;
        $this->collectionFactory    = $collectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->productRepository    = $productRepository;
        $this->orderItemCollectionFactory = $orderItemCollectionFactory;
        $this->dCRepository    = $dCRepository;
        $this->venueRepository    = $venueRepository;
        $this->supplyCompanyRepository    = $supplyCompanyRepository;
        $this->supplierProduct = $supplierProduct;
        $this->scopeConfig = $scopeConfig;
        $this->_resourceConnection = $resourceConnection;
        $this->_conn = $resourceConnection->getConnection();
        $this->eavConfig = $eavConfig;
        $this->supplyCompanyCollectionFactory = $supplyCompanyCollectionFactory;
        $this->_productCollectionFactory = $productCollectionFactory;   

    }

    /**
     * Save and update Multi seller product table.
     * @inheritDoc
     *
     * @throws CouldNotSaveException
     */
    public function save(MultiSellerProductInterface $object)
    {
        try {
            //Check whether the multi seller product already exist in the table
            $existingMultiSellerProduct = $this->getMultiSellerProductByProductIdAndSellerId(
                $object->getProductId(),
                $object->getSellerId()
            );
            $multiSellerProductId=$existingMultiSellerProduct->getId();
            $object->setId($multiSellerProductId);
            $this->objectResourceModel->save($object);
        } catch (\Exception $e) {
            throw new CouldNotSaveException(__($e->getMessage()));
        }
        return $object;
    }

    /**
     * Get multi seller product based or product id and seller id.
     * @param $productId
     * @param $sellerId
     * @return \Magento\Framework\DataObject
     */
    public function getMultiSellerProductByProductIdAndSellerId($productId, $sellerId)
    {
        $multiSellerProductCollection = $this->collectionFactory->create();
        $multiSellerProduct = $multiSellerProductCollection->addFieldToFilter('product_id', ['eq' => $productId])
            ->addFieldToFilter('seller_Id', ['eq' => $sellerId])->getFirstItem();
        return $multiSellerProduct;
    }
    /**
     * @inheritDoc
     *
     */
    public function getSellerProducts($sellerId)
    {
        $collection = $this->collectionFactory->create();

        $collection->addFieldToFilter('seller_id', $sellerId);
        $collection->addFieldToFilter('is_delete', 0);

        if (count($collection) >=1) {
            $products = [];

            foreach ($collection as $sellerProduct) {
                $awsImageUrl = "";
                $product = $this->productRepository->getById($sellerProduct->getProductId());
                $stockItem = $product->getExtensionAttributes()->getStockItem();

                $productDetail['id'] = $sellerProduct->getProductId();
                $productDetail['sku'] = $sellerProduct->getSku();
                $productDetail['name'] = $sellerProduct->getProductName();
                $productDetail['type_id'] = $product->getTypeId();
                //set product image
                $awsUrl = $this->scopeConfig->getValue('productmanagement/general/display_text',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                $images=$product->getMediaGalleryEntries();
                foreach($images as $image){
                    $imagePath=$image->getFile();
                    $path =preg_replace('#/+#','/',$imagePath);
                    $awsImageUrl=$awsUrl.$path;
                    break;
                }
                $productDetail['images'] = $awsImageUrl??'';
                $productDetail['price'] = $sellerProduct->getPrice();
                $productDetail['qty'] = $sellerProduct->getQty();
                $productDetail['qty_sold'] = 'qty_sold';
                $productDetail['qty_confirmed'] = 'qty_confirmed';
                $productDetail['status'] = $sellerProduct->getStatus();
                $productDetail['is_in_stock'] = $stockItem->getIsInStock();
                $productDetail['supplier_sku'] = $product->getSupplierSku();
                $productDetail['upc']=$product->getUpc();
                $products[] = $productDetail;
            }

            return $products;
        }
    }
    /**
     * @inheritDoc
     *
     */
    public function deleteProductById($sellerId,$productId)
    {
        try {
            $this->_conn->beginTransaction();
            $productModel = $this->collectionFactory->create();
            $productModel ->addFieldToFilter('seller_id', $sellerId);
            $productModel ->addFieldToFilter('product_id',$productId);
            $firstItem = $productModel->getFirstItem();
            $firstItem->setData('is_delete', 1);
            $firstItem->save();
            $product = $this->productRepository->getById($productId);
            $product->setStatus(\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_DISABLED);
            $this->productRepository->save($product);

            $this->_conn->commit();

        }
        catch (\Exception $e) {
            $this->_conn->rollBack();
            return false;
        }
         return true;
    }
    /**
     * Get seller id based on nearest dc
     *
     * @param int $venueId
     * @return int[]
     */
    public function getNearestDCSellerId($venueId)
    {
        $venue=$this->venueRepository->get($venueId);
        $dcList= $this->supplierProduct->getActiveDCs($venue->getZipCode());
        $dcSupplerIds = array_column($dcList, 'supply_id');
        $supplierIds=array_unique($dcSupplerIds);
        // Get latitude and longitude from the venue
        $latitudeFrom    = $venue->getLatitude();
        $longitudeFrom    = $venue->getLongitude();

        $sellerIds=[];
        foreach($supplierIds as $supplierId){
            $supplyDCList= $this->supplierProduct->getSupplierDCs($supplierId);
            $dc_distance = array();
            foreach ($supplyDCList as $dc) {
                // Get latitude and longitude from the DC
                $latitudeTo     = $dc->getLatitude();
                $longitudeTo    = $dc->getLongitude();

                $km=$this->vincentyGreatCircleDistance( $latitudeFrom, $longitudeFrom,$latitudeTo,$longitudeTo)/1000;
                $dc_distance=$this->array_push_assoc($dc_distance,$km,$dc->getDcId());
            }
            ksort($dc_distance);
            $nearestDCId= reset($dc_distance);

            if($nearestDCId)
            {
                $dC=$this->dCRepository->get($nearestDCId);
                $supplyCompany=$this->supplyCompanyRepository->get($dC->getSupplyId());
                $sellerId=$supplyCompany->getCompanyAdmin();
                array_push($sellerIds,$sellerId);
            }

        }
        return $sellerIds;
    }

    /**
    * push data to associated array
    *
    * @param [type] $array
    * @param [type] $key
    * @param [type] $value
    * @return void
    */
    public function array_push_assoc($array, $key, $value)
    {
        $array[$key] = $value;
        return $array;
    }

    /**
    * Calculates the great-circle distance between two points, with
    * the Vincenty formula.
    * @param float $latitudeFrom Latitude of start point in [deg decimal]
    * @param float $longitudeFrom Longitude of start point in [deg decimal]
    * @param float $latitudeTo Latitude of target point in [deg decimal]
    * @param float $longitudeTo Longitude of target point in [deg decimal]
    * @param float $earthRadius Mean earth radius in [m]
    * @return float Distance between points in [m] (same as earthRadius)
    */
    public static function vincentyGreatCircleDistance(
        $latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $earthRadius = 6371000)
    {
        // convert from degrees to radians
        $latFrom = deg2rad($latitudeFrom);
        $lonFrom = deg2rad($longitudeFrom);
        $latTo = deg2rad($latitudeTo);
        $lonTo = deg2rad($longitudeTo);

        $lonDelta = $lonTo - $lonFrom;
        $a = pow(cos($latTo) * sin($lonDelta), 2) +
        pow(cos($latFrom) * sin($latTo) - sin($latFrom) * cos($latTo) * cos($lonDelta), 2);
        $b = sin($latFrom) * sin($latTo) + cos($latFrom) * cos($latTo) * cos($lonDelta);

        $angle = atan2(sqrt($a), $b);
        return $angle * $earthRadius;
    }
    /**
     * @inheritDoc
     *
     */
    public function getSellerRelatedProduct($sellerId)
    {
        $collection = $this->collectionFactory->create();

        $collection->addFieldToFilter('seller_id', array('nin' =>$sellerId));
        $collection->addFieldToFilter('is_delete', 0);

        if (count($collection) >=1) {
            $products = [];

            foreach ($collection as $sellerProduct) {
                $product = $this->productRepository->getById($sellerProduct->getProductId());
                $stockItem = $product->getExtensionAttributes()->getStockItem();

                $productDetail['id'] = $product->getProductId();
                $productDetail['sku'] = $product->getSku();
                $productDetail['name'] = $product->getName();
                $productDetail['type_id'] = $product->getTypeId();
                $productDetail['images'] = $product->getMediaGalleryImages();
                $productDetail['price'] = $product->getPrice();
                $productDetail['qty'] = $stockItem->getQty();
                $productDetail['qty_sold'] = 'qty_sold';
                $productDetail['qty_confirmed'] = 'qty_confirmed';
                $productDetail['status'] = $sellerProduct->getStatus();

                $products[] = $productDetail;
            }

            return $products;
        }
    }

    /**
     * Get multi seller product based or product id and seller id.
     * @param $productId
     * @param $sellerId
     * @return \Magento\Framework\DataObject
     */
    public function getMultiSellerProduct($productId, $sellerId)
    {
        $multiSellerProductCollection = $this->collectionFactory->create();
        $multiSellerProduct = $multiSellerProductCollection->addFieldToFilter('product_id', ['eq' => $productId])
            ->addFieldToFilter('seller_Id', ['neq' => $sellerId])->getFirstItem();
        return $multiSellerProduct;
    }

     /**
     * @inheritDoc
     *
     */
    public function getProduct($sku)
    {
        $multiSellerProductCollection = $this->collectionFactory->create();
        $multiSellerProduct = $multiSellerProductCollection->addFieldToFilter('sku', ['eq' => $sku])->getFirstItem();
        return $multiSellerProduct;
    }

    /**
     * get dc against venueId
     *
     * @param int $supplierId
     * @param int $venueId
     * @return int
     */
    public function getDCId($supplierId,$venueId)
    {
        $venue=$this->venueRepository->get($venueId);
        // Get latitude and longitude from the venue
        $latitudeFrom    = $venue->getLatitude();
        $longitudeFrom    = $venue->getLongitude();

        $sellerIds=[];

        $supplyDCList= $this->supplierProduct->getSupplierDCByVenueId($supplierId,$venue->getZipCode());
        $dc_distance = array();
        foreach ($supplyDCList as $dc) {
            // Get latitude and longitude from the DC
            $latitudeTo     = $dc->getLatitude();
            $longitudeTo    = $dc->getLongitude();

            $km=$this->vincentyGreatCircleDistance( $latitudeFrom, $longitudeFrom,$latitudeTo,$longitudeTo)/1000;
            $dc_distance=$this->array_push_assoc($dc_distance,$km,$dc->getDcId());
        }
        ksort($dc_distance);
        $nearestDCId= reset($dc_distance);
        return $nearestDCId;
    }

    /**
     * @inheritDoc
     */
    public function getNearestDCSeller($venueId)
    {
        $venue=$this->venueRepository->get($venueId);
        $dcList= $this->supplierProduct->getActiveDCs($venue->getZipCode());
        $dcSupplerIds = array_column($dcList, 'supply_id');
        $supplierIds=array_unique($dcSupplerIds);
        // Get latitude and longitude from the venue
        $latitudeFrom    = $venue->getLatitude();
        $longitudeFrom    = $venue->getLongitude();

        $sellerNames=[];
        foreach($supplierIds as $supplierId){
            $supplyDCList= $this->supplierProduct->getSupplierDCs($supplierId);
            $dc_distance = array();
            foreach ($supplyDCList as $dc) {
                // Get latitude and longitude from the DC
                $latitudeTo     = $dc->getLatitude();
                $longitudeTo    = $dc->getLongitude();

                $km=$this->vincentyGreatCircleDistance( $latitudeFrom, $longitudeFrom,$latitudeTo,$longitudeTo)/1000;
                $dc_distance=$this->array_push_assoc($dc_distance,$km,$dc->getDcId());
            }
            ksort($dc_distance);
            $nearestDCId= reset($dc_distance);

            if($nearestDCId)
            {
                $dC=$this->dCRepository->get($nearestDCId);
                $supplyCompany=$this->supplyCompanyRepository->get($dC->getSupplyId());
                $sellerName=$supplyCompany->getCompanyName();

                $attribute = $this->eavConfig->getAttribute('catalog_product', 'supply_company_name');
                $optionId = $attribute->getSource()->getOptionId($supplyCompany->getCompanyName());

                array_push($sellerNames,$optionId);
            }

        }
        return $sellerNames;
    }
        /**
     * @inheritDoc
     */
    public function getNearestSupplier($venueId)
    {
        $venue=$this->venueRepository->get($venueId);
        $dcList= $this->supplierProduct->getActiveDCs($venue->getZipCode());
        $dcSupplerIds = array_column($dcList, 'supply_id');
        $supplierIds=array_unique($dcSupplerIds);
        // Get latitude and longitude from the venue
        $latitudeFrom    = $venue->getLatitude();
        $longitudeFrom    = $venue->getLongitude();

        $sellerIds=[];
        $result=[];
        $result2=[];
        foreach($supplierIds as $supplierId){
            $supplyDCList= $this->supplierProduct->getSupplierDCs($supplierId);
            $dc_distance = array();
            foreach ($supplyDCList as $dc) {
                // Get latitude and longitude from the DC
                $latitudeTo     = $dc->getLatitude();
                $longitudeTo    = $dc->getLongitude();

                $km=$this->vincentyGreatCircleDistance( $latitudeFrom, $longitudeFrom,$latitudeTo,$longitudeTo)/1000;
                $dc_distance=$this->array_push_assoc($dc_distance,$km,$dc->getDcId());
            }
            ksort($dc_distance);
            $nearestDCId= reset($dc_distance);

            if($nearestDCId)
            {
                $dC=$this->dCRepository->get($nearestDCId);
                $supplyCompany=$this->supplyCompanyRepository->get($dC->getSupplyId());
                $sellerId=$supplyCompany->getCompanyAdmin();
                array_push($sellerIds,$sellerId);
            }

        }
        foreach($sellerIds as $ids)
        {
            $supplierCollection = $this->_productCollectionFactory->create();
            $supplierCollection->addFieldToFilter('seller_id',$ids);
            if(count($supplierCollection)>0)
            {
                $collection = $this->supplyCompanyCollectionFactory->create();
                $collection->addFieldToFilter('company_admin', $ids);
                $supplierDetails= $collection->getFirstItem();
                $supplierName = $supplierDetails->getCompanyName();
                $supplierId=$supplierDetails->getSupplycompanyId();
                $supplyCompany=$this->supplierProduct->getSupplyCompanyByCompanyAdmin($ids);
                $attribute = $this->eavConfig->getAttribute('catalog_product', 'supply_company_name');
                $optionId = $attribute->getSource()->getOptionId($supplyCompany->getCompanyName());
                $result['seller_id']=$ids;
                $result['supplier_name']=$supplierName;
                $result['supplier_id']=$supplierId;
                $result['supplier_attribute_id']=$optionId;
                $result2[]=$result;
            }

        }
        return $result2;

    }
}
