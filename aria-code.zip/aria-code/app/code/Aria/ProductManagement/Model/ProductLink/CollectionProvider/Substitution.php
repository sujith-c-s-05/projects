<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Model\ProductLink\CollectionProvider;

use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ProductLink\CollectionProviderInterface;

/**
 * Class Substitution
 * @package Aria\ProductManagement\Model\ProductLink\CollectionProvider
 */
class Substitution implements CollectionProviderInterface
{
    /** @var \Aria\ProductManagement\Model\Substitution */
    protected $substitutionModel;

    /**
     * Substitution constructor.
     * @param \Aria\ProductManagement\Model\Substitution $substitutionModel
     */
    public function __construct(
        \Aria\ProductManagement\Model\Substitution $substitutionModel
    ) {
        $this->substitutionModel= $substitutionModel;
    }

    /**
     * {@inheritdoc}
     */
    public function getLinkedProducts(Product $product)
    {
        return (array) $this->substitutionModel->getSubstitutionProducts($product);
    }
}
