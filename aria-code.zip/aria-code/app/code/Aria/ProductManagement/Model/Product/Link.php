<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Model\Product;
/**
 * Class Link
 * @package Aria\ProductManagement\Model\Product
 */
class Link extends \Magento\Catalog\Model\Product\Link
{
    /**
     * custom link type substitution
     */
    const LINK_TYPE_SUBSTITUTION = 6;
    
    /**
     * @return $this
     */
    public function useSubstitutionLinks()
    {
        $this->setLinkTypeId(self::LINK_TYPE_SUBSTITUTION);
        return $this;
    }

   
}
