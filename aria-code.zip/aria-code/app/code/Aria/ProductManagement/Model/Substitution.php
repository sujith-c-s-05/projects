<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\ProductManagement\Model;

use Aria\ProductManagement\Model\Product\Link;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ResourceModel\Product\Link\Collection;
use Magento\Framework\DataObject;

/**
 * Class for managing product link type Substitution
 * @package Aria\ProductManagement\Model
 */
class Substitution extends DataObject
{
    /**
     * Product link instance
     *
     * @var Product\Link
     */
    protected $linkInstance;

    /**
     * Substitution constructor.
     * @param Link $productLink
     */
    public function __construct(
        Link $productLink
    ) {
        $this->linkInstance = $productLink;
    }

    /**
     * Retrieve link instance
     *
     * @return  Product\Link
     */
    public function getLinkInstance()
    {
        return $this->linkInstance;
    }

    /**
     * Retrieve array of substitution products
     *
     * @param Product $currentProduct
     * @return array
     */
    public function getSubstitutionProducts(Product $currentProduct)
    {
        //if (!$this->hasSubstitutionProducts()) {
        $products = [];
        $collection = $this->getSubstitutionProductCollection($currentProduct);
        foreach ($collection as $product) {
            $products[] = $product;
        }
        $this->setSubstitutionProducts($products);
        //}
        return $this->getData('substitution_products');
    }

    /**
     * Retrieve collection substitution product
     *
     * @param Product $currentProduct
     * @return \Magento\Catalog\Model\ResourceModel\Product\Link\Product\Collection
     */
    public function getSubstitutionProductCollection(Product $currentProduct)
    {
        $collection = $this->getLinkInstance()->useSubstitutionLinks()->getProductCollection()->setIsStrongMode();
        $collection->setProduct($currentProduct);
        return $collection;
    }
}
