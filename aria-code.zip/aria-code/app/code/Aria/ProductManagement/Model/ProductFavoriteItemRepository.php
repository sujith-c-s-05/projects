<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductManagement\Model;
use Aria\ProductManagement\Api\ProductFavoriteItemRepositoryInterface;
use Aria\ProductManagement\Api\Data\ProductFavoriteItemInterfaceFactory;
use Aria\ProductManagement\Model\ResourceModel\ProductFavoriteItem as ResourceProductFavoriteItem;
use Aria\ProductManagement\Model\ResourceModel\ProductFavoriteItem\CollectionFactory as ProductFavoriteItemCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Api\ProductRepositoryInterface as productRepositoryInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;


class ProductFavoriteItemRepository implements ProductFavoriteItemRepositoryInterface
{

    protected $productFavoriteItemCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;

    protected $productFavoriteItemFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataProductFavoriteItemFactory;

    protected $productRepositoryInterface;


    protected $categoryRepository;

    protected $supplierProduct;

    /**
     * @param ResourceProductFavoriteItem $resource
     * @param ProductFavoriteItemFactory $productFavoriteItemFactory
     * @param ProductFavoriteItemInterfaceFactory $dataProductFavoriteItemFactory
     * @param ProductFavoriteItemCollectionFactory $productFavoriteItemCollectionFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param productRepositoryInterface $productRepositoryInterface
     * @param \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository
     * @param \Aria\ProductManagement\Model\SupplierProducts $supplierProduct
     */
    public function __construct(
        ResourceProductFavoriteItem $resource,
        ProductFavoriteItemFactory $productFavoriteItemFactory,
        ProductFavoriteItemInterfaceFactory $dataProductFavoriteItemFactory,
        ProductFavoriteItemCollectionFactory $productFavoriteItemCollectionFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        productRepositoryInterface $productRepositoryInterface,
        \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository,
        \Aria\ProductManagement\Model\SupplierProducts $supplierProduct,
        ScopeConfigInterface $scopeConfig,
        \Magento\Eav\Model\Config $eavConfig
    ) {
        $this->resource = $resource;
        $this->productFavoriteItemFactory = $productFavoriteItemFactory;
        $this->productFavoriteItemCollectionFactory = $productFavoriteItemCollectionFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataProductFavoriteItemFactory = $dataProductFavoriteItemFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->productRepositoryInterface = $productRepositoryInterface;
        $this->categoryRepository = $categoryRepository;
        $this->supplierProduct = $supplierProduct;
        $this->scopeConfig = $scopeConfig;
        $this->eavConfig = $eavConfig;

    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface $productFavoriteItem
    ) {
        $productFavoriteItemData = $this->extensibleDataObjectConverter->toNestedArray(
            $productFavoriteItem,
            [],
            \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface::class
        );  
        
        $productFavoriteItemModel = $this->productFavoriteItemFactory->create()->setData($productFavoriteItemData);
        
        try {
            $productId=$productFavoriteItem->getProductId();
            $favoriteId=$productFavoriteItem->getFavoriteId();

            $favoriteItem=$this->getProductFavoriteItem($favoriteId, $productId);
            $id=$favoriteItem->getId();
            if(is_numeric($id)){
                $productFavoriteItemModel->setId($id);
                $qty=$favoriteItem->getQty()+$productFavoriteItemModel->getQty();
                $productFavoriteItemModel->setQty($qty);
            }
            $this->resource->save($productFavoriteItemModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the product favorite item',
                $exception->getMessage()
            ));
        }
        return $productFavoriteItemModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function deleteFavoriteItems($favoriteId)
    { 
        try{
            $favItems = $this->productFavoriteItemCollectionFactory->create();
            $favItems->addFieldToFilter('favorite_id',$favoriteId);
            foreach ($favItems as $model) {
                $model->Delete();
                $this->resource->save($model);
            }
        }
        catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the product favorite item',
                $exception->getMessage()
            ));
        }
        
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteFavoriteListItem($favoriteId,$productId)
    { 
        try{
            $favItems = $this->productFavoriteItemCollectionFactory->create();
            $favItems->addFieldToFilter('favorite_id',$favoriteId);
            $favItems->addFieldToFilter('product_id',$productId);
            $firstItem=$favItems->getFirstItem();
            $firstItem->getData();
            $firstItem->Delete();
            $firstItem->save();    
               
        }
        catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the product from favorite list',
                $exception->getMessage()
            ));
        }
        
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function getFavoriteOrderItems($favoriteId)
    { 
        $favoriteOrderItems = $this->productFavoriteItemCollectionFactory->create();
        $favoriteOrderItems->addFieldToFilter('favorite_id',$favoriteId);
        $items = [];
        foreach ($favoriteOrderItems as $model) {
            //set product name
            $productId=$model->getProductId();
            $productEntity = $this->productRepositoryInterface->getById($productId);
            $model->setProductName($productEntity->getName());

            //set product catagory
            $categoryNames=array();
            foreach ($productEntity->getCategoryIds() as $categoryId) {
                array_push($categoryNames,$this->getCategoryNameById($categoryId));
            }
            $model->setProductCatagory($categoryNames);

            //set unit cost
            $model->setUnitCost($productEntity->getPrice());

            //set total cost
            $qty=$model->getQty();
            $totalCost=$productEntity->getPrice() * $qty;
            $model->setTotalCost($totalCost);

            //set supplier name
            $sellerId=$productEntity->getResource()->getAttributeRawValue($productEntity->getId(),'seller_id',$productEntity->getStore()->getWebsiteId());
            if(is_numeric($sellerId))
            {
                $supplyCompany=$this->supplierProduct->getSupplyCompanyByCompanyAdmin($sellerId);
                $supplierName=$supplyCompany->getCompanyName();
            }
            $model->setSupplierName($supplierName??'');

            //Set unit of measurement name
            $uom=$productEntity->getResource()->getAttributeRawValue($productEntity->getId(),'uom',$productEntity->getStore()->getWebsiteId());
            if(!empty($uom)) {
    
                    $attribute = $this->eavConfig->getAttribute('catalog_product', 'uom');
                    $uomName = $attribute->getSource()->getOptionText($uom);            
            } 
            $model->setUomName($uomName??'');

            //set product image
            $awsUrl = $this->scopeConfig->getValue('productmanagement/general/display_text',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $images=$productEntity->getMediaGalleryEntries();
            $awsImageUrl = "";
            foreach($images as $image){
                $imagePath=$image->getFile();
                $path =preg_replace('#/+#','/',$imagePath);
                $awsImageUrl=$awsUrl.$path;
                break;
            }
            $model->setImage($awsImageUrl??'');
            $items[] = $model->getDataModel();
        }
        return $items;
    }

    /**
     * @param int $id
     * @param null $storeId
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getCategoryNameById($id, $storeId = null)
    {
        $categoryInstance = $this->categoryRepository->get($id, $storeId);
        return $categoryInstance->getName();
    }

    /**
     * get favoriteItem function
     *
     * @param int $favoriteId
     * @param int $productId
     * @return \Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface
     */
    public function getProductFavoriteItem($favoriteId, $productId)
    {
        $favoriteItems = $this->productFavoriteItemCollectionFactory->create();
        $favoriteItem = $favoriteItems->addFieldToFilter('product_id', ['eq' => $productId])
            ->addFieldToFilter('favorite_id', ['eq' => $favoriteId])->getFirstItem();
        return $favoriteItem;
    }
    

}