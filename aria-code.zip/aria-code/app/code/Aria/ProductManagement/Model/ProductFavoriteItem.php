<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ProductManagement\Model;

use Aria\ProductManagement\Api\Data\ProductFavoriteItemInterface;
use Aria\ProductManagement\Api\Data\ProductFavoriteItemInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class ProductFavoriteItem extends \Magento\Framework\Model\AbstractModel
{

    protected $productFavoriteItemDataFactory;

    protected $_eventPrefix = 'aria_product_favorite_item';
    protected $dataObjectHelper;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param ProductFavoriteItemInterfaceFactory $productFavoriteItemDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\ProductManagement\Model\ResourceModel\ProductFavoriteItem $resource
     * @param \Aria\ProductManagement\Model\ResourceModel\ProductFavoriteItem\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        ProductFavoriteItemInterfaceFactory $productFavoriteItemDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\ProductManagement\Model\ResourceModel\ProductFavoriteItem $resource,
        \Aria\ProductManagement\Model\ResourceModel\ProductFavoriteItem\Collection $resourceCollection,
        array $data = []
    ) {
        $this->productFavoriteItemDataFactory = $productFavoriteItemDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve product favorite  model with user role data
     * @return ProductFavoriteItemInterface
     */
    public function getDataModel()
    {
        $productFavoriteItemData = $this->getData();
        
        $productFavoriteItemDataObject = $this->productFavoriteItemDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $productFavoriteItemDataObject,
            $productFavoriteItemData,
            ProductFavoriteItemInterface::class
        );
        
        return $productFavoriteItemDataObject;
    }


}
