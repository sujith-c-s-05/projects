<?php

namespace Aria\Order\Plugin;

use Magento\Store\Api\Data\StoreConfigExtensionInterface;
use Magento\Store\Api\Data\StoreConfigInterface;
use Magento\Store\Api\Data\StoreConfigExtensionFactory;
use Magento\Setup\Exception;
use Magento\Directory\Model\Currency;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\ResourceModel\Order as OrderResource;

/**
 * classname
 */
class OrderIdentityPlugin
{
    protected $globalConfig;

    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $globalConfig,
        OrderResource $orderResource
    ) {
        $this->globalConfig = $globalConfig;
        $this->orderResource = $orderResource;

     }
  
     public function afterIsEnabled(\Magento\Sales\Model\Order\Email\Container\OrderIdentity $subject, $result)
     {
  
         return false;
     }    
}