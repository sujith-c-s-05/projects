<?php

namespace Aria\Order\Plugin;

use Magento\Quote\Api\Data\AddressInterface;
use Magento\Quote\Api\Data\PaymentInterface;
use Magento\Checkout\Model\PaymentInformationManagement;
use Magento\Framework\Exception\AbstractAggregateException;
use Magento\Quote\Api\CartRepositoryInterface;
use Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\HTTP\Client\Curl;
use Aria\Order\Helper\Data as HelperData;
use Aria\Order\Model\SalesOrderGroupRepository;
use Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface;
use Aria\Venue\Model\ResourceModel\VenueUser\CollectionFactory as venueUserCollectionFactory;
use Aria\HospitalityGroup\Model\ResourceModel\HospitalityGroup\CollectionFactory as HospitalityGroupCollectionFactory;
use Magento\Framework\Exception\AuthorizationException;


class PaymentInformation
{
    /**
     * @var \Magento\Catalog\Api\CategoryRepositoryInterface
     */
    protected $quoteRepositoryInterface;

    protected $paymentMethodManagement;

    /**
     * @var \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface 
     */
    protected $multiSellerProductRepositoryInterface;

    protected $objectmanager;

    protected $cartManagement;

    /**
     * @var \Aria\ProductManagement\Model\SupplierProducts
     */
    protected $supplierProduct;

    protected $curl;

    /**
     * @var HelperData
     */
    protected $helper;

    /**
     * @var Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface
     */
    protected $supplyCompanyRepositoryInterface;

    /**
     * @var Aria\Venue\Api\VenueUserRepositoryInterface
     */
    protected $venueUserRepositoryInterface;


    /**
     * PaymentInformation 
     *
     * @param CartRepositoryInterface $quoteRepositoryInterface
     * @param \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepositoryInterface
     * @param \Aria\ProductManagement\Model\SupplierProducts $supplierProduct
     * @param HelperData $helper
     * @param Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface
     * @param Aria\Venue\Api\VenueUserRepositoryInterface $venueUserRepositoryInterface
     */
    public function __construct(
        CartRepositoryInterface $quoteRepositoryInterface,
        \Magento\Framework\ObjectManagerInterface $objectmanager,
        \Magento\Quote\Api\CartManagementInterface $cartManagement,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Sales\Model\ResourceModel\Order $orderResourceModel,
        \Aria\Order\Model\SalesOrderGroupFactory $SalesOrderGroupFactory,
        \Aria\Order\Api\SalesOrderGroupRepositoryInterface $salesOrderGroupRepository,
        \Magento\Checkout\Api\PaymentInformationManagementInterface $paymentInformationManagement,
        \Magento\Quote\Api\PaymentMethodManagementInterface $paymentMethodManagement,
        \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepositoryInterface,
        \Aria\ProductManagement\Model\SupplierProducts $supplierProduct,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Aria\Venue\Api\VenueRepositoryInterface $venueRepository,
        \Aria\HospitalityGroup\Api\HospitalityGroupRepositoryInterface $hospGroup,
        \Aria\SupplyCompanyAccount\Api\DCRepositoryInterface $dc,
        ScopeConfigInterface $scopeConfig,
        StateInterface $state,
        TransportBuilder $transportBuilder,
        \Magento\Sales\Model\Order\Address\Renderer $address,
        \Aria\Venue\Api\VenueUserRepositoryInterface $venueUserRepository,
        Curl $curl,
        HelperData $helper,
        \Aria\Notifications\Model\NotificationsFactory $notifications,
        \Aria\Notifications\Model\ParticipantsFactory $participants,
        \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface,
        \Aria\Notifications\Api\NotificationsRepositoryInterface $notificationsInterface,
        SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface,
        \Aria\SupplyCompanyAccount\Api\DCUserroleMappingRepositoryInterface $dcuserrole,
        \Aria\Venue\Api\VenueUserRepositoryInterface $venueuserInterface,
        VenueUserCollectionFactory $venueUserCollectionFactory,
        HospitalityGroupCollectionFactory $hospitalityGroupCollectionFactory,
        \Aria\Venue\Helper\Data $permissionHelper,
        \Aria\CartManagement\Model\CartItemRepositoryManagement $cartItemRepositoryManagement
    ) {
        $this->quoteRepositoryInterface = $quoteRepositoryInterface;
        $this->multiSellerProductRepositoryInterface = $multiSellerProductRepositoryInterface;
        $this->objectManager = $objectmanager;
        $this->paymentMethodManagement = $paymentMethodManagement;
        $this->paymentInformationManagement = $paymentInformationManagement;
        $this->cartManagement = $cartManagement;
        $this->salesOrderGroupRepository = $salesOrderGroupRepository;
        $this->orderRepository = $orderRepository;
        $this->orderResourceModel = $orderResourceModel;
        $this->salesOrderGroupFactory = $SalesOrderGroupFactory;
        $this->supplierProduct = $supplierProduct;
        $this->storeManager = $storeManager;
        $this->venueRepository = $venueRepository;
        $this->hospitalityGroupRepositoryInterface = $hospGroup;
        $this->dc = $dc;
        $this->scopeConfig = $scopeConfig;
        $this->inlineTranslation = $state;
        $this->transportBuilder = $transportBuilder;
        $this->address = $address;
        $this->venueUserRepository = $venueUserRepository;
        $this->_curl = $curl;
        $this->helper = $helper;
        $this->notifications = $notifications;
        $this->participants = $participants;
        $this->participantsRepositoryInterface = $participantsRepositoryInterface;
        $this->notificationsRepositoryInterface = $notificationsInterface;
        $this->supplyCompanyRepositoryInterface = $supplyCompanyRepositoryInterface;
        $this->dcuserrole = $dcuserrole;
        $this->venueuserInterface = $venueuserInterface;
        $this->venueUserCollectionFactory = $venueUserCollectionFactory;
        $this->hospitalityGroupCollectionFactory = $hospitalityGroupCollectionFactory;
        $this->permissionHelper = $permissionHelper;
        $this->cartItemRepositoryManagement = $cartItemRepositoryManagement;

    }

    /**
     * aroundSavePaymentInformationAndPlaceOrder function
     *
     * @param PaymentInformationManagement $subject
     * @param callable $proceed
     * @param integer $cartId
     * @param PaymentInterface $paymentMethod
     * @param AddressInterface $billingAddress
     * @return int
     */
    public function aroundSavePaymentInformationAndPlaceOrder(
        PaymentInformationManagement $subject,
        callable $proceed,
        int $cartId,
        PaymentInterface $paymentMethod,
        AddressInterface $billingAddress = null
    ) {
        try {
            $object = $this->salesOrderGroupFactory->create();
            $extensionattributes = $paymentMethod->getExtensionAttributes();
            $venueId = $extensionattributes->getVenueId();
            $deliverySlot = $extensionattributes->getDeliverySlot();
            $venueUserId = $extensionattributes->getVenueUserId();
            $comments = $extensionattributes->getComments();
            $quote = $this->quoteRepositoryInterface->get($cartId);
            $noItems = $quote->getItemsCount();
            $cartTotal = $quote->getSubtotal();
            $supplierDCList = array();
            $quoteItems = $this->cartItemRepositoryManagement->getList($quote->getId());
            $supplyTotalCost = $this->getSupplierWiseTotalCost($quote, $quoteItems);
            $venueModel =  $this->venueRepository->get($venueId);
            $hosp_id    = $venueModel->getHospId();

            $hgcollection = $this->hospitalityGroupCollectionFactory->create();
            $hgcollection->addFieldToFilter('hospitalitygroup_id', $hosp_id);
            $hgcollection->getSelect()->joinLeft(
                ['vu' => 'aria_venue_user'],
                'main_table.company_admin = vu.magento_user_id',
                ['vu.*']
            );

            $users = $this->getVenueUsersWithApproval($venueId, $hosp_id);
            if (count($hgcollection) == 1) {
                $hosipitalityGroup = $hgcollection->getFirstItem();
                $adminUserId = $hosipitalityGroup->getData('id');
                $users[] = $adminUserId;
            } else {
                $adminUserId = 0;
            }
            $users = array_unique($users);

            foreach ($quoteItems as $item) {
                $extensionattributes = $item->getExtensionAttributes();
                $supplierId = $extensionattributes->getSupplierId();
                $totalCost = $extensionattributes->getTotalCost();

                //validation for credit status and MOV
                $supplyCompanyDetails = $this->supplyCompanyRepositoryInterface->get($supplierId);
                $mov = $supplyCompanyDetails->getMov();
                $supplierTotalCost = $supplyTotalCost[$supplierId];
                if ($supplierTotalCost < $mov) {
                    throw new \Magento\Framework\Exception\LocalizedException(
                        __('MOV against ' . $extensionattributes->getSupplierName() . ' is not met')
                    );
                }
                $creditStatus = $extensionattributes->getCreditStatus();
                if (in_array($venueId, $creditStatus)) {
                    throw new \Magento\Framework\Exception\LocalizedException(
                        __('Cannot place order from ' . $extensionattributes->getSupplierName())
                    );
                }

                //Supplier DC list
                $dcId = $this->multiSellerProductRepositoryInterface->getDCId($supplierId, $venueId);
                $supplierDCList = $this->array_push_assoc($supplierDCList, $supplierId, $dcId);
            }

            //Code for placing order
            $this->paymentInformationManagement->savePaymentInformation($cartId, $paymentMethod, $billingAddress);
            $orderId = $this->cartManagement->placeOrder($cartId);
            $cartLimit = $this->getVenueCartLimit($venueId);
            if (is_array($orderId) && count($orderId) > 1) {

                //saving order details to Sales order group table

                $object->setVenueId($venueId)
                    ->setVenueUserId($venueUserId)
                    ->setNoOfItems($noItems)
                    ->setCartTotal($cartTotal);

                if ($cartTotal > $cartLimit && !in_array($venueUserId, $users)) {
                    $object->setForApproval(1);
                }

                $salesOrderGroup = $object->save();
                $orderGroupId = $salesOrderGroup->getOrderGroupId();

                $orderGroupIncId = sprintf('%08d', $orderGroupId);
                $object->load($orderGroupId)->setOrderGroupIncrementId($orderGroupIncId)->save();
                if ($cartTotal <= $cartLimit || in_array($venueUserId, $users)) {
                    //save place order notification of venue to participants table
                    $desc = "Order #" . $orderGroupIncId . " placed";
                    $this->participantsRepositoryInterface->saveParticipantNotification(1, $venueId, $venueUserId, $desc, 'venue_user', 'Order placed');
                    $isAdmin = $this->venueuserInterface->isVenueAdmin($venueUserId);
                    if (!$isAdmin) {
                        $venueAdminId =  $this->venueuserInterface->getVenueAdminId($venueUserId);
                        if ($venueAdminId) {
                            $descrption = "Order #" . $orderGroupIncId . " placed";
                            $this->participantsRepositoryInterface->saveParticipantNotification(1, $venueId, $venueAdminId, $descrption, 'venue_user', 'Order placed');
                        }
                    }
                }

                $i = 1;
                foreach ($orderId as $id) {

                    //saving order details to Sales order table
                    $order = $this->orderRepository->get($id);

                    // Set DC id and supplier comment against supplier
                    $items = $order->getAllVisibleItems();
                    $total_qty = 0;
                    foreach ($items as $item) {
                        $sku = $item->getSku();
                        $total_qty += $item->getQtyOrdered();
                        //break;
                    }
                    $order->setTotalQtyOrdered($total_qty);
                    $multiSellerProduct = $this->multiSellerProductRepositoryInterface->getProduct($sku);
                    $sellerId = $multiSellerProduct->getSellerId();
                    if (is_numeric($sellerId)) {
                        $supplyCompany = $this->supplierProduct->getSupplyCompanyByCompanyAdmin($sellerId);
                        $supplierId = $supplyCompany->getSupplycompanyId();
                        $supplierDCId = $supplierDCList[$supplierId];
                        $order->setDcid($supplierDCId);
                        $order->setDeliverySlot($this->getDeliverySlots($deliverySlot, $supplierId));
                    }

                    $order['Venueid'] = $venueId;
                    $order->setGroupOrderId($orderGroupId);
                    $supplier_order_inc_id = $orderGroupIncId . "-" . $i;
                    $order->setSupplierOrderIncId($supplier_order_inc_id);
                    foreach ($comments as $comment) {
                        if ($comment->getSupplierId() == $supplierId) {
                            $supplierComment = $comment->getComment();
                            $order->setVenueComments($supplierComment);
                        }
                    }
                    $order->setIsSplit(1);
                    if ($cartTotal > $cartLimit && !in_array($venueUserId, $users)) {
                        $order->setStatus(SalesOrderGroupRepository::PENDING_APPROVAL);
                    }
                    $this->orderResourceModel->save($order);
                    $i++;
                }

                foreach ($orderId as $id) {
                    $order = $this->orderRepository->get($id);
                    $order_id =  $order->getIncrementId();
                    $supplier_order_inc_id = $order->getSupplierOrderIncId();
                    $order_date = $order->getCreatedAt();
                    $venue_order_id = $order->getGroupOrderId();
                    $venue_order_id = sprintf('%08d', $venue_order_id);
                    $shipping_address = $this->address->format($order->getShippingAddress(), 'html');
                    $dcid = $order->getData('dcid');
                    $dcObj = $this->dc->get($dcid);
                    $dcPhone = $dcObj->getPhone();
                    $message = 'OrderId : ' . $supplier_order_inc_id . ' Your Order Placed Successfully';
                    $this->helper->sendSMS($message, $dcPhone);

                    if ($cartTotal <= $cartLimit || in_array($venueUserId, $users)) { //save order notification of DC into participants table
                        $dcUsers = $this->dcuserrole->getDCUsers($dcid);
                        foreach ($dcUsers as $dcUser) {
                            $desc = "Order #" . $supplier_order_inc_id . " placed";
                            $this->participantsRepositoryInterface->saveParticipantNotification(1, $dcid, $dcUser, $desc, 'dc_user', 'Order placed');
                        }
                    }
                }
                if ($cartTotal <= $cartLimit || in_array($venueUserId, $users)) {
                    $venueUserModel =  $this->venueUserRepository->getById($venueUserId);
                    $venueUserPhone = $venueUserModel->getPhone();

                    $message = 'OrderId : ' . $orderGroupIncId . ' Your Order Placed Successfully';
                    $this->helper->sendSMS($message, $venueUserPhone);

                    $this->sendEmails($orderId, $venueId);
                }
                if ($cartTotal > $cartLimit && !in_array($venueUserId, $users) && $venueUserId != 0) {
                    foreach ($users as $venuePermmittedUser) {
                        $this->sendApprovalNotification($orderGroupIncId, $venueId, $venuePermmittedUser, $venueUserId);
                    }
                }
            } else {

                //saving order details to Sales order group table
                $object->setVenueId($venueId)
                    ->setVenueUserId($venueUserId)
                    ->setNoOfItems($noItems)
                    ->setCartTotal($cartTotal);
                if ($cartTotal > $cartLimit && !in_array($venueUserId, $users)) {
                    $object->setForApproval(1);
                }
                $salesOrderGroup = $object->save();

                $orderGroupId = $salesOrderGroup->getOrderGroupId();

                $orderGroupIncId = sprintf('%08d', $orderGroupId);
                $object->load($orderGroupId)->setOrderGroupIncrementId($orderGroupIncId)->save();
                if ($cartTotal <= $cartLimit || in_array($venueUserId, $users)) {
                    //save place order notification of venue to participants table
                    $desc = "Order #" . $orderGroupIncId . " placed";
                    $this->participantsRepositoryInterface->saveParticipantNotification(1, $venueId, $venueUserId, $desc, 'venue_user', 'Order placed');

                    $isAdmin = $this->venueuserInterface->isVenueAdmin($venueUserId);
                    if (!$isAdmin) {
                        $venueAdminId =  $this->venueuserInterface->getVenueAdminId($venueUserId);
                        if ($venueAdminId) {
                            $descrption = "Order #" . $orderGroupIncId . " placed";
                            $this->participantsRepositoryInterface->saveParticipantNotification(1, $venueId, $venueAdminId, $descrption, 'venue_user', 'Order placed');
                        }
                    }
                }

                $i = 1;
                //saving order details to Sales order table
                foreach ($orderId as $id) {
                    $order = $this->orderRepository->get($id);

                    // Set DC id and supplier comment against supplier
                    $items = $order->getAllVisibleItems();
                    foreach ($items as $item) {
                        $sku = $item->getSku();
                        break;
                    }
                    $multiSellerProduct = $this->multiSellerProductRepositoryInterface->getProduct($sku);
                    $sellerId = $multiSellerProduct->getSellerId();
                    if (is_numeric($sellerId)) {
                        $supplyCompany = $this->supplierProduct->getSupplyCompanyByCompanyAdmin($sellerId);
                        $supplierId = $supplyCompany->getSupplycompanyId();
                        $supplierDCId = $supplierDCList[$supplierId];
                        $order->setDcid($supplierDCId);
                        $order->setDeliverySlot($this->getDeliverySlots($deliverySlot, $supplierId));
                    }
                    $order['Venueid'] = $venueId;
                    $order->setGroupOrderId($orderGroupId);
                    $supplier_order_inc_id = $orderGroupIncId . "-" . $i;
                    $order->setSupplierOrderIncId($supplier_order_inc_id);
                    foreach ($comments as $comment) {
                        if ($comment->getSupplierId() == $supplierId) {
                            $supplierComment = $comment->getComment();
                            $order->setVenueComments($supplierComment);
                        }
                    }
                    $order->setIsSplit(0);
                    if ($cartTotal > $cartLimit && !in_array($venueUserId, $users)) {
                        $order->setStatus(SalesOrderGroupRepository::PENDING_APPROVAL);
                    }
                    $this->orderResourceModel->save($order);
                    $i++;
                }
                foreach ($orderId as $id) {
                    $order = $this->orderRepository->get($id);
                    $order_id =  $order->getIncrementId();
                    $supplier_order_inc_id = $order->getSupplierOrderIncId();
                    $order_date = $order->getCreatedAt();
                    $venue_order_id = $order->getGroupOrderId();
                    $venue_order_id = sprintf('%08d', $venue_order_id);
                    $shipping_address = $this->address->format($order->getShippingAddress(), 'html');
                    $dcid = $order->getData('dcid');
                    $dcObj = $this->dc->get($dcid);
                    $dcPhone = $dcObj->getPhone();
                    $message = 'OrderId : ' . $supplier_order_inc_id . ' Your Order Placed Successfully';
                    $this->helper->sendSMS($message, $dcPhone);

                    if ($cartTotal <= $cartLimit || in_array($venueUserId, $users)) { //save order notification of DC into participants table
                        $dcUsers = $this->dcuserrole->getDCUsers($dcid);
                        foreach ($dcUsers as $dcUser) {
                            $desc = "Order #" . $supplier_order_inc_id . " placed";
                            $this->participantsRepositoryInterface->saveParticipantNotification(1, $dcid, $dcUser, $desc, 'dc_user', 'Order placed');
                        }
                    }
                }
                if ($cartTotal <= $cartLimit || in_array($venueUserId, $users)) {
                    $venueUserModel =  $this->venueUserRepository->getById($venueUserId);
                    $venueUserPhone = $venueUserModel->getPhone();
                    $message = 'OrderId : ' . $orderGroupIncId . ' Your Order Placed Successfully';
                    $this->helper->sendSMS($message, $venueUserPhone);

                    $this->sendEmails($orderId, $venueId);
                }
                if ($cartTotal > $cartLimit && !in_array($venueUserId, $users) && $venueUserId != 0) {
                    foreach ($users as $venuePermmittedUser) {
                        $this->sendApprovalNotification($orderGroupIncId, $venueId, $venuePermmittedUser, $venueUserId);
                    }
                }
            }
        } catch (LocalizedException $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }
        return $orderGroupIncId;
    }
    public function sendEmails($orderId, $venueId)
    {

        //send email to suppliers

        $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId());
        $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $sender_name  = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
        $from = ['email' => $email, 'name' => $sender_name];
        $orderDeliverySlot=[];
        foreach ($orderId as $id) {
            $order = $this->orderRepository->get($id);
            $order_id =  $order->getIncrementId();
            $supplier_order_inc_id = $order->getSupplierOrderIncId();
            $order_date = $order->getCreatedAt();
            $venue_order_id = $order->getGroupOrderId();
            $venue_order_id = sprintf('%08d', $venue_order_id);
            $shipping_address = $this->address->format($order->getShippingAddress(), 'html');
            $email = $order->getCustomerEmail();
            $dcid = $order->getData('dcid');
            $dcObj = $this->dc->get($dcid);
            $dcName = $dcObj->getName();
            $extensionattributes = $order->getExtensionAttributes();
            $supplierId = $extensionattributes->getSupplierId();
            $orderDeliverySlot[$supplierId]=$order->getDeliverySlot();
            $templateVars = array(
                'dcname' => $dcName,
                'increment_id' => $supplier_order_inc_id,
                'order_date' => $order_date,
                'shipping_address' => $shipping_address,
                'order_id' => $id
            );
            $this->inlineTranslation->suspend();
            $transport = $this->transportBuilder->setTemplateIdentifier('supplier_email_order_template', ScopeInterface::SCOPE_STORE)
                ->setTemplateOptions($templateOptions)
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($dcObj->getEmail())
                ->getTransport();
            $transport->sendMessage();
            $this->inlineTranslation->resume();
        }



        //send email to venue user

        $venueModel =  $this->venueRepository->get($venueId);
        $hosp_id = $venueModel->getHospId();
        $hospModel = $this->hospitalityGroupRepositoryInterface->get($hosp_id);
        $company_name = $hospModel->getCompanyName();
        $templateVars = array(
            'company' => $company_name,
            'increment_id' => $venue_order_id,
            'order_date' => $order_date,
            'shipping_address' => $shipping_address,
            'order_id' => $orderId,
            'delivery_slot'=>$orderDeliverySlot
        );
        $this->inlineTranslation->suspend();
        $transport = $this->transportBuilder->setTemplateIdentifier('venue_email_order_template', ScopeInterface::SCOPE_STORE)
            ->setTemplateOptions($templateOptions)
            ->setTemplateVars($templateVars)
            ->setFrom($from)
            ->addTo($email)
            ->getTransport();
        $transport->sendMessage();
        $this->inlineTranslation->resume();
    }

    /**
     * push data to associated array
     *
     * @param [type] $array
     * @param [type] $key
     * @param [type] $value
     * @return void
     */
    public function array_push_assoc($array, $key, $value)
    {
        $array[$key] = $value;
        return $array;
    }

    /**
     * @inheritDoc
     *
     */
    public function getSupplierWiseTotalCost($quote, $quoteItems)
    {
        $groups = array();
        foreach ($quoteItems as $item) {
            $extensionattributes = $item->getExtensionAttributes();
            $key = $extensionattributes->getSupplierId();
            if (!array_key_exists($key, $groups)) {
                $groups[$key] = $extensionattributes->getTotalCost();
            } else {
                $groups[$key] = $groups[$key] + $extensionattributes->getTotalCost();
            }
        }
        return $groups;
    }
    /**
     * @inheritDoc
     *
     */
    public function getVenueCartLimit($venueId)
    {
        $venueModel =  $this->venueRepository->get($venueId);
        return $venueModel->getOrderCostLimit();
    }

    public function sendApprovalNotification($orderGroupIncId, $venueId, $venuePermmittedUser, $venueUserId)
    {
        $venuecollection = $this->venueUserCollectionFactory->create();
        $venuecollection->addFieldToFilter('id', $venueUserId);
        $venueUser       = $venuecollection->getFirstItem();
        $first_name      = $venueUser->getData('first_name');
        $last_name       = $venueUser->getData('last_name');

        $desc = $first_name . " " . $last_name . " has requested approval for #" . $orderGroupIncId;
        $this->participantsRepositoryInterface->saveParticipantNotification(1, $venueId, $venuePermmittedUser, $desc, 'venue_user', 'order is sent for approval');
        //$isAdmin = $this->venueuserInterface->isVenueAdmin($venueUserId);

        // if (!$isAdmin) {
        //     $venueAdminId =  $this->venueuserInterface->getVenueAdminId($venueUserId);
        //     if ($venueAdminId) {
        //         $descrption = $desc;
        //         $this->participantsRepositoryInterface->saveParticipantNotification(1, $venueId, $venueAdminId, $descrption, 'venue_user', 'order is sent for approval');
        //     }
        // }
    }
    public function getVenueUsersWithApproval($venueId, $hospId)
    {
        $collection = $this->venueUserCollectionFactory->create();
        $collection->addFieldToFilter('hg_id', $hospId);
        $users = [];
        foreach ($collection as $venueUser) {
            try {
                if ($this->permissionHelper->permissionCheck($venueId, $venueUser->getId(), 'Order Approval')) {
                    $users[] = $venueUser->getId();
                }
            } catch (AuthorizationException $exception) {
                continue;
            }
        }
        return $users;
    }
    public function getDeliverySlots($deliverySlot, $supplierId)
    {
        if (is_array($deliverySlot) && !empty($deliverySlot)) {
            foreach ($deliverySlot as $slot) {
                if ($slot->getSupplierId() == $supplierId) {
                    return $slot->getSlot();
                }
            }
        }
        return false;
    }
}
