<?php

namespace Aria\Order\Plugin;

use Magento\Store\Api\Data\StoreConfigExtensionInterface;
use Magento\Store\Api\Data\StoreConfigInterface;
use Magento\Store\Api\Data\StoreConfigExtensionFactory;
use Magento\Setup\Exception;
use Magento\Directory\Model\Currency;
use Magento\Store\Model\StoreManagerInterface;


/**
 * classname
 */
class GeneralInfo
{
    protected $storeConfigExtensionFactory;
    protected $storeConfigInterface;
    protected $storeConfigExtensionInterface;
    protected $scopeConfig;
    protected $currency;

   
    public function __construct(
    Currency $currencyFactory, 
    StoreManagerInterface $storeManager, 
    StoreConfigExtensionFactory $storeConfigExtensionFactory, 
    StoreConfigInterface $storeConfigInterface, 
    Currency $currency,
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
            $this->storeConfigExtensionFactory = $storeConfigExtensionFactory;
            $this->storeConfigInterface = $storeConfigInterface;
            $this->scopeConfig = $scopeConfig;
            $this->currencyFactory = $currencyFactory;
            $this->currency = $currency; 
            $this->storeManager = $storeManager;

     }
    /**
     * @param string[] $storeCodes list of stores by store codes, will return all if storeCodes is not set
     * @return \Magento\Store\Api\Data\StoreConfigInterface[]
     */
    public function afterGetStoreConfigs(\Magento\Store\Model\Service\StoreConfigManager $storeConfigManager, $result, array $storeCodes = null)
    {
        
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        
        foreach ($result as $storevalues) {

            if($storeCodes === null){
                $storeCodes = $this->storeManager->getStore()->getCode();
            }
            $dateFormat = $this->scopeConfig->getValue('catalog/custom_options/date_fields_order', $storeScope);
            $currencySymbol =  $this->currency->getCurrencySymbol();
            $extensionAttribute=$storevalues->getExtensionAttributes();
            $extensionAttribute->setCurrencySymbol($currencySymbol); 
            $extensionAttribute->setDateFormat($dateFormat); 
            $storevalues->setExtensionAttributes($extensionAttribute);
        }
        return $result;
    }

}