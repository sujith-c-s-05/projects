<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Aria\Order\Plugin;

use Magento\Sales\Api\Data\OrderInterface;
use Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface;
use Magento\Sales\Api\Data\OrderItemInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Aria\Order\Api\SalesOrderGroupRepositoryInterface;
use Aria\Venue\Api\VenueRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\DCRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\Exception\NoSuchEntityException;

class OrderGet
{
    /**
     * @var \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface 
     */
    protected $multiSellerProductRepositoryInterface;

    /**
     * @var Aria\SupplyCompanyAccount\Api\DCRepositoryInterface
     */

    /**
     * @var \Aria\Order\Api\SalesOrderGroupRepositoryInterface
     */
    protected $salesOrderGroupRepositoryInterface;

    /**
     * @var Aria\Venue\Api\VenueRepositoryInterface
     */
    protected $venueRepositoryInterface;

    protected $productRepositoryInterface;

    /**
     * @var \Magento\Catalog\Api\CategoryRepositoryInterface
     */
    protected $categoryRepository;

    /**
     * @var \Magento\Store\Model\App\Emulation
     */
    protected $appEmulation;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var \Magento\Catalog\Helper\Image
     */
    protected $imageHelper;

    protected $_productRepositoryFactory;
    /**
     * @var Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface
     */
    protected $supplyCompanyRepositoryInterface;

    /**
     * @var \Magento\Eav\Model\Config
     */
    protected $eavConfig;

    protected $itemFactory;

    protected $timezone;

    /**
     * constructor for search order function
     * @param \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepositoryInterface
     * @param \Aria\Order\Api\SalesOrderGroupRepositoryInterface $salesOrderGroupRepositoryInterface
     * @param \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository
     * @param \Magento\Store\Model\App\Emulation $appEmulation
     * @param \Magento\Catalog\Helper\Image   
     * @param Aria\Venue\Api\VenueRepositoryInterface $venueRepositoryInterface
     * @param \Aria\ProductManagement\Model\SupplierProducts $supplierProduct
     * @param Aria\SupplyCompanyAccount\Api\DCRepositoryInterface $dCRepositoryInterface
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface
     * @param \Magento\Eav\Model\Config $eavConfig
     */
    public function __construct(
        \Aria\ProductManagement\Api\MultiSellerProductRepositoryInterface $multiSellerProductRepositoryInterface,
        \Aria\Order\Api\SalesOrderGroupRepositoryInterface $salesOrderGroupRepositoryInterface,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository,
        ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\App\Emulation $appEmulation,
        \Magento\Catalog\Helper\Image $imageHelper,
        \Aria\ProductManagement\Model\SupplierProducts $supplierProduct,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Catalog\Api\ProductRepositoryInterfaceFactory $productRepositoryFactory,
        \Magento\Eav\Model\Config $eavConfig,
        VenueRepositoryInterface $venueRepositoryInterface,
        DCRepositoryInterface $dCRepositoryInterface,
        SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface,
        \Magento\Sales\Model\Order\ItemFactory $itemFactory,
        TimezoneInterface $timezone,
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry,
        \Aria\ProductManagement\Model\VenueCreditstatusRepository $venueCreditstatusRepository,
        \Aria\ReviewRatings\Model\ResourceModel\SupplierReviews\CollectionFactory $supplierReviewsCollectionFactory
    ) {
        $this->multiSellerProductRepositoryInterface = $multiSellerProductRepositoryInterface;
        $this->salesOrderGroupRepositoryInterface = $salesOrderGroupRepositoryInterface;
        $this->productRepositoryInterface = $productRepositoryInterface;
        $this->categoryRepository = $categoryRepository;
        $this->appEmulation = $appEmulation;
        $this->venueRepositoryInterface = $venueRepositoryInterface;
        $this->imageHelper = $imageHelper;
        $this->scopeConfig = $scopeConfig;
        $this->supplierProduct = $supplierProduct;
        $this->storeManager = $storeManager;
        $this->_productRepositoryFactory = $productRepositoryFactory;
        $this->eavConfig = $eavConfig;
        $this->itemFactory = $itemFactory;
        $this->supplyCompanyRepositoryInterface = $supplyCompanyRepositoryInterface;
        $this->dCRepositoryInterface = $dCRepositoryInterface;
        $this->timezone = $timezone;
        $this->stockRegistry = $stockRegistry;
        $this->venueCreditstatusRepository = $venueCreditstatusRepository;
        $this->supplierReviewsCollectionFactory = $supplierReviewsCollectionFactory;
    }

    /**
     * Get order
     *
     * @param \Magento\Sales\Api\OrderRepositoryInterface $subject
     * @param \Magento\Sales\Api\Data\OrderInterface $order
     * @return void
     */
    public function afterGet(
        \Magento\Sales\Api\OrderRepositoryInterface $subject,
        \Magento\Sales\Api\Data\OrderInterface $order

    ) {
        $orderId = $order->getEntityId();
        $extensionattributes = $order->getExtensionAttributes();
        /** get current extension attributes from entity **/
        $venueEntityId = false;
        $supplier = false;
        $supplierAdmin = false;
        $mov = false;
        $supplyCompanyId = false;
        $deliverySlot = $order->getDeliverySlot();
        $orderGroupDetails = $this->salesOrderGroupRepositoryInterface->getSalesOrderDetails($order->getEntityId());
        foreach ($orderGroupDetails as $orderGroupDetail) {
            $dcId = $orderGroupDetail['dc_id'];
            $venueId = $orderGroupDetail['venue_id'];
            $venueUserId = $orderGroupDetail['venue_user_id'];
            $dcDetails = $this->dCRepositoryInterface->get($dcId);
            $supplyCompanyId = $dcDetails->getSupplyId();
            $supplier = $supplyCompanyId;
            $supplyCompanyDetails = $this->supplyCompanyRepositoryInterface->get($supplyCompanyId);
            $supplyCompanyName = $supplyCompanyDetails->getCompanyName();
            $supplierAdmin = $supplyCompanyDetails->getCompanyAdmin();
            $mov = $supplyCompanyDetails->getMov();
            $supplyCompanyDetail['supplier_name'] = $supplyCompanyName;
            $venue = $this->venueRepositoryInterface->get($venueId);
            $venueName = $venue->getName();
            $venueContactNumber = $venue->getPhone();
            $groupOrderId = $orderGroupDetail['order_group_id'];
            $order_group_increment_id = $orderGroupDetail['order_group_increment_id'];
            $supplier_order_inc_id = $orderGroupDetail['supplier_order_inc_id'];
            $venueEntityId = $venueId;
        }


        foreach ($order->getItems() as $key => $item) {
            $extensionattributeItem = $item->getExtensionAttributes();
            /** get current extension attributes from entity **/
            $sku = $item->getSku();
            $productDetails = $this->multiSellerProductRepositoryInterface->getProduct($sku);
            $productItems = $this->productRepositoryInterface->get($sku);
            $images = $productItems->getMediaGalleryEntries();
            foreach ($images as $image) {
                $imagePath = $image->getFile();
                break;
            }

            //Get category names
            $categoryNames = array();
            foreach ($productItems->getCategoryIds() as $categoryId) {
                array_push($categoryNames, $this->getCategoryNameById($categoryId));
            }
            //Get Cost Details
            $costProductId = $item->getProductId();
            $qtyordered = $item->getQtyOrdered();
            $price = $item->getPrice();
            $totalCost = $qtyordered * $price;

            //Get unit of measurement names


            $uom = $productItems->getResource()->getAttributeRawValue($productItems->getId(), 'uom', $productItems->getStore()->getWebsiteId());
            if (!empty($uom)) {

                $attribute = $this->eavConfig->getAttribute('catalog_product', 'uom');
                $uomName = $attribute->getSource()->getOptionText($uom);
            }

            //No of Items

            $itemCount = $this->itemFactory->create()->getCollection();
            $itemCount->addFieldToFilter('order_id', array('eq' => $item->getOrderId()));
            $noOfItems = $itemCount->count();

            $cutofftime = $this->scopeConfig->getValue('ordermanagement/general/display_text', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $currentTimeStamp = $this->timezone->date()->getTimeStamp();
            $currentDateTime = date("Y-m-d H:i:s", $currentTimeStamp);
            $orderPlacedDate = $order->getCreatedAt();

            $d1 = strtotime($orderPlacedDate);
            $d2 = strtotime($currentDateTime);
            $interval = $d2 - $d1;
            $intervalInMin = floor($interval / 60);

            $cutoffTimeInMinutes = (int)$cutofftime * 60;
            $enableCancelButton = false;
            if ($intervalInMin <= $cutoffTimeInMinutes) {
                $enableCancelButton = true;
            }

            //get product salable quantity
            $salableQty = $productItems->getExtensionAttributes()->getsalableQty();

            $extensionattributeItem->setProductCatagory($categoryNames ?? '');
            $extensionattributeItem->setTotalCost($totalCost ?? '');
            $extensionattributeItem->setImageDetails($imagePath ?? '');
            $extensionattributeItem->setUomName($uomName ?? '');
            $extensionattributeItem->setSalableQty($salableQty ?? 0);

            //information for reorder

            $currentFinalPrice = $productItems->getFinalPrice();
            $currentStatus = $productItems->getStatus();
            $supplierVacation = true;
            $stockItem = $this->stockRegistry->getStockItem($item->getProductId());
            $maxQty = $stockItem->getMaxSaleQty();
            $minQty = $stockItem->getMinSaleQty();
            $stockData = $stockItem->getData();
            $stockStatus = $stockItem->getIsInStock();
            if ($venueEntityId && $supplierAdmin) {
                $currentCredit = true;
                $creditStatus = $this->venueCreditstatusRepository->getCreditStatus($supplierAdmin, $venueEntityId);
                if ($creditStatus) {
                    $currentCredit = $creditStatus->getStatus();
                }
                $extensionattributeItem->setCreditStatus($currentCredit);
            }
            $extensionattributeItem->setCurrentPrice($currentFinalPrice);
            $extensionattributeItem->setCurrentTotal($currentFinalPrice * $qtyordered);
            $extensionattributeItem->setSupplierVacation($supplierVacation);
            $extensionattributeItem->setMov($mov);
            $extensionattributeItem->setMinimumQty($minQty);
            $extensionattributeItem->setMaximumQty($maxQty);
            $extensionattributeItem->setStockStatus($stockStatus);
            $extensionattributeItem->setAvailable($currentStatus);


            $item->setExtensionAttributes($extensionattributeItem);
        }
        if ($supplyCompanyId) {
            $supplierReviewsCollection = $this->supplierReviewsCollectionFactory->create();
            $supplierReviewsCollection->addFieldToFilter('supplier_id', ['eq' => $supplyCompanyId])
                ->addFieldToFilter('venue_user_id', ['eq' => $venueUserId])
                ->addFieldToFilter('venue_id', ['eq' => $venueId])
                ->addFieldToFilter('is_delete', ['eq' => 0]);
            if (count($supplierReviewsCollection) > 0) {
                $collectionItem = $supplierReviewsCollection->getFirstItem();
                $ItemData = $collectionItem->getData();
                $reviewId = $ItemData['id'];
            }
        }

        $extensionattributes->setNoOfItems($noOfItems ?? 0);
        $extensionattributes->setCutOffTime($cutofftime ?? 0);
        $extensionattributes->setEnableCancelButton($enableCancelButton ?? false);
        $extensionattributes->setSupplierName($supplyCompanyName ?? '');
        $extensionattributes->setSupplierId($supplyCompanyId ?? 0);
        $extensionattributes->setVenueName($venueName ?? '');
        $extensionattributes->setVenueContactNumber($venueContactNumber ?? '');
        $extensionattributes->setOrderGroupId($groupOrderId ?? 0);
        $extensionattributes->setOrderGroupIncrementId($order_group_increment_id ?? 0);
        $extensionattributes->setSupplierOrderIncrementId($supplier_order_inc_id ?? 0);
        $extensionattributes->setDcId($dcId ?? 0);
        $extensionattributes->setVenueId($venueId ?? '');
        $extensionattributes->setVenueUserId($venueUserId ?? '');
        $extensionattributes->setReviewId($reviewId ?? 0);
        if ($deliverySlot != NULL) {
            $timestamp = strtotime($deliverySlot);
            $deliverySlotDay = date('l', $timestamp) . ' ' . date('d-m-Y', $timestamp);
            $extensionattributes->setDeliverySlot($deliverySlotDay);
        }

        $order->setExtensionAttributes($extensionattributes);
        return $order;
    }


    /**
     * @param int $id
     * @param null $storeId
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getCategoryNameById($id, $storeId = null)
    {
        $categoryInstance = $this->categoryRepository->get($id, $storeId);
        return $categoryInstance->getName();
    }

    /**
     * @param \Magento\Sales\Api\Data\OrderInterface $orders
     * @param \Magento\Sales\Api\OrderRepositoryInterface $subject
     * @return void

     */
    public function afterGetList(
        \Magento\Sales\Api\OrderRepositoryInterface $subject,
        $orders
    ) {
        $orderList = $orders->getItems();
        $venueEntityId = false;
        $supplierAdmin = false;
        $supplier = false;
        $mov = false;
        foreach ($orders->getItems() as $key => $order) {
            $extensionattributes = $order->getExtensionAttributes();
            $deliverySlot = $order->getDeliverySlot();
            /** get current extension attributes from entity **/
            $orderGroupDetails = $this->salesOrderGroupRepositoryInterface->getSalesOrderDetails($order->getEntityId());
            try {
                foreach ($orderGroupDetails as $orderGroupDetail) {
                    $dcId = $orderGroupDetail['dc_id'];
                    $venueId = $orderGroupDetail['venue_id'];
                    $venueUserId = $orderGroupDetail['venue_user_id'];
                    $cartTotal = $orderGroupDetail['cart_total'];
                    $groupOrderId = $orderGroupDetail['order_group_id'];
                    $order_group_increment_id = $orderGroupDetail['order_group_increment_id'];
                    $supplier_order_inc_id = $orderGroupDetail['supplier_order_inc_id'];
                    if (is_numeric($dcId)) {
                        $dcDetails = $this->dCRepositoryInterface->get($dcId);
                        $supplyCompanyId = $dcDetails->getSupplyId();
                        $supplyCompanyDetails = $this->supplyCompanyRepositoryInterface->get($supplyCompanyId);
                        $supplyCompanyName = $supplyCompanyDetails->getCompanyName();
                        $supplierAdmin = $supplyCompanyDetails->getCompanyAdmin();
                        $mov = $supplyCompanyDetails->getMov();
                        $supplier = $supplyCompanyId;
                        $supplyCompanyDetail['supplier_name'] = $supplyCompanyName;
                    }
                    if (is_numeric($venueId)) {
                        $venue = $this->venueRepositoryInterface->get($venueId);
                        $venueName = $venue->getName();
                        $venueContactNumber = $venue->getPhone();
                        $venueEntityId = $venueId;
                    }
                }

                foreach ($order->getItems() as $key => $item) {
                    $imagePath = "";
                    $extensionattributeItem = $item->getExtensionAttributes();
                    /** get current extension attributes from entity **/
                    $sku = $item->getSku();
                    $productDetails = $this->multiSellerProductRepositoryInterface->getProduct($sku);
                    $productItems = $this->productRepositoryInterface->get($sku);
                    $images = $productItems->getMediaGalleryEntries();
                    foreach ($images as $image) {
                        $imagePath = $image->getFile();
                        break;
                    }

                    //Get category names
                    $categoryNames = array();
                    foreach ($productItems->getCategoryIds() as $categoryId) {
                        array_push($categoryNames, $this->getCategoryNameById($categoryId));
                    }
                    //Get Cost Details
                    $costProductId = $item->getProductId();
                    $qtyordered = $item->getQtyOrdered();
                    $price = $item->getPrice();
                    $totalCost = $qtyordered * $price;

                    //Get unit of measurement names


                    $uom = $productItems->getResource()->getAttributeRawValue($productItems->getId(), 'uom', $productItems->getStore()->getWebsiteId());
                    if (!empty($uom)) {

                        $attribute = $this->eavConfig->getAttribute('catalog_product', 'uom');
                        $uomName = $attribute->getSource()->getOptionText($uom);
                    }

                    //No of Items

                    $itemCount = $this->itemFactory->create()->getCollection();
                    $itemCount->addFieldToFilter('order_id', array('eq' => $item->getOrderId()));
                    $noOfItems = $itemCount->count();

                    $cutofftime = $this->scopeConfig->getValue('ordermanagement/general/display_text', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                    $currentTimeStamp = $this->timezone->date()->getTimeStamp();
                    $currentDateTime = date("Y-m-d H:i:s", $currentTimeStamp);
                    $orderPlacedDate = $order->getCreatedAt();

                    $d1 = strtotime($orderPlacedDate);
                    $d2 = strtotime($currentDateTime);
                    $interval = $d2 - $d1;
                    $intervalInMin = floor($interval / 60);

                    $cutoffTimeInMinutes = (int)$cutofftime * 60;
                    $enableCancelButton = false;
                    if ($intervalInMin <= $cutoffTimeInMinutes) {
                        $enableCancelButton = true;
                    }

                    //get product salable quantity
                    $salableQty = $productItems->getExtensionAttributes()->getsalableQty();

                    $extensionattributeItem->setProductCatagory($categoryNames ?? '');
                    $extensionattributeItem->setTotalCost($totalCost ?? '');
                    $extensionattributeItem->setImageDetails($imagePath ?? '');
                    $extensionattributeItem->setUomName($uomName ?? '');
                    $extensionattributeItem->setSalableQty($salableQty ?? 0);

                    //information for reorder
                    $currentFinalPrice = $productItems->getFinalPrice();
                    $currentStatus = $productItems->getStatus();
                    $supplierVacation = true;
                    $stockItem = $this->stockRegistry->getStockItem($item->getProductId());
                    $maxQty = $stockItem->getMaxSaleQty();
                    $minQty = $stockItem->getMinSaleQty();
                    $stockData = $stockItem->getData();
                    $stockStatus = $stockItem->getIsInStock();
                    if ($venueEntityId && $supplierAdmin) {
                        $currentCredit = true;
                        $creditStatus = $this->venueCreditstatusRepository->getCreditStatus($supplierAdmin, $venueEntityId);
                        if ($creditStatus) {
                            $currentCredit = $creditStatus->getStatus();
                        }
                        $extensionattributeItem->setCreditStatus($currentCredit);
                    }

                    $extensionattributeItem->setCurrentPrice($currentFinalPrice);
                    $extensionattributeItem->setCurrentTotal($currentFinalPrice * $qtyordered);
                    $extensionattributeItem->setSupplierVacation($supplierVacation);
                    $extensionattributeItem->setMov($mov);
                    $extensionattributeItem->setMinimumQty($minQty);
                    $extensionattributeItem->setMaximumQty($maxQty);
                    $extensionattributeItem->setStockStatus($stockStatus);
                    $extensionattributeItem->setAvailable($currentStatus);


                    $item->setExtensionAttributes($extensionattributeItem);
                }
            } catch (\Exception $e) {
                throw new NoSuchEntityException(__('Error occured for order' . $order->getEntityId() . "," . $e));
            }
            $extensionattributes->setNoOfItems($noOfItems ?? 0);
            $extensionattributes->setCartTotal($cartTotal ?? 0);
            $extensionattributes->setCutOffTime($cutofftime ?? 0);
            $extensionattributes->setEnableCancelButton($enableCancelButton ?? false);
            $extensionattributes->setDcId($dcId ?? 0);
            $extensionattributes->setSupplierName($supplyCompanyName ?? '');
            $extensionattributes->setSupplierId($supplyCompanyId ?? 0);
            $extensionattributes->setVenueName($venueName ?? '');
            $extensionattributes->setVenueId($venueId ?? '');
            $extensionattributes->setVenueUserId($venueUserId ?? '');
            $extensionattributes->setOrderGroupId($groupOrderId ?? 0);
            $extensionattributes->setOrderGroupIncrementId($order_group_increment_id ?? 0);
            $extensionattributes->setSupplierOrderIncrementId($supplier_order_inc_id ?? 0);
            $extensionattributes->setVenueContactNumber($venueContactNumber ?? '');

            if ($deliverySlot != NULL) {
                $timestamp = strtotime($deliverySlot);
                $deliverySlotDay = date('l', $timestamp) . ' ' . date('d-m-Y', $timestamp);
                $extensionattributes->setDeliverySlot($deliverySlotDay);
            }

            $order->setExtensionAttributes($extensionattributes);
        }
        return $orders;
    }
}
