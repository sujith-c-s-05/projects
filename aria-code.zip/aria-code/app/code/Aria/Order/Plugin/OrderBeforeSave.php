<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Aria\Order\Plugin;

use Magento\Sales\Api\OrderRepositoryInterface;
use Aria\Order\Api\SalesOrderGroupRepositoryInterface;
use Aria\Order\Helper\Data as HelperData;

/**
 * class for handling send email notification while updating the status 
 */
class OrderBeforeSave
{
    /**
     * @var OrderRepositoryInterface $orderRepositoryInterface
     */
    protected $orderRepositoryInterface;

    /**
     * @var \Magento\Sales\Api\OrderRepositoryInterface
     */
    protected $orderRepository;

    /**
     * @var \Magento\Sales\Model\Order\Email\Sender\OrderCommentSender
     */
    protected $orderCommentSender;

    /**
    * @var \Aria\Order\Api\SalesOrderGroupRepositoryInterface
    */
    protected $salesOrderGroupRepositoryInterface;

    protected $venueUserRepositoryInterface;

    protected $dc;

    /**
     * @var HelperData
     */
    protected $helper;


    /**
     * constructor function
     *
     * @param OrderRepositoryInterface $orderRepositoryInterface
     * @param \Magento\Sales\Api\OrderRepositoryInterface $orderRepository
     * @param \Magento\Sales\Model\Order\Email\Sender\OrderCommentSender $orderCommentSender
     * @param \Aria\Order\Api\SalesOrderGroupRepositoryInterface $salesOrderGroupRepositoryInterface
     * @param HelperData $helper
     */
    public function __construct(
        OrderRepositoryInterface $orderRepositoryInterface,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Sales\Model\Order\Email\Sender\OrderCommentSender $orderCommentSender,
        \Aria\Order\Api\SalesOrderGroupRepositoryInterface $salesOrderGroupRepositoryInterface,
        \Aria\Venue\Api\VenueUserRepositoryInterface $venueUserRepository,
        \Aria\SupplyCompanyAccount\Api\DCRepositoryInterface $dc,
        HelperData $helper,
        \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface,
        \Aria\Notifications\Api\NotificationsRepositoryInterface $notificationsInterface,
        \Aria\SupplyCompanyAccount\Api\DCUserroleMappingRepositoryInterface $dcuserrole,
        \Aria\Venue\Api\VenueUserRepositoryInterface $venueuserInterface,
        \Aria\Venue\Model\ResourceModel\VenueUser\CollectionFactory $venueUserCollectionFactory,
        \Aria\ReviewRatings\Model\ResourceModel\SupplierReviews\CollectionFactory $supplierReviewsCollectionFactory,
        \Aria\ReviewRatings\Model\SupplierReviewsFactory $reviewRatingsFactory,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\DC\CollectionFactory $supplyDcCollectionFactory,
        \Magento\Sales\Model\OrderRepositoryFactory $orderRepositoryFactory
    ) {
        $this->orderRepositoryInterface = $orderRepositoryInterface;
        $this->orderRepository = $orderRepository;
        $this->orderCommentSender = $orderCommentSender;
        $this->salesOrderGroupRepositoryInterface=$salesOrderGroupRepositoryInterface;
        $this->venueUserRepository = $venueUserRepository;
        $this->dc = $dc;
        $this->helper = $helper;
        $this->participantsRepositoryInterface=$participantsRepositoryInterface;
        $this->notificationsRepositoryInterface=$notificationsInterface;
        $this->dcuserrole = $dcuserrole;
        $this->venueuserInterface = $venueuserInterface;
        $this->venueUserCollectionFactory = $venueUserCollectionFactory;
        $this->supplierReviewsCollectionFactory = $supplierReviewsCollectionFactory;
        $this->reviewRatingsFactory = $reviewRatingsFactory;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->supplyDcCollectionFactory = $supplyDcCollectionFactory;
        $this->orderRepositoryFactory = $orderRepositoryFactory;

    }

    /**
     * Before save function for sending email based on state and status.
     *
     * @param \Magento\Sales\Api\OrderRepositoryInterface $orderRepo
     * @param OrderInterface $order
     * @return void
     */
    public function beforeSave(\Magento\Sales\Api\OrderRepositoryInterface $orderRepo, $order)
    {
        
        $id=$order->getEntityId();
        if(is_numeric($id)&&$id>0)
        {
            $orderEntity = $this->orderRepository->get($id);
            $extensionAttributes=$order->getExtensionAttributes();
            $customerEmail=$order->getCustomerEmail();
            //get receiver mail id from extension attribute and set as customer_email field.
            $receiverMail=$extensionAttributes->getReceiverEmail();
            $state=strtolower($order->getState());
            $status=strtolower($order->getStatus());
            $newState='new';
            $statusHistories=$order->getStatusHistories();
            $statusHistory=reset($statusHistories);
            $notify = isset($statusHistory['is_customer_notified']) ? $statusHistory['is_customer_notified'] : false;
            if($statusHistory)
            {
                $comment = trim(strip_tags($statusHistory->getComment()));
            }
            if($notify && $state!=$newState){
                if($state=='canceled')
                {
                    $increment_id = $orderEntity->getIncrementId();
                    $orderEntity->cancel();
                    $orderDetails=$this->salesOrderGroupRepositoryInterface->getSalesOrderDetails($id);
                    foreach($orderDetails as $orderGroupDetail){
                        $dcId=$orderGroupDetail['dc_id'];
                        $venueUserId=$orderGroupDetail['venue_user_id'];
                        $order_group_increment_id = $orderGroupDetail['order_group_increment_id'];
                        $supplier_order_inc_id = $orderGroupDetail['supplier_order_inc_id'];
                        $dcDetails=$this->dc->get($dcId);
                        $dcPhone = $dcDetails->getPhone();
                        $venueUserModel =  $this->venueUserRepository->getById($venueUserId);
                        $venueUserPhone = $venueUserModel->getPhone();
                        $message_venue='OrderId : '.$order_group_increment_id.' Your order has been canceled';
                        $message_dc='OrderId : '.$supplier_order_inc_id.' Your order has been canceled';
                        $this->helper->sendSMS($message_dc,$dcPhone);
                        $this->helper->sendSMS($message_venue,$venueUserPhone);
                        
                        //Save notification to participants table.
                        $orderGroupIncId = $orderGroupDetail['order_group_increment_id'];
                        $venueId = $orderGroupDetail['venue_id'];
                        $des = "Order #".$orderGroupIncId." cancelled";
                        $this->participantsRepositoryInterface->saveParticipantNotification(1,$venueId,$venueUserId,$des,'venue_user','Order canceled');
                        $isAdmin = $this->venueuserInterface->isVenueAdmin($venueUserId);
                        if(!$isAdmin){
                            $venueAdminId =  $this->venueuserInterface->getVenueAdminId($venueUserId);
                            if($venueAdminId){
                                $desc_ption = "Order #".$orderGroupIncId." cancelled";
                                $this->participantsRepositoryInterface->saveParticipantNotification(1,$venueId,$venueAdminId,$desc_ption,'venue_user','Order canceled');
                            }
                        }
                        $dcUsers = $this->dcuserrole->getDCUsers($dcId);
                        foreach($dcUsers as $dcUser){
                            $desc = "Order #".$supplier_order_inc_id." cancelled";
                            $this->participantsRepositoryInterface->saveParticipantNotification(1,$dcId,$dcUser,$desc,'dc_user','Order canceled');
                        }
                    }
                    if($status == 'canceled'){
                        $label = "canceled";
                        $orderEntity->setStatus($label);
                    }
                    elseif($status == 'order_rejected'){
                        $label = "order_rejected";
                        $orderEntity->setStatus($label);
                    }

                }
                $orderEntity->setCustomerEmail($receiverMail);
                $this->orderCommentSender->send($orderEntity, $notify, $comment);
                $orderEntity->setCustomerEmail($customerEmail);
            }
            elseif($state=='processing' && $status == 'confirmed')
            {
                $this->OrderConfirmedNotification($id);
            }
        }
    }
    public function afterSave(\Magento\Sales\Api\OrderRepositoryInterface $orderRepo, $order)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 
        $orderData = $this->orderRepositoryFactory->create()->get($order->getId());
        $orderDetails = $orderRepo->get($order->getId());         
        $supplierId = $orderDetails->getExtensionAttributes()->getsupplierId();
        $customerId = $orderData->getCustomerId();
        $venueUserId = $this->getVenueUserByCustomerId($customerId)->getId();
        $collection = $this->supplierReviewsCollectionFactory->create();
        $collection->addFieldToFilter('supplier_id',['eq' => $supplierId])
            ->addFieldToFilter('venue_user_id',['eq' => $venueUserId]);
        foreach($collection as $review){
            $this->updateVerified($review->getId(),$customerId,$supplierId);
        }
        return $order;
    }
    // /**
    //  * {@inheritdoc}
    //  */
    // public function updateReviewUser($supplierId, $venueUserId){
        
    // }
    /**
     * {@inheritdoc}
     */
    public function getVenueUserByCustomerId($customerId)
    { 
        $venueUsers = $this->venueUserCollectionFactory->create();
        $venueUser = $venueUsers->addFieldToFilter('magento_user_id', ['eq' => $customerId])->getFirstItem();
        return $venueUser;
    }
    /**
     * {@inheritdoc}
     */
    public function updateVerified($reviewId,$customerId,$supplierId){
        $reviewRatings = $this->reviewRatingsFactory->create()->load($reviewId);
        $reviewRatings->setVerifiedCustomer($this->getVerifiedUser($customerId,$supplierId));
        $reviewRatings->save();
    }
    /**
     * {@inheritdoc}
     */
    public function getVerifiedUser($customerId,$supplierId)
    {    
        $status = ['confirmed','delivered','disputed'];
        $orderCollection = $this->orderCollectionFactory->create();
        $orderCollection->addFieldToFilter('customer_id', ['eq' => $customerId])
                        ->addFieldToFilter('status', ['in' => $status]);
        foreach($orderCollection as $order){
            $supplyDcId = $order->getDcid();
            $supplyDcCollection = $this->supplyDcCollectionFactory->create();
            $supplyDc = $supplyDcCollection->addFieldToFilter('dc_id', ['eq' => $supplyDcId])
                        ->getFirstItem();
            if($supplyDcCollection->count() && $supplyDc->getSupplyId()== $supplierId){
                return 1;
            }
        }
        return 0;
    }

    /**
     * Sending notification to venue users and sc users when accepting an order
     *
     * @param int $entityId
     * @return void
     */
    public function OrderConfirmedNotification($entityId)
    {
        $orderDetails=$this->salesOrderGroupRepositoryInterface->getSalesOrderDetails($entityId);
        foreach($orderDetails as $orderGroupDetail){
            $dcId=$orderGroupDetail['dc_id'];
            $venueUserId=$orderGroupDetail['venue_user_id'];
            $order_group_increment_id = $orderGroupDetail['order_group_increment_id'];
            $supplier_order_inc_id = $orderGroupDetail['supplier_order_inc_id'];
            
            //Save notification to participants table.
            $orderGroupIncId = $orderGroupDetail['order_group_increment_id'];
            $venueId = $orderGroupDetail['venue_id'];
            $des = "Order #".$orderGroupIncId." confirmed";
            $this->participantsRepositoryInterface->saveParticipantNotification(1,$venueId,$venueUserId,$des,'venue_user','Order confirmed');
            $isAdmin = $this->venueuserInterface->isVenueAdmin($venueUserId);
            if(!$isAdmin){
                $venueAdminId =  $this->venueuserInterface->getVenueAdminId($venueUserId);
                if($venueAdminId){
                    $desc_ption = "Order #".$orderGroupIncId." confirmed";
                    $this->participantsRepositoryInterface->saveParticipantNotification(1,$venueId,$venueAdminId,$desc_ption,'venue_user','Order confirmed');
                }
            }
            $dcUsers = $this->dcuserrole->getDCUsers($dcId);
            foreach($dcUsers as $dcUser){
                $desc = "Order #".$supplier_order_inc_id." confirmed";
                $this->participantsRepositoryInterface->saveParticipantNotification(1,$dcId,$dcUser,$desc,'dc_user','Order confirmed');
            }
        }
    }
}