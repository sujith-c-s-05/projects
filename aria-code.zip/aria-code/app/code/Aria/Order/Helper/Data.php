<?php

namespace Aria\Order\Helper;

use Magento\Store\Model\ScopeInterface;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Framework\App\Config\ScopeConfigInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $curl;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

     /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        Curl $curl,
        \Magento\Framework\App\Helper\Context $context       
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->_curl = $curl;
        parent::__construct($context);
    }

    /**
     * Get attributes to split.
     *
     * @param int $storeId
     * @return string
     */
    public function getAttributes($storeId = null)
    {
        return 'seller_id';
    }

    /**
     * Check if should split delivery.
     *
     * @param string $storeId
     * @return bool
     */
    public function getShippingSplit($storeId = null)
    {
        return true;
    }

    /**
     * Get which kind of attribute related with qty should be load.
     *
     * @param int $storeId
     * @return bool
     */
    public function getQtyType($storeId = null)
    {
        return 'qty';
        
    }

    /**
     * If should apply out of stock if inventory is empty.
     *
     * @param int $storeId
     * @return string
     */
    public function getBackorder($storeId = null)
    {
        return false;
    }

     /**
     * To send sms
     */
    public function sendSMS($message,$phoneNo){
        
        $url=$this->scopeConfig->getValue('ordermanagement/general1/display_text1',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $xApiKey=$this->scopeConfig->getValue('ordermanagement/general1/display_text2',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $xClientId=$this->scopeConfig->getValue('ordermanagement/general1/display_text3',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $this->_curl->addHeader("Content-Type", "application/json");
        $this->_curl->addHeader("x-api-key",$xApiKey);
        $this->_curl->addHeader("x-client-id",$xClientId);
        $params = [
            'message' => $message,
            'phoneNumber' => $phoneNo,
        ];
        $this->_curl->post($url, json_encode($params));
        $response = $this->_curl->getBody();

    }
}
