<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Api\Data;

interface SupplierDeliverySlotInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{


    /**
     * Get supplier_id
     * @return string
     */
    public function getSupplierId();
    /**
     * Set supplier_id
     * @param string $supplierId
     * @return \Aria\Order\Api\Data\SupplierDeliverySlotInterface
     */
    public function setSupplierId($supplierId);
    /**
     * Get slot
     * @return string|null
     */
    public function getSlot();
    /**
     * Set slot
     * @param string $slot
     * @return \Aria\Order\Api\Data\SupplierDeliverySlotInterface
     */
    public function setSlot($slot);
    

}