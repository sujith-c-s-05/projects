<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Api\Data;


interface SupplierCommentsInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    
    /**
     * Get supplierId
     * @return int|null
     */
    public function getSupplierId();

    /**
     * Set supplierId
     * @param int $supplierId
     * @return \Aria\Order\Api\Data\SupplierCommentsInterface
     */
    public function setSupplierId($supplierId);

    /**
     * Get comment
     * @return string|null
     */
    public function getComment();

    /**
     * Set comment
     * @param string $comment
     * @return \Aria\Order\Api\Data\SupplierCommentsInterface
     */
    public function setComment($comment);
}
