<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Api\Data;

interface ReorderResponseInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{


    /**
     * Get cart_status
     * @return bool
     */
    public function getCartStatus();

    /**
     * Set cart_status
     * @param bool $cartStatus
     * @return \Aria\Order\Api\Data\ReorderResponseInterface
     */

    public function setCartStatus($cartStatus);
    /**
    * Get  order_details
    *
    * @return \Aria\Order\Api\Data\OrderDetailsInterface[]
    */
    public function getOrderDetails();

    /**
    * Set order_details
    *
    * @param \Aria\Order\Api\Data\OrderDetailsInterface[] $orderDetailsInterface
    * @return \Aria\Order\Api\Data\OrderDetailsInterface[] | null
    */
    public function setOrderDetails(array $orderDetailsInterface = null);

}