<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Api\Data;

interface ProductDataInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{


    /**
     * Get product_name
     * @return string|null
     */
    public function getProductName();
    /**
     * Set product_name
     * @param string $productName
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setProductName($productName);
    /**
     * Get product_id
     * @return int|null
     */
    public function getProductId();
    /**
     * Set product_id
     * @param int $productId
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setProductId($productId);
    /**
     * Get supplier_id
     * @return int|null
     */
    public function getSupplierId();
    /**
     * Set supplier_id
     * @param int $supplierId
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setSupplierId($supplierId);
    /**
     * Get supplier_name
     * @return string|null
     */
    public function getSupplierName();
    /**
     * Set supplier_name
     * @param string $supplierName
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setSupplierName($supplierName);
    /**
     * Get old_price
     * @return float|null
     */
    public function getOldPrice();
    /**
     * Set old_price
     * @param float $oldPrice
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setOldPrice($oldPrice);
    /**
     * Get new_price
     * @return float|null
     */
    public function getNewPrice();
    /**
     * Set new_price
     * @param float $newPrice
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setNewPrice($newPrice);
    /**
     * Get qty_ordered
     * @return int|null
     */
    public function getQtyOrdered();
    /**
     * Set qty_ordered
     * @param int $qtyOrdered
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setQtyOrdered($qtyOrdered);
    /**
     * Get current_total
     * @return string|null
     */
    public function getCurrentTotal();
    /**
     * Set current_total
     * @param string $currentTotal
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setCurrentTotal($currentTotal);

}