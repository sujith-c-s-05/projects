<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Api\Data;

interface NonSensitiveDataInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{


    /**
     * Get mov
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getMov();
    /**
     * Set mov
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $mov
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setMov(array $mov = null);
    /**
     * Get min_qty
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getMinQty();
    /**
     * Set min_qty
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $minQty
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setMinQty(array $minQty = null);
    /**
     * Get max_qty
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getMaxQty();
    /**
     * Set max_qty
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $maxQty
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setMaxQty(array $maxQty = null);
    /**
     * Get price_variation
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getPriceVariation();
    /**
     * Set price_variation
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $priceVariation
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setPriceVariation(array $priceVariation = null);
    

}