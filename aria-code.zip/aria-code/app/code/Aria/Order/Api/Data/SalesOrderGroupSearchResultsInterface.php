<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Api\Data;

interface SalesOrderGroupSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get recent order list.
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface[]
     */
    public function getItems();

    /**
     * Set recent order list.
     * @param \Aria\Order\Api\Data\SalesOrderGroupInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
