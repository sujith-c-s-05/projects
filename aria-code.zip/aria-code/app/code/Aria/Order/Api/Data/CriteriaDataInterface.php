<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Api\Data;

interface CriteriaDataInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{


    /**
     * Get status
     * @return bool
     */
    public function getStatus();
    /**
     * Set status
     * @param bool $status
     * @return \Aria\Order\Api\Data\CriteriaDataInterface
     */
    public function setStatus($status);
    /**
     * Get message
     * @return string|null
     */
    public function getMessage();
    /**
     * Set message
     * @param string $minQty
     * @return \Aria\Order\Api\Data\CriteriaDataInterface
     */
    public function setMessage($message);
    

}