<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Api\Data;

interface SalesOrderGroupInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const ORDERGROUP_ID = 'order_group_id';
    const ORDERGROUPINCREMENTID_ID = 'order_group_increment_id'; 
    const VENUE_ID = 'venue_id';
    const VENUEUSER_ID='venue_user_id';
    const DC_ID = 'dc_id';
    const NOOFITEMS='no_of_items';
    const CARTTOTAL='cart_total';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const IS_DELETE = 'is_delete';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';


     /**
     * Get orderGroupId
     * @return int|null
     */
    public function getOrderGroupId();

    /**
     * Set orderGroupId
     * @param int $orderGroupId
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setOrderGroupId($orderGroupId);

    /**
     * Get orderGroupIncrementId
     * @return string|null
     */
    public function getOrderGroupIncrementId();

    /**
     * Set orderGroupIncrementId
     * @param string $orderGroupIncrementId
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setOrderGroupIncrementId($orderGroupIncrementId);

    /**
     * Get dcId
     * @return int|null
     */
    public function getDcId();

    /**
     * Set dcId
     * @param int $dcId
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setDcId($dcId);

    /**
     * Get venueId
     * @return int|null
     */
    public function getVenueId();

    /**
     * Set venueId
     * @param int $venueId
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setVenueId($venueId);
   
    /**
     * Get venueUserId
     * @return int|null
     */
    public function getVenueUserId();

    /**
     * Set venueUserId
     * @param int $venueUserId
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setVenueUserId($venueUserId);
    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\Order\Api\Data\SalesOrderGroupExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\Order\Api\Data\SalesOrderGroupExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\Order\Api\Data\SalesOrderGroupExtensionInterface $extensionAttributes
    );
    
    /**
     * Get noOfItems
     * @return int|null
     */
    public function getNoOfItems();

    /**
     * Set noOfItems
     * @param int $noOfItems
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setNoOfItems($noOfItems);

    /**
     * Get cartTotal
     * @return float|null
     */
    public function getCartTotal();

    /**
     * Set cartTotal
     * @param float $cartTotal
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setCartTotal($cartTotal);
    
     /**
     * Get status
     * @return string[]|null
     */
    public function getStatus();

    /**
     * Set status
     * @param string[] $status
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setStatus(array $status);  

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setUpdatedBy($updatedBy);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setIsActive($isActive);

   
     /**
     * Get is_delete
     * @return bool|null
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setIsDelete($isDelete); 
    
    /**
     * Get name
     * @return string|null
     */
    public function getName();

    /**
     * Set name
     * @param string $name
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setName($name);   

    /**
     * Get is_moved_to_cart
     * @return int|null
     */
    public function getIsMovedToCart();

    /**
     * Set is_moved_to_cart
     * @param int $isMovedToCart
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setIsMovedToCart($isMovedToCart); 

    /**
     * Get for_approval
     * @return int|null
     */
    public function getForApproval();

    /**
     * Set for_approval
     * @param int $forApproval
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setForApproval($forApproval);
    
    /**
     * Get Products
     * @return string[]|null
     */
    public function getProducts();

    /**
     * Set Products
     * @param string[] $products
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setProducts(array $products);  

    /**
     * Get first_name
     * @return string|null
     */
    public function getFirstName();

    /**
     * Set first_name
     * @param string $firstName
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setFirstName($firstName);   

    /**
     * Get last_name
     * @return string|null
     */
    public function getLastName();

    /**
     * Set last_name
     * @param string $lastName
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setLastName($lastName);   
}