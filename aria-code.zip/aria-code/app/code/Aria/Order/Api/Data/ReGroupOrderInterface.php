<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Api\Data;

interface ReGroupOrderInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{


    /**
     * Get quote_id
     * @return int|null
     */
    public function getQuoteId();

    /**
     * Set quote_id
     * @param int $quoteId
     * @return \Aria\Order\Api\Data\ReGroupOrderInterface
     */

    public function setQuoteId($quoteId);

    /**
     * Get venue_id
     * @return int|null
     */
    public function getVenueId();

    /**
     * Set venue_id
     * @param int $venueId
     * @return \Aria\Order\Api\Data\ReGroupOrderInterface
     */
    public function setVenueId($venueId);

    /**
     * Get group_order_id
     * @return int|null
     */
    public function getGroupOrderId();

    /**
     * Set group_order_id
     * @param int $groupOrderId
     * @return \Aria\Order\Api\Data\ReGroupOrderInterface
     */
    public function setGroupOrderId($groupOrderId);

}