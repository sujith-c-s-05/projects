<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Api\Data;

interface OrderDetailsInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    /**
    * Get  product_data
    *
    * @return \Aria\Order\Api\Data\ProductDataInterface[]
    */
    public function getProductData();

    /**
    * Set product_data
    *
    * @param \Aria\Order\Api\Data\ProductDataInterface[] $productDataInterface
    * @return \Aria\Order\Api\Data\ProductDataInterface[] | null
    */
    public function setProductData(array $productDataInterface = null);
    /**
    * Get  sensitive_data
    *
    * @return \Aria\Order\Api\Data\SensitiveDataInterface[]
    */
    public function getSensitiveData();

    /**
    * Set sensitive_data
    *
    * @param \Aria\Order\Api\Data\SensitiveDataInterface[] $sensitiveDataInterface
    * @return \Aria\Order\Api\Data\SensitiveDataInterface[] | null
    */
    public function setSensitiveData(array $sensitiveDataInterface = null);
    /**
    * Get  non_sensitive_data
    *
    * @return \Aria\Order\Api\Data\NonSensitiveDataInterface[]
    */
    public function getNonSensitiveData();

    /**
    * Set non_sensitive_data
    *
    * @param \Aria\Order\Api\Data\NonSensitiveDataInterface[] $nonSensitiveDataInterface
    * @return \Aria\Order\Api\Data\NonSensitiveDataInterface[] | null
    */
    public function setNonSensitiveData(array $nonSensitiveDataInterface = null);

}