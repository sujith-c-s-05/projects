<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Api\Data;

interface SensitiveDataInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{


    /**
     * Get product_available
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getProductAvailable();
    /**
     * Set product_available
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $productAvailable
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setProductAvailable(array $productAvailable = null);
    /**
     * Get stock_status
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getStockStatus();
    /**
     * Set stock_status
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $stockStatus
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setStockStatus(array $stockStatus = null);
    /**
     * Get supplier_vacation
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getSupplierVacation();
    /**
     * Set supplier_vacation
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $supplierVacation
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setSupplierVacation(array $supplierVacation = null);
    /**
     * Get credit_status
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getCreditStatus();
    /**
     * Set credit_status
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $creditStatus
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setCreditStatus(array $creditStatus = null);
    

}