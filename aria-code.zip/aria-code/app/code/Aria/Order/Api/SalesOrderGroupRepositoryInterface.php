<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Api;

use Magento\Framework\Api\SearchCriteriaInterface;
use Aria\Order\Api\Data\SalesOrderGroupInterface;

interface SalesOrderGroupRepositoryInterface
{
   /**
     * Retrieve orders
     * @param int $orderGroupId
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    
    public function get($orderGroupId);
    /**
     * Retrieve order details
     * @param \Aria\Order\Api\Data\ReGroupOrderInterface $reorder
     * @return \Aria\Order\Api\Data\ReorderResponseInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    
    public function reorderByOrderGroupId(\Aria\Order\Api\Data\ReGroupOrderInterface $reorder);
    /**
     * Retrieve order details
     * @param \Aria\Order\Api\Data\ReorderInterface $reorder
     * @return \Aria\Order\Api\Data\ReorderResponseInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    
    public function reorderByOrderId(\Aria\Order\Api\Data\ReorderInterface $reorder);

    /**
     * Retrieve orders matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\Order\Api\Data\SalesOrderGroupSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Retrieve orders
     * @param int $Id
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getSalesOrderDetails($Id);

    /**
     * save function
     *
     * @param SalesOrderGroupInterface $salesOrderGroup
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function save(
        SalesOrderGroupInterface $salesOrderGroup
    );
     /**
     * Approve order
     * @param int $orderGroupId
     * @param int $userId
     * @param mixed $status
     * @param int $venueId
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function approveOrder($orderGroupId,$userId,$status,$venueId);

    /**
     * Retrieve orders matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\Order\Api\Data\SalesOrderGroupSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getPendingList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );
}
