<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\Order\Model;

use Aria\Order\Api\SalesOrderGroupRepositoryInterface;
use Aria\Order\Api\Data\SalesOrderGroupInterfaceFactory;
use Aria\Order\Api\Data\SalesOrderGroupSearchResultsInterfaceFactory;
use Aria\Order\Model\ResourceModel\SalesOrderGroup as ResourceSalesOrderGroup;
use Aria\Order\Model\ResourceModel\SalesOrderGroup\CollectionFactory as SalesOrderGroupCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Aria\Order\Api\Data\SalesOrderGroupInterface;
use Aria\SupplyCompanyAccount\Api\DCRepositoryInterface;
use Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Aria\CartManagement\Api\MultiCartRepositoryInterface;
use Aria\CartManagement\Api\Data\MultiCartInterfaceFactory;
use Aria\CartManagement\Api\Data\MultiCartItemInterfaceFactory;
use Aria\ProductManagement\Model\VenueCreditstatusRepository;
use Aria\Venue\Model\VenueUserRepository;
use Magento\Store\Model\ScopeInterface;
use Aria\Order\Helper\Data as HelperData;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Mail\Template\TransportBuilder;


use Aria\Venue\Api\VenueUserRoleMappingRepositoryInterface;
use Magento\Framework\Exception\AuthorizationException;
use Aria\Venue\Model\ResourceModel\VenueUser\CollectionFactory as venueUserCollectionFactory;
use Aria\Order\Model\SalesOrderGroupFactory;

class SalesOrderGroupRepository implements SalesOrderGroupRepositoryInterface
{
    const APPROVED = 'approved';
    const REJECTED = 'rejected';
    const PENDING_APPROVAL = 'pending_approval';
    const STATE_NEW = 'new';
    const CANCELED = 'canceled';
    const PENDING = 'pending';


    protected $SalesOrderGroupCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;

    protected $salesOrderGroupFactory;

    protected $searchResultsFactory;

    private $storeManager;

    protected $_orderCollectionFactory;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataSalesOrderGroupFactory;

    protected $supplyCompanyRepositoryInterface;

    protected $dCRepositoryInterface;
    // protected $salesordergroupRepositoryInterface;

    /**
     * @var HelperData
     */
    protected $helper;

    protected $timezone;

    /**
     * @param ResourceSalesOrderGroup $resource
     * @param SalesOrderGroupFactory $salesOrderGroupFactory
     * @param SalesOrderGroupInterfaceFactory $dataSalesOrderGroupFactory
     * @param SalesOrderGroupCollectionFactory $salesOrderGroupCollectionFactory
     * @param SalesOrderGroupSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param Aria\SupplyCompanyAccount\Api\DCRepositoryInterface $dCRepositoryInterface
     * @param Aria\SupplyCompanyAccount\Api\SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface
     * 
     */
    public function __construct(
        ResourceSalesOrderGroup $resource,
        SalesOrderGroupFactory $salesOrderGroupFactory,
        SalesOrderGroupInterfaceFactory $dataSalesOrderGroupFactory,
        SalesOrderGroupCollectionFactory $salesOrderGroupCollectionFactory,
        SalesOrderGroupSearchResultsInterfaceFactory $searchResultsFactory,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory  $orderCollectionFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        DCRepositoryInterface $dCRepositoryInterface,
        SupplyCompanyRepositoryInterface $supplyCompanyRepositoryInterface,
        TimezoneInterface $timezone,
        OrderRepositoryInterface $orderRepositoryInterface,
        MultiCartRepositoryInterface $multiCartRepositoryInterface,
        MultiCartInterfaceFactory $multiCartInterfaceFactory,
        MultiCartItemInterfaceFactory $multiCartItemInterfaceFactory,
        VenueCreditstatusRepository $venueCreditstatusRepository,
        \Aria\Venue\Api\VenueRepositoryInterface $venueRepository,
        \Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany\CollectionFactory $supplierCollectionFactory,
        \Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Sales\Api\Data\OrderInterfaceFactory $orderFactory,
        VenueUserRepository $venueUserRepository,
        \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface,
        HelperData $helper,
        \Magento\Sales\Model\Order\Address\Renderer $address,
        \Aria\SupplyCompanyAccount\Api\DCRepositoryInterface $dc,
        StateInterface $state,
        TransportBuilder $transportBuilder,
        VenueUserRoleMappingRepositoryInterface $venueUserRoleMappingRepositoryInterface,
        VenueUserCollectionFactory $venueUserCollectionFactory,
        \Aria\Venue\Helper\Data $permissionHelper,
        \Aria\HospitalityGroup\Api\HospitalityGroupRepositoryInterface $hospGroup,
        SalesOrderGroupFactory $salesOrderGroupModelFactory,
        \Magento\Sales\Model\OrderRepositoryFactory $orderRepositoryFactory
    ) {
        $this->resource = $resource;
        $this->salesOrderGroupFactory = $salesOrderGroupFactory;
        $this->salesOrderGroupCollectionFactory = $salesOrderGroupCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->collectionProcessor = $collectionProcessor;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->supplyCompanyRepositoryInterface = $supplyCompanyRepositoryInterface;
        $this->dCRepositoryInterface = $dCRepositoryInterface;
        $this->timezone = $timezone;
        $this->orderRepositoryInterface = $orderRepositoryInterface;
        $this->multiCartRepositoryInterface = $multiCartRepositoryInterface;
        $this->multiCartInterfaceFactory = $multiCartInterfaceFactory;
        $this->multiCartItemInterfaceFactory = $multiCartItemInterfaceFactory;
        $this->venueCreditstatusRepository = $venueCreditstatusRepository;
        $this->venueRepository = $venueRepository;
        $this->quoteFactory = $quoteFactory;
        $this->supplierCollectionFactory = $supplierCollectionFactory;
        $this->venueUserRepository = $venueUserRepository;
        $this->orderFactory = $orderFactory;
        $this->orderRepository = $orderRepository;
        $this->participantsRepositoryInterface = $participantsRepositoryInterface;
        $this->helper = $helper;
        $this->address = $address;
        $this->dc = $dc;
        $this->inlineTranslation = $state;
        $this->transportBuilder = $transportBuilder;
        $this->hospitalityGroupRepositoryInterface = $hospGroup;

        // $this->salesOrderGroupRepositoryInterface = $salesordergroupRepositoryInterface;

        $this->venueUserRoleMappingRepositoryInterface = $venueUserRoleMappingRepositoryInterface;
        $this->venueUserCollectionFactory = $venueUserCollectionFactory;
        $this->permissionHelper = $permissionHelper;
        $this->salesOrderGroupModelFactory = $salesOrderGroupModelFactory;
        $this->orderRepositoryFactory = $orderRepositoryFactory;
    }


    /**
     * {@inheritdoc}
     */
    public function get($orderGroupId)
    {
        $salesOrderGroup = $this->salesOrderGroupFactory->create();
        $this->resource->load($salesOrderGroup, $orderGroupId);
        if (!$salesOrderGroup->getId()) {
            throw new NoSuchEntityException(__('Order with id "%1" does not exist.', $orderGroupId));
        }
        return $salesOrderGroup->getDataModel();
    }
    /**
     * {@inheritdoc}
     */
    public function reorderByOrderGroupId(\Aria\Order\Api\Data\ReGroupOrderInterface $reorder)
    {
        $reorderData = [];
        $reoderResult = [];
        $finalResult = [];
        $validStatus = true;
        $orderGroupId = $reorder->getGroupOrderId();
        $cartId = $reorder->getQuoteId();
        $venueId = $reorder->getVenueId();
        $quote = $this->quoteFactory->create()->loadByIdWithoutStore($cartId);
        if (!$quote->getId()) {
            throw new NoSuchEntityException(__('Quote with id "%1" does not exist.', $cartId));
        }
        $orderGroup = $this->get($orderGroupId);
        $venueModel =  $this->venueRepository->get($venueId);
        $salesOrderDetails = $this->_orderCollectionFactory->create();
        $orderDetails = $salesOrderDetails->addFieldToFilter('group_order_id', $orderGroupId)
            ->addFieldToSelect('entity_id')
            ->addFieldToSelect('dcid')
            ->addFieldToSelect('group_order_id')
            ->addFieldToSelect('customer_email');
        $salesOrders = $orderDetails->getData();
        foreach ($salesOrders as $order) {
            $orderData = [];
            $orderDetails = $this->orderRepositoryInterface->get($order['entity_id']);
            $orderData = $this->getOrderData($orderDetails, $venueId);
            $reorderData = array_merge($reorderData, $orderData);
        }
        $reorderData = $this->setMov($reorderData);
        foreach ($reorderData as $reorder) {
            if (!$this->validateCriteria($reorder['sensitive_data']) || !$this->validateCriteria($reorder['non_sensitive_data'])) {
                $validStatus = false;
            }
        }
        if ($validStatus) {
            $reoderResult['cart_status'] = true;
        } else {
            $reoderResult['cart_status'] = false;
        }
        $reoderResult['order_details'] = $reorderData;
        $finalResult['reorder_info'] = $reoderResult;
        return $finalResult;
    }
    /**
     * {@inheritdoc}
     */
    public function reorderByOrderId(\Aria\Order\Api\Data\ReorderInterface $reorder)
    {
        $reorderData = [];
        $reoderResult = [];
        $finalResult = [];
        $validStatus = true;
        $orderId = $reorder->getOrderId();
        $cartId = $reorder->getQuoteId();
        $venueId = $reorder->getVenueId();
        $orderDetails = $this->orderRepositoryInterface->get($orderId);
        $quote = $this->quoteFactory->create()->loadByIdWithoutStore($cartId);
        if (!$quote->getId()) {
            throw new NoSuchEntityException(__('Quote with id "%1" does not exist.', $cartId));
        }
        if (!$orderDetails->getId()) {
            throw new NoSuchEntityException(__('Order with id "%1" does not exist.', $orderId));
        }
        $venueModel =  $this->venueRepository->get($venueId);
        $reorderData = $this->getOrderData($orderDetails, $venueId);
        $reorderData = $this->setMov($reorderData);
        foreach ($reorderData as $reorder) {
            if (!$this->validateCriteria($reorder['sensitive_data']) || !$this->validateCriteria($reorder['non_sensitive_data'])) {
                $validStatus = false;
            }
        }
        if ($validStatus) {
            $reoderResult['cart_status'] = true;
        } else {
            $reoderResult['cart_status'] = false;
        }
        $reoderResult['order_details'] = $reorderData;
        $finalResult['reorder_info'] = $reoderResult;
        return $finalResult;
    }
    /**
     * {@inheritdoc}
     */
    public function getOrderData($order, $venueId)
    {
        $productsInfo = [];
        $supllierId = $order->getExtensionAttributes()->getsupplierId();
        foreach ($order->getItems() as $key => $item) {
            $productId = $item->getProductId();
            $itemInfo = [];
            $itemInfo['product_data'] = $this->getProductData($item, $order);
            $itemInfo['sensitive_data'] = $this->getSensitiveData($item, $venueId, $supllierId);
            $itemInfo['non_sensitive_data'] = $this->getNonSensitiveData($item, $order);
            $productsInfo[] = $itemInfo;
        }
        return $productsInfo;
    }
    /**
     * {@inheritdoc}
     */
    public function getProductData($item, $order)
    {
        $productData = [];
        $supllierId = $order->getExtensionAttributes()->getSupplierId();
        $supllierName = $order->getExtensionAttributes()->getSupplierName();
        $currentTotal = $item->getExtensionAttributes()->getCurrentTotal();
        $currentFinalPrice = $item->getExtensionAttributes()->getCurrentPrice();
        $productData['product_name'] = $item->GetName();
        $productData['product_id'] = $item->getProductId();
        $productData['supplier_id'] = $supllierId;
        $productData['supplier_name'] = $supllierName;
        $productData['old_price'] = $item->getPrice();
        $productData['new_price'] = $currentFinalPrice;
        $productData['qty_ordered'] = $item->getQtyOrdered();
        $productData['current_total'] = $currentTotal;
        return $productData;
    }

    /**
     * {@inheritdoc}
     */
    public function getSensitiveData($item, $venueId, $supplierId)
    {
        $sensitiveData = [];
        $currentCredit = true;
        $stockStatus = $item->getExtensionAttributes()->getStockStatus();
        $available = $item->getExtensionAttributes()->getAvailable();
        $availableStatus = false;
        if ($available && $available != 2) {
            $availableStatus = true;
        }
        $company = $this->getCustomerIdBySupplierId($supplierId);
        $creditStatus = $this->venueCreditstatusRepository->getCreditStatus($company->getCompanyAdmin(), $venueId);
        if ($creditStatus->getId()) {
            $currentCredit = $creditStatus->getStatus();
        }
        $supplierVacation = $item->getExtensionAttributes()->getSupplierVacation();
        $sensitiveData['product_available'] = $this->getValidatedData($availableStatus, 'product_available');
        $sensitiveData['stock_status'] = $this->getValidatedData($stockStatus, 'stock_status');
        $sensitiveData['supplier_vacation'] = $this->getValidatedData($supplierVacation, 'supplier_vacation');
        $sensitiveData['credit_status'] = $this->getValidatedData($currentCredit, 'credit_status');
        return $sensitiveData;
    }

    /**
     * {@inheritdoc}
     */
    public function getNonSensitiveData($item, $order)
    {
        $nonSensitiveData = [];
        $currentFinalPrice = $item->getExtensionAttributes()->getCurrentPrice();
        $minQty = $item->getExtensionAttributes()->getMinimumQty();
        $maxQty = $item->getExtensionAttributes()->getMaximumQty();
        $currentTotal = $item->getExtensionAttributes()->getCurrentTotal();
        $nonSensitiveData['min_qty'] = $this->getValidatedData(($item->getQtyOrdered() >= $minQty), 'min_qty');
        $nonSensitiveData['max_qty'] = $this->getValidatedData(($item->getQtyOrdered() <= $maxQty), 'max_qty');
        $nonSensitiveData['price_variation'] = $this->getValidatedData(($currentFinalPrice - $item->getPrice() == 0), 'price_variation');
        return $nonSensitiveData;
    }
    /**
     * {@inheritdoc}
     */
    public function setMov($reorderData)
    {
        $movTotal = [];
        foreach ($reorderData as $product) {
            $productData = $product['product_data'];
            $supplierId = $productData['supplier_id'];
            $currentTotal = $productData['current_total'];
            $sensitiveData = $product['sensitive_data'];
            $nonSensitiveData = $product['non_sensitive_data'];
            if ($this->validateCriteria($sensitiveData)) {
                if (!isset($movTotal[$supplierId])) {
                    $movTotal[$supplierId] = $currentTotal;
                } else {
                    $movTotal[$supplierId] = $movTotal[$supplierId] + $currentTotal;
                }
            }
        }

        foreach ($reorderData as $productKey => $product) {
            $nonSensitiveData = $product['non_sensitive_data'];
            $productData = $product['product_data'];
            $supplierId = $productData['supplier_id'];
            $currentTotal = $productData['current_total'];
            $supplyCompanyDetails = $this->supplyCompanyRepositoryInterface->get($supplierId);
            $mov = $supplyCompanyDetails->getMov();
            if (!empty($movTotal) && isset($movTotal[$supplierId])) {
                $reorderData[$productKey]['non_sensitive_data']['mov'] = $this->getValidatedData(($movTotal[$supplierId] >= $mov), 'mov');
            } else {
                $reorderData[$productKey]['non_sensitive_data']['mov'] = $this->getValidatedData(($currentTotal >= $mov), 'mov');
            }
        }

        return $reorderData;
    }
    /**
     * {@inheritdoc}
     */
    public function getValidatedData($criteriaValue, $criteriaCode)
    {
        $criteriaInfo = [];
        if ($criteriaValue) {
            $criteriaInfo['status'] = true;
        } else {
            $criteriaInfo['status'] = false;
            $errorMsg = $this->getErrorMsgs();
            $criteriaInfo['message'] = $errorMsg[$criteriaCode];
        }
        return $criteriaInfo;
    }
    /**
     * {@inheritdoc}
     */
    public function getErrorMsgs()
    {
        $errorMessages = [];
        $errorMessages['product_available'] = __('Product is not available.');
        $errorMessages['stock_status'] = __('Item out of stock.');
        $errorMessages['supplier_vacation'] = __('Supplier is on vacation.');
        $errorMessages['credit_status'] = __('No credit available.');
        $errorMessages['mov'] = __('MOV not met.');
        $errorMessages['min_qty'] = __('Quantity less than minimum quantity.');
        $errorMessages['max_qty'] = __('Quantity greater than maximum quantity.');
        $errorMessages['price_variation'] = __('Price is changed from last order.');
        return $errorMessages;
    } //
    /**
     * {@inheritdoc}
     */
    public function validateCriteria($reorder)
    {
        foreach ($reorder as $criteria) {
            if (isset($criteria['status']) && !$criteria['status']) {
                return false;
            }
        }
        return true;
    }
    /**
     * {@inheritdoc}
     */
    public function moveProductstoCart($orderData, $cartId)
    {
        $items = [];
        foreach ($orderData as $data) {
            $item = $this->multiCartItemInterfaceFactory->create();
            $item->setProductId($data['product_data']['product_id']);
            $item->setQty($data['product_data']['qty_ordered']);
            $items[] = $item;
        }
        $moveCartData = $this->multiCartInterfaceFactory->create();
        $moveCartData->setQuoteId($cartId);
        $moveCartData->setItems($items);
        return $this->multiCartRepositoryInterface->multicart($moveCartData);
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->salesOrderGroupCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\Order\Api\Data\SalesOrderGroupInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $orderGroupId = $model->getOrderGroupId();
            $salesOrderDetails = $this->_orderCollectionFactory->create();
            $orderDetails = $salesOrderDetails->addFieldToFilter('group_order_id', $model->getOrderGroupId());
            $dcIds = $orderDetails->addFieldToSelect('dcid')->addFieldToSelect('status')
                ->addFieldToSelect('entity_id')
                ->addFieldToSelect('customer_email')
                ->addFieldToSelect('supplier_order_inc_id')
                ->addFieldToSelect('created_at')
                ->addFieldToSelect('customer_firstname')
                ->addFieldToSelect('customer_lastname');
            $salesOrders = $dcIds->getData();
            $orderStatus = [];
            foreach ($salesOrders as $salesOrder) {
                $dcId = $salesOrder['dcid'];
                $status = $salesOrder['status'];
                $orderId = $salesOrder['entity_id'];
                $supplierorderIncId = $salesOrder['supplier_order_inc_id'];
                $customerEmail = $salesOrder['customer_email'];
                $orderPlacedDate = $salesOrder['created_at'];
                if (is_numeric($dcId) && $dcId > 0) {
                    $dcDetails = $this->dCRepositoryInterface->get($dcId);
                    $supplyCompanyId = $dcDetails->getSupplyId();
                    $supplyCompanyDetails = $this->supplyCompanyRepositoryInterface->get($supplyCompanyId);
                    $supplyCompanyName = $supplyCompanyDetails->getCompanyName();
                }
                $order['order_id'] = $orderId ?? '';
                $order['supplier_order_inc_id'] = $supplierorderIncId ?? '';
                $order['customer_email'] = $customerEmail ?? '';
                $order['supplier_name'] = $supplyCompanyName ?? '';
                $order['supplier_id'] = $supplyCompanyId ?? '';
                $order['status'] = $status;
                $cutofftime = $this->scopeConfig->getValue('ordermanagement/general/display_text', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                $currentTimeStamp = $this->timezone->date()->getTimeStamp();
                $currentDateTime = date("Y-m-d H:i:s", $currentTimeStamp);

                $d1 = strtotime($orderPlacedDate);
                $d2 = strtotime($currentDateTime);
                $interval = $d2 - $d1;
                $intervalInMin = floor($interval / 60);

                $cutoffTimeInMinutes = (int)$cutofftime * 60;
                $enableCancelButton = false;
                if ($intervalInMin <= $cutoffTimeInMinutes) {
                    $enableCancelButton = true;
                }
                $order['cut_off_time'] = $cutofftime;
                $order['enable_cancel_button'] = $enableCancelButton;
                $orderStatus[] = $order;
                $model->setName($salesOrder['customer_firstname'] . ' ' . $salesOrder['customer_lastname']);
                $model->setFirstName($salesOrder['customer_firstname']);
                $model->setLastName($salesOrder['customer_lastname']);
            }

            $model->setStatus($orderStatus);
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function getSalesOrderDetails($Id)
    {
        $salesGroupDetails = $this->salesOrderGroupCollectionFactory->create();
        $salesOrderDetails = $this->_orderCollectionFactory->create();
        $salesGroupDetails->getSelect()->join(
            ['sales_order' => $salesOrderDetails->getTable('sales_order')],
            'main_table.order_group_id = sales_order.group_order_id AND sales_order.entity_id=' . $Id,
            [
                'venue_id' => 'sales_order.VenueId',
                'order_group_id' => 'main_table.order_group_id',
                'order_group_increment_id' => 'main_table.order_group_increment_id',
                'dc_id' => 'sales_order.dcid',
                'order_id' => 'sales_order.entity_id',
                'increment_id' => 'sales_order.increment_id',
                'venue_user_id' => 'main_table.venue_user_id',
                'no_of_items' => 'main_table.no_of_items',
                'cart_total' => 'main_table.cart_total',
                'supplier_order_inc_id' => 'sales_order.supplier_order_inc_id'
            ]
        );
        $items = [];
        foreach ($salesGroupDetails as $model) {

            $items[] = $model->getData();
        }

        return $items;
    }

    /**
     * Save sales order group table.
     * @inheritDoc
     *
     * @throws CouldNotSaveException
     */
    public function save(SalesOrderGroupInterface $object)
    {
        try {
            $salesOrderGroup = $this->resource->save($object);
            return $salesOrderGroup;
        } catch (\Exception $e) {
            throw new CouldNotSaveException(__($e->getMessage()));
        }
        return $object;
    }
    /**
     * {@inheritdoc}
     */
    public function getCustomerIdBySupplierId($supplierId)
    {
        $companies = $this->supplierCollectionFactory->create();
        $company = $companies->addFieldToFilter('supplycompany_id', ['eq' => $supplierId])->getFirstItem();
        return $company;
    }
    public function approveOrder($orderGroupId, $userId, $status, $venueId)
    {
        $groupOrder = $this->get($orderGroupId);
        if ($venueId != $groupOrder->getVenueId()) {
            throw new CouldNotSaveException(__("Venue Does not Match Wth the Order"));
        }
        $this->checkPermission($venueId, $userId);
        $this->changeGroupOrderStatus($orderGroupId, $status);
        $this->sendNotification($status, $groupOrder, $userId);
        if ($status == self::APPROVED) {
            $this->setForApproval($orderGroupId);

            //send email to suppliers
            $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId());
            $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
            $sender_name  = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
            $from = ['email' => $email, 'name' => $sender_name];
            $salesOrderDetails = $this->_orderCollectionFactory->create();

            $salesDetails = $salesOrderDetails->addFieldToFilter('group_order_id', $orderGroupId);
            $orderIds = [];
            $orderDeliverySlot=[];
            foreach ($salesDetails as $order) {
                $data = $order->getData();
                $order_id =  $order->getIncrementId();
                $id = $order->getEntityId();
                $orderData = $this->orderRepository->get($id);
                $orderIds[] = $id;
                $supplier_order_inc_id = $order->getSupplierOrderIncId();
                $order_date = $order->getCreatedAt();
                $venue_order_id = $order->getGroupOrderId();
                $venue_order_id = sprintf('%08d', $venue_order_id);
                $shipping_address = $this->address->format($order->getShippingAddress(), 'html');
                $email = $order->getCustomerEmail();
                $dcid = $order->getData('dcid');
                $dcObj = $this->dc->get($dcid);
                $dcName = $dcObj->getName();
                $extensionattributes = $orderData->getExtensionAttributes();
                $supplierId = $extensionattributes->getSupplierId();
                $orderDeliverySlot[$supplierId]=$orderData->getDeliverySlot();
                $templateVars = array(
                    'dcname' => $dcName,
                    'increment_id' => $supplier_order_inc_id,
                    'order_date' => $order_date,
                    'shipping_address' => $shipping_address,
                    'order_id' => $id
                );
                $this->inlineTranslation->suspend();
                $transport = $this->transportBuilder->setTemplateIdentifier('supplier_email_order_template', ScopeInterface::SCOPE_STORE)
                    ->setTemplateOptions($templateOptions)
                    ->setTemplateVars($templateVars)
                    ->setFrom($from)
                    ->addTo($dcObj->getEmail())
                    ->getTransport();
                $transport->sendMessage();
                $this->inlineTranslation->resume();
                //send sms to supplier
                $dcPhone = $dcObj->getPhone();
                $message = 'OrderId : ' . $supplier_order_inc_id . ' Your Order Placed Successfully';
                $this->helper->sendSMS($message, $dcPhone);
            }

            //send email to venue user

            $venueModel =  $this->venueRepository->get($venueId);
            $hosp_id = $venueModel->getHospId();
            $hospModel = $this->hospitalityGroupRepositoryInterface->get($hosp_id);
            $company_name = $hospModel->getCompanyName();

            $templateVars = array(
                'company' => $company_name,
                'increment_id' => $venue_order_id,
                'order_date' => $order_date,
                'shipping_address' => $shipping_address,
                'order_id' => $orderIds,
                'delivery_slot'=>$orderDeliverySlot
            );
            $this->inlineTranslation->suspend();
            $transport = $this->transportBuilder->setTemplateIdentifier('venue_email_order_template', ScopeInterface::SCOPE_STORE)
                ->setTemplateOptions($templateOptions)
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($email)
                ->getTransport();
            $transport->sendMessage();
            $this->inlineTranslation->resume();

            $salesGroupDetails = $this->salesOrderGroupCollectionFactory->create();
            $OrderDetails = $salesGroupDetails->addFieldToFilter('order_group_id', $orderGroupId)->getFirstItem();;
            $venueUserId = $OrderDetails->getVenueUserId();
            $venueUserModel =  $this->venueUserRepository->getById($venueUserId);
            $venueUserPhone = $venueUserModel->getPhone();
            $orderGroupId = $OrderDetails->getOrderGroupId();
            //send sms to venue user
            $orderGroupIncId = sprintf('%08d', $orderGroupId);
            $message = 'OrderId : ' . $orderGroupIncId . ' Your Order Placed Successfully';
            $this->helper->sendSMS($message, $venueUserPhone);
        }
        return true;
    }

    public function checkPermission($venueId, $userId)
    {
        $venueUser =  $this->venueUserRepository->get($userId);
        if ($venueUser->getIsAdmin()) {
            return true;
        }
        return $this->permissionHelper->permissionCheck($venueId, $userId, 'Order Approval');
    }
    public function changeGroupOrderStatus($orderGroupId, $status)
    {
        $salesOrderDetails = $this->_orderCollectionFactory->create();
        $orderDetails = $salesOrderDetails->addFieldToFilter('group_order_id', $orderGroupId)
            ->addFieldToSelect('entity_id')
            ->addFieldToSelect('dcid')
            ->addFieldToSelect('group_order_id')
            ->addFieldToSelect('customer_email');
        $salesOrders = $orderDetails->getData();
        if (empty($salesOrders)) {
            throw new CouldNotSaveException(__("Order not found"));
        }
        foreach ($salesOrders as $order) {
            $this->changeOrderStatus($order['entity_id'], $status);
        }
    }
    public function changeOrderStatus($orderId, $status)
    {
        $orderDetails = $this->orderRepositoryInterface->get($orderId);
        $data = $orderDetails->getStatus();
        if ($data = $orderDetails->getStatus() != "pending_approval") {
            throw new CouldNotSaveException(__("Order status cannot be changed"));
        }

        $order = $this->orderFactory->create();
        $order->setEntityId($orderId);
        if ($status == self::REJECTED) {
            $order->setStatus(self::REJECTED);
            $order->setState(self::CANCELED);
        } else {
            $order->setStatus(self::PENDING);
            $order->setState(self::STATE_NEW);
        }
        return $this->orderRepositoryFactory->create()->save($order);
    }
    public function sendNotification($status, $groupOrder, $userId)
    {
        $user = $this->getVenueUserName($userId);
        if ($status == self::APPROVED) {
            $title = 'order approved';
            $message = __('#' . $groupOrder->getOrderGroupIncrementId() . ' has been approved by ' . $user);
        } elseif ($status == self::REJECTED) {
            $title = 'order rejected';
            $message = __('#' . $groupOrder->getOrderGroupIncrementId() . ' has been rejected by ' . $user);
        }
        $this->participantsRepositoryInterface->saveParticipantNotification(1, $groupOrder->getVenueId(), $groupOrder->getVenueUserId(), $message, 'venue_user', $title);
    }
    /**
     * To get venue user name
     */
    public function getVenueUserName($venueUserId)
    {
        $venueUser =  $this->venueUserRepository->get($venueUserId);

        $venueUserFirstName = $venueUser->getFirstName();
        $venueUserLastName = $venueUser->getLastName();

        $venueUserName = $venueUserFirstName . " " . $venueUserLastName;

        return $venueUserName;
    }

    /**
     * {@inheritdoc}
     */
    public function getPendingList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        try {
            $venueId = $this->getVenueId($criteria);
            $venueUserId = $this->getVenueUserId($criteria);
            $permissionCheck = $this->venueUserRoleMappingRepositoryInterface->isPermissionAppproved($venueUserId, $venueId, 'Order Approval');
        } catch (AuthorizationException $exception) {
            $permissionCheck = false;
        }

        if ($permissionCheck) {
            foreach ($criteria->getFilterGroups() as $filterGroup) {
                foreach ($filterGroup->getFilters() as $filter) {
                    $field = $filter->getField();
                    if ($field == 'venue_user_id') {
                        $filter->setValue('0');
                        $filter->setConditionType('neq');
                    }
                }
            }
        }
        $collection = $this->salesOrderGroupCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\Order\Api\Data\SalesOrderGroupInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);
        $collection->addFieldToFilter('for_approval', array('in' => array(1, 2)));

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        $count = 0;
        foreach ($collection as $model) {
            $orderGroupId = $model->getOrderGroupId();
            $salesOrderDetails = $this->_orderCollectionFactory->create();
            $isAddtoCart = $model->getIsMovedToCart();
            $status = false;
            $orderDetails = $salesOrderDetails->addFieldToFilter('group_order_id', $model->getOrderGroupId());
            $dcIds = $orderDetails->addFieldToSelect('dcid')->addFieldToSelect('status')
                ->addFieldToSelect('entity_id')
                ->addFieldToSelect('customer_email')
                ->addFieldToSelect('supplier_order_inc_id')
                ->addFieldToSelect('created_at')
                ->addFieldToSelect('customer_firstname')
                ->addFieldToSelect('customer_lastname');
            $salesOrders = $dcIds->getData();
            $orderStatus = [];
            foreach ($salesOrders as $salesOrder) {
                $dcId = $salesOrder['dcid'];
                $status = $salesOrder['status'];
                $orderId = $salesOrder['entity_id'];
                $supplierorderIncId = $salesOrder['supplier_order_inc_id'];
                $customerEmail = $salesOrder['customer_email'];
                $orderPlacedDate = $salesOrder['created_at'];
                if (is_numeric($dcId) && $dcId > 0) {
                    $dcDetails = $this->dCRepositoryInterface->get($dcId);
                    $supplyCompanyId = $dcDetails->getSupplyId();
                    $supplyCompanyDetails = $this->supplyCompanyRepositoryInterface->get($supplyCompanyId);
                    $supplyCompanyName = $supplyCompanyDetails->getCompanyName();
                }
                $order['order_id'] = $orderId ?? '';
                $order['supplier_order_inc_id'] = $supplierorderIncId ?? '';
                $order['customer_email'] = $customerEmail ?? '';
                $order['supplier_name'] = $supplyCompanyName ?? '';
                $order['supplier_id'] = $supplyCompanyId ?? '';
                $order['status'] = $status;
                $cutofftime = $this->scopeConfig->getValue('ordermanagement/general/display_text', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
                $currentTimeStamp = $this->timezone->date()->getTimeStamp();
                $currentDateTime = date("Y-m-d H:i:s", $currentTimeStamp);
                $d1 = strtotime($orderPlacedDate);
                $d2 = strtotime($currentDateTime);
                $interval = $d2 - $d1;
                $intervalInMin = floor($interval / 60);
                $cutoffTimeInMinutes = (int)$cutofftime * 60;
                $enableCancelButton = false;
                if ($intervalInMin <= $cutoffTimeInMinutes) {
                    $enableCancelButton = true;
                }
                $order['cut_off_time'] = $cutofftime;
                $order['enable_cancel_button'] = $enableCancelButton;
                $orderStatus[] = $order;
                $model->setName($salesOrder['customer_firstname'] . ' ' . $salesOrder['customer_lastname']);
            }
            if (!$isAddtoCart && $status == 'rejected') {
                $products =  $this->getProductDetails($orderGroupId, $venueId);
                $model->setProducts($products);
            }
            $model->setStatus($orderStatus);
            $items[] = $model->getDataModel();
        }
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * To get venue user Id from 
     */
    public function getVenueUserId($criteria)
    {
        $venueUserId = "";
        foreach ($criteria->getFilterGroups() as $filterGroup) {
            foreach ($filterGroup->getFilters() as $filter) {
                $field = $filter->getField();
                if ($field == 'venue_user_id') {
                    $venueUserId = $filter->getValue();
                }
            }
        }

        return $venueUserId;
    }

    /**
     * To get venue Id from collection filters
     */
    public function getVenueId($criteria)
    {
        $venueId = "";
        foreach ($criteria->getFilterGroups() as $filterGroup) {
            foreach ($filterGroup->getFilters() as $filter) {
                $field = $filter->getField();
                if ($field == 'venue_id') {
                    $venueId = $filter->getValue();
                }
            }
        }

        return $venueId;
    }

    /**
     * To get item details
     */
    public function getProductDetails($orderGroupId, $venueId)
    {
        $reorderData = [];
        $reoderResult = [];
        $finalResult = [];
        $validStatus = true;

        $orderGroup = $this->get($orderGroupId);
        $venueModel =  $this->venueRepository->get($venueId);
        $salesOrderDetails = $this->_orderCollectionFactory->create();
        $orderDetails = $salesOrderDetails->addFieldToFilter('group_order_id', $orderGroupId)
            ->addFieldToSelect('entity_id')
            ->addFieldToSelect('dcid')
            ->addFieldToSelect('group_order_id')
            ->addFieldToSelect('customer_email');
        $salesOrders = $orderDetails->getData();
        foreach ($salesOrders as $order) {
            $orderData = [];
            $orderDetails = $this->orderRepositoryInterface->get($order['entity_id']);
            $orderData = $this->getOrderData($orderDetails, $venueId);
            $reorderData = array_merge($reorderData, $orderData);
        }
        $reorderData = $this->setMov($reorderData);
        foreach ($reorderData as $reorder) {
            if (!$this->validateCriteria($reorder['sensitive_data']) || !$this->validateCriteria($reorder['non_sensitive_data'])) {
                $validStatus = false;
            }
        }
        if ($validStatus) {
            $reoderResult['cart_status'] = true;
        } else {
            $reoderResult['cart_status'] = false;
        }
        $reoderResult['order_details'] = $reorderData;
        $finalResult['reorder_info'] = $reoderResult;
        return $finalResult;
    }

    /**
     * Save for approval 
     */
    public function setForApproval($orderGroupId)
    {
        $orderGroup = $this->salesOrderGroupModelFactory->create()->load($orderGroupId);
        $orderGroup->setForApproval(2);
        $orderGroup->save();
    }
}
