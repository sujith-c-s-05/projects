<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Model;

use Aria\Order\Api\Data\SalesOrderGroupInterface;
use Aria\Order\Api\Data\SalesOrderGroupInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class SalesOrderGroup extends \Magento\Framework\Model\AbstractModel
{

    protected $salesOrderGroupDataFactory;
    protected $_eventPrefix = 'Aria_Sales_Order_Group';
    protected $dataObjectHelper;
    protected $_salesOrderGroupCollectionFactory;

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param SalesOrderGroupInterfaceFactory $salesOrderGroupDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\Order\Model\ResourceModel\SalesOrderGroup $resource
     * @param \Aria\Order\Model\ResourceModel\SalesOrderGroup\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        SalesOrderGroupInterfaceFactory $salesOrderGroupDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\Order\Model\ResourceModel\SalesOrderGroup $resource,
        \Aria\Order\Model\ResourceModel\SalesOrderGroup\Collection $resourceCollection,
        array $data = []
    ) {
        $this->salesOrderGroupInterfaceFactory = $salesOrderGroupDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve Order model with Order data
     * @return SalesOrderGroupInterface
     */
    public function getDataModel()
    {
        $OrderData = $this->getData();

        $OrderDataObject = $this->salesOrderGroupInterfaceFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $OrderDataObject,
            $OrderData,
            SalesOrderGroupInterface::class
        );

        return $OrderDataObject;
    }

 
}