<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Model\Data;

use Aria\Order\Api\Data\ReorderResponseInterface;

class ReorderResponse extends \Magento\Framework\Api\AbstractExtensibleObject implements ReorderResponseInterface
{
    /**
     * Get cart_status
     * @return bool
     */
    public function getCartStatus()
    {
        return $this->_get('cart_status');
    }

    /**
     * Set cart_status
     * @param bool $cartStatus
     * @return \Aria\Order\Api\Data\ReorderResponseInterface
     */

    public function setCartStatus($cartStatus)
    {
        return $this->setData('cart_status', $cartStatus);
    }
    /**
    * Get  order_details
    *
    * @return \Aria\Order\Api\Data\OrderDetailsInterface[]
    */
    public function getOrderDetails()
    {
        return $this->_get('order_details');
    }
    /**
    * Set order_details
    *
    * @param \Aria\Order\Api\Data\OrderDetailsInterface[] $orderDetailsInterface
    * @return \Aria\Order\Api\Data\OrderDetailsInterface[] | null
    */
    public function setOrderDetails(array $orderDetailsInterface = null)
    {
        return $this->setData('order_details', $orderDetailsInterface);
    }
}