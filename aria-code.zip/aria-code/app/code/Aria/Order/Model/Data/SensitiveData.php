<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Model\Data;

use Aria\Order\Api\Data\SensitiveDataInterface;

class SensitiveData extends \Magento\Framework\Api\AbstractExtensibleObject implements SensitiveDataInterface
{
    /**
     * Get product_available
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getProductAvailable()
    {
        return $this->_get('product_available');
    }
    /**
     * Set product_available
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $productAvailable
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setProductAvailable(array $productAvailable = null)
    {
        return $this->setData('product_available', $productAvailable);
    }
    /**
     * Get stock_status
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getStockStatus()
    {
        return $this->_get('stock_status');
    }
    /**
     * Set stock_status
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $stockStatus
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setStockStatus(array $stockStatus = null)
    {
        return $this->setData('stock_status', $stockStatus);
    }
    /**
     * Get supplier_vacation
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getSupplierVacation()
    {
        return $this->_get('supplier_vacation');
    }
    /**
     * Set supplier_vacation
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $supplierVacation
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setSupplierVacation(array $supplierVacation = null)
    {
        return $this->setData('supplier_vacation', $supplierVacation);
    }
    /**
     * Get credit_status
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getCreditStatus()
    {
        return $this->_get('credit_status');
    }
    /**
     * Set credit_status
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $creditStatus
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setCreditStatus(array $creditStatus = null)

    {
        return $this->setData('credit_status', $creditStatus);
    }
}