<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Model\Data;

use Aria\Order\Api\Data\NonSensitiveDataInterface;

class NonSensitiveData extends \Magento\Framework\Api\AbstractExtensibleObject implements NonSensitiveDataInterface
{
    /**
     * Get mov
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getMov()
    {
        return $this->_get('mov');
    }
    /**
     * Set mov
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $mov
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setMov(array $mov=null)
    {
        return $this->setData('mov', $mov);
    }
    /**
     * Get min_qty
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getMinQty()
    {
        return $this->_get('min_qty');
    }
    /**
     * Set min_qty
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $minQty
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setMinQty(array $minQty=null)
    {
        return $this->setData('min_qty', $minQty);
    }
    /**
     * Get max_qty
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getMaxQty()
    {
        return $this->_get('max_qty');
    }
    /**
     * Set max_qty
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $maxQty
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setMaxQty(array $maxQty=null)
    {
        return $this->setData('max_qty', $maxQty);
    }
    /**
     * Get price_variation
     * @return \Aria\Order\Api\Data\CriteriaDataInterface[]
     */
    public function getPriceVariation()
    {
        return $this->_get('price_variation');
    }
    /**
     * Set price_variation
     * @param \Aria\Order\Api\Data\CriteriaDataInterface[] $priceVariation
     * @return \\Aria\Order\Api\Data\CriteriaDataInterface[] | null
     */
    public function setPriceVariation(array $priceVariation=null)
    {
        return $this->setData('price_variation', $priceVariation);
    }
}