<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Model\Data;

use Aria\Order\Api\Data\SalesOrderGroupInterface;

class SalesOrderGroup extends \Magento\Framework\Api\AbstractExtensibleObject implements SalesOrderGroupInterface
{

   
    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\Order\Api\Data\SalesOrderGroupExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\Order\Api\Data\SalesOrderGroupExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\Order\Api\Data\SalesOrderGroupExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }
    
    /**
     * Get orderGroupId
     * @return int|null
     */
    public function getOrderGroupId()
    {
        return $this->_get(self::ORDERGROUP_ID);
    }

    /**
     * Set orderGroupId
     * @param int $orderGroupId
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setOrderGroupId($orderGroupId)
    {
        return $this->setData(self::ORDERGROUP_ID, $orderGroupId);
    }

    /**
     * Get orderGroupIncrementId
     * @return string|null
     */
    public function getOrderGroupIncrementId()
    {
        return $this->_get(self::ORDERGROUPINCREMENTID_ID);
    }

    /**
     * Set orderGroupIncrementId
     * @param string $orderGroupIncrementId
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setOrderGroupIncrementId($orderGroupIncrementId)
    {
        return $this->setData(self::ORDERGROUPINCREMENTID_ID, $orderGroupIncrementId);
    }

    /**
     * Get venueId
     * @return int|null
     */
    public function getVenueId()
    {
        return $this->_get(self::VENUE_ID);
    }

    /**
     * Set venueId
     * @param int $venueId
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setVenueId($venueId)
    {
        return $this->setData(self::VENUE_ID, $venueId);
    }
     /**
     * Get venueUserId
     * @return int|null
     */
    public function getVenueUserId()
    {
        return $this->_get(self::VENUEUSER_ID);
    }

    /**
     * Set venueUserId
     * @param int $venueUserId
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setVenueUserId($venueUserId)
    {
        return $this->setData(self::VENUEUSER_ID, $venueUserId);
    }
   
    /**
     * Get noOfItems
     * @return int|null
     */
    public function getNoOfItems()
    {
        return $this->_get(self::NOOFITEMS);
    }

    /**
     * Set noOfItems
     * @param int $noOfItems
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setNoOfItems($noOfItems)
    {
        return $this->setData(self::NOOFITEMS, $noOfItems);
    }
  
    /**
     * Get cartTotal
     * @return int|null
     */
    public function getCartTotal()
    {
        return $this->_get(self::CARTTOTAL);
    }

    /**
     * Set cartTotal
     * @param int $cartTotal
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setCartTotal($cartTotal)
    {
        return $this->setData(self::CARTTOTAL, $cartTotal);
    }
   
    /**
     * Get dcId
     * @return int|null
     */
    public function getDcId()
    {
        return $this->_get(self::DC_ID);
    }

    /**
     * Set dcId
     * @param int $dcId
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setDcId($dcId)
    {
        return $this->setData(self::DC_ID, $dcId);
    }
    
     /**
     * Get status
     * @return string[]|null
     */
    public function getStatus()
    {
        return $this->_get('status');
    }

    /**
     * Set status
     * @param string[] $status
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setStatus(array $status)
    {
        return $this->setData('status', $status);
    }
      /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_By
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_active
     * @return bool|true
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }
    /**
     * Get is_delete
     * @return bool|false
     */
     public function getIsDelete()
     {
         return $this->_get(self::IS_DELETE);
     }
 
    /**
      * Set is_delete
      * @param bool $isDelete
      * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
      */
     public function setIsDelete($isDelete)
     {
         return $this->setData(self::IS_DELETE, $isDelete);
     }

     /**
     * Get name
     * @return string|null
     */
    public function getName()
    {
        return $this->_get('name');
    }

    /**
     * Set name
     * @param string $name
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setName($name)
    {
        return $this->setData('name', $name);
    }

    /**
     * Get is_moved_to_cart
     * @return bool|false
     */
    public function getIsMovedToCart()
    {
        return $this->_get('is_moved_to_cart');
    }

   /**
     * Set is_moved_to_cart
     * @param bool $isMovedToCart
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setIsMovedToCart($isMovedToCart)
    {
        return $this->setData('is_moved_to_cart', $isMovedToCart);
    }

    /**
     * Get for_approval
     * @return int|null
     */
    public function getForApproval()
    {
        return $this->_get('for_approval');
    }

   /**
     * Set for_approval
     * @param int $forApproval
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setForApproval($forApproval)
    {
        return $this->setData('for_approval', $forApproval);
    }

     /**
     * Get products
     * @return string[]|null
     */
    public function getProducts()
    {
        return $this->_get('products');
    }

    /**
     * Set products
     * @param string[] $status
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setProducts(array $status)
    {
        return $this->setData('products', $status);
    }

    /**
     * Get first_name
     * @return string|null
     */
    public function getFirstName()
    {
        return $this->_get('first_name');
    }

    /**
     * Set first_name
     * @param string $firstName
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setFirstName($firstName)
    {
        return $this->setData('first_name', $firstName);
    }

    /**
     * Get last_name
     * @return string|null
     */
    public function getLastName()
    {
        return $this->_get('last_name');
    }

    /**
     * Set last_name
     * @param string $lastName
     * @return \Aria\Order\Api\Data\SalesOrderGroupInterface
     */
    public function setLastName($lastName)
    {
        return $this->setData('last_name', $lastName);
    }
}