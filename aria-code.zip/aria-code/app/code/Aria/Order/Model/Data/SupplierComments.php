<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Model\Data;

use Aria\Order\Api\Data\SupplierCommentsInterface;

class SupplierComments extends \Magento\Framework\Api\AbstractExtensibleObject implements SupplierCommentsInterface
{

    /**
     * Get supplierId
     * @return int|null
     */
    public function getSupplierId()
    {
        return $this->_get('supplier_id');
    }

    /**
     * Set supplierId
     * @param int supplierId
     * @return \Aria\Order\Api\Data\SupplierCommentsInterface
     */
    public function setSupplierId($supplierId)
    {
        return $this->setData('supplier_id', $supplierId);
    }

    /**
     * Get comment
     * @return string|null
     */
    public function getComment()
    {
        return $this->_get('comment');
    }

    /**
     * Set comment
     * @param string $comment
     * @return \Aria\Order\Api\Data\SupplierCommentsInterface
     */
    public function setComment($comment)
    {
        return $this->setData('comment', $comment);
    }
}