<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Model\Data;

use Aria\Order\Api\Data\ReGroupOrderInterface;

class ReGroupOrder extends \Magento\Framework\Api\AbstractExtensibleObject implements ReGroupOrderInterface
{
    /**
     * Get quote_id
     * @return int|null
     */
    public function getQuoteId()
    {
        return $this->_get('quote_id');
    }

    /**
     * Set quote_id
     * @param int $quoteId
     * @return \Aria\Order\Api\Data\ReGroupOrderInterface
     */

    public function setQuoteId($quoteId)
    {
        return $this->setData('quote_id', $quoteId);
    }

    /**
     * Get venue_id
     * @return int|null
     */
    public function getVenueId()
    {
        return $this->_get('venue_id');
    }

    /**
     * Set venue_id
     * @param int $venueId
     * @return \Aria\Order\Api\Data\ReGroupOrderInterface
     */
    public function setVenueId($venueId)
    {
        return $this->setData('venue_id', $venueId);
    }

    /**
     * Get group_order_id
     * @return int|null
     */
    public function getGroupOrderId()
    {
        return $this->_get('group_order_id');
    }

    /**
     * Set group_order_id
     * @param int $groupOrderId
     * @return \Aria\Order\Api\Data\ReGroupOrderInterface
     */
    public function setGroupOrderId($groupOrderId)
    {
        return $this->setData('group_order_id', $groupOrderId);
    }
}