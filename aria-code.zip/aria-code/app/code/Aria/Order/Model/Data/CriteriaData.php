<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Model\Data;

use Aria\Order\Api\Data\CriteriaDataInterface;

class CriteriaData extends \Magento\Framework\Api\AbstractExtensibleObject implements CriteriaDataInterface
{
    /**
     * Get status
     * @return bool
     */
    public function getStatus()
    {
        return $this->_get('status');
    }
    /**
     * Set status
     * @param bool $mov
     * @return \Aria\Order\Api\Data\CriteriaDataInterface
     */
    public function setStatus($status)
    {
        return $this->setData('status', $status);
    }
    /**
     * Get message
     * @return string|null
     */
    public function getMessage()
    {
        return $this->_get('message');
    }
    /**
     * Set message
     * @param string $minQty
     * @return \Aria\Order\Api\Data\CriteriaDataInterface
     */
    public function setMessage($message)
    {
        return $this->setData('message', $message);
    }
}