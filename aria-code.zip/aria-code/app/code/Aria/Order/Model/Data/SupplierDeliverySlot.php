<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Model\Data;

use Aria\Order\Api\Data\SupplierDeliverySlotInterface;

class SupplierDeliverySlot extends \Magento\Framework\Api\AbstractExtensibleObject implements SupplierDeliverySlotInterface
{
    /**
     * Get supplier_id
     * @return string
     */
    public function getSupplierId()
    {
        return $this->_get('supplier_id');
    }
    /**
     * Set supplier_id
     * @param string $supplierId
     * @return \Aria\Order\Api\Data\SupplierDeliverySlotInterface
     */
    public function setSupplierId($supplierId)
    {
        return $this->setData('supplier_id', $supplierId);
    }
   /**
     * Get slot
     * @return string|null
     */
    public function getSlot()
    {
        return $this->_get('slot');
    }
     /**
     * Set slot
     * @param string $slot
     * @return \Aria\Order\Api\Data\SupplierDeliverySlotInterface
     */
    public function setSlot($slot)
    {
        return $this->setData('slot', $slot);
    }
}