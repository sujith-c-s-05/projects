<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Model\Data;

use Aria\Order\Api\Data\OrderDetailsInterface;

class OrderDetails extends \Magento\Framework\Api\AbstractExtensibleObject implements OrderDetailsInterface
{
/**
    * Get  product_data
    *
    * @return \Aria\Order\Api\Data\ProductDataInterface[] |null
    */
    public function getProductData()
    {
        return $this->_get('product_data');
    }

    /**
    * Set product_data
    *
    * @param \Aria\Order\Api\Data\ProductDataInterface[] $productDataInterface
    * @return \Aria\Order\Api\Data\ProductDataInterface[] | null
    */
    public function setProductData(array $productDataInterface = null)
    {
        return $this->setData('product_data', $productDataInterface);
    }
    /**
    * Get  sensitive_data
    *
    * @return \Aria\Order\Api\Data\SensitiveDataInterface|null
    */
    public function getSensitiveData()
    {
        return $this->_get('sensitive_data');
    }

    /**
    * Set sensitive_data
    *
    * @param \Aria\Order\Api\Data\SensitiveDataInterface[] $sensitiveDataInterface
    * @return \Aria\Order\Api\Data\SensitiveDataInterface[] | null
    */
    public function setSensitiveData(array $sensitiveDataInterface = null)
    {
        return $this->setData('sensitive_data', $sensitiveDataInterface);
    }
    /**
    * Get  non_sensitive_data
    *
    * @return \Aria\Order\Api\Data\NonSensitiveDataInterface|null
    */
    public function getNonSensitiveData()
    {
        return $this->_get('non_sensitive_data');
    }

    /**
    * Set non_sensitive_data
    *
    * @param \Aria\Order\Api\Data\NonSensitiveDataInterface[] $nonSensitiveDataInterface
    * @return \Aria\Order\Api\Data\NonSensitiveDataInterface[] | null
    */
    public function setNonSensitiveData(array $nonSensitiveDataInterface = null)
    {
        return $this->setData('non_sensitive_data', $nonSensitiveDataInterface);
    }
}