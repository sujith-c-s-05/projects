<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Model\Data;

use Aria\Order\Api\Data\ProductDataInterface;

class ProductData extends \Magento\Framework\Api\AbstractExtensibleObject implements ProductDataInterface
{
/**
     * Get product_name
     * @return string|null
     */
    public function getProductName()
    {
        return $this->_get('product_name');
    }
    /**
     * Set product_name
     * @param string $productName
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setProductName($productName)
    {
        return $this->setData('product_name', $productName);
    }
    /**
     * Get product_id
     * @return int|null
     */
    public function getProductId()
    {
        return $this->_get('product_id');
    }
    /**
     * Set product_id
     * @param int $productId
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setProductId($productId)
    {
        return $this->setData('product_id', $productId);
    }
    /**
     * Get supplier_id
     * @return int|null
     */
    public function getSupplierId()
    {
        return $this->_get('supplier_id');
    }
    /**
     * Set supplier_id
     * @param int $supplierId
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setSupplierId($supplierId)
    {
        return $this->setData('supplier_id', $supplierId);
    }
    /**
     * Get supplier_name
     * @return string|null
     */
    public function getSupplierName()
    {
        return $this->_get('supplier_name');
    }
    /**
     * Set supplier_name
     * @param string $supplierName
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setSupplierName($supplierName)
    {
        return $this->setData('supplier_name', $supplierName);
    }
    /**
     * Get old_price
     * @return float|null
     */
    public function getOldPrice()
    {
        return $this->_get('old_price');
    }
    /**
     * Set old_price
     * @param float $oldPrice
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setOldPrice($oldPrice)
    {
        return $this->setData('old_price', $oldPrice);
    }
    /**
     * Get new_price
     * @return float|null
     */
    public function getNewPrice()
    {
        return $this->_get('new_price');
    }
    /**
     * Set new_price
     * @param float $newPrice
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setNewPrice($newPrice)
    {
        return $this->setData('new_price', $newPrice);
    }
    /**
     * Get qty_ordered
     * @return int|null
     */
    public function getQtyOrdered()
    {
        return $this->_get('qty_ordered');
    }
    /**
     * Set qty_ordered
     * @param int $qtyOrdered
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setQtyOrdered($qtyOrdered)
    {
        return $this->setData('qty_ordered', $qtyOrdered);
    }
    /**
     * Get current_total
     * @return string|null
     */
    public function getCurrentTotal()
    {
        return $this->_get('current_total');
    }
    /**
     * Set current_total
     * @param string $currentTotal
     * @return \Aria\Order\Api\Data\ProductDataInterface
     */
    public function setCurrentTotal($currentTotal)
    {
        return $this->setData('current_total', $currentTotal);
    }
}