<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\Order\Model\Data;

use Aria\Order\Api\Data\ReorderInterface;

class Reorder extends \Magento\Framework\Api\AbstractExtensibleObject implements ReorderInterface
{
    /**
     * Get quote_id
     * @return int|null
     */
    public function getQuoteId()
    {
        return $this->_get('quote_id');
    }

    /**
     * Set quote_id
     * @param int $quoteId
     * @return \Aria\Order\Api\Data\ReorderInterface
     */

    public function setQuoteId($quoteId)
    {
        return $this->setData('quote_id', $quoteId);
    }

    /**
     * Get venue_id
     * @return int|null
     */
    public function getVenueId()
    {
        return $this->_get('venue_id');
    }

    /**
     * Set venue_id
     * @param int $venueId
     * @return \Aria\Order\Api\Data\ReorderInterface
     */
    public function setVenueId($venueId)
    {
        return $this->setData('venue_id', $venueId);
    }

    /**
     * Get order_id
     * @return int|null
     */
    public function getOrderId()
    {
        return $this->_get('order_id');
    }

    /**
     * Set group_order_id
     * @param int $orderId
     * @return \Aria\Order\Api\Data\ReorderInterface
     */
    public function setOrderId($orderId)
    {
        return $this->setData('order_id', $orderId);
    }
}