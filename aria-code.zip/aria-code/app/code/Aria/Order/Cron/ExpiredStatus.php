<?php

namespace Aria\Order\Cron;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Sales\Api\OrderRepositoryInterface;

class ExpiredStatus
{
	protected $_pageFactory;
	protected $_orderCollectionFactory;
	protected $_date;
	protected $storeManager;
	protected $transportBuilder;
	protected $inlineTranslation;
	protected $scopeConfig;
	protected $orderRepositoryInterface;
    protected $orderFactory;


	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\Stdlib\DateTime\TimezoneInterface $date,
		TransportBuilder $transportBuilder,
        StateInterface $state,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
		CollectionFactory  $orderCollectionFactory,
		OrderRepositoryInterface $orderRepositoryInterface,
        \Magento\Sales\Api\Data\OrderInterfaceFactory $orderFactory)
	{
		$this->_pageFactory = $pageFactory;
		$this->storeManager = $storeManager;
		$this->transportBuilder = $transportBuilder;
        $this->scopeConfig = $scopeConfig;
        $this->inlineTranslation = $state;
		$this->_date =  $date;
		$this->_orderCollectionFactory = $orderCollectionFactory;
        $this->orderRepositoryInterface = $orderRepositoryInterface;
        $this->orderFactory = $orderFactory;
	}

	public function execute()
	{

		//$venueUserIdCollection=[];
		$pendingOrderCollection = $this->_orderCollectionFactory->create();
		$pendingOrderCollection->addFieldToFilter('status', 'pending_approval');
		foreach($pendingOrderCollection as $pendingOrder){
			$startDate = $pendingOrder->getCreatedAt();
            $orderId=$pendingOrder->getEntityId();
			//$endDate = $vacation->getTo();
			$currentDate = $this->_date->date()->format('Y-m-d H:i:s');
            $startDateTimestamp = strtotime($startDate);
            $currentDateTimestamp = strtotime($currentDate);
            $difference = abs($currentDateTimestamp - $startDateTimestamp)/3600;
            if($difference>=24)
            {
                $order = $this->orderFactory->create();
                $order->setEntityId($orderId);
                $order->setStatus('expired');
                $order->setState('canceled');
                $this->orderRepositoryInterface->save($order);
            }			
		}
	}

}