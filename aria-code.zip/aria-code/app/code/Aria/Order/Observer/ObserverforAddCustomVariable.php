<?php
namespace Aria\Order\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Exception\LocalizedException;
use Magento\Store\Model\ScopeInterface;

class ObserverforAddCustomVariable implements ObserverInterface
{

    public function __construct(
        \Aria\Venue\Model\VenueUserFactory $venueuserFactory,
        \Aria\Venue\Model\VenueUserRoleMappingFactory $venueusrolemap,
        \Aria\Venue\Model\VenueFactory $venue,
        \Aria\HospitalityGroup\Model\HospitalityGroup $hospgroup,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        StateInterface $state,
        TransportBuilder $transportBuilder,
        \Aria\SupplyCompanyAccount\Api\DCRepositoryInterface $dc
    ) {
        $this->venueuserFactory = $venueuserFactory;
        $this->venueusrolemapFactory = $venueusrolemap;
        $this->venueFactory = $venue;
        $this->hospgroupFactory = $hospgroup;
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->inlineTranslation = $state;
        $this->transportBuilder = $transportBuilder;
        $this->dcrepository = $dc;
    }

    /**
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        /** @var \Magento\Framework\App\Action\Action $controller */
        try{

            $transportObject = $observer->getEvent()->getData('transportObject');
            $order = $transportObject->getData('order');
            $order_group_inc_id =  $order->getGroupOrderId();
            $order_group_inc_id = sprintf('%08d', $order_group_inc_id);
            $order_status = "Order Rejected";
            $order_status_label =  $order->getFrontendStatusLabel();
            if($order->getStatus() == 'order_rejected'){
                $transportObject->setData('frontend_status_label', $order_status);
            }
            else{
                $transportObject->setData('frontend_status_label', $order_status_label);
            }
            $transportObject->setData('order_group_increment_id', $order_group_inc_id);
                   

        }catch (LocalizedException $exception) {
            throw new LocalizedException(__($exception->getMessage()));
        }
    }
}