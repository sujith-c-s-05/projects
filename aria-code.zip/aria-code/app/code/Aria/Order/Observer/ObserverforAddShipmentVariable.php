<?php
namespace Aria\Order\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Exception\LocalizedException;
use Magento\Store\Model\ScopeInterface;
use Aria\Order\Api\SalesOrderGroupRepositoryInterface;
use Aria\Venue\Api\VenueUserRoleMappingRepositoryInterface;
use Aria\Venue\Model\ResourceModel\VenueRolePermissionMapping\CollectionFactory as VenueRolePermissionMappingCollectionFactory;
use Aria\Venue\Api\VenueRolePermissionMappingRepositoryInterface;

class ObserverforAddShipmentVariable implements ObserverInterface
{

    public function __construct(
        \Aria\Venue\Model\VenueUserFactory $venueuserFactory,
        \Aria\Venue\Model\VenueUserRoleMappingFactory $venueusrolemap,
        \Aria\Venue\Model\VenueFactory $venue,
        \Aria\HospitalityGroup\Model\HospitalityGroup $hospgroup,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        StateInterface $state,
        TransportBuilder $transportBuilder,
        \Aria\SupplyCompanyAccount\Api\DCRepositoryInterface $dc,
        SalesOrderGroupRepositoryInterface $salesOrderGroupRepositoryInterface,
        \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface,
        VenueUserRoleMappingRepositoryInterface $venueUserRoleMappingRepositoryInterface,
        VenueRolePermissionMappingCollectionFactory $venueRolePermissionMappingCollectionFactory,
        VenueRolePermissionMappingRepositoryInterface $venueRolePermissionMappingRepositoryInterface
    ) {
        $this->venueuserFactory = $venueuserFactory;
        $this->venueusrolemapFactory = $venueusrolemap;
        $this->venueFactory = $venue;
        $this->hospgroupFactory = $hospgroup;
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->inlineTranslation = $state;
        $this->transportBuilder = $transportBuilder;
        $this->dcrepository = $dc;
        $this->salesOrderGroupRepositoryInterface=$salesOrderGroupRepositoryInterface;
		$this->participantsRepositoryInterface=$participantsRepositoryInterface;
        $this->venueUserRoleMappingRepositoryInterface=$venueUserRoleMappingRepositoryInterface;
		$this->venueRolePermissionMappingCollectionFactory = $venueRolePermissionMappingCollectionFactory;
        $this->venueRolePermissionMappingRepositoryInterface=$venueRolePermissionMappingRepositoryInterface;

    }

    /**
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        /** @var \Magento\Framework\App\Action\Action $controller */
        try{

            $transportObject = $observer->getEvent()->getData('transportObject');
            $order = $transportObject->getData('order');
            $order_group_inc_id =  $order->getGroupOrderId();
            $order_group_inc_id = sprintf('%08d', $order_group_inc_id);
            $transportObject->setData('order_group_increment_id', $order_group_inc_id);
            $orderGroupId =  $order->getGroupOrderId();   
            $orderGroupDetails=$this->salesOrderGroupRepositoryInterface->get($orderGroupId);
            $venueUserId=$orderGroupDetails->getVenueUserId();
            $venueId=$orderGroupDetails->getVenueId();
            $entityId= $order->getEntityId();
            	$roleId=$this->venueUserRoleMappingRepositoryInterface->getVenueUserRole($venueUserId,$venueId);
                    if($roleId)
                    {
						$venueRolePermissionMapping = $this->venueRolePermissionMappingCollectionFactory->create();
                        $venueRolePermissionMapping->addFieldToFilter('role_id',$roleId,'permission_id',30);
                        if(count($venueRolePermissionMapping)==0)
                        {
							$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
							$venueUserRoleDetails = $objectManager->create('Aria\Venue\Api\Data\VenueRolePermissionMappingInterface');
							$venueUserRoleDetails->setRoleId($roleId)
							->setPermissionId(30)
							->setParentId(0)
							->setIsActive(1)
							->setIsGranted(1);
							$this->venueRolePermissionMappingRepositoryInterface->save($venueUserRoleDetails);
						}
                    }
            $description ='Order #' . $order_group_inc_id . ' has been shipped ';
            $this->participantsRepositoryInterface->saveParticipantNotification(1, $venueId, $venueUserId, $description, 'venue_user', 'Order ha been Shipped');

        }catch (LocalizedException $exception) {
            throw new LocalizedException(__($exception->getMessage()));
        }
    }
}