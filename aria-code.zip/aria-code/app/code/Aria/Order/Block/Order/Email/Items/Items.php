<?php

namespace Aria\Order\Block\Order\Email\Items;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\View\Element\Template\Context;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Aria\SupplyCompanyAccount\Model\ResourceModel\SupplyCompany\CollectionFactory as SupplyCompanyCollectionFactory;

/**
 * Sales Order Email items.
 *
 * @api
 * @since 100.0.2
 */
class Items extends \Magento\Sales\Block\Items\AbstractItems
{
    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    protected $supplyCompanyCollectionFactory;

    /**
     * @param Context $context
     * @param array $data
     * @param OrderRepositoryInterface|null $orderRepository
     */
    public function __construct(
        Context $context,
        array $data = [],
        ?OrderRepositoryInterface $orderRepository = null,
        SupplyCompanyCollectionFactory $supplyCompanyCollectionFactory

    ) {
        $this->orderRepository = $orderRepository ?: ObjectManager::getInstance()->get(OrderRepositoryInterface::class);
        $this->supplyCompanyCollectionFactory = $supplyCompanyCollectionFactory;
        parent::__construct($context, $data);
    }

    /**
     * Returns order.
     *
     * Custom email templates are only allowed to use scalar values for variable data.
     * So order is loaded by order_id, that is passed to block from email template.
     * For legacy custom email templates it can pass as an object.
     *
     * @return OrderInterface|null
     * @since 102.1.0
     */
    public function getOrderId()
    {
        $orderId = $this->getData('order_id');
        return $orderId;
    }
    public function getOrder($order)
    {
        
        if ($order) {
            $orderObj = $this->orderRepository->get($order);
        }

        return $orderObj;
    }

    public function getDeliveySlot()
    {
        $deliveySlot = $this->getData('delivery_slot');
        return $deliveySlot;
    }

    public function getsupplierName($supplierId)
    {

         $supplierCollection = $this->supplyCompanyCollectionFactory->create();
         $supplierCollection->addFieldToFilter('supplycompany_id',$supplierId);
         $collectionItem = $supplierCollection->getFirstItem();
         $ItemData=$collectionItem->getData();
         $supplyCompanyName=$ItemData['company_name'];
         return $supplyCompanyName;
    }

    public function getSlot($slot)
    {
        
        $delievryDay = strtotime($slot);
        $day = date('l', $delievryDay) . ' ' . $slot;
        return $day;
    }

}
