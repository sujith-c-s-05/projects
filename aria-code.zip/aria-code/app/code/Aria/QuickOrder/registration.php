<?php
/**
 * Copyright ©  All rights reserved.
 */
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Aria_QuickOrder', __DIR__);

