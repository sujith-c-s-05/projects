<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ParkOrder\Model;

use Aria\ParkOrder\Api\Data\ParkOrderInterface;
use Aria\ParkOrder\Api\Data\ParkOrderInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class ParkOrder extends \Magento\Framework\Model\AbstractModel
{

    protected $dataObjectHelper;

    protected $parkorderDataFactory;

    protected $_eventPrefix = 'aria_parkorder_parkorder';

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param ParkOrderInterfaceFactory $parkorderDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\ParkOrder\Model\ResourceModel\ParkOrder $resource
     * @param \Aria\ParkOrder\Model\ResourceModel\ParkOrder\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        ParkOrderInterfaceFactory $parkorderDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\ParkOrder\Model\ResourceModel\ParkOrder $resource,
        \Aria\ParkOrder\Model\ResourceModel\ParkOrder\Collection $resourceCollection,
        array $data = []
    ) {
        $this->parkorderDataFactory = $parkorderDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve parkorder model with parkorder data
     * @return ParkOrderInterface
     */
    public function getDataModel()
    {
        $parkorderData = $this->getData();
        
        $parkorderDataObject = $this->parkorderDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $parkorderDataObject,
            $parkorderData,
            ParkOrderInterface::class
        );
        
        return $parkorderDataObject;
    }
}

