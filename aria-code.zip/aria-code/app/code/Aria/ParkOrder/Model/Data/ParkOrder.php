<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ParkOrder\Model\Data;

use Aria\ParkOrder\Api\Data\ParkOrderInterface;

class ParkOrder extends \Magento\Framework\Api\AbstractExtensibleObject implements ParkOrderInterface
{

    /**
     * Get parkorder_id
     * @return string|null
     */
    public function getParkorderId()
    {
        return $this->_get(self::PARKORDER_ID);
    }

    /**
     * Set parkorder_id
     * @param string $parkorderId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setParkorderId($parkorderId)
    {
        return $this->setData(self::PARKORDER_ID, $parkorderId);
    }

    /**
     * Get name
     * @return string|null
     */
    public function getName()
    {
        return $this->_get(self::NAME);
    }

    /**
     * Set name
     * @param string $name
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\ParkOrder\Api\Data\ParkOrderExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\ParkOrder\Api\Data\ParkOrderExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\ParkOrder\Api\Data\ParkOrderExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get price
     * @return string|null
     */
    public function getPrice()
    {
        return $this->_get(self::PRICE);
    }

    /**
     * Set price
     * @param string $price
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setPrice($price)
    {
        return $this->setData(self::PRICE, $price);
    }

    /**
     * Get venue_user_id
     * @return string|null
     */
    public function getVenueUserId()
    {
        return $this->_get(self::VENUE_USER_ID);
    }

    /**
     * Set venue_user_id
     * @param string $venueUserId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setVenueUserId($venueUserId)
    {
        return $this->setData(self::VENUE_USER_ID, $venueUserId);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_delete
     * @return string|null
     */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }

    /**
     * Set is_delete
     * @param string $isDelete
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }

    /**
     * Get item_count
     * @return string|null
     */
    public function getItemCount()
    {
        return $this->_get(self::ITEM_COUNT);
    }

    /**
     * Set item_count
     * @param string $itemCount
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setItemCount($itemCount)
    {
        return $this->setData(self::ITEM_COUNT, $itemCount);
    }

    /**
     * Get venue_id
     * @return string|null
     */
    public function getVenueId()
    {
        return $this->_get(self::VENUE_ID);
    }

    /**
     * Set venue_id
     * @param string $venueId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setVenueId($venueId)
    {
        return $this->setData(self::VENUE_ID, $venueId);
    }

    /**
     * Get is_shared
     * @return int|null
     */
    public function getIsShared()
    {
        return $this->_get(self::IS_SHARED);
    }

    /**
     * Set is_shared
     * @param int $isShared
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setIsShared($isShared)
    {
        return $this->setData(self::IS_SHARED, $isShared);
    }

    /**
     * Get is_locked
     * @return int|null
     */
    public function getIsLocked()
    {
        return $this->_get(self::IS_LOCKED);
    }

    /**
     * Set is_locked
     * @param int $isLocked
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setIsLocked($isLocked)
    {
        return $this->setData(self::IS_LOCKED, $isLocked);
    }

    /**
     * Get locked_by
     * @return int|null
     */
    public function getLockedBy()
    {
        return $this->_get(self::LOCKED_BY);
    }

    /**
     * Set locked_by
     * @param int $lockedBy
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setLockedBy($lockedBy)
    {
        return $this->setData(self::LOCKED_BY, $lockedBy);
    }

    
}

