<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ParkOrder\Model\Data;

use Aria\ParkOrder\Api\Data\ParkOrderItemInterface;

class ParkOrderItem extends \Magento\Framework\Api\AbstractExtensibleObject implements ParkOrderItemInterface
{

    /**
     * Get parkorderitem_id
     * @return string|null
     */
    public function getParkorderitemId()
    {
        return $this->_get(self::PARKORDERITEM_ID);
    }

    /**
     * Set parkorderitem_id
     * @param string $parkorderitemId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setParkorderitemId($parkorderitemId)
    {
        return $this->setData(self::PARKORDERITEM_ID, $parkorderitemId);
    }

    /**
     * Get name
     * @return string|null
     */
    public function getName()
    {
        return $this->_get(self::NAME);
    }

    /**
     * Set name
     * @param string $name
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Aria\ParkOrder\Api\Data\ParkOrderItemExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\ParkOrder\Api\Data\ParkOrderItemExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get sku
     * @return string|null
     */
    public function getSku()
    {
        return $this->_get(self::SKU);
    }

    /**
     * Set sku
     * @param string $sku
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setSku($sku)
    {
        return $this->setData(self::SKU, $sku);
    }

    /**
     * Get qty
     * @return string|null
     */
    public function getQty()
    {
        return $this->_get(self::QTY);
    }

    /**
     * Set qty
     * @param string $qty
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setQty($qty)
    {
        return $this->setData(self::QTY, $qty);
    }

    /**
     * Get price
     * @return string|null
     */
    public function getPrice()
    {
        return $this->_get(self::PRICE);
    }

    /**
     * Set price
     * @param string $price
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setPrice($price)
    {
        return $this->setData(self::PRICE, $price);
    }

    /**
     * Get subtotal
     * @return string|null
     */
    public function getSubtotal()
    {
        return $this->_get(self::SUBTOTAL);
    }

    /**
     * Set subtotal
     * @param string $subtotal
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setSubtotal($subtotal)
    {
        return $this->setData(self::SUBTOTAL, $subtotal);
    }

    /**
     * Get image
     * @return string|null
     */
    public function getImage()
    {
        return $this->_get(self::IMAGE);
    }

    /**
     * Set image
     * @param string $image
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setImage($image)
    {
        return $this->setData(self::IMAGE, $image);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get parked_order_id
     * @return string|null
     */
    public function getParkedOrderId()
    {
        return $this->_get(self::PARKED_ORDER_ID);
    }

    /**
     * Set parked_order_id
     * @param string $parkedOrderId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setParkedOrderId($parkedOrderId)
    {
        return $this->setData(self::PARKED_ORDER_ID, $parkedOrderId);
    }

    /**
     * Get parked_order_name
     * @return string|null
     */
    public function getParkedOrderName()
    {
        return $this->_get(self::PARKED_ORDER_NAME);
    }

    /**
     * Set parked_order_name
     * @param string $parkedOrderName
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setParkedOrderName($parkedOrderName)
    {
        return $this->setData(self::PARKED_ORDER_NAME, $parkedOrderName);
    }

    /**
     * Get seller_id
     * @return string|null
     */
    public function getSellerId()
    {
        return $this->_get(self::SELLER_ID);
    }

    /**
     * Set seller_id
     * @param string $sellerId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setSellerId($sellerId)
    {
        return $this->setData(self::SELLER_ID, $sellerId);
    }

    /**
     * Get seller_name
     * @return string|null
     */
    public function getSellerName()
    {
        return $this->_get(self::SELLER_NAME);
    }

    /**
     * Set seller_name
     * @param string $sellerName
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setSellerName($sellerName)
    {
        return $this->setData(self::SELLER_NAME, $sellerName);
    }

    /**
     * Get category
     * @return string|null
     */
    public function getCategory()
    {
        return $this->_get(self::CATEGORY);
    }

    /**
     * Set category
     * @param string $category
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setCategory($category)
    {
        return $this->setData(self::CATEGORY, $category);
    }

    /**
     * Get product_id
     * @return string|null
     */
    public function getProductId()
    {
        return $this->_get(self::PRODUCT_ID);
    }

    /**
     * Set product_id
     * @param string $productId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setProductId($productId)
    {
        return $this->setData(self::PRODUCT_ID, $productId);
    }

    /**
     * Get uom_name
     * @return string
     */
    public function getUomName()
    {
        return $this->_get('uom_name');
    }

    /**
     * Set uom_name
     * @param string $uomName
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setUomName($uomName)
    {
        return $this->setData('uom_name', $uomName);
    }
}

