<?php
declare(strict_types=1);

namespace Aria\ParkOrder\Model\Data;
use Aria\ParkOrder\Api\Data\UpdateItemsInterface;

/**
 * Interface which represents associative array item.
 */
class UpdateItems extends \Magento\Framework\Api\AbstractExtensibleObject implements UpdateItemsInterface
{   
    /**
     * Get id
     * 
     * @return int
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }
    /**
     * Get product_id
     * 
     * @return int
     */
    public function getProductId()
    {
        return $this->_get(self::PRODUCT_ID);
    }

    /**
     * Get qty
     * 
     * @return int
     */
    public function getQty()
    {
        return $this->_get(self::QTY);
    }

    /**
     * Get price
     * 
     * @return float
     */
    public function getPrice()
    {
        return $this->_get(self::PRICE);
    }
    /**
     * Get isDelete
     * 
     * @return int
     */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }
    /**
     * Set id
     * @param $id
     * @return int
     */
    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }
    /**
     * Set qty
     * @param $qty
     * @return int
     */
    public function setQty($qty)
    {
        return $this->setData(self::QTY, $qty);
    }

    /**
     * Set price
     *  @param $price
     * @return float
     */
    public function setPrice($price)
    {
        return $this->setData(self::PRICE, $price);
    }
    /**
     * Set is_delete
     * @param $isDelete
     * @return int
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }
    /**
     * Set product_id
     * @param $productId
     * @return int
     */
    public function setProductId($productId)
    {
        return $this->setData(self::PRODUCT_ID, $productId);
    }
}