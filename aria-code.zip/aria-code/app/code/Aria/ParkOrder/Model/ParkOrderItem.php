<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ParkOrder\Model;

use Aria\ParkOrder\Api\Data\ParkOrderItemInterface;
use Aria\ParkOrder\Api\Data\ParkOrderItemInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class ParkOrderItem extends \Magento\Framework\Model\AbstractModel
{

    protected $_eventPrefix = 'aria_parkorder_parkorderitem';
    protected $dataObjectHelper;

    protected $parkorderitemDataFactory;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param ParkOrderItemInterfaceFactory $parkorderitemDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Aria\ParkOrder\Model\ResourceModel\ParkOrderItem $resource
     * @param \Aria\ParkOrder\Model\ResourceModel\ParkOrderItem\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        ParkOrderItemInterfaceFactory $parkorderitemDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Aria\ParkOrder\Model\ResourceModel\ParkOrderItem $resource,
        \Aria\ParkOrder\Model\ResourceModel\ParkOrderItem\Collection $resourceCollection,
        array $data = []
    ) {
        $this->parkorderitemDataFactory = $parkorderitemDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve parkorderitem model with parkorderitem data
     * @return ParkOrderItemInterface
     */
    public function getDataModel()
    {
        $parkorderitemData = $this->getData();
        
        $parkorderitemDataObject = $this->parkorderitemDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $parkorderitemDataObject,
            $parkorderitemData,
            ParkOrderItemInterface::class
        );
        
        return $parkorderitemDataObject;
    }
}

