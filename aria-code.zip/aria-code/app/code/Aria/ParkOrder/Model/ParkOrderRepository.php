<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Aria\ParkOrder\Model;

use Aria\ParkOrder\Api\Data\ParkOrderInterfaceFactory;
use Aria\ParkOrder\Api\Data\ParkOrderSearchResultsInterfaceFactory;
use Aria\ParkOrder\Api\ParkOrderRepositoryInterface;
use Aria\ParkOrder\Model\ResourceModel\ParkOrder as ResourceParkOrder;
use Aria\ParkOrder\Model\ResourceModel\ParkOrder\CollectionFactory as ParkOrderCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Aria\ParkOrder\Model\ParkOrderFactory as ParkOrderModelFactory;
use Aria\ParkOrder\Model\ParkOrderItemFactory as ParkOrderItemModelFactory;
use Magento\Quote\Model\Quote\Item;
use Aria\Venue\Model\VenueUserRepository;
use Aria\Venue\Model\VenueRepository;

class ParkOrderRepository implements ParkOrderRepositoryInterface
{

    private $collectionProcessor;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $parkOrderFactory;

    protected $searchResultsFactory;

    protected $dataObjectProcessor;

    protected $parkOrderCollectionFactory;

    protected $resource;

    protected $extensibleDataObjectConverter;

    private $storeManager;

    protected $dataParkOrderFactory;

    protected $quoteRepository;

    protected $_conn;

    protected $_resourceConnection;

    protected $scopeConfig;


    /**
     * @param ResourceParkOrder $resource
     * @param ParkOrderFactory $parkOrderFactory
     * @param ParkOrderInterfaceFactory $dataParkOrderFactory
     * @param ParkOrderCollectionFactory $parkOrderCollectionFactory
     * @param ParkOrderSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter,
     * @param \CartRepositoryInterface $quoteRepository
     * @param ParkOrderItemModelFactory $parkOrderItemModelFactory
     * @param ParkOrderModelFactory $parkOrderItemModelFactory
     */
    public function __construct(
        ResourceParkOrder $resource,
        ParkOrderFactory $parkOrderFactory,
        ParkOrderInterfaceFactory $dataParkOrderFactory,
        ParkOrderCollectionFactory $parkOrderCollectionFactory,
        ParkOrderSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        CartRepositoryInterface $quoteRepository,
        ParkOrderItemModelFactory $parkOrderItemModelFactory,
        ParkOrderModelFactory  $parkOrderModelFactory,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        Item $modelCartItem,
        VenueUserRepository $venueUserRepository,
        VenueRepository $venueRepository,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        \Aria\ParkOrder\Model\ResourceModel\ParkOrderItem\CollectionFactory $parkOrderItemCollectionFactory,
        \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface,
        \Aria\CartManagement\Model\CartItemRepositoryManagement $cartItemRepositoryManagement
    ) {
        $this->resource = $resource;
        $this->parkOrderFactory = $parkOrderFactory;
        $this->parkOrderCollectionFactory = $parkOrderCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataParkOrderFactory = $dataParkOrderFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->quoteRepository = $quoteRepository;
        $this->parkOrderModelFactory = $parkOrderModelFactory;
        $this->parkOrderItemModelFactory = $parkOrderItemModelFactory;
        $this->_conn = $resourceConnection->getConnection();
        $this->_modelCartItem = $modelCartItem;
        $this->venueUserRepository = $venueUserRepository;
        $this->venueRepository = $venueRepository;
        $this->scopeConfig = $scopeConfig;
        $this->productRepositoryInterface = $productRepositoryInterface;
        $this->parkOrderItemCollectionFactory = $parkOrderItemCollectionFactory;
        $this->participantsRepositoryInterface = $participantsRepositoryInterface;
        $this->cartItemRepositoryManagement = $cartItemRepositoryManagement;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Aria\ParkOrder\Api\Data\ParkOrderInterface $parkOrder
    ) {
        /* if (empty($parkOrder->getStoreId())) {
            $storeId = $this->storeManager->getStore()->getId();
            $parkOrder->setStoreId($storeId);
        } */

        $parkOrderData = $this->extensibleDataObjectConverter->toNestedArray(
            $parkOrder,
            [],
            \Aria\ParkOrder\Api\Data\ParkOrderInterface::class
        );

        $parkOrderModel = $this->parkOrderFactory->create()->setData($parkOrderData);

        try {
            $this->resource->save($parkOrderModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the parkOrder: %1',
                $exception->getMessage()
            ));
        }
        return $parkOrderModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($parkOrderId)
    {
        $parkOrder = $this->parkOrderFactory->create();
        $this->resource->load($parkOrder, $parkOrderId);
        if (!$parkOrder->getId()) {
            throw new NoSuchEntityException(__('ParkOrder with id "%1" does not exist.', $parkOrderId));
        }
        return $parkOrder->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->parkOrderCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\ParkOrder\Api\Data\ParkOrderInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \Aria\ParkOrder\Api\Data\ParkOrderInterface $parkOrder
    ) {
        try {
            $parkOrderModel = $this->parkOrderFactory->create();
            $this->resource->load($parkOrderModel, $parkOrder->getParkorderId());
            $this->resource->delete($parkOrderModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the ParkOrder: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($parkOrderId)
    {
        return $this->delete($this->get($parkOrderId));
    }

    /**
     * {@inheritdoc}
     */
    public function createParkOrder($cartId, $venueUserId, $venueId)
    {
        try {
            $this->_conn->beginTransaction();

            $venueParkOrderCount = $this->getParkedOrderCountByVenueUser($venueUserId, $venueId);

            $venueParkOrderLimit = $this->getParkOrderLimit($venueId);

            if ($venueParkOrderCount >= $venueParkOrderLimit) {
                throw new CouldNotSaveException(__(
                    'Maximum Number of Limit reached for the park order.'
                ));
            }

            $quote = $this->quoteRepository->getActive($cartId);

            if (count($quote->getAllVisibleItems()) == 0) {
                throw new CouldNotSaveException(__(
                    'Cart doesnt have any items'
                ));
            }

            $cartTotal = $quote->getGrandTotal();

            $itemCount = count($quote->getAllVisibleItems());

            $parkOrderName =  $this->getParkOrderName($venueUserId);

            $parkOrderFactory = $this->parkOrderModelFactory->create();

            $parkOrderFactory->setName($parkOrderName);
            $parkOrderFactory->setVenueUserId($venueUserId);
            $parkOrderFactory->setItemCount($itemCount);
            $parkOrderFactory->setPrice($cartTotal);
            $parkOrderFactory->setVenueId($venueId);

            $parkOrder = $parkOrderFactory->save();

            $quoteItems = $this->cartItemRepositoryManagement->getList($cartId);

            foreach ($quoteItems as $item) {

                $extensionAttributes = $item->getExtensionAttributes();

                $categories = $extensionAttributes->getProductCategoryName();

                if (!empty($categories)) {
                    $category = $categories[0];
                }

                $parkOrderItemFactory = $this->parkOrderItemModelFactory->create();
                $parkOrderItemFactory->setName($item->getName());
                $parkOrderItemFactory->setSku($item->getSku());
                $parkOrderItemFactory->setQty($item->getQty());
                $parkOrderItemFactory->setPrice($item->getPrice());
                $parkOrderItemFactory->setSubtotal($item->getRowTotalInclTax());
                $parkOrderItemFactory->setImage($extensionAttributes->getThumbnailImage());
                $parkOrderItemFactory->setSellerName($extensionAttributes->getSupplierName());
                $parkOrderItemFactory->setSellerId($extensionAttributes->getSupplierId());
                $parkOrderItemFactory->setParkedOrderId($parkOrder->getParkorderId());
                $parkOrderItemFactory->setVenueUserId($venueUserId);
                $parkOrderItemFactory->setParkedOrderName($parkOrderName);
                $parkOrderItemFactory->setCategory($category ?? '');
                $parkOrderItemFactory->setProductId($item->getProductId());

                $parkOrderItem = $parkOrderItemFactory->save();
            }

            $this->clearCart($quote);
            $this->_conn->commit();

            return true;
        } catch (\Exception $exception) {

            $this->_conn->rollBack();

            throw new CouldNotSaveException(__(
                'Could not save the parkOrder: %1',
                $exception->getMessage()
            ));
        }
    }

    /**
     * To clear cart
     */
    public function clearCart($quote)
    {

        $quote->removeAllItems();
        $this->quoteRepository->save($quote);
        return true;
    }

    /**
     * To get the parked order count by venue user
     */
    public function getParkedOrderCountByVenueUser($venueUserId, $venueId)
    {
        $collection = $this->parkOrderCollectionFactory->create();
        $collection->addFieldToFilter('venue_user_id', $venueUserId);
        $collection->addFieldToFilter('venue_id', $venueId);
        $collection->addFieldToFilter('is_delete', 0);

        return count($collection);
    }

    /**
     * To get the parked order name
     */
    public function getParkOrderName($venueUserId)
    {
        $venueUser =  $this->venueUserRepository->get($venueUserId);

        $venueUsername = $venueUser->getFirstName();

        $parkOrderName = $venueUsername . "_" . $this->getDate();

        return $parkOrderName;
    }

    /**
     * To get the parked order limit for venue
     */
    public function getParkOrderLimit($venueId)
    {
        try {
            $venue = $this->venueRepository->get($venueId);

            return $parkedOrderLimit = $venue->getNumberOfParkedOrders();
        } catch (\Exception $exception) {

            throw new CouldNotSaveException(__(
                'Venue Not found'
            ));
        }
    }

    /**
     * To get formatted date 
     */
    public function getDate()
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $dateFormat = $this->scopeConfig->getValue('catalog/custom_options/date_fields_order', $storeScope);
        $dateFormat =  str_replace(',', '/', $dateFormat);
        $dateFormat =  str_replace('y', 'Y', $dateFormat);
        return date($dateFormat);
    }
    /**
     * {@inheritdoc}
     */
    public function checkSharedOrder($parkedOrderId,$userId)
    {
        $parkOrderCollection = $this->getSharedOrder($parkedOrderId);
        if($parkOrderCollection->getIsShared() && $parkOrderCollection->getIsLocked() && $parkOrderCollection->getLockedBy()!=$userId){
            $venueUser =  $this->venueUserRepository->get($parkOrderCollection->getLockedBy());
            throw new CouldNotSaveException(__('Parked order cannot be updated as it is being used by '.$venueUser->getFirstName()));
        }
        return true;

    }
    /**
     * {@inheritdoc}
     */
    public function sendSharedOrderNotification($parkOrderId, $venueUserId)
    {
        $parkOrderCollection = $this->getSharedOrder($parkOrderId);
        if(!empty($parkOrderCollection->getData())){
            $message = $parkOrderCollection->getName().' has been updated by '.$this->getVenueUserName($venueUserId);
            $this->participantsRepositoryInterface->saveParticipantNotification(6, $parkOrderCollection->getVenueId(), $parkOrderCollection->getVenueUserId(), $message, 'venue_user', 'shared parked order edited');
        }
        return true;
    }
    /**
     * {@inheritdoc}
     */
    public function getSharedOrder($parkedOrderId)
    {
        $parkOrderCollection = $this->parkOrderCollectionFactory->create();
        $parkOrderCollection->addFieldToFilter('parkorder_id', $parkedOrderId)
                            ->addFieldToFilter('is_shared', 1);
        if(empty($parkOrderCollection->getData())){
            throw new CouldNotSaveException(__('Parked order '.$parkedOrderId.' not found '));
        }
        return $parkOrderCollection->getFirstItem();
    }
    /**
     * {@inheritdoc}
     */
    public function updateOrderItems($parkOrderId,$userId,$items)
    {
        
        $parkOrderFactory = $this->parkOrderModelFactory->create()->load($parkOrderId);
        if (!$parkOrderFactory->getParkorderId()) {
            throw new CouldNotSaveException(__(
                'ParkOrder not found'
            ));
        }
        if($parkOrderFactory->getVenueUserId() == $userId){
            throw new CouldNotSaveException(__(
                'User not allowed to edit the order'
            ));   
        }
        $this->checkSharedOrder($parkOrderId, $userId);
        $products = $items;
        foreach ($products as $item) {
            if ($item->getQty() == 0 || $item->getIsDelete()) {
                $this->deleteItem($item);
            } else {
                $this->updateItem($item);
            }
        }
        $orderTotalData = $this->getOrderTotals($parkOrderId);
        $parkOrderFactory->setPrice($orderTotalData['total_price']);
        $parkOrderFactory->setItemCount($orderTotalData['total_items']);
        $parkOrderFactory->setIsLocked(0);
        $parkOrderFactory->save();
        $this->sendSharedOrderNotification($parkOrderId,$userId);
        return $parkOrderFactory->getDataModel();
    }
    /**
     * {@inheritdoc}
     */
    public function deleteItem($item)
    {
        $parkOrderItemFactory = $this->parkOrderItemModelFactory->create()->load($item->getId());
        if ($parkOrderItemFactory->getId()) {
            return $parkOrderItemFactory->delete();
        } else {
            throw new CouldNotSaveException(__(
                'ParkOrder Item not found'
            ));
        }

    }
    /**
     * {@inheritdoc}
     */
    public function updateItem($item)
    {
        $parkOrderItemFactory = $this->parkOrderItemModelFactory->create()->load($item->getId());
        if ($parkOrderItemFactory->getId()) {
            $parkOrderItemFactory->setQty($item->getQty());
            $productId = $parkOrderItemFactory->getProductId();
            $product = $this->productRepositoryInterface->getById($productId);
            $currentPrice = $product->getFinalPrice();
            $subTotal = $currentPrice * $item->getQty();
            $parkOrderItemFactory->setPrice($currentPrice);
            $parkOrderItemFactory->setSubtotal($subTotal);
            return $parkOrderItemFactory->save();
        } else {
            throw new CouldNotSaveException(__(
                'ParkOrder Item not found'
            ));
        }
    }

   /**
     * {@inheritdoc}
     */
    public function getOrderTotals($parkOrderId)
    {
        $parkOrderItemCollection = $this->parkOrderItemCollectionFactory->create();
        $parkOrderItemCollection->addFieldToFilter('parked_order_id', $parkOrderId);
        $result = [];
        $sum = 0;
        $qtyTotal = 0;
        foreach ($parkOrderItemCollection as $item) {
            $sum += $item->getSubtotal();
            $qtyTotal += $item->getQty();
        }
        $result['total_price'] = $sum;
        $result['total_items'] = count($parkOrderItemCollection);
        return $result;
    }
    /**
     * {@inheritdoc}
     */
    public function shareParkedOrder($parkOrderId,$isShared,$venueUserId)
    {
        try {
            $parkOrder = $this->parkOrderFactory->create()->load($parkOrderId);

            $userId = $parkOrder->getVenueUserId();

            if ($venueUserId != $userId) {
                throw new CouldNotSaveException(__(
                    'User Doesnt have the permission to share park order.'
                ));
            }

            $parkOrder->setIsShared($isShared);

            $parkOrder->save();
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the ParkOrder: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function checkParkOrderEdit($parkOrderId,$venueUserId)
    {
        $this->lockParkedOrder($parkOrderId,$venueUserId);
        
        $items = [];

        $collection = $this->parkOrderItemCollectionFactory->create();
        $collection->addFieldToFilter('parked_order_id',$parkOrderId);

        if (count($collection) >= 1) {
            foreach ($collection as $item) {
                $items[] = $item->getDataModel();
            }
        }

        return $items;
    }

    /**
     * To get venue user name
     */
    public function getVenueUserName($venueUserId)
    {
        $venueUser =  $this->venueUserRepository->get($venueUserId);

        $venueUserFirstName = $venueUser->getFirstName();
        $venueUserLastName = $venueUser->getLastName();

        $venueUserName = $venueUserFirstName ." ".$venueUserLastName;

        return $venueUserName;
    }

    /**
     * To lock park order
     */
    public function lockParkedOrder($parkOrderId,$venueUserId)
    {
        $parkOrder = $this->parkOrderFactory->create()->load($parkOrderId);

        if(!($parkOrder->getIsLocked()))
        {
            $parkOrder->setIsLocked(1);
            $parkOrder->setLockedBy($venueUserId);
            $parkOrder->save();
        }
        else if($parkOrder->getIsLocked() && ($parkOrder->getLockedBy() != $venueUserId))
        {
            $lockedBy = $parkOrder->getLockedBy();

            $venueUserName = $this->getVenueUserName($lockedBy);

            throw new CouldNotSaveException(__(
                'Parked order cannot be updated as it is being used by '.$venueUserName
            ));
        }

    }
    
    /**
     * {@inheritdoc}
     */
    public function setLock($parkOrderId,$isLock,$venueUserId)
    {
        try {
            $parkOrder = $this->parkOrderFactory->create()->load($parkOrderId);
            $parkOrder->setIsLocked($isLock);
            $parkOrder->save();
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the ParkOrder: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function getParkedOrders($venueId,$venueUserId)
    {
        
        $items = [];

        $collection = $this->parkOrderCollectionFactory->create();
        $collection->addFieldToFilter('venue_id',$venueId);
        $collection->addFieldToFilter('venue_user_id',$venueUserId);
        $collection->addFieldToFilter('is_delete',0);
        
        if (count($collection) >= 1) {
            foreach ($collection as $item) {
                $items[] = $item->getDataModel();
            }
        }
        $collection->clear()->getSelect()->reset('where');
        $collection->addFieldToFilter('venue_id',$venueId);
        $collection->addFieldToFilter('is_shared',1);
        $collection->addFieldToFilter('venue_user_id', array('neq' => $venueUserId));
        $collection->addFieldToFilter('is_delete',0);

        if (count($collection) >= 1) {
            foreach ($collection as $item) {
                $items[] = $item->getDataModel();
            }
        }
        
        arsort($items);
        return $items;
    }
}
