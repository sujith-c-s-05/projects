<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ParkOrder\Model;

use Aria\ParkOrder\Api\Data\ParkOrderItemInterfaceFactory;
use Aria\ParkOrder\Api\Data\ParkOrderItemSearchResultsInterfaceFactory;
use Aria\ParkOrder\Api\ParkOrderItemRepositoryInterface;
use Aria\ParkOrder\Model\ResourceModel\ParkOrderItem as ResourceParkOrderItem;
use Aria\ParkOrder\Model\ResourceModel\ParkOrderItem\CollectionFactory as ParkOrderItemCollectionFactory;
use Aria\ParkOrder\Model\ResourceModel\ParkOrder\CollectionFactory as ParkOrderCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Aria\Venue\Model\VenueUserRepository;
use Aria\ParkOrder\Model\ParkOrderFactory as ParkOrderModelFactory;
class ParkOrderItemRepository implements ParkOrderItemRepositoryInterface
{

    protected $parkOrderItemCollectionFactory;

    protected $parkOrderItemFactory;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    private $collectionProcessor;

    protected $searchResultsFactory;

    protected $dataObjectProcessor;

    protected $extensibleDataObjectConverter;
    protected $resource;

    protected $dataParkOrderItemFactory;

    private $storeManager;


    /**
     * @param ResourceParkOrderItem $resource
     * @param ParkOrderItemFactory $parkOrderItemFactory
     * @param ParkOrderItemInterfaceFactory $dataParkOrderItemFactory
     * @param ParkOrderItemCollectionFactory $parkOrderItemCollectionFactory
     * @param ParkOrderItemSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     */
    public function __construct(
        ResourceParkOrderItem $resource,
        ParkOrderItemFactory $parkOrderItemFactory,
        ParkOrderItemInterfaceFactory $dataParkOrderItemFactory,
        ParkOrderItemCollectionFactory $parkOrderItemCollectionFactory,
        ParkOrderCollectionFactory $parkOrderCollectionFactory,
        ParkOrderItemSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Aria\Notifications\Api\ParticipantsRepositoryInterface $participantsRepositoryInterface,
        ParkOrderModelFactory  $parkOrderModelFactory,
        \Aria\Venue\Api\VenueRepositoryInterface $venueRepository,
        VenueUserRepository $venueUserRepository,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository
    ) {
        $this->resource = $resource;
        $this->parkOrderItemFactory = $parkOrderItemFactory;
        $this->parkOrderItemCollectionFactory = $parkOrderItemCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataParkOrderItemFactory = $dataParkOrderItemFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->parkOrderModelFactory = $parkOrderModelFactory;
        $this->collectionProcessor = $collectionProcessor;
        $this->parkOrderCollectionFactory = $parkOrderCollectionFactory;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->participantsRepositoryInterface = $participantsRepositoryInterface;
        $this->venueRepository = $venueRepository;
        $this->productRepositoryInterface = $productRepositoryInterface;
        $this->venueUserRepository = $venueUserRepository;
        $this->eavConfig = $eavConfig;
        $this->categoryRepository = $categoryRepository;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        $userId,
        \Aria\ParkOrder\Api\Data\ParkOrderItemInterface $parkOrderItem
    ) {
        /* if (empty($parkOrderItem->getStoreId())) {
            $storeId = $this->storeManager->getStore()->getId();
            $parkOrderItem->setStoreId($storeId);
        } */
        
        $parkOrderItemData = $this->extensibleDataObjectConverter->toNestedArray(
            $parkOrderItem,
            [],
            \Aria\ParkOrder\Api\Data\ParkOrderItemInterface::class
        );
        $product = $this->productRepositoryInterface->get($parkOrderItem->getSku());
        $extensionAttributes = $product->getExtensionAttributes();
        $categoryNames=array();
            foreach ($product->getCategoryIds() as $categoryId) {
                array_push($categoryNames,$this->getCategoryNameById($categoryId));
            }
        $parkOrder = $this->getSharedOrder($parkOrderItem->getParkedOrderId());
        $category = '';
        if (!empty($categoryNames)) {
            $category = $categoryNames[0];
        }
        if($product->getSku()){
            $parkOrderItemData['sku'] = $product->getSku();
            $parkOrderItemData['name'] = $product->getName();
            $parkOrderItemData['image'] = $extensionAttributes->getSmallImage();
            $parkOrderItemData['seller_id'] = $extensionAttributes->getSupplierId();
            $parkOrderItemData['seller_name'] = $extensionAttributes->getSupplierName();
            $parkOrderItemData['category'] = $category;
            $parkOrderItemData['subtotal'] = (int)$parkOrderItem->getQty()*(float)$parkOrderItem->getPrice();
            $parkOrderItemData['parked_order_name'] = $parkOrder->getName();
        }
        $parkorderItem = $this->productExists($parkOrderItem);
        if(!empty($parkorderItem->getData())){
            $parkOrderItemData['parkorderitem_id'] = $parkorderItem->getParkorderitemId();
            $parkOrderItemData['qty'] = $parkOrderItemData['qty']+$parkorderItem->getQty();
            $parkOrderItemData['subtotal'] = $parkOrderItemData['subtotal']+$parkorderItem->getSubtotal();
        }
        $parkOrderItemModel = $this->parkOrderItemFactory->create()->setData($parkOrderItemData);
        $this->checkSharedOrder($parkOrderItem->getParkedOrderId(),$userId);
        try {
            $this->resource->save($parkOrderItemModel);
            $orderTotalData = $this->getOrderTotals($parkOrderItem->getParkedOrderId());
            $parkOrderFactory = $this->parkOrderModelFactory->create()->load($parkOrderItem->getParkedOrderId());
            $parkOrderFactory->setPrice($orderTotalData['total_price']);
            $parkOrderFactory->setItemCount($orderTotalData['total_items']);
            $parkOrderFactory->setIsLocked(0);
            $parkOrderFactory->save();
            if($parkOrder->getVenueUserId() != $userId){
                $this->sendSharedOrderNotification($parkOrderItem,$userId);
            }    
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the parkOrderItem: %1',
                $exception->getMessage()
            ));
        }
        return $parkOrderItemModel->getDataModel();
    }
    /**
     * @param int $id
     * @param null $storeId
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getCategoryNameById($id, $storeId = null)
    {
        $categoryInstance = $this->categoryRepository->get($id, $storeId);
        return $categoryInstance->getName();
    }
     /**
     * {@inheritdoc}
     */
    public function productExists($parkOrderItem)
    {
        $parkOrderItemCollection = $this->parkOrderItemCollectionFactory->create();
        $parkOrderItemCollection->addFieldToFilter('parked_order_id', $parkOrderItem->getParkedOrderId())
                                ->addFieldToFilter('product_id', $parkOrderItem->getProductId());
        if(empty($parkOrderItemCollection)){
            return false;
        }
        return $parkOrderItemCollection->getFirstItem();

    }
     /**
     * {@inheritdoc}
     */
    public function checkSharedOrder($parkedOrderId,$userId)
    {
        $parkOrderCollection = $this->getSharedOrder($parkedOrderId);
        if($parkOrderCollection->getIsShared() && $parkOrderCollection->getIsLocked() && $parkOrderCollection->getLockedBy()!=$userId){
            $currentUser = $this->getVenueUserName($parkOrderCollection->getLockedBy());
            throw new CouldNotSaveException(__('Parked order cannot be updated as it is being used by '.$currentUser));
        }
        return true;

    }
    /**
     * To get venue user name
     */
    public function getVenueUserName($venueUserId)
    {
        $venueUser =  $this->venueUserRepository->get($venueUserId);

        $venueUserFirstName = $venueUser->getFirstName();
        $venueUserLastName = $venueUser->getLastName();

        $venueUserName = $venueUserFirstName ." ".$venueUserLastName;

        return $venueUserName;
    }
    /**
     * {@inheritdoc}
     */
    public function getSharedOrder($parkedOrderId)
    {
        $parkOrderCollection = $this->parkOrderCollectionFactory->create();
        $parkOrderCollection->addFieldToFilter('parkorder_id', $parkedOrderId);
        if(empty($parkOrderCollection->getData())){
            throw new CouldNotSaveException(__('Parked order '.$parkedOrderId.' not found '));
        }
        return $parkOrderCollection->getFirstItem();
    }
    /**
     * {@inheritdoc}
     */
    public function sendSharedOrderNotification($parkOrderItem,$userId)
    {
        $parkOrderCollection = $this->getSharedOrder($parkOrderItem->getParkedOrderId());
        if(!empty($parkOrderCollection->getData())){
           $message = $parkOrderCollection->getName().' has been updated by '.$this->getVenueUserName($userId);
            $this->participantsRepositoryInterface->saveParticipantNotification(6, $parkOrderCollection->getVenueId(), $parkOrderCollection->getVenueUserId(), $message, 'venue_user', 'product added to shared parked order');
        }
        return true;
    }
    /**
     * To get formatted date 
     */
    public function getOrderTotals($parkOrderId)
    {
        $parkOrderItemCollection = $this->parkOrderItemCollectionFactory->create();
        $parkOrderItemCollection->addFieldToFilter('parked_order_id', $parkOrderId);
        $result = [];
        $sum = 0;
        $qtyTotal = 0;
        foreach ($parkOrderItemCollection as $item) {
            $sum += $item->getSubtotal();
            $qtyTotal += $item->getQty();
        }
        $result['total_price'] = $sum;
        $result['total_items'] = count($parkOrderItemCollection);
        return $result;
    }
    /**
     * {@inheritdoc}
     */
    public function get($parkOrderItemId)
    {
        $parkOrderItem = $this->parkOrderItemFactory->create();
        $this->resource->load($parkOrderItem, $parkOrderItemId);
        if (!$parkOrderItem->getId()) {
            throw new NoSuchEntityException(__('ParkOrderItem with id "%1" does not exist.', $parkOrderItemId));
        }
        return $parkOrderItem->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->parkOrderItemCollectionFactory->create();
        
        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Aria\ParkOrder\Api\Data\ParkOrderItemInterface::class
        );
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        foreach($items as $item){

            $productId = $item->getProductId();
            $productEntity = $this->productRepositoryInterface->getById($productId);
            $uom=$productEntity->getResource()->getAttributeRawValue($productEntity->getId(),'uom',$productEntity->getStore()->getWebsiteId());
            if(!empty($uom)) {
    
                $attribute = $this->eavConfig->getAttribute('catalog_product', 'uom');
                $uomName = $attribute->getSource()->getOptionText($uom);            
            } 
            $item->setUomName($uomName??'');
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \Aria\ParkOrder\Api\Data\ParkOrderItemInterface $parkOrderItem
    ) {
        try {
            $parkOrderItemModel = $this->parkOrderItemFactory->create();
            $this->resource->load($parkOrderItemModel, $parkOrderItem->getParkorderitemId());
            $this->resource->delete($parkOrderItemModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the ParkOrderItem: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($parkOrderItemId)
    {
        return $this->delete($this->get($parkOrderItemId));
    }
}

