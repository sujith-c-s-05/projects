<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ParkOrder\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface ParkOrderItemRepositoryInterface
{

    /**
     * Save ParkOrderItem
     * @param int $userId
     * @param \Aria\ParkOrder\Api\Data\ParkOrderItemInterface $parkOrderItem
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        $userId,
        \Aria\ParkOrder\Api\Data\ParkOrderItemInterface $parkOrderItem
    );

    /**
     * Retrieve ParkOrderItem
     * @param string $parkorderitemId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($parkorderitemId);

    /**
     * Retrieve ParkOrderItem matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete ParkOrderItem
     * @param \Aria\ParkOrder\Api\Data\ParkOrderItemInterface $parkOrderItem
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Aria\ParkOrder\Api\Data\ParkOrderItemInterface $parkOrderItem
    );

    /**
     * Delete ParkOrderItem by ID
     * @param string $parkorderitemId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($parkorderitemId);
}

