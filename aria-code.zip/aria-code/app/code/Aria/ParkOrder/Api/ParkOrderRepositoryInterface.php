<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ParkOrder\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface ParkOrderRepositoryInterface
{

    /**
     * Save ParkOrder
     * @param \Aria\ParkOrder\Api\Data\ParkOrderInterface $parkOrder
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Aria\ParkOrder\Api\Data\ParkOrderInterface $parkOrder
    );

    /**
     * Retrieve ParkOrder
     * @param string $parkorderId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($parkorderId);

    /**
     * Retrieve ParkOrder matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Aria\ParkOrder\Api\Data\ParkOrderSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete ParkOrder
     * @param \Aria\ParkOrder\Api\Data\ParkOrderInterface $parkOrder
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Aria\ParkOrder\Api\Data\ParkOrderInterface $parkOrder
    );

    /**
     * Delete ParkOrder by ID
     * @param string $parkorderId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($parkorderId);

    /**
     * Create new parked order
     * @param int $cartId
     * @param int $venueUserId
     * @param int $venueId 
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function createParkOrder($cartId,$venueUserId,$venueId);

    /**
     * Update order
     * @param int $parkOrderId 
     * @param int $userId
     * @param \Aria\ParkOrder\Api\Data\UpdateItemsInterface[] $items
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */

    public function updateOrderItems($parkOrderId,$userId,array $items);
    /**
     * Share Parked Order
     * @param int $parOrderId
     * @param int $isShared
     * @param int $venueUserId
     * @return bool true on success
     */
    public function shareParkedOrder($parkOrderId,$isShared,$venueUserId);

    /**
     * Get Parked Order
     * @param int $parOrderId
     * @param int $venueUserId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface[]
     */
    public function checkParkOrderEdit($parkOrderId,$venueUserId);

    /**
     * Lock or unlock parkorder
     * @param int $parOrderId
     * @param int $isLock
     * @param int $venueUserId
     * @return bool true on success
     */
    public function setLock($parkOrderId,$isLock,$venueUserId);

    /**
     * Get Parked Orders
     * @param int $venueId
     * @param int $venueUserId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface[]
     */
    public function getParkedOrders($venueId,$venueUserId);

}

