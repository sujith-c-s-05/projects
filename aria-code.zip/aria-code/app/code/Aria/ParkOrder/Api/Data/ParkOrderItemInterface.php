<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ParkOrder\Api\Data;

interface ParkOrderItemInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const PARKED_ORDER_NAME = 'parked_order_name';
    const QTY = 'qty';
    const PRICE = 'price';
    const NAME = 'name';
    const PARKORDERITEM_ID = 'parkorderitem_id';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const PARKED_ORDER_ID = 'parked_order_id';
    const SUBTOTAL = 'subtotal';
    const IMAGE = 'image';
    const SKU = 'sku';
    const SELLER_NAME = 'seller_name';
    const SELLER_ID = 'seller_id';
    const CATEGORY = 'category';
    const PRODUCT_ID = 'product_id';

    /**
     * Get parkorderitem_id
     * @return string|null
     */
    public function getParkorderitemId();

    /**
     * Set parkorderitem_id
     * @param string $parkorderitemId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setParkorderitemId($parkorderitemId);

    /**
     * Get name
     * @return string|null
     */
    public function getName();

    /**
     * Set name
     * @param string $name
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setName($name);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\ParkOrder\Api\Data\ParkOrderItemExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\ParkOrder\Api\Data\ParkOrderItemExtensionInterface $extensionAttributes
    );

    /**
     * Get sku
     * @return string|null
     */
    public function getSku();

    /**
     * Set sku
     * @param string $sku
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setSku($sku);

    /**
     * Get qty
     * @return string|null
     */
    public function getQty();

    /**
     * Set qty
     * @param string $qty
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setQty($qty);

    /**
     * Get price
     * @return string|null
     */
    public function getPrice();

    /**
     * Set price
     * @param string $price
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setPrice($price);

    /**
     * Get subtotal
     * @return string|null
     */
    public function getSubtotal();

    /**
     * Set subtotal
     * @param string $subtotal
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setSubtotal($subtotal);

    /**
     * Get image
     * @return string|null
     */
    public function getImage();

    /**
     * Set image
     * @param string $image
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setImage($image);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get parked_order_id
     * @return string|null
     */
    public function getParkedOrderId();

    /**
     * Set parked_order_id
     * @param string $parkedOrderId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setParkedOrderId($parkedOrderId);

    /**
     * Get parked_order_name
     * @return string|null
     */
    public function getParkedOrderName();

    /**
     * Set parked_order_name
     * @param string $parkedOrderName
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setParkedOrderName($parkedOrderName);

    /**
     * Get seller_id
     * @return string|null
     */
    public function getSellerId();

    /**
     * Set seller_id
     * @param string $sellerId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setSellerId($sellerId);

    /**
     * Get seller_name
     * @return string|null
     */
    public function getSellerName();

    /**
     * Set seller_name
     * @param string $sellerName
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setSellerName($sellerName);

    /**
     * Get category
     * @return string|null
     */
    public function getCategory();

    /**
     * Set category
     * @param string $category
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setCategory($category);

    /**
     * Get product_id
     * @return string|null
     */
    public function getProductId();

    /**
     * Set product_id
     * @param string $productId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setProductId($productId);

     /**
     * Get uom_name
     * @return string|null
     */
    public function getUomName();
    
    /**
     * Set uom_name
     * @param string $uomName
     * @return \Aria\ParkOrder\Api\Data\ParkOrderItemInterface
     */
    public function setUomName($uomName);
}

