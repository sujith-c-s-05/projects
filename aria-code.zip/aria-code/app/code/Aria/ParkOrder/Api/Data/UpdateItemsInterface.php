<?php
namespace Aria\ParkOrder\Api\Data;

/**
 * Interface which represents associative array item.
 */
interface UpdateItemsInterface
{  
    const ID = 'id';
    const QTY = 'qty';
    const PRICE = 'price';
    const IS_DELETE = 'is_delete';
    const PRODUCT_ID = 'product_id';

    /**
     * Get id
     * 
     * @return int
     */
    public function getId();
    /**
     * Get product_id
     * 
     * @return int
     */
    public function getProductId();

    /**
     * Get qty
     * 
     * @return int
     */
    public function getQty();

    /**
     * Get price
     * 
     * @return float
     */
    public function getPrice();
    /**
     * Get is_delete
     * 
     * @return int
     */
    public function getIsDelete();
    /**
     * Set id
     * @param $id
     * @return int
     */
    public function setId($id);
    /**
     * Set product_id
     * @param $productId
     * @return int
     */
    public function setProductId($productId);
    /**
     * Set qty
     * @param $qty
     * @return int
     */
    public function setQty($qty);

    /**
     * Set price
     *  @param $price
     * @return float
     */
    public function setPrice($price);
    /**
     * Set is_delete
     * @param $isDelete
     * @return int
     */
    public function setIsDelete($isDelete);
}