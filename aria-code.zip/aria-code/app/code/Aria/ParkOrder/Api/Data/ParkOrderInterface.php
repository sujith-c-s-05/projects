<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ParkOrder\Api\Data;

interface ParkOrderInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const VENUE_USER_ID = 'venue_user_id';
    const PRICE = 'price';
    const NAME = 'name';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const PARKORDER_ID = 'parkorder_id';
    const IS_DELETE = 'is_delete';
    const ITEM_COUNT = 'item_count';
    const VENUE_ID = 'venue_id';
    const IS_SHARED = 'is_shared';
    const IS_LOCKED = 'is_locked';
    const LOCKED_BY = 'locked_by';


    /**
     * Get parkorder_id
     * @return string|null
     */
    public function getParkorderId();

    /**
     * Set parkorder_id
     * @param string $parkorderId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setParkorderId($parkorderId);

    /**
     * Get name
     * @return string|null
     */
    public function getName();

    /**
     * Set name
     * @param string $name
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setName($name);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Aria\ParkOrder\Api\Data\ParkOrderExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Aria\ParkOrder\Api\Data\ParkOrderExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Aria\ParkOrder\Api\Data\ParkOrderExtensionInterface $extensionAttributes
    );

    /**
     * Get price
     * @return string|null
     */
    public function getPrice();

    /**
     * Set price
     * @param string $price
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setPrice($price);

    /**
     * Get venue_user_id
     * @return string|null
     */
    public function getVenueUserId();

    /**
     * Set venue_user_id
     * @param string $venueUserId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setVenueUserId($venueUserId);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_delete
     * @return string|null
     */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param string $isDelete
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setIsDelete($isDelete);

    /**
     * Get item_count
     * @return string|null
     */
    public function getItemCount();

    /**
     * Set item_count
     * @param string $itemCount
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setItemCount($itemCount);

    /**
     * Get venue_id
     * @return string|null
     */
    public function getVenueId();

    /**
     * Set venue_id
     * @param string $venueId
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setVenueId($venueId);

    /**
     * Get is_shared
     * @return int|null
     */
    public function getIsShared();

    /**
     * Set is_shared
     * @param int $isShared
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setIsShared($isShared);

    /**
     * Get is_locked
     * @return int|null
     */
    public function getIsLocked();

    /**
     * Set is_locked
     * @param int $isLocked
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setIsLocked($isLocked);

    /**
     * Get locked_by
     * @return int|null
     */
    public function getLockedBy();

    /**
     * Set locked_by
     * @param int $lockedBy
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface
     */
    public function setLockedBy($lockedBy);
}

