<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Aria\ParkOrder\Api\Data;

interface ParkOrderSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get ParkOrder list.
     * @return \Aria\ParkOrder\Api\Data\ParkOrderInterface[]
     */
    public function getItems();

    /**
     * Set name list.
     * @param \Aria\ParkOrder\Api\Data\ParkOrderInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

