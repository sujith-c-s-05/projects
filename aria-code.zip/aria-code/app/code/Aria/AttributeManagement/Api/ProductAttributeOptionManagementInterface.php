<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Aria\AttributeManagement\Api;

/**
 * @api
 * @since 100.0.2
 */
interface ProductAttributeOptionManagementInterface
{
    
    /**
     * Add option to attribute
     *
     * @param string $attributeCode
     * @param \Magento\Eav\Api\Data\AttributeOptionInterface $option
     * @param int $companyId
     * @param int $userId
     * @throws \Magento\Framework\Exception\StateException
     * @throws \Magento\Framework\Exception\InputException
     * @return string
     */
    public function add($attributeCode, $option ,$companyId ,$userId);

    /**
     * Update attribute option
     *
     * @param string $attributeCode
     * @param int $optionId
     * @param \Magento\Eav\Api\Data\AttributeOptionInterface $option
     * @param int $companyId
     * @param int $userId
     * @return bool
     * @throws \Magento\Framework\Exception\StateException
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\InputException
     */
    public function update(
        string $attributeCode,
        int $optionId,
        \Magento\Eav\Api\Data\AttributeOptionInterface $option,$companyId ,$userId
    ): bool;

    /**
     * Get Product Attributes
     *
     * @param string $sku
     * @return mixed[]
     */
    public function getProductAttributes(int $id);
}
