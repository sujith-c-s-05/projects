<?php

/**
 * @author      Magento Core Team <core@magentocommerce.com>
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Aria\AttributeManagement\Model\Product;

use Magento\Catalog\Api\Data\ProductAttributeInterface;
use Aria\AttributeManagement\Api\ProductAttributeOptionManagementInterface;
//use Magento\Catalog\Api\ProductAttributeOptionUpdateInterface;
use Magento\Eav\Api\AttributeOptionManagementInterface;
use Magento\Eav\Api\AttributeOptionUpdateInterface;
use Magento\Eav\Api\Data\AttributeOptionInterface;
use Magento\Framework\Exception\InputException;
use Aria\SupplyCompanyAccount\Model\ResourceModel\DCUser\CollectionFactory as DCUserCollectionFactory;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Phrase;
use Magento\Framework\Pricing\PriceCurrencyInterface;


/**
 * Option management model for product attribute.
 */
class OptionManagement implements ProductAttributeOptionManagementInterface
{
    /**
     * @var AttributeOptionManagementInterface
     */
    protected $eavOptionManagement;

    /**
     * @var AttributeOptionUpdateInterface
     */
    private $eavOptionUpdate;

    /**
     * @param AttributeOptionManagementInterface $eavOptionManagement
     * @param AttributeOptionUpdateInterface $eavOptionUpdate
     */
    public function __construct(
        AttributeOptionManagementInterface $eavOptionManagement,
        AttributeOptionUpdateInterface $eavOptionUpdate,
        DCUserCollectionFactory $dCUserCollectionFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        StateInterface $state,
        TransportBuilder $transportBuilder,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        PriceCurrencyInterface $priceCurrency
    ) {
        $this->eavOptionManagement = $eavOptionManagement;
        $this->eavOptionUpdate = $eavOptionUpdate;
        $this->dCUserCollectionFactory = $dCUserCollectionFactory;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->inlineTranslation = $state;
        $this->transportBuilder = $transportBuilder;
        $this->productFactory = $productFactory;
        $this->priceCurrency = $priceCurrency;
    }

    /**
     * @inheritdoc
     */
    public function add($attributeCode, $option, $companyId, $userId)
    {
        $optionId = $this->eavOptionManagement->add(
            ProductAttributeInterface::ENTITY_TYPE_CODE,
            $attributeCode,
            $option
        );
        $this->fetchCompanyDetails($companyId, $userId,$attributeCode);
        return $optionId;
    }

    /**
     * @inheritdoc
     */
    public function update(string $attributeCode, int $optionId, AttributeOptionInterface $option, $companyId, $userId): bool
    {
        $isUpdate =  $this->eavOptionUpdate->update(
            ProductAttributeInterface::ENTITY_TYPE_CODE,
            $attributeCode,
            $optionId,
            $option
        );
        $this->fetchCompanyDetails($companyId, $userId,$attributeCode);
        return $isUpdate;
    }

    public function fetchCompanyDetails($companyId, $userId,$attributeCode)
    {
        $collection = $this->dCUserCollectionFactory->create();
        $collection->addFieldToFilter('id', $userId);
        $collection->getSelect()->joinLeft(
            ['sc' => 'aria_supply_company'],
            'main_table.sc_id = sc.supplycompany_id',
            ['*']
        );

        if (count($collection) == 1) {
            $supplyCompany = $collection->getFirstItem();

            $supplycompanyName = $supplyCompany->getData('company_name');
            $userName = $supplyCompany->getData('company_name');

            $this->sendEmail($supplycompanyName, $userName, $attributeCode);
        }

        return true;
    }

    public function sendEmail($supplycompanyName, $userName, $attribute)
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

        $email = $this->scopeConfig->getValue('trans_email/ident_support/email', $storeScope);
        $sender_name  = $this->scopeConfig->getValue('trans_email/ident_support/name', $storeScope);


        $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId());
        $templateVars = array(
            'companyName' => $supplycompanyName,
            'userName' => $userName,
            'attributeName' => $attribute
        );

        $from = ['email' => $email, 'name' => $sender_name];
        $this->inlineTranslation->suspend();
        $transport = $this->transportBuilder->setTemplateIdentifier('attribute_update_template', $storeScope)
            ->setTemplateOptions($templateOptions)
            ->setTemplateVars($templateVars)
            ->setFrom($from)
            ->addTo($email)
            ->getTransport();
        $transport->sendMessage();
        $this->inlineTranslation->resume();

        return true;
    }

    /**
     * @inheritdoc
     */
    public function getProductAttributes(int $id)
    {
        $data = [];
        $excludeAttr = [];

        $product = $this->productFactory->create();
        $product->load($id);

        $attributes = $product->getAttributes();
        foreach ($attributes as $attribute) {
            if ($this->isVisibleOnFrontend($attribute, $excludeAttr)) {
                $value = $attribute->getFrontend()->getValue($product);

                if ($value instanceof Phrase) {
                    $value = (string)$value;
                } elseif ($attribute->getFrontendInput() == 'price' && is_string($value)) {
                    $value = $this->priceCurrency->convertAndFormat($value);
                }

                if (is_string($value) && strlen(trim($value))) {
                    $data[$attribute->getAttributeCode()] = [
                        'label' => $attribute->getStoreLabel(),
                        'value' => $value,
                        'code' => $attribute->getAttributeCode(),
                    ];
                }
            }
        }
        return $data;
    }

    /**
     * Determine if we should display the attribute on the front-end
     *
     * @param \Magento\Eav\Model\Entity\Attribute\AbstractAttribute $attribute
     * @param array $excludeAttr
     * @return bool
     * @since 103.0.0
     */
    protected function isVisibleOnFrontend(
        \Magento\Eav\Model\Entity\Attribute\AbstractAttribute $attribute,
        array $excludeAttr
    ) {
        return ($attribute->getIsVisibleOnFront() && !in_array($attribute->getAttributeCode(), $excludeAttr));
    }
}
