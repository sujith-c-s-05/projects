<?php

/**
 *
 */

namespace Bazar\SellerManagement\Controller\Adminhtml\ChangeStatus;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;

class Index extends \Magento\Backend\App\Action
{
    protected $request;
    protected $scopeConfig;
    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    protected $resultPageFactory = false;
    /**
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Bazar\SellerManagement\Model\SellerFactory $sellerFactory
     */
    public function __construct(
        \Magento\Framework\App\Request\Http $request,
        ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Bazar\SellerManagement\Model\SellerFactory $sellerFactory,
        CustomerRepositoryInterface $customerRepositoryInterface
    ) {
        parent::__construct($context);
        $this->scopeConfig = $scopeConfig;
        $this->request = $request;
        $this->_transportBuilder = $transportBuilder;
        $this->_storeManager = $storeManager;
        $this->resultPageFactory = $resultPageFactory;
        $this->sellerFactory = $sellerFactory;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
    }
    /**
     * execute
     *
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $status = $this->getRequest()->getParam('status');
        $seller = $this->sellerFactory->create()->load($id);
        if ($seller) {
            $seller->setIsActive($status);
            $seller->save();
            $this->messageManager->addSuccess(__('Status Updated!'));
        }
        
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('bazar_sellermanagement/seller', ['_current' => true]);
    }
}