<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SellerManagement\Controller\Adminhtml\Seller;

use Magento\Framework\Exception\LocalizedException;
use Magento\Store\Model\StoreManagerInterface;

class Save extends \Magento\Backend\App\Action
{

    protected $dataPersistor;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Bazar\SellerManagement\Model\SellerRepository $sellerRepository,
        StoreManagerInterface $storeManager
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->customerFactory  = $customerFactory;
        $this->storeManager = $storeManager;
        $this->sellerRepository = $sellerRepository;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        if ($data) {
            $id = $this->getRequest()->getParam('id');
            if (isset($data['email_id']) && $id) {
                unset($data['email_id']);
            }
            $model = $this->_objectManager->create(\Bazar\SellerManagement\Model\Seller::class)->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addErrorMessage(__('This Seller no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
            if (!$id) {
                if(!$this->validateEmail($data['email_id']))
                {
                    $this->messageManager->addErrorMessage( __('Email ID exists'));
                    $this->dataPersistor->set('bazar_sellermanagement_seller', $data);
                    return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
                }
                $password = $this->generateStrongPassword();
                $customer = $this->createCustomer($data, $password);
                if ($customer->getId()) {
                    $data['customer_id'] = $customer->getId();
                } else {
                    throw new LocalizedException(__('Customer Not Created.'));
                }
            }

            $model->setData($data);

            

            try {
                $model->save();
                if (!$id) {
                    $this->sellerRepository->sentNotificationMail($data['email_id'], $model);
                }
                if (!$id && $data['is_active']) {
                    $this->sellerRepository->sentNotificationMail($data['email_id'], $model, $password);
                }
                $this->messageManager->addSuccessMessage(__('Seller details saved successfully.'));
                $this->dataPersistor->clear('bazar_sellermanagement_seller');
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage(
                    $e,
                    __(
                        'Something went wrong while saving the Seller.' . $e->getMessage()
                    )
                );
            }

            $this->dataPersistor->set('bazar_sellermanagement_seller', $data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
    /**
     *
     * @param mixed $seller
     * @return mixed
     */
    public function createCustomer($data, $password)
    {
        $websiteId  = $this->storeManager->getWebsite()->getWebsiteId();
        $customer = $this->customerFactory->create();
        if (!$customer->getStoreId()) {
            if ($customer->getWebsiteId()) {
                $storeId = $this->storeManager->getWebsite($customer->getWebsiteId())->getDefaultStore()->getId();
            } else {
                $this->storeManager->setCurrentStore(null);
                $storeId = $this->storeManager->getStore()->getId();
            }
            $customer->setStoreId($storeId);
        }
        if (!$customer->getWebsiteId()) {
            $websiteId = $this->storeManager->getStore($customer->getStoreId())->getWebsiteId();
            $customer->setWebsiteId($websiteId);
        }
        $customer->setWebsiteId($websiteId);
        $customer->setEmail($data['email_id']);
        $customer->setFirstname($data['first_name']);
        $customer->setLastname($data['first_name']);
        $customer->setGroupId(\Bazar\SellerManagement\Api\SellerRepositoryInterface::CUSTOMER_GROUP_ID);
        $customer->setPassword($password);
        return $customer->save();
    }
    /**
     * Retrieve seller by email id
     * @param string $email
     * @return bool|null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function validateEmail($email)
    {

        $websiteId  = $this->storeManager->getWebsite()->getWebsiteId();
        $customer = $this->customerFactory->create();
        $customer->setWebsiteId(1);
        $customer->loadByEmail($email);
        if ($customer->getId()) {
            return false;
            throw new LocalizedException(__(
                'There is already an account associated with this email adress.'
                
            ));
        }
        return true;
    }
    /**
     *
     * @param integer $length
     * @param boolean $addDashes
     * @param string $availableSets
     * @return mixed
     */
    public function generateStrongPassword($length = 8, $availableSets = 'luds')
    {
        $sets = [];
        if (strpos($availableSets, 'l') !== false) {
            $sets[] = 'abcdefghjkmnpqrstuvwxyz';
        }
        if (strpos($availableSets, 'u') !== false) {
            $sets[] = 'ABCDEFGHJKMNPQRSTUVWXYZ';
        }
        if (strpos($availableSets, 'd') !== false) {
            $sets[] = '23456789';
        }
        if (strpos($availableSets, 's') !== false) {
            $sets[] = '!@#$%&*?';
        }

        $all = '';
        $password = '';
        foreach ($sets as $set) {
            $password .= $set[$this->tweakArrayRand(str_split($set))];
            $all .= $set;
        }

        $all = str_split($all);
        $i = 0;
        while ($i < $length - count($sets)) {
            $password .= $all[$this->tweakArrayRand($all)];
            $i++;
        }

        $password = str_shuffle($password);

        return $password;
    }
    /**
     *
     * @param mixed $array
     * @return mixed
     */
    public function tweakArrayRand($array)
    {
        if (function_exists('random_int')) {
            return random_int(0, count($array) - 1);
        } else {
            return array_rand($array);
        }
    }
}
