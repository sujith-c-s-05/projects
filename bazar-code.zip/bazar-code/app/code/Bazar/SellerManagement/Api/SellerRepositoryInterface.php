<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SellerManagement\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface SellerRepositoryInterface
{
    const CUSTOMER_GROUP_ID = 5;

    /**
     * Save Seller
     * @param Bazar\SellerManagement\Api\Data\SellerInterface $seller
     * @return Bazar\SellerManagement\Api\Data\SellerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Bazar\SellerManagement\Api\Data\SellerInterface $seller
    );

    /**
     * Retrieve seller
     * @param string $sellerId
     * @return Bazar\SellerManagement\Api\Data\SellerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($sellerId);
    /**
     * Retrieve seller by email id
     * @param string $sellerEmail
     * @return bool|null
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function checkCustomerExists($sellerEmail);
    /**
     * Retrieve sellers matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Bazar\SellerManagement\Api\Data\SellerSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete seller
     * @param int $id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete($id);

     /**
      * Retrieve seller
      * @param string $sellerEmail
      * @return Bazar\SellerManagement\Api\Data\SellerInterface
      * @throws \Magento\Framework\Exception\LocalizedException
      */
    public function getSellerByEmail($sellerEmail);
    /**
     * @param int $customerId
     * @param string $token
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function verifyCustomer($customerId, $token);

    /**
     * Create access token for customer credentials.
     *
     * @param string $username
     * @param string $password
     * @return string Token created
     * @throws \Magento\Framework\Exception\AuthenticationException
     */
    public function createCustomerAccessToken($username, $password);

    /**
     * change customer password.
     *
     * @param string $sellerId
     * @param string $currentPassword
     * @param string $newPassword
     *
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws InputException
     */
    public function changePassword($sellerId, $currentPassword, $newPassword);

    /**
     * Get password reset code.
     *
     * @param string $email
     *
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws InputException
     */
    public function getPasswordResetCode($email);

    /**
     * Check verification code and set Password
     *
     * @param string $email
     * @param string $code
     * @param string $password
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws InputException
     */
    public function checkVerificationCodeAndSetPassword($email, $code, $password);
    /**
     * To send the verification mail to email address
     * 
     * @param string $emailAPI
     * @param string $first_name
     * @param string $last_name
     * @param string $invite_code
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws InputException
     */
    public function emailVerification($first_name,$last_name,$invite_code,$emailAPI);
    
   

    /**
     * Get details of seller
    * @param Bazar\SellerManagement\Api\Data\SellerInterface $seller
     * @return Bazar\SellerManagement\Api\Data\SellerInterface
     */
    public function signUpBazarSeller(\Bazar\SellerManagement\Api\Data\SellerInterface $seller);
    
    /** 
     * @param string $inviteCode
     * @return bool
    */
    public function validateInviteCode($inviteCode);

   /**
     * set store url
     * @param int $customerId
     * @param string $storeUrl
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function setSellerStoreUrl($customerId,$storeUrl);

}
