<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SellerManagement\Api\Data;

interface SellerSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get DeliverySlot list.
     * @return \Bazar\SellerManagement\Api\Data\SellerInterface[]
     */
    public function getItems();

    /**
     * Set DeliverySlot list.
     * @param \Bazar\SellerManagement\Api\Data\SellerInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
