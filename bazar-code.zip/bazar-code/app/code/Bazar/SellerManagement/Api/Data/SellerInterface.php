<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SellerManagement\Api\Data;

interface SellerInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**#@+
     * Constants defined for keys of the data array. Identical to the name of the getter in snake case
     */
    const ID = 'id';
    const CUSTOMER_ID = 'customer_id';
    const FIRST_NAME = 'first_name';
    const LAST_NAME = 'last_name';
    const EMAIL_ID = 'email_id';
    const MOBILE_NUMBER = 'mobile_number';
    const ROUTING_NO = 'routing_no';
    const ACCOUNT_NO = 'account_no';
    const TOTAL_EARNING = 'total_earning';
    const TOTAL_CUSTOMER_ORDER = 'total_customer_order';
    const AVAILABLE_CASH = 'available_cash';
    const BANK_INFO = 'bank_info';
    const CREDITCARD_NO = 'creditcard_no';
    const EXP_DATE = 'exp_date';
    const ZIP_CODE = 'zip_code';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const IS_ACTIVE = 'is_active';
    const IS_DELETED = 'is_deleted';
    const STORE_URL='store_url';
    const INVITE_CODE='invite_code';
    const CUSTOMER_PASSWORD = 'password';


    /**#@-*/

    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param string $id
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setId($id);

    /**
     * Get customer_id
     * @return int|null
     */
    public function getCustomerId();

    /**
     * Set customer_id
     * @param string $customerId
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setCustomerId($customerId);

    /**
     * Get first_name
     * @return string|null
     */
    public function getFirstName();

    /**
     * Set first_name
     * @param string $firstName
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setFirstName($firstName);

    /**
     * Get invite_code
     * @return string|null
     */
    public function getInviteCode();

    /**
     * Set invite_code
     * @param string $inviteCode
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setInviteCode($inviteCode);

    /**
     * Get last_name
     * @return string|null
     */
    public function getLastName();

    /**
     * Set last_name
     * @param string $lastName
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setLastName($lastName);
    

    /**
     * Get email_id
     * @return string|null
     */
    public function getEmailId();

    /**
     * Set email_id
     * @param string $emailId
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setEmailId($emailId);

    /**
     * Get store_url
     * @return string|null
     */
    public function getStoreUrl();

    /**
     * Set store_url
     * @param string $storeUrl
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setStoreUrl($storeUrl);

    /**
     * Get mobile_number
     * @return string|null
     */
    public function getMobileNumber();

    /**
     * Set mobile_number
     * @param string $mobileNumber
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setMobileNumber($mobileNumber);
    
    /**
     * Get routing_no
     * @return string|null
     */
    public function getRoutingNo();

    /**
     * Set routing_number
     * @param string $routingNumber
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setRoutingNo($routingNumber);

    /**
     * Get account_no
     * @return string|null
     */
    public function getAccountNo();

    /**
     * Set account_no
     * @param string $accountNo
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setAccountNo($accountNo);
    
    /**
     * Get total_earning
     * @return float |null
     */
    public function getTotalEarning();

    /**
     * Set total_earning
     * @param float  $totalEarning
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setTotalEarning($totalEarning);

    /**
     * Get total_customer_order
     * @return int|null
     */
    public function getTotalCustomerOrder();

    /**
     * Set total_customer_order
     * @param int $totalCustomerOrder
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setTotalCustomerOrder($totalCustomerOrder);
    
    /**
     * Get available_cash
     * @return float|null
     */
    public function getAvailableCash();

    /**
     * Set available_cash
     * @param string $availableCash
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setAvailableCash($availableCash);

    /**
     * Get bank_info
     * @return string|null
     */
    public function getBankInfo();

    /**
     * Set bank_info
     * @param string $bankInfo
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setBankInfo($bankInfo);

    /**
     * Get credit_card_no
     * @return string|null
     */
    public function getCreditCardNo();

    /**
     * Set credit_card_no
     * @param string $creditCardNo
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setCreditCardNo($creditCardNo);

    /**
     * Get exp_date
     * @return string|null
     */
    public function getExpData();

    /**
     * Set exp_date
     * @param string $expDate
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setExpData($expDate);
    /**
     * Get passowrd
     * @return string|null
     */
    public function getPassword();

    /**
     * Set passowrd
     * @param string $passowrd
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setPassword($passowrd);

    /**
     * Get zip_code
     * @return string|null
     */
    public function getZipCode();

    /**
     * Set zip_code
     * @param string $zipCode
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setZipCode($zipCode);

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setCreatedby($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setUpdatedBy($updatedBy);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_deleted
     * @return string|null
     */
    public function getIsDeleted();

    /**
     * Set is_deleted
     * @param string $isDeleted
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setIsDeleted($isDeleted);
    /**
     * Get is_active
     * @return string|null
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param string $isActive
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setIsActive($isActive);

}
