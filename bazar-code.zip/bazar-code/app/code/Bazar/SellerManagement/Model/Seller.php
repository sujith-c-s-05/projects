<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SellerManagement\Model;

use Bazar\SellerManagement\Api\Data\SellerInterface;
use Bazar\SellerManagement\Api\Data\SellerInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Serialize\SerializerInterface;

class Seller extends \Magento\Framework\Model\AbstractModel
{

    protected $dataObjectHelper;
    protected $parkorderDataFactory;
    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param SellerInterfaceFactory $sellerInterfaceFactory
     * @param SerializerInterface $serializer
     * @param DataObjectHelper $dataObjectHelper
     * @param \Bazar\SellerManagement\Model\ResourceModel\Seller $resource
     * @param \Bazar\SellerManagement\Model\ResourceModel\Seller\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        SellerInterfaceFactory $sellerInterfaceFactory,
        SerializerInterface $serializer,
        DataObjectHelper $dataObjectHelper,
        \Bazar\SellerManagement\Model\ResourceModel\Seller $resource,
        \Bazar\SellerManagement\Model\ResourceModel\Seller\Collection $resourceCollection,
        array $data = []
    ) {
        $this->sellerInterfaceFactory = $sellerInterfaceFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->serializer = $serializer;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve SellerInterfaceData
     * @return SellerInterface
     */
    public function getDataModel()
    {
        $sellerData = $this->getData();
        $sellerDataObject = $this->sellerInterfaceFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $sellerDataObject,
            $sellerData,
            SellerInterface::class
        );

        return $sellerDataObject;
    }
}
