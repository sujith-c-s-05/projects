<?php
namespace Bazar\SellerManagement\Model;
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
use Bazar\SellerManagement\Api\Data\SellerInterfaceFactory;
use Magento\Framework\Exception\MailException;
use Bazar\SellerManagement\Api\Data\SellerSearchResultsInterfaceFactory;
use Bazar\SellerManagement\Api\SellerRepositoryInterface;
use Bazar\SellerManagement\Model\ResourceModel\Seller as ResourceSeller;
use Bazar\SellerManagement\Model\ResourceModel\Seller\CollectionFactory as SellerCollectionFactory;
use Bazar\SupplierManagement\Model\ResourceModel\Invite\CollectionFactory as inviteCollectionFactory;
use Magento\Integration\Model\CredentialsValidator;
use Magento\Integration\Model\Oauth\Token as Token;
use Magento\Integration\Model\Oauth\TokenFactory as TokenModelFactory;
use Magento\Integration\Model\ResourceModel\Oauth\Token\CollectionFactory as TokenCollectionFactory;
use Magento\Integration\Model\Oauth\Token\RequestThrottler;
use Magento\Framework\Exception\AuthenticationException;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Stdlib\StringUtils as StringHelper;
use Magento\Store\Model\ScopeInterface;
use Bazar\SupplierManagement\Api\InviteRepositoryInterface;


class SellerRepository implements SellerRepositoryInterface
{
    const XML_PATH_REQUIRED_CHARACTER_CLASSES_NUMBER = 'customer/password/required_character_classes_number';

    const XML_PATH_MINIMUM_PASSWORD_LENGTH = 'customer/password/minimum_password_length';
    /**
     * Token Model
     *
     * @var TokenModelFactory
     */
    private $tokenModelFactory;

    /**
     * @var Magento\Framework\Event\ManagerInterface
     */
    private $eventManager;

    /**
     * Customer Account Service
     *
     * @var AccountManagementInterface
     */
    private $accountManagement;

    /**
     * @var \Magento\Integration\Model\CredentialsValidator
     */
    private $validatorHelper;

    /**
     * Token Collection Factory
     *
     * @var TokenCollectionFactory
     */
    private $tokenModelCollectionFactory;

    /**
     * @var RequestThrottler
     */
    private $requestThrottler;
    protected $inviteCollectionFactory;

    /**
     * @param ResourceSeller $resource
     * @param SellerFactory $sellerFactory
     * @param SellerInterfaceFactory $sellerInterfaceFactory
     * @param SellerCollectionFactory $sellerCollectionFactory
     * @param InviteCollectionFactory $inviteCollectionFactory
     * @param SellerSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Magento\Integration\Model\CredentialsValidator $validatorHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param CustomerInterfaceFactory $customerInterfaceFactory
     * @param AccountManagementInterface $accountManagementInterface
     * @param CustomerRepositoryInterface $customerRepositoryInterface
     * @param ScopeConfigInterface $scopeConfig
     * @param StringHelper $stringHelper
     * @param TokenModelFactory $tokenModelFactory
     * @param AccountManagementInterface $accountManagement
     * @param TokenCollectionFactory $tokenModelCollectionFactory
     * @param \Magento\Integration\Model\CredentialsValidator $validatorHelper
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     */
    public function __construct(
        ResourceSeller $resource,
        TokenModelFactory $tokenModelFactory,
        TokenCollectionFactory $tokenModelCollectionFactory,
        InviteCollectionFactory $inviteCollectionFactory,
        ManagerInterface $eventManager = null,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        \Magento\Framework\Math\Random $mathRandom,
        \Magento\Customer\Model\ResourceModel\Customer\CollectionFactory $customerCollectionFactory,
        StateInterface $state,
        SellerFactory $sellerFactory,
        SellerInterfaceFactory $sellerInterfaceFactory,
        SellerCollectionFactory $sellerCollectionFactory,
        SellerSearchResultsInterfaceFactory $searchResultsFactory,
        CredentialsValidator $validatorHelper,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Customer\Model\CustomerRegistry $customerRegistry,
        \Magento\Framework\Encryption\EncryptorInterface $encryptor,
        CustomerInterfaceFactory $customerInterfaceFactory,
        AccountManagementInterface $accountManagement,
        CustomerRepositoryInterface $customerRepositoryInterface,
        ScopeConfigInterface $scopeConfig,
        StringHelper $stringHelper,
        \Bazar\SupplierManagement\Model\EmailTokenRepository $mailTokenRepository
    ) {
        $this->customerCollectionFactory = $customerCollectionFactory;
        $this->tokenModelFactory = $tokenModelFactory;
        $this->validatorHelper = $validatorHelper;
        $this->accountManagement = $accountManagement;
        $this->tokenModelCollectionFactory = $tokenModelCollectionFactory;
        $this->inviteCollectionFactory = $inviteCollectionFactory;
        $this->customerRepository= $customerRepository;
        $this->mathRandom= $mathRandom;
        $this->inlineTranslation = $state;
        $this->resource = $resource;
        $this->sellerFactory = $sellerFactory;
        $this->sellerCollectionFactory = $sellerCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->sellerInterfaceFactory = $sellerInterfaceFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->_conn = $resourceConnection->getConnection();
        $this->customerFactory  = $customerFactory;
        $this->customerInterfaceFactory = $customerInterfaceFactory;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
        $this->scopeConfig = $scopeConfig;
        $this->stringHelper = $stringHelper;
        $this->transportBuilder = $transportBuilder;
        $this->customerRegistry = $customerRegistry;
        $this->encryptor = $encryptor;
        $this->mailTokenRepository = $mailTokenRepository;
        $this->eventManager = $eventManager ?: \Magento\Framework\App\ObjectManager::getInstance()
            ->get(ManagerInterface::class);
    }

    /**
     * Undocumented function
     *
     * @param \Bazar\SellerManagement\Api\Data\SellerInterface $seller
     * @return void
     */
    public function save(
        \Bazar\SellerManagement\Api\Data\SellerInterface $seller
    ) {
        $this->_conn->beginTransaction();
        $sellerData = $this->extensibleDataObjectConverter->toNestedArray(
            $seller,
            [],
            \Bazar\SellerManagement\Api\Data\SellerInterface::class
        );
        try {
            $this->validateInfo($sellerData);
            if (!isset($sellerData['id']) && isset($sellerData['email_id'])) {
                $this->checkCustomerExists($sellerData['email_id']);
            }
            $customer = $this->createCustomer($seller);
            if (!$customer->getId()) {
                throw new CouldNotSaveException(__('Could not save the Customer'));
            }
            $sellerData['customer_id'] = $customer->getId();
            $this->updateTokenData($sellerData['customer_id']);
             unset($sellerData['password']);
            //------------************* ADD Fields
            $sellerModel = $this->sellerFactory->create()->setData($sellerData);
            
            $this->resource->save($sellerModel);
            $mailtoNotify = $sellerModel->getNotificationEmail();
             if (!$mailtoNotify) {
                 $mailtoNotify = $sellerModel->getCustomerEmail();
                 $mailtoNotify = $sellerModel->getEmailId();
             }
            $this->_conn->commit();
        } catch (\Exception $exception) {
            $this->_conn->rollBack();
            throw new CouldNotSaveException(__(
                'Could not save the Seller: %1',
                $exception->getMessage()
            ));
        }
        $this->sentNotificationMail($mailtoNotify, $sellerModel);
        return $sellerModel->getDataModel();
    }



     /**
     * @inheritdoc
     */
    public function createCustomerAccessToken($username, $password)
    {
        $isPasswordSet = 0 ;
        $this->validatorHelper->validate($username, $password);
        $this->getRequestThrottler()->throttle($username, RequestThrottler::USER_TYPE_CUSTOMER);
        try {
            $customerDataObject = $this->accountManagement->authenticate($username, $password);
        } catch (\Exception $e) {
            $this->getRequestThrottler()->logAuthenticationFailure($username, RequestThrottler::USER_TYPE_CUSTOMER);
            throw new AuthenticationException(
                __(
                    'Username or password incorrect. '
                    . 'Please wait and try again later.'
                )
            );
        }
        if (!$customerDataObject->getCustomAttribute('user_confirmation')->getValue()) {
            throw new AuthenticationException(
                __(
                    'You have not confirmed the Email that is sent to you Please confirm the Email and try Login again.'
                )
            );
        }

        $this->eventManager->dispatch('customer_login', ['customer' => $customerDataObject]);
        $this->getRequestThrottler()->resetAuthenticationFailuresCount($username, RequestThrottler::USER_TYPE_CUSTOMER);
        $token = $this->tokenModelFactory->create()->createCustomerToken($customerDataObject->getId())->getToken();
        if ($resetPassword = $customerDataObject->getCustomAttribute('is_password_set')) {
            $isPasswordSet = $resetPassword->getValue();
        }
        $userDetails['email_id'] = $customerDataObject->getEmail();
        $userDetails['is_password_reset'] = $isPasswordSet;
        $userDetails['token'] = $token;
        $userDetails['seller_id'] = $this->getSellerId($customerDataObject->getId());

        return  [$userDetails];
    }


    /**
     * @inheritdoc
     */
    public function changePassword($sellerId, $currentPassword, $newPassword)
    {
        $this->accountManagement->changePasswordById($sellerId, $currentPassword, $newPassword);

        $customer = $this->customerRepository->getById($sellerId);
        $customer->setCustomAttribute('is_password_set', 1);
        $this->customerRepository->save($customer);

        return true;
    }

    /**
     * @inheritdoc
     */
    public function getPasswordResetCode($email)
    {
        $customerCollection = $this->customerCollectionFactory->create();
        $customerCollection->addAttributeToFilter('email', $email);

        if (count($customerCollection) ==1) {
            $customer = $customerCollection->getFirstItem();
            $verificationCode = rand(100000, 999999);
            $this->sendEmailWithVerificationCode($email, $verificationCode);

            return true;
        } else {
            throw new AuthenticationException(
                __(
                    'Invalid Username or email.'
                )
            );
        }
        return false;
    }

    /**
     * Get request throttler instance
     *
     * @return RequestThrottler
     * @deprecated 100.0.4
     */
    private function getRequestThrottler()
    {
        if (!$this->requestThrottler instanceof RequestThrottler) {
            return \Magento\Framework\App\ObjectManager::getInstance()->get(RequestThrottler::class);
        }
        return $this->requestThrottler;
    }

    /**
     * To generate Password reset Token
     */
    public function getToken($email)
    {
        $customer = $this->_customerRepository->get($email, $this->storeManager->getStore()->getWebsiteId());

        $newPasswordToken = $this->_mathRandom->getUniqueHash();
        $this->_accountmanagement->changeResetPasswordLinkToken($customer, $newPasswordToken);
    }

    /**
     * Send Email with forgot password
     */
    public function sendEmailWithVerificationCode($email, $code)
    {
        $templateOptions = ['area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                            'store' => $this->storeManager->getStore()->getId()];
        $templateVars = [
            'code' => $code
        ];
        $senderEmail = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $sender_name  = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
        $from = ['email' => $senderEmail, 'name' => $sender_name];
        $this->inlineTranslation->suspend();
        $transport = $this->transportBuilder
                          ->setTemplateIdentifier('password_reset_code_template', ScopeInterface::SCOPE_STORE)
            ->setTemplateOptions($templateOptions)
            ->setTemplateVars($templateVars)
            ->setFrom($from)
            ->addTo($email)
            ->getTransport();
        $transport->sendMessage();
        $this->inlineTranslation->resume();
        return true;
    }

    /**
     * @inheritdoc
     */
    public function checkVerificationCodeAndSetPassword($email, $code, $password)
    {
        $customerCollection = $this->customerCollectionFactory->create();
        $customerCollection->addAttributeToFilter('email', $email);

        if (count($customerCollection) ==1)
         {
            $customer = $customerCollection->getFirstItem();
            $customerId = $customer->getId();
                $this->setPassword($customerId, $password);
                return true;
         }
        else{
        return false;}
    }


    /**
     * To set the Password
     */
    public function setPassword($customerId, $password)
    {
        $customer = $this->customerRepository->getById($customerId);
        $customerSecure = $this->customerRegistry->retrieveSecureData($customerId);
        $customerSecure->setRpToken(null);
        $customerSecure->setRpTokenCreatedAt(null);
        $customerSecure->setPasswordHash($this->encryptor->getHash($password, true));
        $this->customerRepository->save($customer);
    }



     /**
      * To get Seller Id
      */
    public function getSellerId($customerId)
    {
        $sellerCollection = $this->sellerCollectionFactory->create();
        $sellerCollection->addFieldToFilter('customer_id', $customerId);


        if (count($sellerCollection) == 1) {
            $seller = $sellerCollection->getFirstItem();

            return $seller->getId();
        }

        throw new AuthenticationException(
            __(
                'Invalid seller or seller not active'
            )
        );
    }


    /**
     * Retrieve seller by email id
     * @param string $sellerEmail
     * @return bool|null
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function checkCustomerExists($sellerEmail)
    {

        $websiteId  = $this->storeManager->getWebsite()->getWebsiteId();
        $customer = $this->customerFactory->create();
        $customer->setWebsiteId(1);
        $customer->loadByEmail($sellerEmail);
        if ($customer->getId()) {
            throw new CouldNotSaveException(__(
                'Seller already exists!'
            ));
        }
        return false;
    }


    /**
     * @param string[] $sellerData
     * @return void
     */
    public function validateInfo($sellerData)
    {
        $requiredFields = [
            'first_name',
            'last_name',
            'invite_code'
           
        ];
        foreach ($requiredFields as $field) {
            if (!in_array($field, array_keys($sellerData))) {
                throw new CouldNotSaveException(__(
                    '%1 is Required!',
                    $field
                ));
            } elseif ($sellerData[$field] == 'business_type') {
                $this->validateBusinessType($sellerData[$field]);
                continue;
            } elseif (empty($sellerData[$field]) || $sellerData[$field] == '  ' | $sellerData[$field] == null) {
                throw new CouldNotSaveException(__(
                    '%1 cannot be empty!',
                    $field
                ));
            }
        }
    }


    /**
     *
     * @param mixed $seller
     * @return mixed
     */
    public function createCustomer($seller)
    {    $this->checkPasswordStrength($seller->getPassword());
        $websiteId  = $this->storeManager->getWebsite()->getWebsiteId();
        $customer = $this->customerFactory->create();
        // Associate website_id with customer
        if (!$customer->getStoreId()) {
            if ($customer->getWebsiteId()) {
                $storeId = $this->storeManager->getWebsite($customer->getWebsiteId())->getDefaultStore()->getId();
            } else {
                $this->storeManager->setCurrentStore(null);
                $storeId = $this->storeManager->getStore()->getId();
            }
            $customer->setStoreId($storeId);
        }
        if (!$customer->getWebsiteId()) {
            $websiteId = $this->storeManager->getStore($customer->getStoreId())->getWebsiteId();
            $customer->setWebsiteId($websiteId);
        }

        $customer->setWebsiteId($websiteId);
        $customer->setEmail($seller->getEmailId());
         $customer->setFirstname($seller->getFirstName());
        $customer->setLastname($seller->getLastName());
        $customer->setGroupId(self::CUSTOMER_GROUP_ID);
         $customer->setPassword($seller->getPassword());
        return $customer->save();
    }
    /**
     * Make sure that password complies with minimum security requirements.
     *
     * @param string $password
     * @return void
     * @throws InputException
     */
    protected function checkPasswordStrength($password)
    {
        $length = $this->stringHelper->strlen($password);
        if ($length > 256) {
            throw new InputException(
                __(
                    'Please enter a password with at most %1 characters.',
                    256
                )
            );
        }
        $configMinPasswordLength = $this->getMinPasswordLength();
        if ($length < $configMinPasswordLength) {
            throw new InputException(
                __(
                    'The password needs at least %1 characters. Create a new password and try again.',
                    $configMinPasswordLength
                )
            );
        }
        if ($this->stringHelper->strlen(trim($password)) != $length) {
            throw new InputException(
                __("The password can't begin or end with a space. Verify the password and try again.")
            );
        }

        $requiredCharactersCheck = $this->makeRequiredCharactersCheck($password);
        if ($requiredCharactersCheck !== 0) {
            throw new InputException(
                __(
                    'Minimum of different classes of characters in password is %1.' .
                        ' Classes of characters: Lower Case, Upper Case, Digits, Special Characters.',
                    $requiredCharactersCheck
                )
            );
        }
    }
    /**
     * Check password for presence of required character sets
     *
     * @param string $password
     * @return int
     */
    protected function makeRequiredCharactersCheck($password)
    {
        $counter = 0;
        $requiredNumber = $this->scopeConfig->getValue(self::XML_PATH_REQUIRED_CHARACTER_CLASSES_NUMBER);
        $return = 0;

        if (preg_match('/[0-9]+/', $password)) {
            $counter++;
        }
        if (preg_match('/[A-Z]+/', $password)) {
            $counter++;
        }
        if (preg_match('/[a-z]+/', $password)) {
            $counter++;
        }
        if (preg_match('/[^a-zA-Z0-9]+/', $password)) {
            $counter++;
        }

        if ($counter < $requiredNumber) {
            $return = $requiredNumber;
        }

        return $return;
    }

    /**
     * Retrieve minimum password length
     *
     * @return int
     */
    protected function getMinPasswordLength()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_MINIMUM_PASSWORD_LENGTH);
    }

    /**
     * updateTokenData
     *
     * @param int $customerId
     * @return mixed
     */
    public function updateTokenData($customerId)
    {
        $customer = $this->_customerRepositoryInterface->getById($customerId);
        $tokenFrom = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        $token = substr(str_shuffle($tokenFrom), 0, 50);
        $customer->setCustomAttribute('user_confirmation', 0);
        $customer->setCustomAttribute('confirmation_token', $token);
        $customer->setCustomAttribute('is_password_set', 1);
        return $this->_customerRepositoryInterface->save($customer);
    }

    /**
     * Retrieve seller
     * @param string $sellerId
     * @return Bazar\SellerManagement\Api\Data\SellerInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($sellerId)
    {
        $seller = $this->sellerFactory->create();
        $this->resource->load($seller, $sellerId);
        if (!$seller->getId()) {
            throw new NoSuchEntityException(__('seller with id "%1" does not exist.', $sellerId));
        }
        return $seller->getDataModel();
    }

    /**
     * Retrieve sellers matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Bazar\SellerManagement\Api\Data\SellerSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->sellerCollectionFactory->create();

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * Delete seller
     * @param int $id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete($id)
    {
        try {
            $sellerModel = $this->sellerFactory->create();
            $this->resource->load($sellerModel, $id);
            $this->resource->delete($sellerModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the seller: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }
    /**
     * @param string $sellerEmail
     * @return mixed
     */
    public function getSellerByEmail($sellerEmail)
    {
        $sellerCollection = $this->sellerCollectionFactory->create()
            ->addFieldToFilter('email_id', $sellerEmail)
            ->getFirstItem();
        if (empty($sellerCollection->getData())) {
            return false;
        }
        return $sellerCollection;
    }
    /**
     * @param int $customerId
     * @param string $token
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function verifyCustomer($customerId, $token)
    {
        $customer = $this->_customerRepositoryInterface->getById($customerId);
        $verified = false;
        $tokenAvailable = '';

        if ($customer->getCustomAttribute('user_confirmation')) {
            $verified = $customer->getCustomAttribute('user_confirmation')->getValue();
        }
        if ($customer->getCustomAttribute('confirmation_token')) {
            $tokenAvailable = $customer->getCustomAttribute('confirmation_token')->getValue();
        }

        if ($verified) {
            throw new LocalizedException(__('Customer Already Verified!.'));
        } elseif (!$verified && $token == $tokenAvailable) {
            $customer->setCustomAttribute('user_confirmation', 1);
            $seller = $this->sellerCollectionFactory->create()
                ->addFieldToFilter('customer_id', $customerId)
                ->getFirstItem();
            $seller->setData('is_active', 1);
            $this->resource->save($seller);
            $this->_customerRepositoryInterface->save($customer);
            return true;
        } else {
            throw new LocalizedException(__('Verfication Failed!'));
        }

    }
    public function sentNotificationMail($mailtoNotify, $seller,$password=false)
    {
        $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $store = $this->storeManager->getStore()->getId();
        $template = "bazar_seller_adminsignup_template";
        $customer = $this->_customerRepositoryInterface->getById($seller->getCustomerId());
        $customerId = $customer->getId();
        $frontEndUrl = $this->scopeConfig->getValue(
            'frontend_url/url/front_end_base_url',
            ScopeInterface::SCOPE_STORE
        );
        $tokenAvailable = $customer->getCustomAttribute('confirmation_token')->getValue();
        $loginLink = $frontEndUrl . '?t_id=' . $tokenAvailable . '&id=' . $customerId;
        $loginUrl = "<a href='".$frontEndUrl."'>".$frontEndUrl."</a>";
        $templateVars = [
            'loginlink' => $loginLink,
            'user_name' => $mailtoNotify,
            'password' => $password
        ];
        $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $senderName  = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
        $from = ['email' => $email, 'name' => $senderName];
        $transport = $this->transportBuilder->setTemplateIdentifier($template, ScopeInterface::SCOPE_STORE)
            ->setFrom($from)
            ->addTo($mailtoNotify)
            ->setTemplateVars($templateVars)
            ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $store])
            ->getTransport();
        $transport->sendMessage();
    }
     /**
     * Get seller by customer email
     * @param string $customerEmail
     * @return mixed
     */
    public function getSellerByCustomerEmail($customerEmail)
    {
        $sellerCollection = $this->sellerCollectionFactory->create()
            ->addFieldToFilter('email_id', $customerEmail)
            ->getFirstItem();
        if (empty($sellerCollection->getData())) {
            return false;
        }
        return $sellerCollection;
    }
    /**
     * @param string $emailAPI
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function emailVerification($first_name,$last_name,$invite_code,$emailAPI)
    {
        $store = $this->storeManager->getStore()->getId();
        $tokenFrom = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        $token = substr(str_shuffle($tokenFrom), 0, 50);
        $this->mailTokenRepository->updateTokensExpireStatus($emailAPI, 1);
        $this->mailTokenRepository->saveEmailToken($token, $emailAPI);
        $frontEndUrl = $this->scopeConfig->getValue(
            'frontend_url/url/front_end_base_url',
            ScopeInterface::SCOPE_STORE
            );
        $verificationUrl = $frontEndUrl . 'emailVerify?email=' . $emailAPI . '&fn=' .$first_name .
         '&ln=' .$last_name. '&invite_code=' .$invite_code. '&token=' .$token;
        $templateVars = [
            'verification_url' => $verificationUrl
            ];
        $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $senderName = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
        $from = ['email' => $email, 'name' => $senderName];
        try {
            $transport = $this->transportBuilder->setTemplateIdentifier('bazar_seller_verification_email_template',ScopeInterface::SCOPE_STORE)
                ->setFrom($from)
                ->addTo($emailAPI)
                ->setTemplateVars($templateVars)
                ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $store])
                ->getTransport();
            $transport->sendMessage();
            return true;
        } catch (\Exception $exception) {
            throw new MailException(__(
                'Unable to send verification mail.',
                $exception->getMessage()
            ));
            return false;
        }

    }
    
    public function signUpBazarSeller(\Bazar\SellerManagement\Api\Data\SellerInterface $seller
    )
    {   
        $sellerData = $this->extensibleDataObjectConverter->toNestedArray(
            $seller,
            [],
            \Bazar\SellerManagement\Api\Data\SellerInterface::class
        );
        try {
            $this->validateInfo($sellerData);    
            $customer = $this->createSellerCustomer($seller);
                if (!$customer->getId()) {
                throw new CouldNotSaveException(__('Could not save the Customer'));
            }
            $sellerData['customer_id'] = $customer->getId();  
            $sellerModel = $this->sellerFactory->create()->setData($sellerData);
            $inviteCode=$seller->getInviteCode();
            $inviteCollection = $this->inviteCollectionFactory->create();
            $inviteCode=$inviteCollection->addFieldToFilter('invite_code',$inviteCode)
            ->addFieldToFilter('is_used', 0);
            if(count($inviteCode)==0 )
            {
                throw new \Magento\Framework\Webapi\Exception( __('Sorry, this is not a valid invitation code'),
                0,\Magento\Framework\Webapi\Exception::HTTP_BAD_REQUEST
                );           
            }
            if(count($inviteCode)==1)
            $this->resource->save($sellerModel);
           
        }
        
         catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the Seller: %1',
                $exception->getMessage()
            ));
        }
        return $sellerModel->getDataModel();

          
    }

    /**
     *
     * @param mixed $seller
     * @return mixed
     */
    public function createSellerCustomer($seller)
    {   
        $websiteId  = $this->storeManager->getWebsite()->getWebsiteId();
        $customer = $this->customerFactory->create();
        // Associate website_id with customer
        if (!$customer->getStoreId()) {
            if ($customer->getWebsiteId()) {
                $storeId = $this->storeManager->getWebsite($customer->getWebsiteId())->getDefaultStore()->getId();
            } else {
                $this->storeManager->setCurrentStore(null);
                $storeId = $this->storeManager->getStore()->getId();
            }
            $customer->setStoreId($storeId);
        }
        if (!$customer->getWebsiteId()) {
            $websiteId = $this->storeManager->getStore($customer->getStoreId())->getWebsiteId();
            $customer->setWebsiteId($websiteId);
        }
        $customer->setWebsiteId($websiteId);
         $customer->setFirstname($seller->getFirstName());
        $customer->setLastname($seller->getLastName());
        $customer->setEmail($seller->getEmailId());
        $customer->setGroupId(self::CUSTOMER_GROUP_ID);
        return $customer->save();
    }

     /**
     *
     * @param string $inviteCode
     * @return bool
     */
    public function validateInviteCode($inviteCode)
    {
            $inviteCollection = $this->inviteCollectionFactory->create();
            $inviteCode=$inviteCollection->addFieldToFilter('invite_code',$inviteCode)
            ->addFieldToFilter('is_used', 0);
            if(count($inviteCode)==0 )
            {   
                return false;          
            }
            else if(count($inviteCode)==1)
            {
               return true;

            }
            return true;
    }
   


    /**
     * add seller url
     * @param int $customerId
     * @param string $storeUrl
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function setSellerStoreUrl($customerId,$storeUrl)
    {
        $sellerCollection = $this->sellerCollectionFactory->create()
            ->addFieldToFilter('store_url', $storeUrl)
            ->getFirstItem();

        if (!empty($sellerCollection->getData())) {
            throw new LocalizedException(__('This URL is already taken'));
            die;
        }

        $customer = $this->_customerRepositoryInterface->getById($customerId);
        $customer->setCustomAttribute('store_url', $storeUrl);
        $seller = $this->sellerCollectionFactory->create()
            ->addFieldToFilter('customer_id', $customerId)
            ->getFirstItem();
        $seller->setData('store_url', $storeUrl);
        $this->resource->save($seller);
        $this->_customerRepositoryInterface->save($customer);
        return true;
    }

    
}
