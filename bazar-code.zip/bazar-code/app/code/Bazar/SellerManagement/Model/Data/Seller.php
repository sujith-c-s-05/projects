<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SellerManagement\Model\Data;

use Bazar\SellerManagement\Api\Data\SellerInterface;

class Seller extends \Magento\Framework\Api\AbstractExtensibleObject implements SellerInterface
{

    /**
     * Get id
     * @return int|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param string $id
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setId($ID)
    {
        return $this->setData(self::ID, $ID);
    }
    /**
     * Get customer_id
     * @return int|null
     */
    public function getCustomerId()
    {
        return $this->_get(self::CUSTOMER_ID);
    }

    /**
     * Set customer_id
     * @param string $customerId
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setCustomerId($customerId)
    {
        return $this->setData(self::CUSTOMER_ID, $customerId);
    }

    /**
     * Get first_name
     * @return string|null
     */
    public function getFirstName()
    {
        return $this->_get(self::FIRST_NAME);
    }

    /**
     * Set first_name
     * @param string $firstName
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setFirstName($firstName)
    {
        return $this->setData(self::FIRST_NAME, $firstName);
    }

    /**
     * Get last_name
     * @return string|null
     */
    public function getLastName()
    {
        return $this->_get(self::LAST_NAME);
    }

    /**
     * Set last_name
     * @param string $lastName
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setLastName($lastName)
    {
        return $this->setData(self::LAST_NAME, $lastName);
    }

    /**
     * Get email_id
     * @return string|null
     */
    public function getEmailId()
    {
        return $this->_get(self::EMAIL_ID);
    }

    /**
     * Set email_id
     * @param string $emailId
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setEmailId($emailId)
    {
        return $this->setData(self::EMAIL_ID, $emailId);
    }

    /**
     * Get mobile_number
     * @return string|null
     */
    public function getMobileNumber()
    {
        return $this->_get(self::MOBILE_NUMBER);
    }

    /**
     * Set mobile_number
     * @param string $mobileNumber
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setMobileNumber($mobileNumber)
    {
        return $this->setData(self::MOBILE_NUMBER, $mobileNumber);
    }

    /**
     * Get routing_no
     * @return string|null
     */
    public function getRoutingNo()
    {
        return $this->_get(self::ROUTING_NO);
    }

    /**
     * Set routing_no
     * @param string $routingNumber
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setRoutingNo($routingNumber)
    {
        return $this->setData(self::ROUTING_NO, $routingNumber);
    }
    
    /**
     * Get account_no
     * @return string|null
     */
    public function getAccountNo()
    {
        return $this->_get(self::ACCOUNT_NO);
    }

    /**
     * Set account_no
     * @param string $accountNo
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setAccountNo($accountNo)
    {
        return $this->setData(self::ACCOUNT_NO, $accountNo);
    }
      /**
     * Get store_url
     * @return string|null
     */
    public function getStoreUrl()
    {
        return $this->_get(self::STORE_URL);
    }

    /**
     * Set store_url
     * @param string $storeUrl
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setStoreUrl($storeUrl)
    {
        return $this->setData(self::STORE_URL, $storeUrl);
    }

    /**
     * Get invite_code
     * @return string|null
     */
    public function getInviteCode()
    {
        return $this->_get(self::INVITE_CODE);
    }

    /**
     * Set invite_code
     * @param string $inviteCode
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setInviteCode($inviteCode)
    {
        return $this->setData(self::INVITE_CODE, $inviteCode);
    }

    /**
     * Get total_earning
     * @return float |null
     */
    public function getTotalEarning()
    {
        return $this->_get(self::TOTAL_EARNING);
    }
    /**
     * Set total_earning
     * @param float  $totalEarning
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setTotalEarning($totalEarning)
    {
        return $this->setData(self::TOTAL_EARNING, $totalEarning);
    }

    /**
     * Get total_customer_order
     * @return int|null
     */
    public function getTotalCustomerOrder()
    {
        return $this->_get(self::TOTAL_CUSTOMER_ORDER);
    }

    /**
     * Set total_customer_order
     * @param int $totalCustomerOrder
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setTotalCustomerOrder($totalCustomerOrder)
    {
        return $this->setData(self::TOTAL_CUSTOMER_ORDER, $totalCustomerOrder);
    }

    /**
     * Get available_cash
     * @return float |null
     */
    public function getAvailableCash()
    {
        return $this->_get(self::AVAILABLE_CASH);
    }
    /**
     * Set available_cash
     * @param float  $totalEarning
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setAvailableCash($availableCash)
    {
        return $this->setData(self::AVAILABLE_CASH, $availableCash);
    }

    /**
     * Get bank_info
     * @return string|null
     */
    public function getBankInfo()
    {
        return $this->_get(self::BANK_INFO);
    }

    /**
     * Set bank_info
     * @param string $bankInfo
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setBankInfo($bankInfo)
    {
        return $this->setData(self::BANK_INFO, $bankInfo);
    }

    /**
     * Get credit_card_no
     * @return string|null
     */
    public function getCreditCardNo()
    {
        return $this->_get(self::CREDITCARD_NO);
    }

    /**
     * Set credit_card_no
     * @param string $creditCardNo
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setCreditCardNo($creditCardNo)
    {
        return $this->setData(self::CREDITCARD_NO, $creditCardNo);
    }

    /**
     * Get exp_date
     * @return string|null
     */
    public function getExpData()
    {
        return $this->_get(self::EXP_DATE);
    }

    /**
     * Set exp_date
     * @param string $expDate
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setExpData($expDate)
    {
        return $this->setData(self::EXP_DATE, $expDate);
    }

    /**
     * Get zip_code
     * @return string|null
     */
    public function getZipCode()
    {
        return $this->_get(self::ZIP_CODE);
    }

    /**
     * Set zip_code
     * @param string $zipCode
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setZipCode($zipCode)
    {
        return $this->setData(self::ZIP_CODE, $zipCode);
    }

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setCreatedby($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_deleted
     * @return string|null
     */
    public function getIsDeleted()
    {
        return $this->_get(self::IS_DELETED);
    }

    /**
     * Set is_deleted
     * @param string $isDeleted
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setIsDeleted($isDeleted)
    {
        return $this->setData(self::IS_DELETED, $isDeleted);
    }
    /**
     * Get is_active
     * @return string|null
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param string $isActive
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }
    /**
     * Get passowrd
     * @return string|null
     */
    public function getPassword()
    {
        return $this->_get(self::CUSTOMER_PASSWORD);
    }

    /**
     * Set passowrd
     * @param string $passowrd
     * @return \Bazar\SellerManagement\Api\Data\Api\Data\SellerInterface
     */
    public function setPassword($passowrd)
    {
        return $this->setData(self::CUSTOMER_PASSWORD, $passowrd);
    }
    
}
