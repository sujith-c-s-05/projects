<?php
/**
* Copyright © All rights reserved.
* See COPYING.txt for license details.
*/
declare(strict_types=1);

 
namespace Bazar\CartManagement\Model;
use Bazar\CartManagement\Api\MultiCartRepositoryInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\QuoteIdMaskFactory;
use Magento\Framework\Exception\CouldNotSaveException;
 
class MultiCartRepository implements MultiCartRepositoryInterface
{

/**
* @var \Magento\Framework\App\State
* @var \Magento\Framework\App\Request\Http
* @var \Magento\Checkout\Model\Cart
* @var \Magento\Catalog\Model\Product
* @var \Magento\Customer\Model\Session
* @var \Magento\Quote\Model\QuoteFactory
* @var QuoteIdMaskFactory
* @var CartRepositoryInterface
*/
protected $obj;
protected $request;
protected $cart;
protected $product;
protected $customerSession;
protected $quoteFactory;
protected $quoteRepository;
protected $quoteIdMaskFactory;

 
/**
* @param \Magento\Framework\App\State $obj
* @param \Magento\Framework\App\Request\Http $request
* @param \Magento\Checkout\Model\Cart $cart
* @param \Magento\Catalog\Model\Product $product
* @param \Magento\Customer\Model\Session $customerSession
* @param \Magento\Quote\Model\QuoteFactory $quoteFactory
* @param \CartRepositoryInterface $quoteRepository
* @param \QuoteIdMaskFactory $quoteIdMaskFactory
*/

 
public function __construct(
\Magento\Framework\App\State $obj,
\Magento\Framework\App\Request\Http $request,
\Magento\Checkout\Model\Cart $cart,
\Magento\Catalog\Model\Product $product,
\Magento\Customer\Model\Session $customerSession,
\Magento\Quote\Model\QuoteFactory $quoteFactory,
CartRepositoryInterface $quoteRepository, 
QuoteIdMaskFactory $quoteIdMaskFactory
)
{
$this->obj = $obj;
$this->request = $request;
$this->cart = $cart;
$this->_product = $product;
$this->customerSession = $customerSession;
$this->quoteFactory = $quoteFactory;
$this->quoteIdMaskFactory = $quoteIdMaskFactory;
$this->quoteRepository = $quoteRepository;

}

public function multicart(\Bazar\CartManagement\Api\Data\MultiCartInterface $products)
{

    try
    {
    $productId = [];
    $productIds = [];
    $itemids = [];
    foreach ($products->getItems() as $item)
    {
    $productId = $item->getProductId();
    $qty = $item->getQty();
    $quote_id = $products->getQuoteId();
    $quote = $this->quoteFactory->create()->load($quote_id);
    $product = $this->_product->load($productId);
    $quoteItems = $quote->addProduct($product, $qty); 
    $quote->collectTotals()
    ->save();
    }

    return true;
    $quote->save();
    }

    catch(\Exception $e)
    {
    throw new CouldNotSaveException(__($e->getMessage()));
    }

}

}