<?php
namespace Bazar\CartManagement\Model;
 
use Bazar\CartManagement\Api\ClearCartInterface;
 
use Magento\Quote\Api\CartRepositoryInterface;
 
 
class ClearCartRepository implements ClearCartInterface
 
{
 
   /**
   * @var CartRepositoryInterface
   */
  
   protected $quoteRepository;
  
   /**
   * @param \CartRepositoryInterface $quoteRepository
   */
 
   public function __construct(
 
   CartRepositoryInterface $quoteRepository
   
   )
   
   {
      $this->quoteRepository = $quoteRepository;
   }
 
   public function clearCart($cartId)
 
   { 
    $quote = $this->quoteRepository->getActive($cartId);
    $quote->removeAllItems();
    $this->quoteRepository->save($quote);
    return true;
 
   }
 
}