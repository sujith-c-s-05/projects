<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\CartManagement\Model\Data;

use Bazar\CartManagement\Api\Data\MultiCartItemInterface;

class MultiCartItem extends \Magento\Framework\Api\AbstractExtensibleObject implements MultiCartItemInterface
{

    /**
     * Get product_id
     * @return int|null
     */
    public function getProductId()
    {
        return $this->_get('product_id');
    }

    /**
     * Set product_id
     * @param int $productId
     * @return \Bazar\CartManagement\Api\Data\MultiCartItemInterface
     */
    public function setProductId($productId)
    {
        return $this->setData('product_id', $productId);
    }

     /**
      * Get qty
      * @return int|null
      */
    public function getQty()
    {
        return $this->_get('qty');
    }

    /**
     * Set qty
     * @param int $qty
     * @return \Bazar\CartManagement\Api\Data\MultiCartItemInterface
     */
    public function setQty($qty)
    {
        return $this->setData('qty', $qty);
    }
}