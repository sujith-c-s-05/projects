<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Bazar\CartManagement\Plugin;

// use vendor\magento\module-quote\Data\CartManagementInterface;
use Magento\Quote\Api\Data\CartItemInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Api\Data\CartInterfaceFactory;
use Magento\Framework\App\ObjectManager;
use \Magento\Framework\Exception\NoSuchEntityException;
use Bazar\SupplierManagement\Api\SupplierRepositoryInterface;
use Bazar\ProductManagement\Api\SupplierProductRepositoryInterface;


class CartGet
{
    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepositoryInterface;

    protected $date;

    /**
     * @var \Magento\Catalog\Api\CategoryRepositoryInterface
     */
    protected $categoryRepository;

    /**
     * @var \Magento\Store\Model\App\Emulation
     */
    protected $appEmulation;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var \Magento\Catalog\Helper\Image
     */
    protected $imageHelper;

    /**
     * @var Bazar\SupplierManagement\Api\SupplierRepositoryInterface
     */
    protected $supplierRepositoryInterface;

    /**
     * @var \Bazar\ProductManagement\Api\SupplierProductRepositoryInterface 
     */
    protected $supplierProductRepositoryInterface;

    /**
     * Undocumented function
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface
     * @param \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository
     * @param \Magento\Store\Model\App\Emulation $appEmulation
     * @param \Magento\Catalog\Helper\Image   
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param Bazar\SupplierManagement\Api\SupplierRepositoryInterface $supplierRepositoryInterface
     * @param \Bazar\ProductManagement\Api\SupplierProductRepositoryInterface $supplierProductRepositoryInterface
     */
    public function __construct(
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        \Magento\Framework\Stdlib\DateTime\DateTime $date,
        \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository,
        \Magento\Catalog\Model\Category $categoryFactory,
        ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\App\Emulation $appEmulation,
        \Magento\Catalog\Helper\Image $imageHelper,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        CartRepositoryInterface $quoteRepository,
        \Magento\Quote\Model\QuoteFactory $quoteFactory,
        CartInterfaceFactory $cartFactory = null,
        \Magento\Eav\Model\Config $eavConfig,
        SupplierRepositoryInterface $supplierRepositoryInterface,
        SupplierProductRepositoryInterface $supplierProductRepositoryInterface
    ) {
        $this->productRepositoryInterface = $productRepositoryInterface;
        $this->date = $date;
        $this->categoryRepository = $categoryRepository;
        $this->_categoryFactory = $categoryFactory;
        $this->appEmulation = $appEmulation;
        $this->imageHelper = $imageHelper;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->quoteRepository = $quoteRepository;
        $this->_quoteFactory = $quoteFactory;
        $this->cartFactory = $cartFactory ?: ObjectManager::getInstance()->get(CartInterfaceFactory::class);
        $this->eavConfig = $eavConfig;
        $this->supplierRepositoryInterface = $supplierRepositoryInterface;
        $this->supplierProductRepositoryInterface = $supplierProductRepositoryInterface;
    }

    /**
     * Get Cart
     *
     * @param \Magento\Quote\Api\CartItemRepositoryInterface $subject
     * @param \Magento\Quote\Api\Data\CartInterface $cart
     * @return void
     */
    public function afterGet(
        \Magento\Quote\Api\CartRepositoryInterface $subject,
        $quote
    ) {

        /** @var  \Magento\Quote\Model\Quote\Item  $item */
        foreach ($quote->getAllVisibleItems() as $item) {
            $extensionattributes = $item->getExtensionAttributes();

            $sku = $item->getSku();
            $productDetails = $this->productRepositoryInterface->get($sku);
            $productName=$productDetails->getName();
            $productId=$productDetails->getId();
            $supplierId = $productDetails->getSupplierId();
            $stockItem = $productDetails->getExtensionAttributes()->getStockItem();

            //Get category names
            //Get subcategory   names
            $categoryNames = array();
            $subcategoryName = array();
            foreach ($productDetails->getCategoryIds() as $categoryId) {
                array_push($categoryNames, $this->getCategoryNameById($categoryId));
                array_push($subcategoryName, $this->getSubCategoryNameById($categoryId));
                $subcategoryNames = json_encode($subcategoryName, true);
            }

            //Get supplier details
            if (is_numeric($supplierId)) {
                try{
                    $supplierDetails = $this->supplierRepositoryInterface->get($supplierId);
                    $supplierName= $supplierDetails->getCompanyName();
                    }
                    catch(\Exception $exception)
                    {
                        $supplierName=null;
                    }
            }

            $color=$productDetails->getResource()->getAttributeRawValue($productDetails->getId(),'color',$productDetails->getStore()->getWebsiteId());
            if(!empty($color)) {
    
                     $attribute = $this->eavConfig->getAttribute('catalog_product', 'color');
                     $colorName = $attribute->getSource()->getOptionText($color);            
            } 
   
            $size=$productDetails->getResource()->getAttributeRawValue($productDetails->getId(),'size',$productDetails->getStore()->getWebsiteId());
            if(!empty($size)) {
    
                     $attribute = $this->eavConfig->getAttribute('catalog_product', 'size');
                     $sizeName = $attribute->getSource()->getOptionText($size);            
            } 

            //Get product stock status

            $isInStock = $stockItem->getIsInStock();

            $status = $productDetails->getStatus();

            //Total cost of product
            $qty = $item->getQty();
            $price = $item->getPrice();
            $totalCost = $qty * $price;
            $timestamp = strtotime($productDetails->getUpdatedAt());
            $stockUpdatedDate = date("d-m-Y", $timestamp);
         
            //image details
            $productimages = $productDetails->getMediaGalleryImages();
            $images=[];
            foreach($productimages as $productimage)
            {
                $image= $productimage['url'];
                $images[] = $image;
            }

              //validations

            $supplierProduct=$this->supplierProductRepositoryInterface->getSupplierProductByProductIdAndSellerId($productDetails->getId(), $supplierId);
            $isDelete=$supplierProduct->getIsDelete();

            if($isDelete ==1||$status==0||$isInStock==false)
            {
                $outOfStockTag = 1;
            }
            $productMedia=$productDetails->getMediaGalleryEntries();
            $mediaCount =[];
            foreach($productMedia as $media)
            {
                $mediaCount[]=$media->getData();
            }
            $mediaValue= json_encode($mediaCount,true);

            $extensionattributes->setProductCategoryName($categoryNames ?? '');
            $extensionattributes->setSupplierName($supplierName ?? '');
            $extensionattributes->setSupplierId($supplierId ?? '');
            $extensionattributes->setStockUpdatedDate($stockUpdatedDate ?? '');
            $extensionattributes->setTotalCost($totalCost);
            $extensionattributes->setIsInStock($isInStock ?? false);
            $extensionattributes->setproductStatus($status);
            $extensionattributes->setProductName($productName??'');
            $extensionattributes->setColor($colorName??'');
            $extensionattributes->setSize($sizeName??'');
            $extensionattributes->setProductId($productId??'');
            $extensionattributes->setQuantity($qty??'');
            $extensionattributes->setProductImage($images??'');
            $extensionattributes->setOutOfStockTag($outOfStockTag??0);
            $extensionattributes->setProductMedia($mediaValue??'');
            $item->setExtensionAttributes($extensionattributes);
        }
        return $quote;
    }

    /**
     * @param int $id
     * @param null $storeId
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getCategoryNameById($id, $storeId = null)
    {
        $categoryInstance = $this->categoryRepository->get($id, $storeId);
        return $categoryInstance->getName();
    }
    protected function getSubCategoryNameById($categoryId)
    {
        $catagory = $this->_categoryFactory->load($categoryId);
        $subcatagory = $catagory->getChildren();
        $subcategories = array();
        foreach (explode(',', $subcatagory) as $subCatagoryid) {
            $_subCategory = $this->_categoryFactory->load($subCatagoryid);
            if ($_subCategory->getIsActive()) {
                $subcategories = array('id' => $_subCategory->getId(), 'name' => $_subCategory->getName());
            }
        }
        return $subcategories;
    }

}