<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\CartManagement\Api;


interface ClearCartInterface
{

    /**
     * Clears the cart when venue user switches to another venue
     * @param int $cartId
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function clearCart($cartId);
   
}  