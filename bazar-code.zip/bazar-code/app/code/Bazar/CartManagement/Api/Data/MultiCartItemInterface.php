<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\CartManagement\Api\Data;

interface MultiCartItemInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    
    /**
     * Get product_id
     * @return int|null
     */
    public function getProductId();

    /**
     * Set product_id
     * @param int $productId
     * @return \Bazar\CartManagement\Api\Data\MultiCartItemInterface
     */
    public function setProductId($productId);

    /**
     * Get qty
     * @return int|null
     */
    public function getQty();

    /**
     * Set qty
     * @param int $qty
     * @return \Bazar\CartManagement\Api\Data\MultiCartItemInterface
     */
    public function setQty($qty);
}