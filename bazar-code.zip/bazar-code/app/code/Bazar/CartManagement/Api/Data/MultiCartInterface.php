<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\CartManagement\Api\Data;

interface MultiCartInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    /**
     * Get quote_id
     * @return int|null
     */
    public function getQuoteId();

    /**
     * Set quote_id
     * @param int $quoteId
     * @return \Bazar\CartManagement\Api\Data\MultiCartInterface
     */

    public function setQuoteId($quoteId);

     /**
      * Get  cart  info
      *
      * @return \Bazar\CartManagement\Api\Data\MultiCartItemInterface[]|null
      */
    public function getItems();

    /**
     * Set cart info
     *
     * @param \Bazar\CartManagement\Api\Data\MultiCartItemInterface[] $multiCartItemInterface
     * @return $this
     */
    public function setItems(array $multiCartItemInterface = null);
}