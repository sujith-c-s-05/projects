<?php
/**
 * Copyright ©  All rights reserved.
 */
declare(strict_types=1);

namespace  Bazar\SupplierManagement\Controller\Adminhtml\Invite;

class Delete extends \Bazar\SupplierManagement\Controller\Adminhtml\Invite
{

    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        // check if we know what should be deleted
        $id = $this->getRequest()->getParam('invite_id');
        if ($id) {
            try {
                // init model and delete
                $model = $this->_objectManager->create(\Bazar\SupplierManagement\Model\Invite::class);
                $model->load($id);
                $model->delete();
                $model->save();
                // display success message
                $this->messageManager->addSuccessMessage(__('You deleted the invite code.'));
                // go to grid
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                // display error message
                $this->messageManager->addErrorMessage($e->getMessage());
                // go back to edit form
                return $resultRedirect->setPath('*/*/edit', ['invite_id' => $id]);
            }
        }
        // display error message
        $this->messageManager->addErrorMessage(__('We can\'t find a invite code to delete.'));
        // go to grid
        return $resultRedirect->setPath('*/*/');
    }
}
