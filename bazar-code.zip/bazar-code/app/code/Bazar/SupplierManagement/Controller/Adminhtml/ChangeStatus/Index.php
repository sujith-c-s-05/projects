<?php

namespace Bazar\SupplierManagement\Controller\Adminhtml\ChangeStatus;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;

class Index extends \Magento\Backend\App\Action
{
    protected $request;
    protected $scopeConfig;
    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    protected $resultPageFactory = false;
    /**
     *
     * @param \Magento\Framework\App\Request\Http $request
     * @param ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Bazar\SupplierManagement\Model\SupplierRepository $supplierRepository
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Bazar\SupplierManagement\Model\SupplierFactory $supplierFactory
     * @param CustomerRepositoryInterface $customerRepositoryInterface
     * @param \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
     */
    public function __construct(
        \Magento\Framework\App\Request\Http $request,
        ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Bazar\SupplierManagement\Model\SupplierRepository $supplierRepository,
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Bazar\SupplierManagement\Model\SupplierFactory $supplierFactory,
        CustomerRepositoryInterface $customerRepositoryInterface,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Catalog\Model\Product\Action $productAction
    ) {
        parent::__construct($context);
        $this->scopeConfig = $scopeConfig;
        $this->request = $request;
        $this->_transportBuilder = $transportBuilder;
        $this->_storeManager = $storeManager;
        $this->resultPageFactory = $resultPageFactory;
        $this->supplierFactory = $supplierFactory;
        $this->supplierRepository = $supplierRepository;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->productAction = $productAction;
    }
    /**
     * execute
     *
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $status = $this->getRequest()->getParam('status');
        $supplier = $this->supplierFactory->create()->load($id);
        if ($supplier) {
            $supplier->setIsActive($status);
            $supplier->save();
            $this->updateProducts($supplier);
            $this->messageManager->addSuccess(__('Status Updated!'));
            $mailtoNotify = $supplier->getNotificationEmail();
            if (!$mailtoNotify) {
                $mailtoNotify = $supplier->getCustomerEmail();
            }
            $customer = $this->_customerRepositoryInterface->getById($supplier->getCustomerId());
            if ($supplier->getIsActive()) {
                if ($supplier->getStoreCode()) {
                    $customer->setCustomAttribute('user_confirmation', 1);
                }
                $this->supplierRepository->sendNotificationMail($supplier);
            } else {
                $customer = $this->_customerRepositoryInterface->getById($supplier->getCustomerId());
                $customer->setCustomAttribute('user_confirmation', 0);
            }
            $this->_customerRepositoryInterface->save($customer);
        }
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('bazar_suppliermanagement/supplier', ['_current' => true]);
    }
    /**
     *
     * @param mixed $supplier
     * @return void
     */
    public function updateProducts($supplier)
    {
        if($supplier->getIsActive()){
            $status = \Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED;
        } else {
            $status = \Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_DISABLED;
        }
        $productsCollection = $this->getProductsCollection($supplier->getId());
        $idArray = [];
        foreach($productsCollection as $product) {
            $idArray[] =$product->getId();
        }
        if(!empty($idArray))
        {
            $this->productAction->updateAttributes($idArray, array('status' => $status), 0);
        }
    }
    /**
     *
     * @param int $supplierId
     * @return mixed
     */
    public function getProductsCollection($supplierId){
        $productsCollection = $this->productCollectionFactory->create()
        ->addAttributeToSelect('*')
        ->addAttributeToFilter('supplier_id', $supplierId);
        return $productsCollection;
    }
    
}
