<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SupplierManagement\Controller\Adminhtml\Supplier;

class Delete extends \Bazar\SupplierManagement\Controller\Adminhtml\Supplier
{

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Bazar\SupplierManagement\Model\SupplierFactory $supplierFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Framework\Registry $coreRegistry
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->customerFactory  = $customerFactory;
        $this->supplierFactory = $supplierFactory;
        $this->productCollectionFactory = $productCollectionFactory;
        parent::__construct($context, $coreRegistry);
    }
    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        // check if we know what should be deleted
        $id = $this->getRequest()->getParam('id');
        if ($id) {
            try {
                $productsCollection = $this->getProductsCollection($id);
                if ($productsCollection->getSize()) {
                    // display error message
                    $this->messageManager->addErrorMessage(
                        __(
                            'Cannot delete the supplier. 
                            Remove all the products associated with the supplier to delete the supplier.'
                        )
                    );
                    // go to grid
                    return $resultRedirect->setPath('*/*/');
                }
                // init model and delete
                $model = $this->supplierFactory->create();
                $model->load($id);
                $customerId = $model->getCustomerId();
                //$this->registry->register('isSecureArea', true);
                $customer = $this->customerFactory->create()->load($customerId);
                $customer->delete();
                $model->delete();
                // display success message
                $this->messageManager->addSuccessMessage(__('You deleted the Supplier.'));
                // go to grid
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                // display error message
                $this->messageManager->addErrorMessage($e->getMessage());
                // go back to edit form
                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
            }
        }
        // display error message
        $this->messageManager->addErrorMessage(__('We can\'t find a Supplier to delete.'));
        // go to grid
        return $resultRedirect->setPath('*/*/');
    }
    /**
     *
     * @param int $supplierId
     * @return mixed
     */
    public function getProductsCollection($supplierId)
    {
        $productsCollection = $this->productCollectionFactory->create()
            ->addAttributeToSelect('*')
            ->addAttributeToFilter('supplier_id', $supplierId);
        return $productsCollection;
    }
}
