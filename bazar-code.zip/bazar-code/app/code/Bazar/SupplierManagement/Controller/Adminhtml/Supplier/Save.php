<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SupplierManagement\Controller\Adminhtml\Supplier;

use Magento\Framework\Exception\LocalizedException;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

class Save extends \Magento\Backend\App\Action
{

    protected $dataPersistor;

    /**
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param \Bazar\SupplierManagement\Model\SupplierRepository $supplierRepository
     * @param CustomerRepositoryInterface $customerRepositoryInterface
     * @param \Bazar\SupplierManagement\Model\SupplierFactory $supplierFactory
     * @param ScopeConfigInterface $scopeConfig
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param StoreManagerInterface $storeManager
     * @param \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Bazar\SupplierManagement\Model\SupplierRepository $supplierRepository,
        CustomerRepositoryInterface $customerRepositoryInterface,
        \Bazar\SupplierManagement\Model\SupplierFactory $supplierFactory,
        ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        StoreManagerInterface $storeManager,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Catalog\Model\Product\Action $productAction
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->customerFactory  = $customerFactory;
        $this->storeManager = $storeManager;
        $this->supplierRepository = $supplierRepository;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
        $this->scopeConfig = $scopeConfig;
        $this->_transportBuilder = $transportBuilder;
        $this->supplierFactory = $supplierFactory;
        $this->productCollectionFactory = $productCollectionFactory;
        $this->productAction = $productAction;
        parent::__construct($context);
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        if ($data) {
            try {
                $id = $this->getRequest()->getParam('id');
                $oldStatus = false;
                $password = false;
                if (isset($data['customer_email']) && $id) {
                    unset($data['customer_email']);
                }
                $model = $this->supplierFactory->create()->load($id);
                if (!$model->getId() && $id) {
                    $this->messageManager->addErrorMessage(__('This Supplier no longer exists.'));
                    return $resultRedirect->setPath('*/*/');
                }
                if (!$id) {
                    $data['store_code'] = 0;
                    $password = $this->generateStrongPassword();
                    $customer = $this->createCustomer($data, $password);
                    $data['notification_email'] = $data['customer_email'];
                    $data['customer_id'] = $customer->getId();
                } else {
                    $oldStatus = $model->getIsActive();
                }
                if (isset($data['business_type']) && is_array($data['business_type'])) {
                    $data['business_type'] = implode(',', $data['business_type']);
                }
                $model->setData($data);
                $model->save();
                $this->updateProducts($model);
                $this->updateCustomerConfirmation($oldStatus, $model);
                $this->supplierRepository->sendNotificationMail($model, $password);
                $this->messageManager->addSuccessMessage(__('Supplier details saved successfully.'));
                $this->dataPersistor->clear('bazar_suppliermanagement_supplier');
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage(
                    $e,
                    __(
                        'Something went wrong while saving the Supplier.' . $e->getMessage()
                    )
                );
            }
            $this->dataPersistor->set('bazar_suppliermanagement_supplier', $data);
            if (!$id) {
                return $resultRedirect->setPath('*/*/new');
            }
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
    /**
     * updateCustomerConfirmation
     *
     * @param bool $oldStatus
     * @param mixed $model
     * @return void
     */
    public function updateCustomerConfirmation($oldStatus, $model)
    {
        $customer = $this->_customerRepositoryInterface->getById($model->getCustomerId());
        if (!$oldStatus && $model->getIsActive() && $model->getStoreCode()) {
            $customer->setCustomAttribute('user_confirmation', 1);
        } elseif ($oldStatus && !$model->getIsActive()) {
            $customer->setCustomAttribute('user_confirmation', 0);
        }
        $this->_customerRepositoryInterface->save($customer);
    }
    /**
     *
     * @param mixed $supplier
     * @return void
     */
    public function updateProducts($supplier)
    {
        if($supplier->getIsActive()){
            $status = \Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_ENABLED;
        } else {
            $status = \Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_DISABLED;
        }
        $productsCollection = $this->getProductsCollection($supplier->getId());
        $idArray = [];
        foreach($productsCollection as $product) {
            $idArray[] =$product->getId();
        }
        if(!empty($idArray))
        {
            $this->productAction->updateAttributes($idArray, array('status' => $status), 0);
        }
    }
    /**
     *
     * @param int $supplierId
     * @return mixed
     */
    public function getProductsCollection($supplierId){
        $productsCollection = $this->productCollectionFactory->create()
        ->addAttributeToSelect('*')
        ->addAttributeToFilter('supplier_id', $supplierId);
        return $productsCollection;
    }
   /**
    *
    * @param mixed $data
    * @param string|null $password
    * @return mixed
    */
    public function createCustomer($data, $password)
    {
        $this->validateEmail($data['customer_email']);
        $websiteId  = $this->storeManager->getWebsite()->getWebsiteId();
        $customer = $this->customerFactory->create();
        if (!$customer->getStoreId()) {
            if ($customer->getWebsiteId()) {
                $storeId = $this->storeManager->getWebsite($customer->getWebsiteId())->getDefaultStore()->getId();
            } else {
                $this->storeManager->setCurrentStore(null);
                $storeId = $this->storeManager->getStore()->getId();
            }
            $customer->setStoreId($storeId);
        }
        if (!$customer->getWebsiteId()) {
            $websiteId = $this->storeManager->getStore($customer->getStoreId())->getWebsiteId();
            $customer->setWebsiteId($websiteId);
        }
        $customer->setWebsiteId($websiteId);
        $customer->setEmail($data['customer_email']);
        $customer->setFirstname($data['company_name']);
        $customer->setLastname(" ");
        $customer->setGroupId(\Bazar\SupplierManagement\Api\SupplierRepositoryInterface::CUSTOMER_GROUP_ID);
        $customer->setPassword($password);
        $customer->save();
        if ($customer->getId()) {
            $resetPassword = true;
            $this->supplierRepository->updateTokenData($customer->getId(),$resetPassword);
            return $customer;
        } else {
            throw new LocalizedException(__('Customer Not Created.'));
        }
    }
    /**
     * Retrieve supplier by email id
     * @param string $email
     * @return bool|null
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function validateEmail($email)
    {

        $websiteId  = $this->storeManager->getWebsite()->getWebsiteId();
        $customer = $this->customerFactory->create();
        $customer->setWebsiteId(1);
        $customer->loadByEmail($email);
        if ($customer->getId()) {
            throw new LocalizedException(__(
                'There is already an account associated with this email adress.'
            ));
        }
        return true;
    }
    /**
     *
     * @param integer $length
     * @param boolean $addDashes
     * @param string $availableSets
     * @return mixed
     */
    public function generateStrongPassword($length = 8, $availableSets = 'luds')
    {
        $sets = [];
        if (strpos($availableSets, 'l') !== false) {
            $sets[] = 'abcdefghjkmnpqrstuvwxyz';
        }
        if (strpos($availableSets, 'u') !== false) {
            $sets[] = 'ABCDEFGHJKMNPQRSTUVWXYZ';
        }
        if (strpos($availableSets, 'd') !== false) {
            $sets[] = '23456789';
        }
        if (strpos($availableSets, 's') !== false) {
            $sets[] = '!@#$%&*?';
        }

        $all = '';
        $password = '';
        foreach ($sets as $set) {
            $password .= $set[$this->tweakArrayRand(str_split($set))];
            $all .= $set;
        }

        $all = str_split($all);
        $i = 0;
        while ($i < $length - count($sets)) {
            $password .= $all[$this->tweakArrayRand($all)];
            $i++;
        }

        $password = str_shuffle($password);
        return $password;
    }
    /**
     *
     * @param mixed $array
     * @return mixed
     */
    public function tweakArrayRand($array)
    {
        if (function_exists('random_int')) {
            return random_int(0, count($array) - 1);
        } else {
            return array_rand($array);
        }
    }
}
