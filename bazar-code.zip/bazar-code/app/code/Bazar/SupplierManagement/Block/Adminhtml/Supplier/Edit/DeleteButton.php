<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Block\Adminhtml\Supplier\Edit;
use Magento\Backend\Block\Widget\Context;
use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

class DeleteButton extends GenericButton implements ButtonProviderInterface
{
    /**
     *
     * @param \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
     * @param Context $context
     */
    public function __construct(
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        Context $context
        )
    {
        $this->productCollectionFactory = $productCollectionFactory;
        parent::__construct($context);
    }

    /**
     * @return array
     */
    public function getButtonData()
    {
        $data = [];
        if ($this->getModelId()) {
            $productsCollection = $this->getProductsCollection($this->getModelId());
            if($productsCollection->getSize()){
                $data = [
                    'label' => __('Delete Supplier'),
                    'class' => 'information',
                    'on_click' => "jQuery('#xigen-admin-modal').modal('openModal')",
                    'sort_order' => 20,
                ];
            } else {
                $data = [
                    'label' => __('Delete Supplier'),
                    'class' => 'delete',
                    'on_click' => 'deleteConfirm(\'' . __(
                        'Are you sure you want to do this?'
                    ) . '\', \'' . $this->getDeleteUrl() . '\')',
                    'sort_order' => 20,
                ];
            }
            
        }
        return $data;
    }
    /**
     *
     * @param int $supplierId
     * @return mixed
     */
    public function getProductsCollection($supplierId){
        $productsCollection = $this->productCollectionFactory->create()
        ->addAttributeToSelect('*')
        ->addAttributeToFilter('supplier_id', $supplierId);
        return $productsCollection;
    }

    /**
     * Get URL for delete button
     *
     * @return string
     */
    public function getDeleteUrl()
    {
        return $this->getUrl('*/*/delete', ['id' => $this->getModelId()]);
    }
}
