<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SupplierManagement\Model\ResourceModel\Supplier;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Bazar\SupplierManagement\Model\Supplier::class,
            \Bazar\SupplierManagement\Model\ResourceModel\Supplier::class
        );
    }
}
