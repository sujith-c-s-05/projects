<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SupplierManagement\Model;

use Bazar\SupplierManagement\Api\Data\NotificationOtpInterface;
use Bazar\SupplierManagement\Api\Data\NotificationOtpSearchResultsInterface;
use Bazar\SupplierManagement\Model\NotificationOtpFactory;
use Bazar\SupplierManagement\Model\ResourceModel\NotificationOtp as NotificationOtpResourceModel;
use Exception;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\MailException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\CouldNotDeleteException;
use Bazar\SupplierManagement\Model\ResourceModel\NotificationOtp\CollectionFactory;
use Bazar\SupplierManagement\Api\Data\NotificationOtpSearchResultsInterfaceFactory;
use Bazar\SupplierManagement\Api\NotificationOtpRepositoryInterface;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Bazar\SupplierManagement\Api\SupplierRepositoryInterface as SupplierRepository;

class NotificationOtpRepository implements NotificationOtpRepositoryInterface
{
    /**
     * @var NotificationOtpFactory
     */
    protected $notificationOtpFactory;

    /**
     * @var NotificationOtpResourceModel
     */
    protected $NotificationOtpResourceModel;

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var NotificationOtpSearchResultsInterfaceFactory
     */
    protected $notificationOtpSearchResultsFactory;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var TransportBuilder
     */
    protected $transportBuilder;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var SupplierRepository
     */
    protected $supplierRepository;

    /**
     * Constructor
     *
     * @param NotificationOtpFactory $notificationOtpFactory
     * @param NotificationOtpResourceModel $NotificationOtpResourceModel
     * @param CollectionFactory $collectionFactory
     * @param NotificationOtpSearchResultsInterfaceFactory $notificationOtpSearchResultsFactory
     * @param StoreManagerInterface $storeManager
     * @param ScopeConfigInterface $scopeConfig
     * @param TransportBuilder $transportBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param SupplierRepository $supplierRepository
     */
    public function __construct(
        NotificationOtpFactory $notificationOtpFactory,
        NotificationOtpResourceModel $NotificationOtpResourceModel,
        CollectionFactory $collectionFactory,
        NotificationOtpSearchResultsInterfaceFactory $notificationOtpSearchResultsFactory,
        StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        TransportBuilder $transportBuilder,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        SupplierRepository $supplierRepository
    )
    {
        $this->notificationOtpFactory = $notificationOtpFactory;
        $this->NotificationOtpResourceModel = $NotificationOtpResourceModel;
        $this->collectionFactory = $collectionFactory;
        $this->notificationOtpSearchResultsFactory = $notificationOtpSearchResultsFactory;
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->transportBuilder = $transportBuilder;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->supplierRepository = $supplierRepository;
    }

    /**
     * Get Email OTP by id
     *
     * @param int $id
     * @return NotificationOtpInterface
     * @throws NoSuchEntityException
     */
    public function getById($id)
    {
        $notificationOtp = $this->notificationOtpFactory->create();
        $this->NotificationOtpResourceModel->load($notificationOtp, $id);
        if (!$notificationOtp->getId()) {
            throw new NoSuchEntityException(__("Email OTP with id %1 does not exist", $id));
        }
        return $notificationOtp;
    }

    /**
     * Save notification email OTP
     *
     * @param NotificationOtpInterface $notificationOtp
     * @return NotificationOtpInterface
     * @throws CouldNotSaveException
     */
    public function save(NotificationOtpInterface $notificationOtp)
    {
        try {
            $this->NotificationOtpResourceModel->save($notificationOtp);
        } catch (Exception $e) {
            throw new CouldNotSaveException(__($e->getMessage()));
        }
        return $notificationOtp;
    }

    /**
     * Delete notification email otp by id
     *
     * @param int $id
     * @return mixed
     * @throws CouldNotDeleteException
     * @throws NoSuchEntityException
     */
    public function deleteById($id)
    {
        return $this->delete($this->getById($id));
    }

    /**
     * Delete Email Code
     *
     * @param NotificationOtpInterface $notificationOtp
     * @return mixed
     * @throws CouldNotDeleteException
     */
    public function delete(NotificationOtpInterface $notificationOtp)
    {
        try {
            $this->NotificationOtpResourceModel->delete($notificationOtp);
        } catch (Exception $exception) {
            throw new CouldNotDeleteException(__($exception->getMessage()));
        }
        return true;
    }


    /**
     * Get notification email otp collection
     *
     * @param SearchCriteriaInterface $searchCriteria
     * @return NotificationOtpSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        $searchResults = $this->notificationOtpSearchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $collection = $this->collectionFactory->create();
        foreach ($searchCriteria->getFilterGroups() as $filterGroup) {
            $fields = [];
            $conditions = [];
            foreach ($filterGroup->getFilters() as $filter) {
                $condition = $filter->getConditionType() ? $filter->getConditionType() : 'eq';
                $fields[] = $filter->getField();
                $conditions[] = [$condition => $filter->getValue()];
            }
            if ($fields) {
                $collection->addFieldToFilter($fields, $conditions);
            }
        }
        $searchResults->setTotalCount($collection->getSize());
        $sortOrders = $searchCriteria->getSortOrders();
        if ($sortOrders) {
            /** @var SortOrder $sortOrder */
            foreach ($sortOrders as $sortOrder) {
                $collection->addOrder(
                    $sortOrder->getField(),
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        }
        $collection->setCurPage($searchCriteria->getCurrentPage());
        $collection->setPageSize($searchCriteria->getPageSize());
        $notificationOtps = [];
        foreach ($collection as $otp) {
            $notificationOtps[] = $otp;
        }
        $searchResults->setItems($notificationOtps);
        return $searchResults;
    }

    /**
     * Generate otp and send notification email for given email id
     *
     * @param string $email
     * @return boolean
     */
    public function sendOtp($email)
    {
        $otp = rand(100000, 999999);
        $this->updateOtpsExpireStatus($email, 1);
        $this->saveNotificationOtp($otp, $email);
        $this->sendMail($email, $otp);

        return true;
    }

    /**
     * Update otp expiry status
     *
     * @param string $email
     * @param string $status
     * @throws CouldNotSaveException
     */
    public function updateOtpsExpireStatus($email, $status)
    {
        // filter existing non-expired otps for given email and make it as expired
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter("email", $email, "eq")
            ->addFilter("is_expired", 0, "eq")
            ->create();
        $otps = $this->getList($searchCriteria)->getItems();
        foreach ($otps as $otp) {
            $otp->setIsExpired($status);
            try {
                $this->save($otp);
            } catch (Exception $e) {
                throw new CouldNotSaveException(__('Could not update notification email otp'));
            }
        }
    }

    /**
     * Generate and save new otp
     *
     * @param string $otp
     * @param string $email
     * @throws CouldNotSaveException
     */
    public function saveNotificationOtp($otp, $email)
    {
        // save new otp
        $notificationOtp = $this->notificationOtpFactory->create();
        $notificationOtp->setEmail($email)
            ->setOtp($otp);
        try {
            $this->save($notificationOtp);
        } catch (Exception $e) {
            throw new CouldNotSaveException(__('Could not save notification email otp'));
        }
    }

    /**
     * Send verification email for given otp
     *
     * @param string $mailtoNotify
     * @param string $otp
     * @return void
     * @throws LocalizedException
     */
    public function sendMail($mailtoNotify, $otp)
    {
        $this->storeManager->setCurrentStore(null);
        $store = $this->storeManager->getStore()->getId();
        $template = "bazar_supplier_notification_otp_email_template";
        $templateVars = [
            'verification_otp' => $otp
        ];
        $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $senderName = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
        $from = ['email' => $email, 'name' => $senderName];
        try {
            $transport = $this->transportBuilder->setTemplateIdentifier($template)
                ->setFrom($from)
                ->addTo($mailtoNotify)
                ->setTemplateVars($templateVars)
                ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $store])
                ->getTransport();
            $transport->sendMessage();
        } catch (\Exception $exception) {
            throw new MailException(__(
                'Unable to send notification email',
                $exception->getMessage()
            ));
        }
    }

    /**
     * Verify given email, otp and update is_verified, is_expired flags on success
     * also update supplier notification email
     *
     * @param string $supplierId
     * @param string $email
     * @param string $otp
     * @return bool
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws NotFoundException
     */
    public function verifyOtp($supplierId, $email, $otp)
    {
        // check and get notification otp entry for given email and otp
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter("email", $email, "eq")
            ->addFilter("otp", $otp, "eq")
            ->create();
        $searchCriteria->setPageSize(1)
            ->setCurrentPage(1);
        $otps = $this->getList($searchCriteria)->getItems();
        $otp = current($otps);
        if (empty($otps)) {
            throw new NotFoundException(__('Invalid verification code!'));
        } else {
            if ($otp->getIsExpired() == 1) {
                throw new InputException(__('Verification code expired !'));
            }
            $this->updateSupplierNotificationMail($supplierId, $email);
            $otp->setIsVerified(1)
                ->setIsExpired(1);
            $this->save($otp);
        }

        return true;
    }

    /**
     * Update supplier notification email
     *
     * @param int $supplierId
     * @param string $email
     * @throws NotFoundException
     */
    public function updateSupplierNotificationMail($supplierId, $email)
    {
        try {
            $supplier = $this->supplierRepository->get($supplierId);
            $supplier->setNotificationEmail($email);
            $this->supplierRepository->save($supplier);
        } catch (\Exception $e) {
            throw new NotFoundException(__('Unable to update supplier with supplier id %1', $e->getMessage()));
        }
    }
}
