<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Model;

use \Magento\Framework\Api\SearchResults;
use \Bazar\SupplierManagement\Api\Data\EmailTokenSearchResultsInterface;

/**
 * Class EmailTokenSearchResults
 *
 * @package Bazar\SupplierManagement\Model
 */
class EmailTokenSearchResults extends SearchResults implements EmailTokenSearchResultsInterface
{

}
