<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Model\Data;

use Bazar\SupplierManagement\Api\Data\InviteInterface;

class Invite extends \Magento\Framework\Api\AbstractExtensibleObject implements InviteInterface
{

    /**
     * Get invite_id
     * @return int|null
     */
    public function getInviteId()
    {
        return $this->_get(self::INVITEID);
    }

    /**
     * Set invite_id
     * @param int $inviteId
     * @return Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setInviteId($inviteId)
    {
        return $this->setData(self::INVITEID, $inviteId);
    }

    /**
     * Get inviteCode
     * @return string|null
     */
    public function getInviteCode()
    {
        return $this->_get(self::INVITECODE);
    }

    /**
     * Set inviteCode
     * @param string $inviteCode
     * @return Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setInviteCode($inviteCode)
    {
        return $this->setData(self::INVITECODE, $inviteCode);
    }
    /**
     * Get usedBy
     * @return string|null
     */
    public function getUsedBy()
    {
        return $this->_get(self::USEDBY);
    }

    /**
     * Set usedBy
     * @param string $usedBy
     * @return Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setUsedBy($usedBy)
    {
        return $this->setData(self::USEDBY, $usedBy);
    }

    /**
     * Get isUsed
     * @return string|null
     */
    public function getisUsed()
    {
        return $this->_get(self::ISUSED);
    }

    /**
     * Set isUsed
     * @param string $isUsed
     * @return Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setisUsed($isUsed)
    {
        return $this->setData(self::ISUSED, $isUsed);
    }
    
    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return Bazar\SupplierManagement\Api\Data\InviteExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param Bazar\SupplierManagement\Api\Data\InviteExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Bazar\SupplierManagement\Api\Data\InviteExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy()
    {
        return $this->_get(self::CREATED_BY);
    }

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setCreatedBy($createdBy)
    {
        return $this->setData(self::CREATED_BY, $createdBy);
    }

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy()
    {
        return $this->_get(self::UPDATED_BY);
    }

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setUpdatedBy($updatedBy)
    {
        return $this->setData(self::UPDATED_BY, $updatedBy);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }
   
     /**
      * Get is_delete
      * @return bool|null
      */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }
}
