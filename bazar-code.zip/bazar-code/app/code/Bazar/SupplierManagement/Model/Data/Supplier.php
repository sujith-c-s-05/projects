<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Model\Data;

use Bazar\SupplierManagement\Api\Data\SupplierInterface;

class Supplier extends \Magento\Framework\Api\AbstractExtensibleObject implements SupplierInterface
{

    /**
     * Get id
     * @return int|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param string $id
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setId($ID)
    {
        return $this->setData(self::ID, $ID);
    }
    /**
     * Get customer_id
     * @return int|null
     */
    public function getCustomerId()
    {
        return $this->_get(self::CUSTOMER_ID);
    }

    /**
     * Set customer_id
     * @param string $customerId
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCustomerId($customerId)
    {
        return $this->setData(self::CUSTOMER_ID, $customerId);
    }
    /**
     * Get company_name
     * @return string|null
     */
    public function getCompanyName()
    {
        return $this->_get(self::COMPANY_NAME);
    }

    /**
     * Set company_ame
     * @param string $companyName
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCompanyName($companyName)
    {
        return $this->setData(self::COMPANY_NAME, $companyName);
    }
    /**
     * Get description
     * @return string|null
     */
    public function getDescription()
    {
        return $this->_get(self::DESCRIPTION);
    }

    /**
     * Set description
     * @param string $description
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }
    /**
     * Get website_url
     * @return string|null
     */
    public function getWebsiteUrl()
    {
        return $this->_get(self::WEBSITE_URL);
    }

    /**
     * Set website_url
     * @param string $websiteUrl
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setWebsiteUrl($websiteUrl)
    {
        return $this->setData(self::WEBSITE_URL, $websiteUrl);
    }
    /**
     * Get company_address
     * @return string|null
     */
    public function getCompanyAddress()
    {
        return $this->_get(self::COMPANY_ADDRESS);
    }

    /**
     * Set company_address
     * @param string $companyAddress
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCompanyAddress($companyAddress)
    {
        return $this->setData(self::COMPANY_ADDRESS, $companyAddress);
    }
    /**
     * Get city
     * @return string|null
     */
    public function getCity()
    {
        return $this->_get(self::CITY);
    }

    /**
     * Set city
     * @param string $city
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCity($city)
    {
        return $this->setData(self::CITY, $city);
    }
    /**
     * Get state
     * @return string|null
     */
    public function getState()
    {
        return $this->_get(self::STATE);
    }

    /**
     * Set state
     * @param string $state
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setState($state)
    {
        return $this->setData(self::STATE, $state);
    }
    /**
     * Get country
     * @return string|null
     */
    public function getCountry()
    {
        return $this->_get(self::COUNTRY);
    }

    /**
     * Set country
     * @param string $country
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCountry($country)
    {
        return $this->setData(self::COUNTRY, $country);
    }
    /**
     * Get zip_code
     * @return string|null
     */
    public function getZipCode()
    {
        return $this->_get(self::ZIP_CODE);
    }

    /**
     * Set zip_code
     * @param string $zipCode
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setZipCode($zipCode)
    {
        return $this->setData(self::ZIP_CODE, $zipCode);
    }
    /**
     * Get customer_email
     * @return string|null
     */
    public function getCustomerEmail()
    {
        return $this->_get(self::CUSTOMER_EMAIL);
    }

    /**
     * Set customer_email
     * @param string $customerEmail
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCustomerEmail($customerEmail)
    {
        return $this->setData(self::CUSTOMER_EMAIL, $customerEmail);
    }
    /**
     * Get passowrd
     * @return string|null
     */
    public function getPassword()
    {
        return $this->_get(self::CUSTOMER_PASSWORD);
    }

    /**
     * Set passowrd
     * @param string $passowrd
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setPassword($passowrd)
    {
        return $this->setData(self::CUSTOMER_PASSWORD, $passowrd);
    }
    /**
     * Get company_email
     * @return string|null
     */
    public function getCompanyEmail()
    {
        return $this->_get(self::COMPANY_EMAIL);
    }

    /**
     * Set company_email
     * @param string $companyEmail
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCompanyEmail($companyEmail)
    {
        return $this->setData(self::COMPANY_EMAIL, $companyEmail);
    }
    /**
     * Get phone_number
     * @return string|null
     */
    public function getPhoneNumber()
    {
        return $this->_get(self::PHONE_NUMBER);
    }

    /**
     * Set phone_number
     * @param string $phoneNumber
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setPhoneNumber($phoneNumber)
    {
        return $this->setData(self::PHONE_NUMBER, $phoneNumber);
    }
    /**
     * Get vat_number
     * @return string|null
     */
    public function getVatNumber()
    {
        return $this->_get(self::VAT_NUMBER);
    }

    /**
     * Set vat_number
     * @param string $vatNumber
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setVatNumber($vatNumber)
    {
        return $this->setData(self::VAT_NUMBER, $vatNumber);
    }
    /**
     * Get notification_email
     * @return string|null
     */
    public function getNotificationEmail()
    {
        return $this->_get(self::NOTIFICATION_EMAIL);
    }

    /**
     * Set notification_email
     * @param string $notificationEmail
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setNotificationEmail($notificationEmail)
    {
        return $this->setData(self::NOTIFICATION_EMAIL, $notificationEmail);
    }
    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_deleted
     * @return string|null
     */
    public function getIsDeleted()
    {
        return $this->_get(self::IS_DELETED);
    }

    /**
     * Set is_deleted
     * @param string $isDeleted
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setIsDeleted($isDeleted)
    {
        return $this->setData(self::IS_DELETED, $isDeleted);
    }
    /**
     * Get is_active
     * @return string|null
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param string $isActive
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }
    /**
     * Get storeCode
     * @return string|null
     */
    public function getStoreCode()
    {
        return $this->_get(self::STORE_CODE);
    }

    /**
     * Set storeCode
     * @param string $storeCode
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setStoreCode($storeCode)
    {
        return $this->setData(self::STORE_CODE, $storeCode);
    }

    /**
     * Get business_type
     * @return string[]|null
     */
    public function getBusinessType()
    {
        return $this->_get(self::BUSINESS_TYPE);
    }

    /**
     * Set business_type
     * @param string[] $businessType
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setBusinessType(array $businessType)
    {
        return $this->setData(self::BUSINESS_TYPE, $businessType);
    }
}
