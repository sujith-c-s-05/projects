<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SupplierManagement\Model;

use Magento\Framework\Model\AbstractModel;
use Bazar\SupplierManagement\Api\Data\NotificationOtpInterface;
use Bazar\SupplierManagement\Model\ResourceModel\NotificationOtp as ResourceNotificationOtp;

class NotificationOtp extends AbstractModel implements NotificationOtpInterface
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init(ResourceNotificationOtp::class);
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->_getData('id');
    }

    /**
     * Get Otp
     *
     * @return string
     */
    public function getOtp()
    {
        return $this->_getData('otp');
    }

    /**
     * Get Email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->_getData('email');
    }

    /**
     * Get is_verified
     *
     * @return string
     */
    public function getIsVerified()
    {
        return $this->_getData('is_verified');
    }

    /**
     * Get is_expired
     *
     * @return string
     */
    public function getIsExpired()
    {
        return $this->_getData('is_expired');
    }

    /**
     * Get created_at
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->_getData('created_at');
    }

    /**
     * Get updated_at
     *
     * @return string
     */
    public function getUpdatedAt()
    {
        return $this->_getData('updated_at');
    }

    /**
     * Set id
     *
     * @param int $id
     * @return NotificationOtpInterface
     */
    public function setId($id)
    {
        return $this->setData('id', $id);
    }

    /**
     * Set otp
     *
     * @param string $otp
     * @return NotificationOtpInterface
     */
    public function setOtp($otp)
    {
        return $this->setData('otp', $otp);
    }

    /**
     * Set email
     *
     * @param string $email
     * @return NotificationOtpInterface
     */
    public function setEmail($email)
    {
        return $this->setData('email', $email);
    }

    /**
     * Set is_verified
     *
     * @param string $isVerified
     * @return NotificationOtpInterface
     */
    public function setIsVerified($isVerified)
    {
        return $this->setData('is_verified', $isVerified);
    }

    /**
     * Set is_expired
     *
     * @param string|int $isExpired
     * @return NotificationOtpInterface
     */
    public function setIsExpired($isExpired)
    {
        return $this->setData('is_expired', $isExpired);
    }

    /**
     * Set created_at
     *
     * @param string $created_at
     * @return NotificationOtpInterface
     */
    public function setCreatedAt($created_at)
    {
        return $this->setData('created_at', $created_at);
    }

    /**
     * Set updated_at
     *
     * @param string $updated_at
     * @return NotificationOtpInterface
     */
    public function setUpdatedAt($updated_at)
    {
        return $this->setData('updated_at', $updated_at);
    }
}
