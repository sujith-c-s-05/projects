<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SupplierManagement\Model;

use Magento\Framework\Model\AbstractModel;
use Bazar\SupplierManagement\Api\Data\EmailTokenInterface;
use Bazar\SupplierManagement\Model\ResourceModel\EmailToken as ResourceEmailToken;

class EmailToken extends AbstractModel implements EmailTokenInterface
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init(ResourceEmailToken::class);
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->_getData('id');
    }

    /**
     * Get Token
     *
     * @return string
     */
    public function getToken()
    {
        return $this->_getData('token');
    }

    /**
     * Get Email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->_getData('email');
    }

    /**
     * Get is_verified
     *
     * @return string
     */
    public function getIsVerified()
    {
        return $this->_getData('is_verified');
    }

    /**
     * Get is_expired
     *
     * @return string
     */
    public function getIsExpired()
    {
        return $this->_getData('is_expired');
    }

    /**
     * Get created_at
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->_getData('created_at');
    }

    /**
     * Get updated_at
     *
     * @return string
     */
    public function getUpdatedAt()
    {
        return $this->_getData('updated_at');
    }

    /**
     * Set id
     *
     * @param int $id
     * @return EmailTokenInterface
     */
    public function setId($id)
    {
        return $this->setData('id', $id);
    }

    /**
     * Set token
     *
     * @param string $token
     * @return EmailTokenInterface
     */
    public function setToken($token)
    {
        return $this->setData('token', $token);
    }

    /**
     * Set email
     *
     * @param string $email
     * @return EmailTokenInterface
     */
    public function setEmail($email)
    {
        return $this->setData('email', $email);
    }

    /**
     * Set is_verified
     *
     * @param string $isVerified
     * @return EmailTokenInterface
     */
    public function setIsVerified($isVerified)
    {
        return $this->setData('is_verified', $isVerified);
    }

    /**
     * Set is_expired
     *
     * @param string|int $isExpired
     * @return EmailTokenInterface
     */
    public function setIsExpired($isExpired)
    {
        return $this->setData('is_expired', $isExpired);
    }

    /**
     * Set created_at
     *
     * @param string $created_at
     * @return EmailTokenInterface
     */
    public function setCreatedAt($created_at)
    {
        return $this->setData('created_at', $created_at);
    }

    /**
     * Set updated_at
     *
     * @param string $updated_at
     * @return EmailTokenInterface
     */
    public function setUpdatedAt($updated_at)
    {
        return $this->setData('updated_at', $updated_at);
    }
}
