<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Model;

use Bazar\SupplierManagement\Api\InviteRepositoryInterface;
use Bazar\SupplierManagement\Api\Data\InviteInterfaceFactory;
use Bazar\SupplierManagement\Api\Data\InviteSearchResultsInterfaceFactory;
use Bazar\SupplierManagement\Model\ResourceModel\Invite as ResourceInvite;
use Bazar\SupplierManagement\Model\ResourceModel\Invite\CollectionFactory as inviteCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Bazar\SupplierManagement\Model\ResourceModel\Supplier\CollectionFactory as SupplierCollectionFactory;

class InviteRepository implements InviteRepositoryInterface
{

    protected $inviteCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;
    protected $inviteFactory;

    protected $searchResultsFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataInviteFactory;

    protected $supplierCollectionFactory;
    protected $groupRepository;

    /**
     * @param ResourceInvite $resource
     * @param InviteFactory $inviteFactory
     * @param InviteInterfaceFactory $dataInviteFactory
     * @param InviteCollectionFactory $inviteCollectionFactory
     * @param InviteSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param SupplierCollectionFactory $supplierCollectionFactory
     *

     */
    public function __construct(
        ResourceInvite $resource,
        InviteFactory $inviteFactory,
        InviteInterfaceFactory $dataInviteFactory,
        InviteCollectionFactory $inviteCollectionFactory,
        InviteSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        SupplierCollectionFactory $supplierCollectionFactory,
        \Magento\Customer\Api\GroupRepositoryInterface $groupRepository,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
        \Magento\Customer\Model\ResourceModel\Customer\CollectionFactory $customerCollectionFactory
    ) {
        $this->resource = $resource;
        $this->inviteFactory = $inviteFactory;
        $this->inviteCollectionFactory = $inviteCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataInviteFactory = $dataInviteFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->supplierCollectionFactory = $supplierCollectionFactory;
        $this->groupRepository = $groupRepository;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
        $this->customerCollectionFactory    = $customerCollectionFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function get($Id)
    {
        $invite = $this->inviteFactory->create();
        $this->resource->load($invite, $Id);
        if (!$invite->getId()) {
            throw new NoSuchEntityException(__('Invite code with id "%1" does not exist.', $Id));
        }
        return $invite->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->inviteCollectionFactory->create();
        
        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Bazar\Invite\Api\Data\InviteInterface::class
        );
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }
   
    /**
     * {@inheritdoc}
     */
    public function getVerifyInvite($customerId, $inviteCode)
    {
        try {
            $inviteCollection = $this->inviteCollectionFactory->create();
            $inviteCollection->addFieldToFilter('invite_code', ['eq' => $inviteCode]);
            $inviteCollection->addFieldToFilter('is_used', ['eq' => 0]);
            if (count($inviteCollection)) {
                
                $invite=$inviteCollection->getFirstItem();
                $customerCollection = $this->customerCollectionFactory->create();
                $customerCollection->addAttributeToFilter('entity_id', $customerId);
                if (count($customerCollection)) {
                    $collectionItem = $customerCollection->getFirstItem();
                    $ItemData=$collectionItem->getData();
                    $groupId=$ItemData['group_id'];
                    $userBy='';
                    if ($groupId==4) {
                        $customerVerifed = $this->verifyCustomer($customerId);
                        $supplierCollection = $this->supplierCollectionFactory->create();
                        $supplierCollection->addFieldToFilter('customer_id', $customerId);
                        $supplierDetail=$supplierCollection->getFirstItem();
                        if ($customerVerifed && $supplierDetail) {
                            $supplierDetail->setIsActive(1);
                            $supplierDetail->save();
                        }
                        $usedBy=$supplierDetail->getCompanyName();
                    } elseif ($groupId==5) {
                        $firstName = $collectionItem->getFirstName();
                        $lastName = $collectionItem->getLastName();
                        $usedBy = $firstName ." ".$lastName;
                    }
                    $invite->setUsedBy($usedBy);
                    $invite->setisUsed(1);
                    $invite->save();
                    return true;
                }
            } else {
                throw new CouldNotSaveException(__(
                    'Invalid invitation code. Please contact Bazar admin for clarifications'
                ));
            }
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Invalid invitation code. Please contact Bazar admin for clarifications',
                $exception->getMessage()
            ));
        }
    }
            /**
             * @param int $customerId
             * @return bool
             * @throws \Magento\Framework\Exception\LocalizedException
             */
    public function verifyCustomer($customerId)
    {
        $customer = $this->_customerRepositoryInterface->getById($customerId);
        $verified = 0;
        if ($customer->getCustomAttribute('user_confirmation')) {
            $verified = $customer->getCustomAttribute('user_confirmation')->getValue();
        }
        if ($customer->getCustomAttribute('user_confirmation')) {
            $tokenAvailable = $customer->getCustomAttribute('confirmation_token')->getValue();
        }
        if ($verified) {
            throw new LocalizedException(__('Customer Already Verified!.'));
        } elseif (!$verified) {
            $customer->setCustomAttribute('user_confirmation', 1);
            $this->_customerRepositoryInterface->save($customer);
            return true;
        } else {
            throw new LocalizedException(__('Verfication Failed!'));
        }
    }
}
