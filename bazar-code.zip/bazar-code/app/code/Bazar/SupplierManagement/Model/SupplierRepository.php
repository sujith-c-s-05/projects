<?php

namespace Bazar\SupplierManagement\Model;

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

use Bazar\SupplierManagement\Api\Data\SupplierInterfaceFactory;
use Bazar\SupplierManagement\Api\Data\SupplierSearchResultsInterfaceFactory;
use Bazar\SupplierManagement\Api\SupplierRepositoryInterface;
use Bazar\SupplierManagement\Model\ResourceModel\Supplier as ResourceSupplier;
use Bazar\SupplierManagement\Model\ResourceModel\Supplier\CollectionFactory as SupplierCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Stdlib\StringUtils as StringHelper;
use Magento\Store\Model\ScopeInterface;

class SupplierRepository implements SupplierRepositoryInterface
{
    const XML_PATH_REQUIRED_CHARACTER_CLASSES_NUMBER = 'customer/password/required_character_classes_number';

    const XML_PATH_MINIMUM_PASSWORD_LENGTH = 'customer/password/minimum_password_length';

    /**
     * @param ResourceSupplier $resource
     * @param SupplierFactory $supplierFactory
     * @param SupplierInterfaceFactory $supplierInterfaceFactory
     * @param SupplierCollectionFactory $supplierCollectionFactory
     * @param SupplierSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param \Magento\Customer\Model\CustomerFactory $customerFactory
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param CustomerInterfaceFactory $customerInterfaceFactory
     * @param AccountManagementInterface $accountManagementInterface
     * @param CustomerRepositoryInterface $customerRepositoryInterface
     * @param ScopeConfigInterface $scopeConfig
     * @param StringHelper $stringHelper
     */
    public function __construct(
        ResourceSupplier $resource,
        SupplierFactory $supplierFactory,
        SupplierInterfaceFactory $supplierInterfaceFactory,
        SupplierCollectionFactory $supplierCollectionFactory,
        SupplierSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        CustomerInterfaceFactory $customerInterfaceFactory,
        AccountManagementInterface $accountManagementInterface,
        CustomerRepositoryInterface $customerRepositoryInterface,
        ScopeConfigInterface $scopeConfig,
        StringHelper $stringHelper
    ) {
        $this->resource = $resource;
        $this->supplierFactory = $supplierFactory;
        $this->supplierCollectionFactory = $supplierCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->supplierInterfaceFactory = $supplierInterfaceFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->_conn = $resourceConnection->getConnection();
        $this->customerFactory  = $customerFactory;
        $this->customerInterfaceFactory = $customerInterfaceFactory;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
        $this->accountManagementInterface = $accountManagementInterface;
        $this->scopeConfig = $scopeConfig;
        $this->stringHelper = $stringHelper;
        $this->_transportBuilder = $transportBuilder;
    }

    /**
     * Undocumented function
     *
     * @param \Bazar\SupplierManagement\Api\Data\SupplierInterface $supplier
     * @return void
     */
    public function save(
        \Bazar\SupplierManagement\Api\Data\SupplierInterface $supplier
    ) {
        $this->_conn->beginTransaction();
        $supplierData = $this->extensibleDataObjectConverter->toNestedArray(
            $supplier,
            [],
            \Bazar\SupplierManagement\Api\Data\SupplierInterface::class
        );
        try {
            if (!isset($supplierData['id'])) {
                $this->validateInfo($supplierData);
                $supplierData['store_code'] = 1;
            }
            if (!isset($supplierData['id']) && isset($supplierData['customer_email'])) {
                $this->checkCustomerExists($supplierData['customer_email']);
                $customer = $this->createCustomer($supplier);
                if (!$customer->getId()) {
                    throw new CouldNotSaveException(__('Could not save the Customer'));
                }
                $supplierData['customer_id'] = $customer->getId();
                $this->updateTokenData($supplierData['customer_id']);
                unset($supplierData['password']);
            }
            if (isset($supplierData['business_type'])) {
                $supplierData['business_type'] = implode(",", $supplierData['business_type']);
            }
            $supplierModel = $this->supplierFactory->create()->setData($supplierData);
            $this->resource->save($supplierModel);
            $mailtoNotify = $supplierModel->getNotificationEmail();
            if (!$mailtoNotify) {
                $mailtoNotify = $supplierModel->getCustomerEmail();
            }
            $this->_conn->commit();
        } catch (\Exception $exception) {
            $this->_conn->rollBack();
            throw new CouldNotSaveException(__(
                'Could not save the Supplier: %1',
                $exception->getMessage()
            ));
        }
        if (!isset($supplierData['id'])) {
            $this->sendNotificationMail($supplierModel);
        }
        return $supplierModel->getDataModel();
    }
    /**
     * validateBusinessType
     * @param mixed $businessType
     * @return mixed
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function validateBusinessType($businessType)
    {
        if (is_array($businessType) && !empty($businessType)) {
            return true;
        } else {
            throw new CouldNotSaveException(__("Invalid business types given."));
        }
    }

    /**
     * Retrieve supplier by email id
     * @param string $supplierEmail
     * @return bool|null
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function checkCustomerExists($supplierEmail)
    {

        $websiteId  = $this->storeManager->getWebsite()->getWebsiteId();
        $customer = $this->customerFactory->create();
        $customer->setWebsiteId(1);
        $customer->loadByEmail($supplierEmail);
        if ($customer->getId()) {
            throw new CouldNotSaveException(__(
                'There is already an account associated with this email address.'
            ));
        }
        return false;
    }
    /**
     * @param string[] $supplierData
     * @return void
     */
    public function validateInfo($supplierData)
    {
        $requiredFields = [
            'customer_email',
            'company_email',
            'company_name',
            'company_address',
            'password',
            'business_type'
        ];
        foreach ($requiredFields as $field) {
            if (!in_array($field, array_keys($supplierData))) {
                throw new CouldNotSaveException(__(
                    '%1 is Required!',
                    $field
                ));
            } elseif ($supplierData[$field] == 'business_type') {
                $this->validateBusinessType($supplierData[$field]);
                continue;
            } elseif (empty($supplierData[$field]) || $supplierData[$field] == '  ' | $supplierData[$field] == null) {
                throw new CouldNotSaveException(__(
                    '%1 cannot be empty!',
                    $field
                ));
            }
        }
    }

    /**
     *
     * @param mixed $supplier
     * @return mixed
     */
    public function createCustomer($supplier)
    {
        $this->checkPasswordStrength($supplier->getPassword());
        $websiteId  = $this->storeManager->getWebsite()->getWebsiteId();
        $customer = $this->customerFactory->create();
        // Associate website_id with customer
        if (!$customer->getStoreId()) {
            if ($customer->getWebsiteId()) {
                $storeId = $this->storeManager->getWebsite($customer->getWebsiteId())->getDefaultStore()->getId();
            } else {
                $this->storeManager->setCurrentStore(null);
                $storeId = $this->storeManager->getStore()->getId();
            }
            $customer->setStoreId($storeId);
        }
        if (!$customer->getWebsiteId()) {
            $websiteId = $this->storeManager->getStore($customer->getStoreId())->getWebsiteId();
            $customer->setWebsiteId($websiteId);
        }
        $customer->setWebsiteId($websiteId);
        $customer->setEmail($supplier->getCustomerEmail());
        $customer->setFirstname($supplier->getCompanyName());
        $customer->setLastname(" ");
        $customer->setGroupId(self::CUSTOMER_GROUP_ID);
        $customer->setPassword($supplier->getPassword());
        return $customer->save();
    }
    /**
     * Make sure that password complies with minimum security requirements.
     *
     * @param string $password
     * @return void
     * @throws InputException
     */
    protected function checkPasswordStrength($password)
    {
        $length = $this->stringHelper->strlen($password);
        if ($length > 256) {
            throw new InputException(
                __(
                    'Please enter a password with at most %1 characters.',
                    256
                )
            );
        }
        $configMinPasswordLength = $this->getMinPasswordLength();
        if ($length < $configMinPasswordLength) {
            throw new InputException(
                __(
                    'The password needs at least %1 characters. Create a new password and try again.',
                    $configMinPasswordLength
                )
            );
        }
        if ($this->stringHelper->strlen(trim($password)) != $length) {
            throw new InputException(
                __("The password can't begin or end with a space. Verify the password and try again.")
            );
        }
        $requiredCharactersCheck = $this->makeRequiredCharactersCheck($password);
        if ($requiredCharactersCheck !== 0) {
            throw new InputException(
                __(
                    'Minimum of different classes of characters in password is %1.' .
                        ' Classes of characters: Lower Case, Upper Case, Digits, Special Characters.',
                    $requiredCharactersCheck
                )
            );
        }
    }
    /**
     * Check password for presence of required character sets
     *
     * @param string $password
     * @return int
     */
    protected function makeRequiredCharactersCheck($password)
    {
        $counter = 0;
        $requiredNumber = $this->scopeConfig->getValue(self::XML_PATH_REQUIRED_CHARACTER_CLASSES_NUMBER);
        $return = 0;

        if (preg_match('/[0-9]+/', $password)) {
            $counter++;
        }
        if (preg_match('/[A-Z]+/', $password)) {
            $counter++;
        }
        if (preg_match('/[a-z]+/', $password)) {
            $counter++;
        }
        if (preg_match('/[^a-zA-Z0-9]+/', $password)) {
            $counter++;
        }

        if ($counter < $requiredNumber) {
            $return = $requiredNumber;
        }

        return $return;
    }

    /**
     * Retrieve minimum password length
     *
     * @return int
     */
    protected function getMinPasswordLength()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_MINIMUM_PASSWORD_LENGTH);
    }

    /**
     * updateTokenData
     *
     * @param int $customerId
     * @return mixed
     */
    public function updateTokenData($customerId, $resetPassword = false)
    {
        $customer = $this->_customerRepositoryInterface->getById($customerId);
        $tokenFrom = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        $token = substr(str_shuffle($tokenFrom), 0, 50);
        $customer->setCustomAttribute('user_confirmation', 0);
        $customer->setCustomAttribute('confirmation_token', $token);
        $customer->setCustomAttribute('is_password_set', 1);
        if ($resetPassword) {
            $customer->setCustomAttribute('is_password_set', 0);
        }
        
        return $this->_customerRepositoryInterface->save($customer);
    }

    /**
     * Retrieve supplier
     * @param string $supplierId
     * @return Bazar\SupplierManagement\Api\Data\SupplierInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($supplierId)
    {
        $supplier = $this->supplierFactory->create();
        $this->resource->load($supplier, $supplierId);
        if (!$supplier->getId()) {
            throw new NoSuchEntityException(__('supplier with id "%1" does not exist.', $supplierId));
        }
        return $supplier->getDataModel();
    }

    /**
     * Retrieve suppliers matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Bazar\SupplierManagement\Api\Data\SupplierSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->supplierCollectionFactory->create();

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * Delete supplier
     * @param int $id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete($id)
    {
        try {
            $supplierModel = $this->supplierFactory->create();
            $this->resource->load($supplierModel, $id);
            $this->resource->delete($supplierModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the supplier: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }
    /**
     * @param string $supplierEmail
     * @return mixed
     */
    public function getSupplierByEmail($supplierEmail)
    {
        $supplierCollection = $this->supplierCollectionFactory->create()
            ->addFieldToFilter('company_email', $supplierEmail)
            ->getFirstItem();
        if (empty($supplierCollection->getData())) {
            return false;
        }
        return $supplierCollection;
    }
    /**
     * @param int $customerId
     * @param string $token
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function verifyCustomer($customerId, $token)
    {
        $customer = $this->_customerRepositoryInterface->getById($customerId);
        $verified = false;
        $tokenAvailable = '';
        if ($customer->getCustomAttribute('user_confirmation')) {
            $verified = $customer->getCustomAttribute('user_confirmation')->getValue();
        }
        if ($customer->getCustomAttribute('confirmation_token')) {
            $tokenAvailable = $customer->getCustomAttribute('confirmation_token')->getValue();
        }

        if ($verified) {
            throw new LocalizedException(__('Customer Already Verified!.'));
        } elseif (!$verified && $token == $tokenAvailable) {
            $customer->setCustomAttribute('user_confirmation', 1);
            $supplier = $this->supplierCollectionFactory->create()
                ->addFieldToFilter('customer_id', $customerId)
                ->getFirstItem();
            $supplier->setData('is_active', 1);
            $this->resource->save($supplier);
            $this->_customerRepositoryInterface->save($customer);
            return true;
        } else {
            throw new LocalizedException(__('Verfication Failed!'));
        }
    }
    /**
     * Undocumented function
     *
     * @param string $mailtoNotify
     * @param mixed $supplier
     * @param boolean $password
     * @return void
     */
    public function sendNotificationMail($supplier, $password = false)
    {
        $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $store = $this->storeManager->getStore()->getId();
        $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $senderName  = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
        $from = ['email' => $email, 'name' => $senderName];
        $mailtoNotify = $supplier->getNotificationEmail();
        $transport = $this->_transportBuilder->setTemplateIdentifier($this->getTemplate($supplier), ScopeInterface::SCOPE_STORE)
            ->setFrom($from)
            ->addTo($mailtoNotify)
            ->setTemplateVars($this->getTemplateVariables($supplier, $password))
            ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $store])
            ->getTransport();
        $transport->sendMessage();
    }

    /**
     * Get supplier by customer email
     * @param string $customerEmail
     * @return mixed
     */
    public function getSupplierByCustomerEmail($customerEmail)
    {
        $supplierCollection = $this->supplierCollectionFactory->create()
            ->addFieldToFilter('customer_email', $customerEmail)
            ->getFirstItem();
        if (empty($supplierCollection->getData())) {
            return false;
        }
        return $supplierCollection;
    }
    /**
     * getTemplate
     *
     * @param mixed $supplier
     * @return string
     */
    public function getTemplate($supplier)
    {
        if($supplier->getStoreCode() && $supplier->getIsActive()){
            $template = "bazar_supplier_activation_template";
        } elseif($supplier->getStoreCode() && !$supplier->getIsActive()){
            $template = "bazar_supplier_signup_template";
        } elseif (!$supplier->getStoreCode() && $supplier->getIsActive()){
            $template = 'bazar_supplier_adminsignup_template';
        } elseif(!$supplier->getStoreCode() && !$supplier->getIsActive()){
            $template = 'bazar_supplier_editregister_template';
        }
        else{
            $template = "bazar_supplier_signup_template";
        }
        return $template;
    }
    /**
     * Undocumented function
     *
     * @param string $mailtoNotify
     * @param mixed $supplier
     * @param string|bool $password
     * @return string[]
     */
    public function getTemplateVariables($supplier, $password)
    {
        $companyName = $supplier->getCompanyName();
        $customer = $this->_customerRepositoryInterface->getById($supplier->getCustomerId());
        $customerId = $customer->getId();
        $frontEndUrl = $this->scopeConfig->getValue(
            'frontend_url/url/front_end_base_url',
            ScopeInterface::SCOPE_STORE
        );
        $tokenAvailable = $customer->getCustomAttribute('confirmation_token')->getValue();
        $loginLink = $frontEndUrl . '?t_id=' . $tokenAvailable . '&id=' . $customerId;
        $loginUrl = "<a href='".$frontEndUrl."'>".$frontEndUrl."</a>";
        if ($password) {
            $loginUrl = "<a href='".$loginLink."'>".$loginLink."</a>";
        }
        if(!$supplier->getStoreCode() && !$supplier->getIsActive()){
            $loginUrl = "<a href='".$frontEndUrl."'>".$frontEndUrl."</a>";
        }
        if(!$supplier->getStoreCode() && $supplier->getIsActive()){
            $loginUrl = "<a href='".$loginLink."'>".$loginLink."</a>";
        }
        $templateVars = [
            'customer_name' => $companyName,
            'loginlink' => $loginUrl,
            'user_name' => $supplier->getNotificationEmail(),
            'password' => $password
        ];
        return $templateVars;
    }
}
