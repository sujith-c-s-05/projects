<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SupplierManagement\Model;

use Bazar\SupplierManagement\Model\EmailTokenFactory;
use Bazar\SupplierManagement\Api\Data\EmailTokenInterface;
use Bazar\SupplierManagement\Api\Data\EmailTokenSearchResultsInterface;
use Bazar\SupplierManagement\Model\ResourceModel\EmailToken as EmailTokenResourceModel;
use Exception;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\MailException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\CouldNotDeleteException;
use Bazar\SupplierManagement\Model\ResourceModel\EmailToken\CollectionFactory;
use Bazar\SupplierManagement\Api\Data\EmailTokenSearchResultsInterfaceFactory;
use Bazar\SupplierManagement\Api\EmailTokenRepositoryInterface;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Bazar\SupplierManagement\Api\SupplierRepositoryInterface as SupplierRepository;

class EmailTokenRepository implements EmailTokenRepositoryInterface
{
    /**
     * @var EmailTokenFactory
     */
    protected $emailTokenFactory;

    /**
     * @var EmailTokenResourceModel
     */
    protected $emailTokenResourceModel;

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var EmailTokenSearchResultsInterfaceFactory
     */
    protected $emailTokenSearchResultsFactory;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var TransportBuilder
     */
    protected $transportBuilder;

    /**
     * @var SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var SupplierRepository
     */
    protected $supplierRepository;

    /**
     * Constructor
     *
     * @param EmailTokenFactory $emailTokenFactory
     * @param EmailTokenResourceModel $emailTokenResourceModel
     * @param CollectionFactory $collectionFactory
     * @param EmailTokenSearchResultsInterfaceFactory $emailTokenSearchResultsFactory
     * @param StoreManagerInterface $storeManager
     * @param ScopeConfigInterface $scopeConfig
     * @param TransportBuilder $transportBuilder
     * @param SearchCriteriaBuilder $searchCriteriaBuilder
     * @param SupplierRepository $supplierRepository
     */
    public function __construct(
        EmailTokenFactory $emailTokenFactory,
        EmailTokenResourceModel $emailTokenResourceModel,
        CollectionFactory $collectionFactory,
        EmailTokenSearchResultsInterfaceFactory $emailTokenSearchResultsFactory,
        StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        TransportBuilder $transportBuilder,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        SupplierRepository $supplierRepository
    ) {
        $this->emailTokenFactory = $emailTokenFactory;
        $this->emailTokenResourceModel = $emailTokenResourceModel;
        $this->collectionFactory = $collectionFactory;
        $this->emailTokenSearchResultsFactory = $emailTokenSearchResultsFactory;
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->transportBuilder = $transportBuilder;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->supplierRepository = $supplierRepository;
    }

    /**
     * Get Email Token by id
     *
     * @param int $id
     * @return EmailTokenInterface
     * @throws NoSuchEntityException
     */
    public function getById($id)
    {
        $emailToken = $this->emailTokenFactory->create();
        $this->emailTokenResourceModel->load($emailToken, $id);
        if (!$emailToken->getId()) {
            throw new NoSuchEntityException(__("Email Token with id %1 does not exist", $id));
        }
        return $emailToken;
    }

    /**
     * Save Email Token
     *
     * @param EmailTokenInterface $emailToken
     * @return EmailTokenInterface
     * @throws CouldNotSaveException
     */
    public function save(EmailTokenInterface $emailToken)
    {
        try {
            $this->emailTokenResourceModel->save($emailToken);
        } catch (Exception $e) {
            throw new CouldNotSaveException(__($e->getMessage()));
        }
        return $emailToken;
    }

    /**
     * Delete email token by id
     *
     * @param int $id
     * @return mixed
     * @throws CouldNotDeleteException
     * @throws NoSuchEntityException
     */
    public function deleteById($id)
    {
        return $this->delete($this->getById($id));
    }

    /**
     * Delete Email Token
     *
     * @param EmailTokenInterface $emailToken
     * @return mixed
     * @throws CouldNotDeleteException
     */
    public function delete(EmailTokenInterface $emailToken)
    {
        try {
            $this->emailTokenResourceModel->delete($emailToken);
        } catch (Exception $exception) {
            throw new CouldNotDeleteException(__($exception->getMessage()));
        }
        return true;
    }

    /**
     * Get email token collection
     *
     * @param SearchCriteriaInterface $searchCriteria
     * @return EmailTokenSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        $searchResults = $this->emailTokenSearchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $collection = $this->collectionFactory->create();
        foreach ($searchCriteria->getFilterGroups() as $filterGroup) {
            $fields = [];
            $conditions = [];
            foreach ($filterGroup->getFilters() as $filter) {
                $condition = $filter->getConditionType() ? $filter->getConditionType() : 'eq';
                $fields[] = $filter->getField();
                $conditions[] = [$condition => $filter->getValue()];
            }
            if ($fields) {
                $collection->addFieldToFilter($fields, $conditions);
            }
        }
        $searchResults->setTotalCount($collection->getSize());
        $sortOrders = $searchCriteria->getSortOrders();
        if ($sortOrders) {
            /** @var SortOrder $sortOrder */
            foreach ($sortOrders as $sortOrder) {
                $collection->addOrder(
                    $sortOrder->getField(),
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        }
        $collection->setCurPage($searchCriteria->getCurrentPage());
        $collection->setPageSize($searchCriteria->getPageSize());
        $emailTokens = [];
        foreach ($collection as $token) {
            $emailTokens[] = $token;
        }
        $searchResults->setItems($emailTokens);
        return $searchResults;
    }

    /**
     * Generate token and send verification email for given email id
     *
     * @param string $email
     * @return boolean
     * @throws CouldNotSaveException
     * @throws MailException
     */
    public function sendVerificationMail($email)
    {
        $tokenFrom = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        $token = substr(str_shuffle($tokenFrom), 0, 50);
        $this->updateTokensExpireStatus($email, 1);
        $this->saveEmailToken($token, $email);
        $this->sendMail($email, $token);

        return true;
    }

    /**
     * Update token expiry status
     *
     * @param string $email
     * @param string $status
     * @throws CouldNotSaveException
     */
    public function updateTokensExpireStatus($email, $status)
    {
        // filter existing non-expired tokens and make it as expired
        $searchCriteria = $this->searchCriteriaBuilder
            ->addFilter("email", $email, "eq")
            ->addFilter("is_expired", 0, "eq")
            ->create();
        $tokens = $this->getList($searchCriteria)->getItems();
        foreach ($tokens as $token) {
            $token->setIsExpired($status);
            try {
                $this->save($token);
            } catch (Exception $e) {
                throw new CouldNotSaveException(__('Could not update email token'));
            }
        }
    }

    /**
     * Generate and save new token
     *
     * @param string $token
     * @param string $email
     * @throws CouldNotSaveException
     */
    public function saveEmailToken($token, $email)
    {
        // save new token
        $emailToken = $this->emailTokenFactory->create();
        $emailToken->setEmail($email)
            ->setToken($token);
        try {
            $this->save($emailToken);
        } catch (Exception $e) {
            throw new CouldNotSaveException(__('Could not save email token'));
        }
    }

    /**
     * Send verification email for given token
     *
     * @param string $mailtoNotify
     * @param string $token
     * @return void
     * @throws LocalizedException
     */
    public function sendMail($mailtoNotify, $token)
    {
        $store = $this->storeManager->getStore()->getId();
        $template = "bazar_supplier_verification_email_template";
        $frontEndUrl = $this->scopeConfig->getValue(
            'frontend_url/url/front_end_base_url',
            ScopeInterface::SCOPE_STORE
        );
        $verificationUrl = $frontEndUrl . 'emailVerify?email=' . $mailtoNotify . '&token=' . $token;
        $templateVars = [
            'verification_url' => $verificationUrl
        ];
        $email = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $senderName = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
        $from = ['email' => $email, 'name' => $senderName];
        try {
            $transport = $this->transportBuilder->setTemplateIdentifier($template)
                ->setFrom($from)
                ->addTo($mailtoNotify)
                ->setTemplateVars($templateVars)
                ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $store])
                ->getTransport();
            $transport->sendMessage();
        } catch (\Exception $exception) {
            throw new MailException(__(
                'Unable to send verification mail: %1',
                $exception->getMessage()
            ));
        }
    }

    /**
     * Verify given email, token update is_verified flag on success
     *
     * @param string $email
     * @param string $token
     * @return bool
     * @throws CouldNotSaveException
     * @throws InputException
     * @throws NotFoundException
     */
    public function verifyMail($email, $token)
    {
        $emailVerified = false;
        $supplierOnboarded = false;
        $supplier = $this->supplierRepository->getSupplierByCustomerEmail($email);
        //if supplier with given email already exists
        if ($supplier != false) {
            $emailVerified = true;
            $supplierOnboarded = true;
        } else {
            // filter existing non-expired tokens and make it as expired
            $searchCriteria = $this->searchCriteriaBuilder
                ->addFilter("email", $email, "eq")
                ->addFilter("token", $token, "eq")
                ->create();
            $searchCriteria->setPageSize(1)
                ->setCurrentPage(1);
            $tokens = $this->getList($searchCriteria)->getItems();
            $token = current($tokens);
            if (empty($tokens)) {
                throw new NotFoundException(__('Invalid email address or token !'));
            } elseif ($token->getIsVerified() == 1) {
                $emailVerified = true;
            } else {
                if ($token->getIsExpired() == 1) {
                    throw new InputException(__('Token expired !'));
                }
                $token->setIsVerified(1)
                    ->setIsExpired(1);
                $this->save($token);
                $emailVerified = true;

            }
        }
        $response = [
            'email_verified' => $emailVerified,
            'supplier_onboarded' => $supplierOnboarded
        ];

        return json_encode($response);
    }
}
