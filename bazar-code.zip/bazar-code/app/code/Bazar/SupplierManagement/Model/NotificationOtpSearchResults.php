<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Model;

use \Magento\Framework\Api\SearchResults;
use \Bazar\SupplierManagement\Api\Data\NotificationOtpSearchResultsInterface;

/**
 * Class NotificationOtpSearchResults
 *
 * @package Bazar\SupplierManagement\Model
 */
class NotificationOtpSearchResults extends SearchResults implements NotificationOtpSearchResultsInterface
{

}
