<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SupplierManagement\Model;

use Bazar\SupplierManagement\Api\Data\SupplierInterface;
use Bazar\SupplierManagement\Api\Data\SupplierInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Serialize\SerializerInterface;

class Supplier extends \Magento\Framework\Model\AbstractModel
{

    protected $dataObjectHelper;
    protected $parkorderDataFactory;
    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param SupplierInterfaceFactory $supplierInterfaceFactory
     * @param SerializerInterface $serializer
     * @param DataObjectHelper $dataObjectHelper
     * @param \Bazar\SupplierManagement\Model\ResourceModel\Supplier $resource
     * @param \Bazar\SupplierManagement\Model\ResourceModel\Supplier\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        SupplierInterfaceFactory $supplierInterfaceFactory,
        SerializerInterface $serializer,
        DataObjectHelper $dataObjectHelper,
        \Bazar\SupplierManagement\Model\ResourceModel\Supplier $resource,
        \Bazar\SupplierManagement\Model\ResourceModel\Supplier\Collection $resourceCollection,
        array $data = []
    ) {
        $this->supplierInterfaceFactory = $supplierInterfaceFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->serializer = $serializer;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve SupplierInterfaceData
     * @return SupplierInterface
     */
    public function getDataModel()
    {
        $supplierData = $this->getData();
        if (isset($supplierData['business_type']) && $supplierData['business_type']!= NULL) {
            $supplierData['business_type'] = explode(",", $supplierData['business_type']);
        } else {
            $supplierData['business_type'] = [];
        }
        $supplierDataObject = $this->supplierInterfaceFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $supplierDataObject,
            $supplierData,
            SupplierInterface::class
        );

        return $supplierDataObject;
    }
}
