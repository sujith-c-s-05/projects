<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Model;

use Bazar\SupplierManagement\Api\Data\InviteInterface;
use Bazar\SupplierManagement\Api\Data\InviteInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class Invite extends \Magento\Framework\Model\AbstractModel
{

    protected $inviteDataFactory;

    protected $dataObjectHelper;

    protected $_eventPrefix = 'bazar_invite_invite';

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param InviteInterfaceFactory $inviteDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Bazar\SupplierManagement\Model\ResourceModel\Invite $resource
     * @param \Bazar\SupplierManagement\Model\ResourceModel\Invite\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        InviteInterfaceFactory $inviteDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Bazar\SupplierManagement\Model\ResourceModel\Invite $resource,
        \Bazar\SupplierManagement\Model\ResourceModel\Invite\Collection $resourceCollection,
        array $data = []
    ) {
        $this->inviteDataFactory = $inviteDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve invite model with invite data
     * @return InviteInterface
     */
    public function getDataModel()
    {
        $inviteData = $this->getData();
        
        $inviteDataObject = $this->inviteDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $inviteDataObject,
            $inviteData,
            InviteInterface::class
        );
        
        return $inviteDataObject;
    }
}
