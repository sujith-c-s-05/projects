<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SupplierManagement\Api;

use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Bazar\SupplierManagement\Api\Data\EmailTokenInterface;
use Bazar\SupplierManagement\Api\Data\EmailTokenSearchResultsInterface;
use Magento\Framework\Exception\NotFoundException;

/**
 * Interface EmailTokenRepositoryInterface
 *
 * @package Bazar\SupplierManagement\Api
 */
interface EmailTokenRepositoryInterface
{

    /**
     * Get Email Token by id
     *
     * @param int $id
     * @return EmailTokenInterface
     * @throws NoSuchEntityException
     */
    public function getById($id);

    /**
     * Save Email Token
     *
     * @param EmailTokenInterface $emailToken
     * @return EmailTokenInterface
     */
    public function save(EmailTokenInterface $emailToken);

    /**
     * Delete email token
     *
     * @param int $id
     * @return mixed
     */
    public function deleteById($id);

    /**
     * Delete Email Token
     *
     * @param EmailTokenInterface $emailToken
     * @return mixed
     */
    public function delete(EmailTokenInterface $emailToken);

    /**
     * Get email token collection
     *
     * @param SearchCriteriaInterface $searchCriteria
     * @return EmailTokenSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);

    /**
     * Generate token and send verification email for given email id
     *
     * @param string $email
     * @return string
     */
    public function sendVerificationMail($email);

    /**
     * Verify given email, token update is_verified flag on success
     *
     * @param string $email
     * @param string $token
     * @return bool
     * @throws CouldNotSaveException
     * @throws NotFoundException
     */
    public function verifyMail($email, $token);
}
