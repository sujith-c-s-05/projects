<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface SupplierRepositoryInterface
{
    const CUSTOMER_GROUP_ID = 4;

    /**
     * Save Supplier
     * @param Bazar\SupplierManagement\Api\Data\SupplierInterface $supplier
     * @return Bazar\SupplierManagement\Api\Data\SupplierInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Bazar\SupplierManagement\Api\Data\SupplierInterface $supplier
    );

    /**
     * Retrieve supplier
     * @param string $supplierId
     * @return Bazar\SupplierManagement\Api\Data\SupplierInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($supplierId);
    /**
     * Retrieve supplier by email id
     * @param string $supplierEmail
     * @return bool|null
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function checkCustomerExists($supplierEmail);
    /**
     * Retrieve suppliers matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Bazar\SupplierManagement\Api\Data\SupplierSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete supplier
     * @param int $id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete($id);

     /**
      * Retrieve supplier
      * @param string $supplierEmail
      * @return Bazar\SupplierManagement\Api\Data\SupplierInterface
      * @throws \Magento\Framework\Exception\LocalizedException
      */
    public function getSupplierByEmail($supplierEmail);
    /**
     * @param int $customerId
     * @param string $token
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function verifyCustomer($customerId, $token);
}
