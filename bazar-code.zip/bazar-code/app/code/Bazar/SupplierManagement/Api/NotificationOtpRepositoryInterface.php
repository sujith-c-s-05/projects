<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SupplierManagement\Api;

use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Bazar\SupplierManagement\Api\Data\NotificationOtpInterface;
use Bazar\SupplierManagement\Api\Data\NotificationOtpSearchResultsInterface;

/**
 * Interface NotificationOtpRepositoryInterface
 *
 * @package Bazar\SupplierManagement\Api
 */
interface NotificationOtpRepositoryInterface
{

    /**
     * Get notification mail OTP by id
     *
     * @param int $id
     * @return NotificationOtpInterface
     * @throws NoSuchEntityException
     */
    public function getById($id);

    /**
     * Save notification mail OTP
     *
     * @param NotificationOtpInterface $notificationOtp
     * @return NotificationOtpInterface
     */
    public function save(NotificationOtpInterface $notificationOtp);

    /**
     * Delete notification mail otp
     *
     * @param int $id
     * @return mixed
     */
    public function deleteById($id);

    /**
     * Delete notification mail OTP
     *
     * @param NotificationOtpInterface $notificationOtp
     * @return mixed
     */
    public function delete(NotificationOtpInterface $notificationOtp);

    /**
     * Get notification mail otp collection
     *
     * @param SearchCriteriaInterface $searchCriteria
     * @return NotificationOtpSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria);

    /**
     * Generate notification otp and send notification email verification code for given email id
     *
     * @param string $email
     * @return string
     */
    public function sendOtp($email);

    /**
     * Verify given email, otp and update is_verified, is_expired flags on success
     * also update supplier notification email
     *
     * @param int $supplierId
     * @param string $email
     * @param string $otp
     * @return bool
     */
    public function verifyOtp($supplierId, $email, $otp);
}
