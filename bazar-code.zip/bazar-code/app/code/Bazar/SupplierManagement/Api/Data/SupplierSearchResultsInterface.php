<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */

declare(strict_types=1);

namespace Bazar\SupplierManagement\Api\Data;

interface SupplierSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get DeliverySlot list.
     * @return \Bazar\SupplierManagement\Api\Data\SupplierInterface[]
     */
    public function getItems();

    /**
     * Set DeliverySlot list.
     * @param \Bazar\SupplierManagement\Api\Data\SupplierInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
