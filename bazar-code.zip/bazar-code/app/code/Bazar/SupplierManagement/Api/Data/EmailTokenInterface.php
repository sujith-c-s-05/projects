<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Api\Data;

interface EmailTokenInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    /**
     * Get id
     *
     * @return string|null
     */
    public function getId();

    /**
     * Set id
     *
     * @param string $emailTokenId
     * @return $this
     */
    public function setId($emailTokenId);

    /**
     * Get token
     *
     * @return string|null
     */
    public function getToken();

    /**
     * Set token
     *
     * @param string $token
     * @return $this
     */
    public function setToken($token);

    /**
     * Get email
     *
     * @return string|null
     */
    public function getEmail();

    /**
     * Set email
     *
     * @param string email
     * @return $this
     */
    public function setEmail($email);

    /**
     * Get is_verified
     *
     * @return int|null
     */
    public function getIsVerified();

    /**
     * Set is_verified
     *
     * @param int $isVerified
     * @return $this
     */
    public function setIsVerified($isVerified);

    /**
     * Get is_expired
     *
     * @return int|null
     */
    public function getIsExpired();

    /**
     * Set is_expired
     *
     * @param string|int $isExpired
     * @return $this
     */
    public function setIsExpired($isExpired);

    /**
     * Get created_at
     *
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     *
     * @param string $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     *
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     *
     * @param string $updatedAt
     * @return $this
     */
    public function setUpdatedAt($updatedAt);
}
