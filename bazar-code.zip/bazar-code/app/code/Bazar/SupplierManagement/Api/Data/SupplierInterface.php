<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Api\Data;

interface SupplierInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**#@+
     * Constants defined for keys of the data array. Identical to the name of the getter in snake case
     */
    const ID = 'id';
    const CUSTOMER_ID = 'customer_id';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const COMPANY_NAME = 'company_name';
    const DESCRIPTION = 'description';
    const WEBSITE_URL = 'website_url';
    const COMPANY_ADDRESS = 'company_address';
    const CITY = 'city';
    const STATE = 'state';
    const COUNTRY = 'country';
    const ZIP_CODE = 'zip_code';
    const CUSTOMER_EMAIL = 'customer_email';
    const CUSTOMER_PASSWORD = 'password';
    const COMPANY_EMAIL = 'company_email';
    const PHONE_NUMBER = 'phone_number';
    const VAT_NUMBER = 'vat_number';
    const NOTIFICATION_EMAIL = 'notification_email';
    const IS_ACTIVE = 'is_active';
    const IS_DELETED = 'is_deleted';
    const BUSINESS_TYPE = 'business_type';
    const STORE_CODE = 'store_code';
    /**#@-*/

    /**
     * Get id
     * @return int|null
     */
    public function getId();

    /**
     * Set id
     * @param string $id
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setId($id);
    /**
     * Get customer_id
     * @return int|null
     */
    public function getCustomerId();

    /**
     * Set customer_id
     * @param string $customerId
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCustomerId($customerId);
    /**
     * Get company_name
     * @return string|null
     */
    public function getCompanyName();

    /**
     * Set company_ame
     * @param string $companyName
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCompanyName($companyName);
    /**
     * Get passowrd
     * @return string|null
     */
    public function getPassword();

    /**
     * Set passowrd
     * @param string $passowrd
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setPassword($passowrd);
    /**
     * Get description
     * @return string|null
     */
    public function getDescription();

    /**
     * Set description
     * @param string $description
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setDescription($description);
    /**
     * Get website_url
     * @return string|null
     */
    public function getWebsiteUrl();

    /**
     * Set website_url
     * @param string $websiteUrl
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setWebsiteUrl($websiteUrl);
    /**
     * Get company_address
     * @return string|null
     */
    public function getCompanyAddress();

    /**
     * Set company_address
     * @param string $companyAddress
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCompanyAddress($companyAddress);
    /**
     * Get city
     * @return string|null
     */
    public function getCity();

    /**
     * Set city
     * @param string $city
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCity($city);
    /**
     * Get state
     * @return string|null
     */
    public function getState();

    /**
     * Set state
     * @param string $state
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setState($state);
    /**
     * Get country
     * @return string|null
     */
    public function getCountry();

    /**
     * Set country
     * @param string $country
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCountry($country);
    /**
     * Get zip_code
     * @return string|null
     */
    public function getZipCode();

    /**
     * Set zip_code
     * @param string $zipCode
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setZipCode($zipCode);
    /**
     * Get customer_email
     * @return string|null
     */
    public function getCustomerEmail();

    /**
     * Set customer_email
     * @param string $customerEmail
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCustomerEmail($customerEmail);
    /**
     * Get company_email
     * @return string|null
     */
    public function getCompanyEmail();

    /**
     * Set company_email
     * @param string $companyEmail
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCompanyEmail($companyEmail);
    /**
     * Get phone_number
     * @return string|null
     */
    public function getPhoneNumber();

    /**
     * Set phone_number
     * @param string $phoneNumber
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setPhoneNumber($phoneNumber);
    /**
     * Get vat_number
     * @return string|null
     */
    public function getVatNumber();

    /**
     * Set vat_number
     * @param string $vatNumber
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setVatNumber($vatNumber);
    /**
     * Get notification_email
     * @return string|null
     */
    public function getNotificationEmail();

    /**
     * Set notification_email
     * @param string $notificationEmail
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setNotificationEmail($notificationEmail);
    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_deleted
     * @return string|null
     */
    public function getIsDeleted();

    /**
     * Set is_deleted
     * @param string $isDeleted
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setIsDeleted($isDeleted);
    /**
     * Get is_active
     * @return string|null
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param string $isActive
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setIsActive($isActive);
    /**
     * Get store_code
     * @return string|null
     */
    public function getStoreCode();

    /**
     * Set store_code
     * @param string $storeCode
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setStoreCode($storeCode);

    /**
     * Get business_type
     * @return string[]|null
     */
    public function getBusinessType();

    /**
     * Set business_type
     * @param string[] $businessType
     * @return \Bazar\SupplierManagement\Api\Data\Api\Data\SupplierInterface
     */
    public function setBusinessType(array $businessType);
}
