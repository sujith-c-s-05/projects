<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Api\Data;

interface InviteSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get invite code list.
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface[]
     */
    public function getItems();

    /**
     * Set Id list.
     * @param \Bazar\SupplierManagement\Api\Data\InviteInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
