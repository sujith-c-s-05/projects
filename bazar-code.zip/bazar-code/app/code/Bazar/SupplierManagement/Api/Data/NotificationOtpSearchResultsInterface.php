<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface NotificationOtpSearchResultsInterface
 * @package Bazar\SupplierManagement\Api\Data
 */
interface NotificationOtpSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get notification email otp
     *
     * @return NotificationOtpInterface[]
     */
    public function getItems();

    /**
     * @param NotificationOtpInterface[] $otps
     *
     * @return $this
     */
    public function setItems(array $otps);
}
