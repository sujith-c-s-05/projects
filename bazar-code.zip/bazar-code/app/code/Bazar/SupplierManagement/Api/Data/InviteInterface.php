<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Api\Data;

interface InviteInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    const INVITEID='invite_id';
    const INVITECODE = 'invite_code';
    const ISUSED ='is_used';
    const USEDBY='used_by';
    const CREATED_AT = 'created_at';
    const UPDATED_AT = 'updated_at';
    const CREATED_BY = 'created_by';
    const UPDATED_BY = 'updated_by';
    const IS_ACTIVE = 'is_active';
    const IS_DELETE = 'is_delete';
    
    /**
     * Get invite_id
     * @return int|null
     */
    public function getInviteId();

    /**
     * Set invite_id
     * @param int $inviteId
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setInviteId($inviteId);
  
    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Bazar\SupplierManagement\Api\Data\InviteExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Bazar\SupplierManagement\Api\Data\InviteExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Bazar\SupplierManagement\Api\Data\InviteExtensionInterface $extensionAttributes
    );

    /**
     * Get inviteCode
     * @return string|null
     */
    public function getInviteCode();

    /**
     * Set inviteCode
     * @param string $inviteCode
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setInviteCode($inviteCode);
    /**
     * Get usedBy
     * @return string|null
     */
    public function getUsedBy();

    /**
     * Set usedBy
     * @param string $usedBy
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setUsedBy($usedBy);

    /**
     * Get isUsed
     * @return string|null
     */
    public function getisUsed();

    /**
     * Set isUsed
     * @param string $isUsed
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setisUsed($isUsed);
   
    /**
     * Get created_by
     * @return string|null
     */
    public function getCreatedBy();

    /**
     * Set created_by
     * @param string $createdBy
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setCreatedBy($createdBy);

    /**
     * Get updated_by
     * @return string|null
     */
    public function getUpdatedBy();

    /**
     * Set updated_by
     * @param string $updatedBy
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setUpdatedBy($updatedBy);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_active
     * @return bool|null
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param bool $isActive
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setIsActive($isActive);

     /**
      * Get is_delete
      * @return bool|null
      */
    public function getIsDelete();

    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     */
    public function setIsDelete($isDelete);
}
