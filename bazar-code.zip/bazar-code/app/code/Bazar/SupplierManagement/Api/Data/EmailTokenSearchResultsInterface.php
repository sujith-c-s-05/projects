<?php

/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

/**
 * Interface EmailTokenSearchResultsInterface
 * @package Bazar\SupplierManagement\Api\Data
 */
interface EmailTokenSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get email tokens
     *
     * @return EmailTokenInterface[]
     */
    public function getItems();

    /**
     * @param EmailTokenInterface[] $items
     *
     * @return $this
     */
    public function setItems(array $items);
}
