<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface InviteRepositoryInterface
{

    /**
     * Retrieve invite
     * @param int $Id
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($Id);

    /**
     * Retrieve invite matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Bazar\SupplierManagement\Api\Data\InviteSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Retrieve supplierId
     * @param int $customerId
     * @param string $inviteCode
     * @return \Bazar\SupplierManagement\Api\Data\InviteInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getVerifyInvite($customerId, $inviteCode);
}
