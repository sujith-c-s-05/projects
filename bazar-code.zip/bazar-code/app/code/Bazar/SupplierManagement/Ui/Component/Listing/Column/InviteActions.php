<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\SupplierManagement\Ui\Component\Listing\Column;

class InviteActions extends \Magento\Ui\Component\Listing\Columns\Column
{

    const URL_PATH_EDIT = 'bazar_supplier/invite/edit';
    const URL_PATH_DELETE = 'bazar_supplier/invite/delete';
    const URL_PATH_DETAILS = 'bazar_supplier/invite/details';
    protected $urlBuilder;

    /**
     * @param \Magento\Framework\View\Element\UiComponent\ContextInterface $context
     * @param \Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\UiComponent\ContextInterface $context,
        \Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory,
        \Magento\Framework\UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                if (isset($item['invite_id'])) {
                    $deleteStatus = $item['is_delete'];
                    $isUsed = $item['is_used'];
                    if ($isUsed!='Used') {
                        
                        $item[$this->getData('name')]['edit'] = [
                            
                            'href' => $this->urlBuilder->getUrl(
                                static::URL_PATH_EDIT,
                                [
                                    'invite_id' => $item['invite_id']
                                ]
                            ),
                            'label' => __('Edit')
                            
                        ];
                        
                    }
                    if ($deleteStatus !=1) {
                        $item[$this->getData('name')]['delete'] = [
                        'href' => $this->urlBuilder->getUrl(
                            static::URL_PATH_DELETE,
                            [
                                'invite_id' => $item['invite_id']
                            ]
                        ),
                        'label' => __('Delete'),
                        'confirm' => [
                            'title' => __('Delete Invite Code ?'),
                            'message' => __('Are you sure you want to delete the '.$item['invite_code'].'?')
                        ]

                                ];
                        
                    }
                }
            }
        }
        
        return $dataSource;
    }
}
