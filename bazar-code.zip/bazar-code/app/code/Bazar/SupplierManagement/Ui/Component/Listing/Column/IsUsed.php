<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace  Bazar\SupplierManagement\Ui\Component\Listing\Column;

class IsUsed extends \Magento\Ui\Component\Listing\Columns\Column
{
    protected $urlBuilder;

    /**
     * @param \Magento\Framework\View\Element\UiComponent\ContextInterface $context
     * @param \Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\UiComponent\ContextInterface $context,
        \Magento\Framework\View\Element\UiComponentFactory $uiComponentFactory,
        \Magento\Framework\UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {
                if (isset($item['invite_id'])) {

                    $isUsed= $item['is_used'];

                    if ($isUsed == 0) {
                        $statusLabel = "Unused";
                    } else {
                        $statusLabel = "Used";
                       
                    }

                    if ($statusLabel != null) {
                        $item[$this->getData('name')] = $statusLabel;
                    }
                }
            }
        }
        
        return $dataSource;
    }
}
