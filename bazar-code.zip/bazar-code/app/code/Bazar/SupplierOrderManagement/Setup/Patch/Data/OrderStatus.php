<?php
namespace Bazar\SupplierOrderManagement\Setup\Patch\Data;

use Magento\Framework\Setup\Patch\DataPatchInterface;
use Magento\Framework\Setup\Patch\PatchVersionInterface;

class OrderStatus implements DataPatchInterface
{
    /**
     * @var \Magento\Framework\Setup\ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    public function __construct(
        \Magento\Framework\Setup\ModuleDataSetupInterface $moduleDataSetup
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
    }

    /**
     * {@inheritdoc}
     */
    public function apply()
    {
        // Insert statuses
        // use insertOnDuplicate(), insertArray() etc here
        $this->moduleDataSetup->getConnection()->insertMultiple(
            $this->moduleDataSetup->getTable('sales_order_status'),
            [
                ['status' => 'unfulfilled', 'label' => 'Unfulfilled'],
                ['status' => 'shipped', 'label' => 'Shipped'],
                ['status' => 'delivered', 'label' => 'Delivered']
            ]
        );

        //Bind status to state
        $states = [
            [
                'status'     => 'unfulfilled',
                'state'      => 'processing',
                'is_default' => 0,
            ],
            [
                'status'     => 'shipped',
                'state'      => 'complete',
                'is_default' => 0,
            ],
            [
                'status'     => 'delivered',
                'state'      => 'closed',
                'is_default' => 0,
            ],

        ];
        foreach ($states as $state) {
            $this->moduleDataSetup->getConnection()->insertOnDuplicate(
                $this->moduleDataSetup->getTable('sales_order_status_state'),
                $state
            );
        }
    }

    /**
     * {@inheritdoc}
     */
    public static function getDependencies()
    {
        return [];
    }

    /**
     * {@inheritdoc}
     */
    public function getAliases()
    {
        return [];
    }

    
}
