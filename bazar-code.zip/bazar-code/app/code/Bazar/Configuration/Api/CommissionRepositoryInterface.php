<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\Configuration\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface CommissionRepositoryInterface
{
    /**
     * Retrieve commissiondetails
     * @throws \Magento\Framework\Exception\LocalizedException
     * @return void
     */
    public function getCommission();
}