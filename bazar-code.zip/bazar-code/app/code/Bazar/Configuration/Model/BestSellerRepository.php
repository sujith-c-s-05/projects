<?php

namespace Bazar\Configuration\Model;

use Bazar\Configuration\Api\BestSellerRepositoryInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;

class BestSellerRepository implements BestSellerRepositoryInterface
{
    

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
      * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
      */
    public function __construct(
        ScopeConfigInterface $scopeConfig
    ) {
        $this->scopeConfig = $scopeConfig;
    }

    public function getBestSellerCount()
    {
        
        $bestSellerCount=$this->scopeConfig->getValue(
            'product_catalog_config/bestSeller/bestSellerProducts_number',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

        $count=[];
        $count['bestSellerProducts_number']=$bestSellerCount;
        return json_encode($count);
    }
}