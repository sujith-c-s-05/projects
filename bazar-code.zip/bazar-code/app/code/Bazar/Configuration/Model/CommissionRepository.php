<?php

namespace Bazar\Configuration\Model;

use Bazar\Configuration\Api\CommissionRepositoryInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;

class CommissionRepository implements CommissionRepositoryInterface
{
    

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
      * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
      */
    public function __construct(
        ScopeConfigInterface $scopeConfig
    ) {
        $this->scopeConfig = $scopeConfig;
    }

    public function getCommission()
    {
        
        $enable=$this->scopeConfig->getValue(
            'commission/general/bazar_commission_enable',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $bazarcommission=$this->scopeConfig->getValue(
            'commission/general/bazar_commission',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
        $sellercommission=$this->scopeConfig->getValue(
            'commission/general/seller_commission',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

        $result=[];
        $result['bazar_commission_enable']=$enable;
        $result['bazar_commission']=$bazarcommission;
        $result['seller_commission']=$sellercommission;
        

        return json_encode($result);
    }
}