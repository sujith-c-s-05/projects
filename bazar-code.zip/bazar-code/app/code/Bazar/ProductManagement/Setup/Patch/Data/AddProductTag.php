<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */


namespace Bazar\ProductManagement\Setup\Patch\Data;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;

/**
 * Class CreateCustomAttr for Create Custom Product Attribute using Data Patch.
 */
class AddProductTag implements DataPatchInterface
{

    /**
     * ModuleDataSetupInterface
     *
     * @var ModuleDataSetupInterface
     */
    private $moduleDataSetup;

    /**
     * EavSetupFactory
     *
     * @var EavSetupFactory
     */
    private $eavSetupFactory;

    /**
     * @param ModuleDataSetupInterface $moduleDataSetup
     * @param EavSetupFactory          $eavSetupFactory
     */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        EavSetupFactory $eavSetupFactory
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->eavSetupFactory = $eavSetupFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function apply()
    {
        /** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $this->moduleDataSetup]);

        $eavSetup->addAttribute(\Magento\Catalog\Model\Product::ENTITY, 'product_tag', [
            'group' => 'General',
            'type' => 'text',
            'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
            'frontend' => '',
            'label' => 'Product Tag',
            'input' => 'multiselect',
            'class' => '',
            'option' => ['values' => 
                                [
                                    '1' => 'Minimalist',
                                    '2' => 'Chic',
                                    '3' => 'Funky',
                                    '4' => 'Retro',
                                    '5' => 'Cozy',
                                    '6' => 'Summer',
                                    '7' => 'Fall',
                                    '8' => 'Spring',
                                    '9' => 'Winter',
                                    '10' => 'Rustic',
                                    '11' => 'Gen Z',
                                    '12' => 'Y2K',
                                    '13' => 'Modern',
                                    '14' => 'Floral',
                                    '15' => 'Sophisticated',
                                    '16' => 'Luxury',
                                    '17' => 'Urban',
                                    '18' => 'Country',
                                    '19' => 'Homemade',
                                    '20' => 'Local',
                                    '21' => 'Family',
                                    '22' => 'Bohomien',
                                    '23' => 'Midcentury Modern',
                                    '24' => 'Sporty',
                                    '25' => 'Natural',
                                    '26' => 'Clean',
                                    '27' => 'Contemporary',
                                    '28' => 'Bright',
                                    '29' => 'Pastel',
                                    '30' => 'Cute',
                                    '31' => 'Party',
                                    '32' => 'Fun',
                                    '33' => 'Silly',
                                    '34' => 'Traditional',
                                    '35' => 'Trendy',
                                    '36' => 'Artisanal',
                                    '37' => 'Classic',
                                    '38' => 'Beach',
                                    '39' => 'Country',
                                    '40' => 'Urban',
                                    '41' => 'Indie',
                                    '42' => 'Eco-friendly',
                                    '43' => 'New',
                                    '44' => 'Women-owned',
                                    '45' => 'Healthy',
                                    '46' => 'Unique',
                                    '47' => 'Not on Amazon',
                                    '48' => 'Made in USA'
                                ],
                            ],
            'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
            'visible' => true,
            'required' => false,
            'user_defined' => true,
            'searchable' => true,
            'filterable' => true,
            'comparable' => true,
            'visible_on_front' => true,
            'used_in_product_listing' => true,
            'use_in_filter_options' => true,
            'add_to_column_options' => true
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public static function getDependencies()
    {
        return [];
    }

    /**
     * {@inheritdoc}
     */
    public function getAliases()
    {
        return [];
    }
}