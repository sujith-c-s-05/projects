<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Bazar\ProductManagement\Api;

/**
 * Interface multi seller product handling interface
 * @api
 * @since 100.0.2
 */
interface SupplierProductRepositoryInterface
{
    
     /**
     * Save Supplier product
     *
     * @param \Bazar\ProductManagement\Api\Data\SupplierProductInterface $SupplierProduct
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductInterface
     */
    public function save(\Bazar\ProductManagement\Api\Data\SupplierProductInterface $SupplierProduct);


     /**
     *Get details from Supplier product Table
     *
     * @param [type] $productId
     * @param [type] $supplierId
     * @return void
     */
    public function getSupplierProductByProductIdAndSellerId($productId,$supplierId);



    /**
     * Delete Product of a supplier by Id
     * @param int $supplierId
     * @param int $productId
     * @return bool
     */
    public function deleteProductById($supplierId, $productId);

    /**
     * Retrieve Product
     * @param int $Id
     * @return  \Bazar\ProductManagement\Api\Data\SupplierProductInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($Id);

    /**
     * Retrieve Product matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return  \Bazar\ProductManagement\Api\Data\SupplierProductSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * update Product of a supplier by Id
     * @param int $supplierId
     * @param int $productId
     * @return bool
     */
    public function updateProductById($supplierId, $productId);

     /**
     * Get Product Count
     * @return Bazar\ProductManagement\Api\Data\ProductCountInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */

    public function getProductCount();

    /**
    * Delete Product by ID
    * @api
    * @param int[] $Id
    * @return bool Will return True if deleted.
    * @throws \Magento\Framework\Exception\NoSuchEntityException
    * @throws \Magento\Framework\Exception\LocalizedException
    * @throws \Magento\Framework\Exception\CouldNotDeleteException
    */
    public function deleteProductByIds(array $Id);

    /**
    * Delete Product by ID
    * @api
    * @param int[] $Id
    * @return bool Will return True if deleted.
    * @throws \Magento\Framework\Exception\NoSuchEntityException
    * @throws \Magento\Framework\Exception\LocalizedException
    * @throws \Magento\Framework\Exception\CouldNotDeleteException
    */
    public function archiveProductByIds(array $Id);

        /**
    * Delete Product by ID
    * @api
    * @param int[] $Id
    * @return bool Will return True if deleted.
    * @throws \Magento\Framework\Exception\NoSuchEntityException
    * @throws \Magento\Framework\Exception\LocalizedException
    * @throws \Magento\Framework\Exception\CouldNotDeleteException
    */
    public function activeProductByIds(array $Id);

        /**
    * Delete Product by ID
    * @api
    * @param int[] $Id
    * @return bool Will return True if deleted.
    * @throws \Magento\Framework\Exception\NoSuchEntityException
    * @throws \Magento\Framework\Exception\LocalizedException
    * @throws \Magento\Framework\Exception\CouldNotDeleteException
    */
    public function draftProductByIds(array $Id);
   
}
