<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\ProductManagement\Api\Data;

interface SupplierProductSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get SupplierProduct list.
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductInterface[]
     */
    public function getItems();

    /**
     * Set SupplierProduct list.
     * @param \Bazar\ProductManagement\Api\Data\SupplierProductInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
