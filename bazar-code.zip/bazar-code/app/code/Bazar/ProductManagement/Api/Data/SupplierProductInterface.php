<?php
 
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */


 
namespace Bazar\ProductManagement\Api\Data;
/**
 * @api
 * @since 100.0.2
 */
 
interface SupplierProductInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
 
    const ID = 'id';
    const SUPPLIER_ID = 'supplier_id';
    const PRODUCT_ID = 'product_id';
    const IS_ACTIVE = 'is_active';
    const IS_DELETE = 'is_delete';
    
    /**
     * Get id
     * @return int|null
     */
    public function getId();
 
    /**
     * Set id
     * @param int $Id
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductInterface
     */
    public function setId($Id);
 
    /**
     * Get supplier user id
     * @return int|null
     */
    public function getSupplierId();
 
    /**
     * Set supplier user id
     * @param int $supplierId
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductInterface
     */
    public function setSupplierId($supplierId);
 
    /**
     * Get product_id
     * @return int|null
     */
    public function getProductId();
 
    /**
     * Set product id
     * @param int $productId
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductInterface
     */
    public function setProductId($productId);
 
    /**
     * Get is_active
     * @return bool
     */
    public function getIsActive();
 
    /**
     * Set is_active
     * @param bool $isActive
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductInterface
     */
    public function setIsActive($isActive);
 
    /**
     * Get is_delete
     * @return bool
     */
    public function getIsDelete();
 
    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductInterface
     */
    public function setIsDelete($isDelete);
 
    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Bazar\ProductManagement\Api\Data\SupplierProductExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Bazar\ProductManagement\Api\Data\SupplierProductExtensionInterface $extensionAttributes
    );
}
