<?php
 
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */


 
namespace Bazar\ProductManagement\Api\Data;
/**
 * @api
 * @since 100.0.2
 */

/**
 * Interface which represents associative array item.
 */
 
interface ProductCountInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
 
    const TOTAL_COUNT = 'total_count';
    const ACTIVE_COUNT = 'active_count';
    const DRAFT_COUNT = 'draft_count';
    const ARCHIVE_COUNT = 'archive_count';
    const OUT_OF_STOCK = 'out_of_stock_count';
   /**
     * Get total_count
     * @return int|null
     */
    public function getTotalCount();
 
    /**
     * Set total_count
     * @param int $totalCount
     * @return \Bazar\ProductManagement\Api\Data\ProductCountInterface
     */
    public function setTotalCount($totalCount);

    /**
     * Get active_count
     * @return int|null
     */
    public function getActiveCount();
 
    /**
     * Set active_count
     * @param int $activeCount
     * @return \Bazar\ProductManagement\Api\Data\ProductCountInterface
     */
    public function setActiveCount($activeCount);

    /**
     * Get draft_count
     * @return int|null
     */
    public function getDraftCount();
 
    /**
     * Set draft_count
     * @param int $draftCount
     * @return \Bazar\ProductManagement\Api\Data\ProductCountInterface
     */
    public function setDraftCount($draftCount);

    /**
     * Get archive_count
     * @return int|null
     */
    public function getArchiveCount();
 
    /**
     * Set archive_count
     * @param int $archiveCount
     * @return \Bazar\ProductManagement\Api\Data\ProductCountInterface
     */
    public function setArchiveCount($archiveCount);

    /**
     * Get out_of_stock_count
     * @return int|null
     */
    public function getOutOfStockCount();
 
    /**
     * Set out_of_stock_count
     * @param int $outOfStockCount
     * @return \Bazar\ProductManagement\Api\Data\ProductCountInterface
     */
    public function setOutOfStockCount($outOfStockCount);

}