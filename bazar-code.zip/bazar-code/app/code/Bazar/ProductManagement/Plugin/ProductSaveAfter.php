<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Bazar\ProductManagement\Plugin;

use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Catalog\Api\Data\ProductInterface;

/**
 * Class ProductSaveAfter
 */
class ProductSaveAfter 
{
    /**
     * @var \Bazar\ProductManagement\Api\SupplierProductRepositoryInterface
     */
    protected $supplierProductRepositoryInterface;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * ProductSaveAfter constructor.
     * @param \Bazar\ProductManagement\Api\SupplierProductRepositoryInterface $SupplierProductRepositoryInterface
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    public function __construct(
        \Bazar\ProductManagement\Api\SupplierProductRepositoryInterface $SupplierProductRepositoryInterface,
        \Magento\Store\Model\StoreManagerInterface $storeManager
      
    ) {
        $this->supplierProductRepositoryInterface = $SupplierProductRepositoryInterface;
        $this->_storeManager = $storeManager;
      }

   /**
    * after save function
    *
    * @param \Magento\Catalog\Api\ProductRepositoryInterface $subject
    * @param \Magento\Catalog\Api\Data\ProductInterface $_product
    * @return void
    */
    public function afterSave(\Magento\Catalog\Api\ProductRepositoryInterface $subject,
    \Magento\Catalog\Api\Data\ProductInterface $_product)
    {
        $currentWebsiteId = $this->_storeManager->getStore()->getWebsiteId();
        //$_product = $observer->getProduct();  // you will get product object
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $supplierProductObject = $objectManager->create('Bazar\ProductManagement\Model\SupplierProduct');

        try {
           
            $prod = $supplierProductObject->load($_product->getEntityId(),'product_id');
            if($prod->getId()){
                $prod->setSupplierId($_product->getSupplierId());
            }
            else{
                $prod->setProductId($_product->getEntityId())
                ->setSupplierId($_product->getSupplierId());
                if(is_numeric($_product->getSupplierId()))
                {
                    $supplierProduct = $prod->save();
                }
            }

            return $_product; 
           
        } catch (CouldNotSaveException $e) {
            echo $e->getMessage();
        }
    }
}
