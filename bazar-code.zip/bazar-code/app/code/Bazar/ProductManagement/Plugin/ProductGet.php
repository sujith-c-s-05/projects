<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Bazar\ProductManagement\Plugin;

use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Bazar\SupplierManagement\Api\SupplierRepositoryInterface;
use Bazar\ProductManagement\Api\SupplierProductRepositoryInterface;
use Bazar\ProductManagement\Model\ResourceModel\SupplierProduct\CollectionFactory as
SupplierProductCollectionFactory;
class ProductGet
{
    /**
     * @var \Magento\Catalog\Api\CategoryRepositoryInterface
     */
    protected $categoryRepository;

    /**
     * @var \Magento\Eav\Model\Config
     */
    protected $eavConfig;

    /**
     * @var Bazar\SupplierManagement\Api\SupplierRepositoryInterface
     */
    protected $supplierRepositoryInterface;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var \Bazar\ProductManagement\Api\SupplierProductRepositoryInterface 
     */
    protected $supplierProductRepositoryInterface;

    protected $_productCollectionFactory;

    protected $supplierProductCollectionFactory;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;
    /**
     * constructor for search product function
     * @param \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository
     * @param \Magento\Eav\Model\Config $eavConfig
     * @param Bazar\SupplierManagement\Api\SupplierRepositoryInterface $supplierRepositoryInterface
     * @param \Magento\Catalog\Api\ProductRepositoryInterface
     * @param \Bazar\ProductManagement\Api\SupplierProductRepositoryInterface $supplierProductRepositoryInterface
     * @param SupplierProductCollectionFactory $supplierProductCollectionFactory
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     */

    public function __construct(
        \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository,
        \Magento\Catalog\Model\Category $categoryFactory,
        \Magento\Eav\Model\Config $eavConfig,
        SupplierRepositoryInterface $supplierRepositoryInterface,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        SupplierProductRepositoryInterface $supplierProductRepositoryInterface,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        SupplierProductCollectionFactory $supplierProductCollectionFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager

    )
    {
        $this->categoryRepository = $categoryRepository;
        $this->_categoryFactory = $categoryFactory;
        $this->eavConfig = $eavConfig;
        $this->supplierRepositoryInterface = $supplierRepositoryInterface;
        $this->productRepositoryInterface = $productRepositoryInterface;
        $this->supplierProductRepositoryInterface = $supplierProductRepositoryInterface;
        $this->_productCollectionFactory = $productCollectionFactory;   
        $this->supplierProductCollectionFactory = $supplierProductCollectionFactory;
        $this->storeManager = $storeManager;
    }

    /**
     * Get product
     *
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $subject
     * @param \Magento\Catalog\Api\Data\ProductInterface $product
     * @return void
     */
    public function afterGet
    (
        \Magento\Catalog\Api\ProductRepositoryInterface $subject,
        \Magento\Catalog\Api\Data\ProductInterface $product
    ) 
    {
        $childSku=[];
        $extensionattributes = $product->getExtensionAttributes(); /** get current extension attributes from entity **/
        $supplierId=$product->getResource()->getAttributeRawValue($product->getId(),'supplier_id',$product->getStore()->getWebsiteId());

         //Get supplier name
         if(is_numeric($supplierId))
         {
             try{
             $supplierDetails = $this->supplierRepositoryInterface->get($supplierId);
             $supplierName= $supplierDetails->getCompanyName();
             }
             catch(\Exception $exception)
             {
                 $supplierName=null;
             }

         }   

        //Get category names
        $categoryNames=array();
        foreach ($product->getCategoryIds() as $categoryId) {
            array_push($categoryNames,$this->getCategoryNameById($categoryId));
        }

        //Get subcategory names
        $subcategoryName=array();
        foreach ($product->getCategoryIds() as $categoryId) {
            array_push($subcategoryName,$this->getSubCategoryNameById($categoryId));
            $subcategoryNames = json_encode($subcategoryName,true);
        }

         //Get eav attribute names
        
         $color=$product->getResource()->getAttributeRawValue($product->getId(),'color',$product->getStore()->getWebsiteId());
         if(!empty($color)) {
 
                  $attribute = $this->eavConfig->getAttribute('catalog_product', 'color');
                  $colorName = $attribute->getSource()->getOptionText($color);            
         } 

         $size=$product->getResource()->getAttributeRawValue($product->getId(),'size',$product->getStore()->getWebsiteId());
         if(!empty($size)) {
 
                  $attribute = $this->eavConfig->getAttribute('catalog_product', 'size');
                  $sizeName = $attribute->getSource()->getOptionText($size);            
         } 

         //configurable product info
         $productType = $product->getTypeId();
        if($productType=='configurable')
        {
            $_children = $product->getTypeInstance()->getUsedProducts($product);
            foreach ($_children as $child){
                $child=$child->getID();
                $childDetail=$product->getResource()->getAttributeRawValue($child,'sku',$product->getStore()->getWebsiteId());
                $childsku =$childDetail['sku'];
                array_push($childSku,$childsku);
            }
        }

        $productEntity=$this->productRepositoryInterface->getById($product->getId());
       
            $stockItem = $productEntity->getExtensionAttributes()->getStockItem();
            $isInStock=$stockItem->getIsInStock();
            $quantity =$stockItem->getQty();

            if($isInStock==true)
            {
                $stock=1;
            }
            else
            {
                $stock=0;
            }
        
        $supplierProduct=$this->supplierProductRepositoryInterface->getSupplierProductByProductIdAndSellerId($product->getId(), $supplierId);
        $isDelete=$supplierProduct->getIsDelete();

        if($isDelete==1)
        {
            $productStatus='archive';
        }
        $status = $product->getStatus();
        if($status==1)
        {
            $productStatus='active';
        }
        if($status==0)
        {
            $productStatus='draft';
        }
        $payout=100;
       
       
        $productimages = $product->getMediaGalleryImages();
        $images=[];
        foreach($productimages as $productimage)
        {
            $image= $productimage['url'];
            $images[] = $image;
        }

        //adding extentions
        $extensionattributes->setProductcatagoryName($categoryNames??'');
        $extensionattributes->setProductSubcatagoryName($subcategoryNames??[]);
        $extensionattributes->setColor($colorName??'');
        $extensionattributes->setSize($sizeName??'');
        $extensionattributes->setSupplierName($supplierName??'');
        $extensionattributes->setChildSku($childSku??'');
        $extensionattributes->setStockStatus($stock??'');
        $extensionattributes->setIsArchivedProduct($isDelete??'');
        $extensionattributes->setProductStatus($productStatus??'');
        $extensionattributes->setQuantity($quantity??'');
        $extensionattributes->setPayout($payout??'');
        $extensionattributes->setProductUrl($images??'');

        $product->setExtensionAttributes($extensionattributes);
        return $product;
    }

    /**
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $subject
     * @param \Magento\Catalog\Model\ResourceModel\Product\Collection $products
     * @return \Magento\Catalog\Model\ResourceModel\Product\Collection
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function afterGetList(
        \Magento\Catalog\Api\ProductRepositoryInterface $subject,
        $products
    ) {
        $productList=$products->getItems();

        $activeProductCollection = $this->_productCollectionFactory->create();
        $activeProductCollection->addFieldToFilter('status',1);
        $activeCount=count($activeProductCollection);
        $draftProductCollection = $this->_productCollectionFactory->create();
        $draftProductCollection->addFieldToFilter('status',0);
        $draftCount=count($draftProductCollection);
        $ArchiveProductCollection = $this->supplierProductCollectionFactory->create();
        $ArchiveProductCollection->addFieldToFilter('is_delete',1);
        $archiveCount=count($ArchiveProductCollection);

        foreach ($products->getItems() as $key => $product) {
        $extensionattributes = $product->getExtensionAttributes();
        $supplierId=$product->getResource()->getAttributeRawValue($product->getId(),'supplier_id',$product->getStore()->getWebsiteId());

            //Get category names
            $categoryNames=array();
            foreach ($product->getCategoryIds() as $categoryId) {
                array_push($categoryNames,$this->getCategoryNameById($categoryId));
            }

            //Get supplier name
            if(is_numeric($supplierId))
            {
                try{
                $supplierDetails = $this->supplierRepositoryInterface->get($supplierId);
                $supplierName= $supplierDetails->getCompanyName();
                }
                catch(\Exception $exception)
                {
                    $supplierName=null;
                }

            }   
            //configurable product info
            $productType = $product->getTypeId();
            $productEntity=$this->productRepositoryInterface->getById($product->getId());
         
                $stockItem = $productEntity->getExtensionAttributes()->getStockItem();
                $isInStock=$stockItem->getIsInStock();
                $quantity =$stockItem->getQty();
                if($isInStock==true)
                {
                    $stock=1;
                }
                else
                {
                        $stock=0;
                }
            
            $supplierProduct=$this->supplierProductRepositoryInterface->getSupplierProductByProductIdAndSellerId($product->getId(), $supplierId);
            $isDelete=$supplierProduct->getIsDelete();
            if($isDelete==1)
            {
                $productStatus='archive';
            }
            $status = $product->getStatus();
            if($status==1)
            {
                $productStatus='active';
            }
            if($status==0)
            {
                $productStatus='draft';
            }
            $payout=100;

            $productimages = $product->getMediaGalleryImages();
            $images=[];
            foreach($productimages as $productimage)
            {
                $image= $productimage['url'];
                $images[] = $image;
            }
        $extensionattributes->setProductcatagoryName($categoryNames??'');
        $extensionattributes->setSupplierName($supplierName??'');
        $extensionattributes->setStockStatus($stock??'');
        $extensionattributes->setIsArchivedProduct($isDelete??'');
        $extensionattributes->setActiveCount($activeCount??'');
        $extensionattributes->setDraftCount($draftCount??'');
        $extensionattributes->setArchiveCount($archiveCount??'');
        $extensionattributes->setProductStatus($productStatus??'');
        $extensionattributes->setQuantity($quantity??'');
        $extensionattributes->setPayout($payout??'');
        $extensionattributes->setProductUrl($images??'');

        $product->setExtensionAttributes($extensionattributes);
        }
        $products->setItems($productList);
        return $products;
    }

     /**
     * @param int $id
     * @param null $storeId
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getCategoryNameById($id, $storeId = null)
    {
        $categoryInstance = $this->categoryRepository->get($id, $storeId);
        return $categoryInstance->getName();
    }

    protected function getSubCategoryNameById($categoryId)
    {
         $catagory = $this->_categoryFactory->load($categoryId);
         $subcatagory = $catagory->getChildren();
         $subcategories = array();
         foreach(explode(',',$subcatagory) as $subCatagoryid){
         $_subCategory = $this->_categoryFactory->load($subCatagoryid);
         if($_subCategory->getIsActive()) {
            $subcategories = array('id'=>$_subCategory->getId(),'name'=>$_subCategory->getName()); 
            
         }

        }
        return $subcategories; 

    }

  
}