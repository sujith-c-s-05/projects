<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Bazar\ProductManagement\Plugin;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Bazar\ProductManagement\Api\SupplierProductRepositoryInterface;

class ConfigChildGet
{

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepositoryInterface;

    protected $linkManagementInterface;

    /**
     * @var \Magento\Eav\Model\Config
     */
    protected $eavConfig;

    /**
     * @var \Magento\Catalog\Api\CategoryRepositoryInterface
     */
    protected $categoryRepository;

    /**
     * @var \Bazar\ProductManagement\Api\SupplierProductRepositoryInterface 
     */
    protected $supplierProductRepositoryInterface;

    protected $_storeManager;

     /**
     * constructor for search product function
     * @param \Magento\Catalog\Api\ProductRepositoryInterface
     * @param \Magento\ConfigurableProduct\Api\LinkManagementInterface 
     * @param \Magento\Eav\Model\Config $eavConfig
     * @param \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository
     * @param \Bazar\ProductManagement\Api\SupplierProductRepositoryInterface $supplierProductRepositoryInterface
     */
    public function __construct(
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        \Magento\ConfigurableProduct\Api\LinkManagementInterface $linkManagementInterface,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository,
        \Magento\Catalog\Model\Category $categoryFactory,
        SupplierProductRepositoryInterface $supplierProductRepositoryInterface,
        \Magento\Store\Model\StoreManagerInterface $storemanager
    )
    {
        $this->productRepositoryInterface = $productRepositoryInterface;
        $this->linkManagementInterface = $linkManagementInterface;
        $this->eavConfig = $eavConfig;
        $this->categoryRepository = $categoryRepository;
        $this->_categoryFactory = $categoryFactory;
        $this->supplierProductRepositoryInterface = $supplierProductRepositoryInterface;
        $this->_storeManager =  $storemanager;

    }
    /**
     * Get product
     *
     * @param \Magento\ConfigurableProduct\Api\LinkManagementInterface $subject
     * @param \Magento\Catalog\Api\Data\ProductInterface $product
     * @return void
     */
    public function afterGetChildren
    (
        \Magento\ConfigurableProduct\Api\LinkManagementInterface $subject,
        $product
    ) 
    {
        foreach ($product as $key => $productkey) {
        $sku = $productkey->getSku();
        $extensionattributes = $productkey->getExtensionAttributes(); /** get current extension attributes from entity **/
        $supplierId=$productkey->getResource()->getAttributeRawValue($productkey->getId(),'supplier_id',$productkey->getStore()->getWebsiteId());

        //Get eav attribute names
        
         $color=$productkey->getResource()->getAttributeRawValue($productkey->getId(),'color',$productkey->getStore()->getWebsiteId());
         if(!empty($color)) {
 
                  $attribute = $this->eavConfig->getAttribute('catalog_product', 'color');
                  $colorName = $attribute->getSource()->getOptionText($color);            
         } 

         $size=$productkey->getResource()->getAttributeRawValue($productkey->getId(),'size',$productkey->getStore()->getWebsiteId());
         if(!empty($size)) {
 
                  $attribute = $this->eavConfig->getAttribute('catalog_product', 'size');
                  $sizeName = $attribute->getSource()->getOptionText($size);            
         }

          //Get category names
        $categoryNames=array();
        foreach ($productkey->getCategoryIds() as $categoryId) {
            array_push($categoryNames,$this->getCategoryNameById($categoryId));
        }

        //Get subcategory names
        $subcategoryName=array();
        foreach ($productkey->getCategoryIds() as $categoryId) {
            array_push($subcategoryName,$this->getSubCategoryNameById($categoryId));
            $subcategoryNames = json_encode($subcategoryName,true);
        }

        $productDetail =  $this->productRepositoryInterface->get($sku);
        $productimages = $productDetail->getMediaGalleryImages();
        $productMedia=$productDetail->getMediaGalleryEntries();
        $mediaCount =[];
        foreach($productMedia as $media)
        {
            $mediaCount[]=$media->getData();
        }
        $mediaValue= json_encode($mediaCount,true);
        $images=[];
        foreach($productimages as $productimage)
        {
            $image= $productimage['url'];
            $images[] = $image;
        }
       
        $categoryLinks = $productDetail->getExtensionAttributes()->getCategoryLinks();
        $LinkCount =[];
        foreach($categoryLinks as $link)
        {
            $LinkCount[]=$link->getData();
        }
        $linkValue= json_encode($LinkCount,true);

        $productEntity=$this->productRepositoryInterface->getById($productkey->getId());
       
        $stockItem = $productEntity->getExtensionAttributes()->getStockItem();
        $isInStock=$stockItem->getIsInStock();
        $quantity =$stockItem->getQty();

        if($isInStock==true)
        {
            $stock=1;
        }
        else
        {
            $stock=0;
        }

        $supplierProduct=$this->supplierProductRepositoryInterface->getSupplierProductByProductIdAndSellerId($productkey->getId(), $supplierId);
        $isDelete=$supplierProduct->getIsDelete();

        if($isDelete==1)
        {
            $productStatus='archive';
        }
        $status = $productkey->getStatus();
        if($status==1)
        {
            $productStatus='active';
        }
        if($status==0)
        {
            $productStatus='draft';
        }
        $payout=100;

         $extensionattributes->setColor($colorName??'');
         $extensionattributes->setSize($sizeName??''); 
         $extensionattributes->setProductcatagoryName($categoryNames??'');
         $extensionattributes->setProductSubcatagoryName($subcategoryNames??[]);
         $extensionattributes->setProductUrl($images??'');
         $extensionattributes->setStockStatus($stock??'');
         $extensionattributes->setIsArchivedProduct($isDelete??'');
         $extensionattributes->setProductStatus($productStatus??'');
         $extensionattributes->setQuantity($quantity??'');
         $extensionattributes->setProductMedia($mediaValue??'');
         $extensionattributes->setPayout($payout??'');
         $extensionattributes->setCatagoryLink($linkValue??'');
         $productkey->setExtensionAttributes($extensionattributes);

    }
    return $product;

}

 /**
     * @param int $id
     * @param null $storeId
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getCategoryNameById($id, $storeId = null)
    {
        $categoryInstance = $this->categoryRepository->get($id, $storeId);
        return $categoryInstance->getName();
    }

    protected function getSubCategoryNameById($categoryId)
    {
         $catagory = $this->_categoryFactory->load($categoryId);
         $subcatagory = $catagory->getChildren();
         $subcategories = array();
         foreach(explode(',',$subcatagory) as $subCatagoryid){
         $_subCategory = $this->_categoryFactory->load($subCatagoryid);
         if($_subCategory->getIsActive()) {
            $subcategories = array('id'=>$_subCategory->getId(),'name'=>$_subCategory->getName()); 
            
         }

        }
        return $subcategories; 

    }
}