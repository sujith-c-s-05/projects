<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Bazar\ProductManagement\Plugin;


use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\App\Config\ScopeConfigInterface;

/**
 * Class ProductSaveBefore
 */
class ProductSaveBefore 
{
       
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    
    /**
     * @var \Magento\Eav\Model\Config
     */
    protected $eavConfig;


    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface 
     */
    protected $productRepositoryInterface;
    private $logger;

    protected $_productCollectionFactory;


    /**
     * constructor function
     *
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Eav\Model\Config $eavConfig
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface
     */

    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        \Psr\Log\LoggerInterface $logger,
        ScopeConfigInterface $scopeConfig,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory

    ) {
        $this->_storeManager = $storeManager;
        $this->eavConfig = $eavConfig;
        $this->productRepositoryInterface=$productRepositoryInterface;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;
        $this->_productCollectionFactory = $productCollectionFactory;   
 
    }

    /**
     * before save function
     *
     * @param \Magento\Catalog\Api\ProductRepositoryInterface $subject
     * @param \Magento\Catalog\Api\Data\ProductInterface $_product
     * @return void
     */
     public function beforeSave(\Magento\Catalog\Api\ProductRepositoryInterface $subject,
    \Magento\Catalog\Api\Data\ProductInterface $_product)
    {
        $productId=$_product->getId();

            //Set images for bulk product import
            if($productId==null||$productId=0){
                $images=$_product->getMediaGalleryEntries();
                $imagePath="";
                if(!empty($images))
                {
                    foreach($images as $key =>$image){
                        $imagePath=$image->getFile();
                        if(isset($imagePath)&&!empty($imagePath)){
                            try{
                                $imageData = file_get_contents($imagePath);
                                if ($image !== false){
                                    $baseContent= base64_encode($imageData??'');
                                    $content=$image->getContent();
                                    $content->setBase64EncodedData($baseContent);
                                    $content->setType('image/jpeg');
                                    $fileName=basename($imagePath);
                                    $content->setName($fileName);
                                }
                            }
                            catch (\Exception $e) {
                                unset($images[$key]);
                            }
                        }
                    }
                }
                
                if(!empty($imagePath)){
                    $_product->setMediaGalleryEntries($images);
                }
            }
    }
}