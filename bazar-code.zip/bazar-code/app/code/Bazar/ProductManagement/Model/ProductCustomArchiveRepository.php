<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Bazar\ProductManagement\Model;



use Magento\Catalog\Api\CategoryLinkManagementInterface;
use Magento\Catalog\Api\Data\ProductExtension;
use Magento\Catalog\Api\Data\ProductInterface;
use Magento\Catalog\Model\Product\Gallery\MimeTypeExtensionMap;
use Magento\Catalog\Model\ProductRepository\MediaGalleryProcessor;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Eav\Model\Entity\Attribute\Exception as AttributeException;
use Magento\Framework\Api\Data\ImageContentInterfaceFactory;
use Magento\Framework\Api\ImageContentValidatorInterface;
use Magento\Framework\Api\ImageProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\DB\Adapter\ConnectionException;
use Magento\Framework\DB\Adapter\DeadlockException;
use Magento\Framework\DB\Adapter\LockWaitException;
use Magento\Framework\EntityManager\Operation\Read\ReadExtensions;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Exception\TemporaryState\CouldNotSaveException as TemporaryCouldNotSaveException;
use Magento\Framework\Exception\ValidatorException;
use Magento\Catalog\Model\Product;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\InventorySalesAdminUi\Model\GetSalableQuantityDataBySku;
use Bazar\SupplierManagement\Api\SupplierRepositoryInterface;
use Bazar\ProductManagement\Api\SupplierProductRepositoryInterface;
use Bazar\ProductManagement\Api\ProductCustomArchiveRepositoryInterface;

/**
 * Product Repository.
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @SuppressWarnings(PHPMD.TooManyFields)
 */
class ProductCustomArchiveRepository extends \Magento\Catalog\Model\ProductRepository implements ProductCustomArchiveRepositoryInterface 
{
    /**
     * @var \Magento\Catalog\Api\ProductCustomOptionRepositoryInterface
     */
    protected $optionRepository;

    /**
     * @var ProductFactory
     */
    protected $productFactory;

    /**
     * @var Product[]
     */
    protected $instances = [];

    /**
     * @var Product[]
     */
    protected $instancesById = [];

    /**
     * @var \Magento\Catalog\Controller\Adminhtml\Product\Initialization\Helper
     */
    protected $initializationHelper;

    /**
     * @var \Magento\Catalog\Api\Data\ProductSearchResultsInterfaceFactory
     */
    protected $searchResultsFactory;

    /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    protected $searchCriteriaBuilder;

    /**
     * @var \Magento\Framework\Api\FilterBuilder
     */
    protected $filterBuilder;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product
     */
    protected $resourceModel;

    /**
     * @var Product\Initialization\Helper\ProductLinks
     */
    protected $linkInitializer;

    /**
     * @var Product\LinkTypeProvider
     */
    protected $linkTypeProvider;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Catalog\Api\ProductAttributeRepositoryInterface
     */
    protected $attributeRepository;

    /**
     * @var \Magento\Catalog\Api\ProductAttributeRepositoryInterface
     */
    protected $metadataService;

    /**
     * @var \Magento\Framework\Api\ExtensibleDataObjectConverter
     */
    protected $extensibleDataObjectConverter;

    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $fileSystem;

    /**
     * @deprecated 103.0.2
     *
     * @var ImageContentInterfaceFactory
     */
    protected $contentFactory;

    /**
     * @deprecated 103.0.2
     *
     * @var ImageProcessorInterface
     */
    protected $imageProcessor;

    /**
     * @var \Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface
     */
    protected $extensionAttributesJoinProcessor;

    /**
     * @deprecated 103.0.2
     *
     * @var \Magento\Catalog\Model\Product\Gallery\Processor
     */
    protected $mediaGalleryProcessor;

    /**
     * @var MediaGalleryProcessor
     */
    private $mediaProcessor;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @var int
     */
    private $cacheLimit = 0;

    /**
     * @var \Magento\Framework\Serialize\Serializer\Json
     */
    private $serializer;

    /**
     * @var ReadExtensions
     */
    private $readExtensions;

    /**
     * @var CategoryLinkManagementInterface
     */
    private $linkManagement;

    protected $multiSellerProductRepository;



    /**
     * @var \Magento\Catalog\Api\CategoryRepositoryInterface
     */
    protected $categoryRepository;


    /**
     * @var \Magento\Eav\Model\Config
     */
    protected $eavConfig;


    /**
     * @var \Magento\Store\Model\App\Emulation
     */
    protected $appEmulation;

    /**
     * @var \Magento\Catalog\Helper\Image
     */
    protected $imageHelper;


     /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    protected $getSalableQuantityDataBySku;

    /**
     * @var Bazar\SupplierManagement\Api\SupplierRepositoryInterface
     */
    protected $supplierRepositoryInterface;

    /**
     * @var \Bazar\ProductManagement\Api\SupplierProductRepositoryInterface 
     */
    protected $supplierProductRepositoryInterface;

    /**
     * ProductRepository constructor.
     * @param ProductFactory $productFactory
     * @param \Magento\Catalog\Controller\Adminhtml\Product\Initialization\Helper $initializationHelper
     * @param \Magento\Catalog\Api\Data\ProductSearchResultsInterfaceFactory $searchResultsFactory
     * @param ResourceModel\Product\CollectionFactory $collectionFactory
     * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder
     * @param \Magento\Catalog\Api\ProductAttributeRepositoryInterface $attributeRepository
     * @param ResourceModel\Product $resourceModel
     * @param Product\Initialization\Helper\ProductLinks $linkInitializer
     * @param Product\LinkTypeProvider $linkTypeProvider
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Api\FilterBuilder $filterBuilder
     * @param \Magento\Catalog\Api\ProductAttributeRepositoryInterface $metadataServiceInterface
     * @param \Magento\Framework\Api\ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param Product\Option\Converter $optionConverter
     * @param \Magento\Framework\Filesystem $fileSystem
     * @param ImageContentValidatorInterface $contentValidator
     * @param ImageContentInterfaceFactory $contentFactory
     * @param MimeTypeExtensionMap $mimeTypeExtensionMap
     * @param ImageProcessorInterface $imageProcessor
     * @param \Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param CollectionProcessorInterface $collectionProcessor [optional]
     * @param \Magento\Framework\Serialize\Serializer\Json|null $serializer
     * @param int $cacheLimit [optional]
     * @param ReadExtensions $readExtensions
     * @param CategoryLinkManagementInterface $linkManagement
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     * @param \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository
     * @param \Magento\Eav\Model\Config $eavConfig
     * @param \Magento\Store\Model\App\Emulation $appEmulation
     * @param Bazar\SupplierManagement\Api\SupplierRepositoryInterface $supplierRepositoryInterface
     * @param \Bazar\ProductManagement\Api\SupplierProductRepositoryInterface $supplierProductRepositoryInterface
     */
    public function __construct(
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Catalog\Controller\Adminhtml\Product\Initialization\Helper $initializationHelper,
        \Magento\Catalog\Api\Data\ProductSearchResultsInterfaceFactory $searchResultsFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $collectionFactory,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteriaBuilder,
        \Magento\Catalog\Api\ProductAttributeRepositoryInterface $attributeRepository,
        \Magento\Catalog\Model\ResourceModel\Product $resourceModel,
        \Magento\Catalog\Model\Product\Initialization\Helper\ProductLinks $linkInitializer,
        \Magento\Catalog\Model\Product\LinkTypeProvider $linkTypeProvider,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Api\FilterBuilder $filterBuilder,
        \Magento\Catalog\Api\ProductAttributeRepositoryInterface $metadataServiceInterface,
        \Magento\Framework\Api\ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        \Magento\Catalog\Model\Product\Option\Converter $optionConverter,
        \Magento\Framework\Filesystem $fileSystem,
        ImageContentValidatorInterface $contentValidator,
        ImageContentInterfaceFactory $contentFactory,
        MimeTypeExtensionMap $mimeTypeExtensionMap,
        ImageProcessorInterface $imageProcessor,
        \Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface $extensionAttributesJoinProcessor,
        CollectionProcessorInterface $collectionProcessor = null,
        \Magento\Framework\Serialize\Serializer\Json $serializer = null,
        $cacheLimit = 1000,
        ReadExtensions $readExtensions = null,
        CategoryLinkManagementInterface $linkManagement = null,
        \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository,
        \Magento\Eav\Model\Config $eavConfig,
        ScopeConfigInterface $scopeConfig,
        \Magento\Store\Model\App\Emulation $appEmulation,
        \Magento\Catalog\Helper\Image $imageHelper,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepositoryInterface,
        GetSalableQuantityDataBySku $getSalableQuantityDataBySku,
        SupplierRepositoryInterface $supplierRepositoryInterface,
        SupplierProductRepositoryInterface $supplierProductRepositoryInterface


    ) {
        $this->productFactory = $productFactory;
        $this->collectionFactory = $collectionFactory;
        $this->initializationHelper = $initializationHelper;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->resourceModel = $resourceModel;
        $this->linkInitializer = $linkInitializer;
        $this->linkTypeProvider = $linkTypeProvider;
        $this->storeManager = $storeManager;
        $this->attributeRepository = $attributeRepository;
        $this->filterBuilder = $filterBuilder;
        $this->metadataService = $metadataServiceInterface;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->fileSystem = $fileSystem;
        $this->contentFactory = $contentFactory;
        $this->imageProcessor = $imageProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->collectionProcessor = $collectionProcessor ?: $this->getCollectionProcessor();
        $this->serializer = $serializer ?: \Magento\Framework\App\ObjectManager::getInstance()
            ->get(\Magento\Framework\Serialize\Serializer\Json::class);
        $this->cacheLimit = (int)$cacheLimit;
        $this->readExtensions = $readExtensions ?: \Magento\Framework\App\ObjectManager::getInstance()
            ->get(ReadExtensions::class);
        $this->linkManagement = $linkManagement ?: \Magento\Framework\App\ObjectManager::getInstance()
            ->get(CategoryLinkManagementInterface::class);
        $this->categoryRepository = $categoryRepository;
        $this->eavConfig = $eavConfig;
        $this->scopeConfig = $scopeConfig;
        $this->appEmulation = $appEmulation;
        $this->imageHelper = $imageHelper;
        $this->productRepositoryInterface = $productRepositoryInterface;
        $this->getSalableQuantityDataBySku = $getSalableQuantityDataBySku;
        $this->supplierRepositoryInterface = $supplierRepositoryInterface;
        $this->supplierProductRepositoryInterface = $supplierProductRepositoryInterface;


    }

 /**
     * @inheritdoc
     */
    public function getLists(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        /** @var \Magento\Catalog\Model\ResourceModel\Product\Collection $collection */
        
        $collection = $this->collectionFactory->create();
        $this->extensionAttributesJoinProcessor->process($collection);

        $collection->addAttributeToSelect('*');
        $collection->joinAttribute('status', 'catalog_product/status', 'entity_id', null, 'inner');
        $collection->joinAttribute('visibility', 'catalog_product/visibility', 'entity_id', null, 'inner');

        $this->collectionProcessor->process($searchCriteria, $collection);

        $collection->load();
      
        $collection->addCategoryIds();
        $this->addExtensionAttributes($collection);
        $searchResult = $this->searchResultsFactory->create();
        $searchResult->setSearchCriteria($searchCriteria);
        $searchResult->setItems($collection->getItems());
        $searchResult->setTotalCount($collection->getSize());

        foreach ($collection->getItems() as $product) {
            $this->cacheProduct(
                $this->getCacheKey(
                    [
                        false,
                        $product->getStoreId()
                    ]
                ),
                $product
            );
        }
        $productList=$searchResult->getItems();


        foreach ($searchResult->getItems() as $key => $product) {
            $extensionattributes = $product->getExtensionAttributes();
            $supplierId=$product->getResource()->getAttributeRawValue($product->getId(),'supplier_id',$product->getStore()->getWebsiteId());
    
                //Get category names
                $categoryNames=array();
                foreach ($product->getCategoryIds() as $categoryId) {
                    array_push($categoryNames,$this->getCategoryNameById($categoryId));
                }
    
                //Get supplier name
                // if(is_numeric($supplierId))
                // {
                //     $supplierDetails = $this->supplierRepositoryInterface->get($supplierId);
                //     $supplierName= $supplierDetails->getCompanyName();
    
                // }   
                //configurable product info
                $productType = $product->getTypeId();
                $productEntity=$this->productRepositoryInterface->getById($product->getId());
              
                    $stockItem = $productEntity->getExtensionAttributes()->getStockItem();
                    $isInStock=$stockItem->getIsInStock();
                
                    if($isInStock==true)
                    {
                        $stock=1;
                    }
                    else
                    {
                        $stock=0;
                    }
                
                $supplierProduct=$this->supplierProductRepositoryInterface->getSupplierProductByProductIdAndSellerId($product->getId(), $supplierId);
                $isDelete=$supplierProduct->getIsDelete();
              
            $extensionattributes->setProductcatagoryName($categoryNames??'');
            $extensionattributes->setSupplierName($supplierName??'');
            $extensionattributes->setStockStatus($stock??'');
            $extensionattributes->setIsArchivedProduct($isDelete??'');
    
            $product->setExtensionAttributes($extensionattributes);
            if($isDelete!=1)
            {
                unset($productList[$key]);
            }
            }
        $searchResult->setItems($productList);
        $searchResult->setTotalCount(count($productList));
        return $searchResult;
    }


   /**
     * Add extension attributes to loaded items.
     *
     * @param Collection $collection
     * @return Collection
     */
    private function addExtensionAttributes(Collection $collection) : Collection
    {
        foreach ($collection->getItems() as $item) {
            $this->readExtensions->execute($item);
        }
        return $collection;
    }

    /**
     * Add product to internal cache and truncate cache if it has more than cacheLimit elements.
     *
     * @param string $cacheKey
     * @param ProductInterface $product
     * @return void
     */
    private function cacheProduct($cacheKey,ProductInterface $product)
    {
        $this->instancesById[$product->getId()][$cacheKey] = $product;
        $this->saveProductInLocalCache($product, $cacheKey);

        if ($this->cacheLimit && count($this->instances) > $this->cacheLimit) {
            $offset = round($this->cacheLimit / -2);
            $this->instancesById = array_slice($this->instancesById, $offset, null, true);
            $this->instances = array_slice($this->instances, $offset, null, true);
        }
    }

    /**
     * Saves product in the local cache by sku.
     *
     * @param Product $product
     * @param string $cacheKey
     * @return void
     */
    private function saveProductInLocalCache(Product $product, string $cacheKey): void
    {
        $preparedSku = $this->prepareSku($product->getSku());
        $this->instances[$preparedSku][$cacheKey] = $product;
    }   
       /**
     * Converts SKU to lower case and trims.
     *
     * @param string $sku
     * @return string
     */
    private function prepareSku(string $sku): string
    {
        return mb_strtolower(trim($sku));
    }

       /**
     * Get key for cache
     *
     * @param array $data
     * @return string
     */
    protected function getCacheKey($data)
    {
        $serializeData = [];
        foreach ($data as $key => $value) {
            if (is_object($value)) {
                $serializeData[$key] = $value->getId();
            } else {
                $serializeData[$key] = $value;
            }
        }
        $serializeData = $this->serializer->serialize($serializeData);
        return sha1($serializeData);
    }

        /**
     * Gets product from the local cache by SKU.
     *
     * @param string $sku
     * @param string $cacheKey
     * @return Product|null
     */
    private function getProductFromLocalCache(string $sku, string $cacheKey)
    {
        $preparedSku = $this->prepareSku($sku);

        return $this->instances[$preparedSku][$cacheKey] ?? null;
    }  
    
     /**
     * @param int $id
     * @param null $storeId
     * @return string
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    protected function getCategoryNameById($id, $storeId = null)
    {
        $categoryInstance = $this->categoryRepository->get($id, $storeId);
        return $categoryInstance->getName();
    }

      /**
     * Get image url
     *
     * @param \Magento\Catalog\Api\Data\ProductInterface $product
     * @param \Magento\Catalog\Api\Data\ProductExtensionInterface $extensionattributes
     * @return void
     */
    public function getProductImageUrl($product,$extensionattributes)
    {
        $awsUrl = $this->scopeConfig->getValue('productmanagement/general/display_text',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $storeId = $this->storeManager->getStore()->getId();
        $this->appEmulation->startEnvironmentEmulation($storeId, \Magento\Framework\App\Area::AREA_FRONTEND, true);
        $images=$product->getMediaGalleryEntries();
        $awsImageUrl="";
        foreach($images as $image){
            $imagePath=$image->getFile();
            $headers = @get_headers($imagePath);
            if(!$headers || $headers[0] == 'HTTP/1.1 404 Not Found') {
                $path =preg_replace('#/+#','/',$imagePath);
                $awsImageUrl=$awsUrl.$path;
                $image->setFile($awsImageUrl);
            }
        }
        $product->setMediaGalleryEntries($images);
        $smallImage=$product->getResource()->getAttributeRawValue($product->getId(),'image',$product->getStore()->getWebsiteId());
        $baseImage=$product->getResource()->getAttributeRawValue($product->getId(),'small_image',$product->getStore()->getWebsiteId());
        $thumbnailImage=$product->getResource()->getAttributeRawValue($product->getId(),'thumbnail',$product->getStore()->getWebsiteId());
        $swatchImage=$product->getResource()->getAttributeRawValue($product->getId(),'swatch_image',$product->getStore()->getWebsiteId());

        $baseImageUrl = $this->imageHelper->init($product, 'product_base_image')->getUrl();
        $pos = strpos($baseImageUrl, "cache");
        $baseUrl = substr_replace($baseImageUrl,$awsUrl.'/',0,$pos);

        $thumbnailImageUrl = $this->imageHelper->init($product, 'product_thumbnail_image')->getUrl();
        $posTumbImage = strpos($thumbnailImageUrl, "cache");
        $thumbNailUrl = substr_replace($thumbnailImageUrl,$awsUrl.'/',0,$posTumbImage);

        $smallImageUrl = $this->imageHelper->init($product, 'product_small_image')->getUrl();
        $posSmallImage = strpos($smallImageUrl, "cache");
        $smallUrl = substr_replace($smallImageUrl,$awsUrl.'/',0,$posSmallImage);

        $swatchImageUrl = $this->imageHelper->init($product, 'swatch_image')->getUrl();
        $posSwatchImage = strpos($swatchImageUrl, "cache");
        $swatchUrl = substr_replace($swatchImageUrl,$awsUrl.'/',0,$posSwatchImage);

        $extensionattributes->setBaseImage($baseImage=='no_selection'?'':$baseUrl??'');
        $extensionattributes->setSmallImage($smallImage=='no_selection'?'':$smallUrl??'');
        $extensionattributes->setThumbnailImage($thumbnailImage=='no_selection'?'':$thumbNailUrl??'');
        $extensionattributes->setSwatchImage($swatchImage=='no_selection'?'':$swatchUrl??'');

        $this->appEmulation->stopEnvironmentEmulation();
    }

     /**
     * get product salable qty
     *
     * @param string $sku
     * @return int
     */
    public function getSalableQty($sku)
    {
        $salable = $this->getSalableQuantityDataBySku->execute($sku);
        $salableQty=$salable[0]['qty'];
        return $salableQty;
    }

}
