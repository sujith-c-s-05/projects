<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);
 
namespace Bazar\ProductManagement\Model\Data;
 
use Bazar\ProductManagement\Api\Data\ProductCountInterface;
 
class ProductCount extends \Magento\Framework\Api\AbstractExtensibleObject implements ProductCountInterface
{
     
    /**
     * Get total_count
     * @return int|null
     */
    public function getTotalCount()
    {
        return $this->_get(self::TOTAL_COUNT);
    }
 
    /**
     * Set total_count
     * @param int $totalCount
     * @return \Bazar\ProductManagement\Api\Data\ProductCountInterface
     */
    public function setTotalCount($totalCount)
    {
        return $this->setData(self::TOTAL_COUNT, $totalCount);
    }

    /**
     * Get active_count
     * @return int|null
     */
    public function getActiveCount()
    {
        return $this->_get(self::ACTIVE_COUNT);
    }
 
    /**
     * Set active_count
     * @param int $activeCount
     * @return \Bazar\ProductManagement\Api\Data\ProductCountInterface
     */
    public function setActiveCount($totalCount)
    {
        return $this->setData(self::ACTIVE_COUNT, $activeCount);
    }

    /**
     * Get draft_count
     * @return int|null
     */
    public function getDraftCount()
    {
        return $this->_get(self::DRAFT_COUNT);
    }
 
    /**
     * Set draft_count
     * @param int $draftCount
     * @return \Bazar\ProductManagement\Api\Data\ProductCountInterface
     */
    public function setDraftCount($draftCount)
    {
        return $this->setData(self::DRAFT_COUNT, $draftCount);
    }

     /**
     * Get archive_count
     * @return int|null
     */
    public function getArchiveCount()
    {
        return $this->_get(self::ARCHIVE_COUNT);
    }
 
    /**
     * Set archive_count
     * @param int $archiveCount
     * @return \Bazar\ProductManagement\Api\Data\ProductCountInterface
     */
    public function setArchiveCount($archiveCount)
    {
        return $this->setData(self::ARCHIVE_COUNT, $archiveCount);
    }

    /**
     * Get out_of_stock_count
     * @return int|null
     */
    public function getOutOfStockCount()
    {
        return $this->_get(self::OUT_OF_STOCK);
    }
 
    /**
     * Set out_of_stock_count
     * @param int $outOfStockCount
     * @return \Bazar\ProductManagement\Api\Data\ProductCountInterface
     */
    public function setOutOfStockCount($outOfStockCount)
    {
        return $this->setData(self::OUT_OF_STOCK, $outOfStockCount);
    }
}