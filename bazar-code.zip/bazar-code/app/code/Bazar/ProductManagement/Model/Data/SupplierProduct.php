<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);
 
namespace Bazar\ProductManagement\Model\Data;
 
use Bazar\ProductManagement\Api\Data\SupplierProductInterface;
 
class SupplierProduct extends \Magento\Framework\Api\AbstractExtensibleObject implements SupplierProductInterface
{
 
    /**
     * Get id
     * @return int|null
     */
    public function getId()
    {
        return $this->_get(self::ID);
    }
 
    /**
     * Set id
     * @param int $Id
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductInterface
     */
    public function setId($Id)
    {
        return $this->setData(self::ID, $Id);
    }
 
    /**
     * Get supplier_id
     * @return int|null
     */
    public function getSupplierId()
    {
        return $this->_get(self::SUPPLIER_ID);
    }
 
    /**
     * Set supplier_id
     * @param int $supplierId
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductInterface
     */
    public function setSupplierId($supplierId)
    {
        return $this->setData(self::SUPPLIER_ID, $supplierId);
    }
 
    /**
     * Get product_id
     * @return int|null
     */
    public function getProductId()
    {
        return $this->_get(self::PRODUCT_ID);
    }
 
    /**
     * Set product_id
     * @param int $productId
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductInterface
     */
    public function setProductId($productId)
    {
        return $this->setData(self::PRODUCT_ID, $productId);
    }
 
    /**
     * Get is_active
     * @return bool|true
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }
 
    /**
     * Set is_active
     * @param bool $isActive
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }
    /**
     * Get is_delete
     * @return bool|false
     */
    public function getIsDelete()
    {
        return $this->_get(self::IS_DELETE);
    }
 
    /**
     * Set is_delete
     * @param bool $isDelete
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductInterface
     */
    public function setIsDelete($isDelete)
    {
        return $this->setData(self::IS_DELETE, $isDelete);
    }
 
     /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Bazar\ProductManagement\Api\Data\SupplierProductExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Bazar\ProductManagement\Api\Data\SupplierProductExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Bazar\ProductManagement\Api\Data\SupplierProductExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }
}
