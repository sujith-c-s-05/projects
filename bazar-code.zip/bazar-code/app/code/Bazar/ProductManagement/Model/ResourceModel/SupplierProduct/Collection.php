<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Bazar\ProductManagement\Model\ResourceModel\SupplierProduct;
 
use Bazar\ProductManagement\Model\SupplierProduct as Model;
use Bazar\ProductManagement\Model\ResourceModel\SupplierProduct as ResourceModel;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'id';

   /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Bazar\ProductManagement\Model\SupplierProduct::class,
            \Bazar\ProductManagement\Model\ResourceModel\SupplierProduct::class
        );  
    }
}