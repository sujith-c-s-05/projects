<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\ProductManagement\Model;

use Bazar\ProductManagement\Api\Data\SupplierProductInterface;
use Bazar\ProductManagement\Api\Data\SupplierProductInterfaceFactory; //**Doubt */
use Magento\Framework\Api\DataObjectHelper;

class SupplierProduct extends \Magento\Framework\Model\AbstractModel
{
    //supplierProduct
    protected $supplierProductDataFactory;

    protected $dataObjectHelper;

    protected $_eventPrefix = 'bazar_supplier_product';

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param SupplierProductInterfaceFactory $supplierProductDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Bazar\ProductManagement\Model\ResourceModel\SupplierProduct $resource
     * @param \Bazar\ProductManagement\Model\ResourceModel\SupplierProduct\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        SupplierProductInterfaceFactory $supplierProductDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Bazar\ProductManagement\Model\ResourceModel\SupplierProduct $resource,
        \Bazar\ProductManagement\Model\ResourceModel\SupplierProduct\Collection $resourceCollection,
        array $data = []
    ) {
        $this->supplierProductDataFactory = $supplierProductDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve supplycompany model with supply company data
     * @return SupplierProductInterface
     */
    public function getDataModel()
    {
        $SupplierProductData = $this->getData();
        
        $SupplierProductDataObject = $this->supplierProductDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $SupplierProductDataObject,
            $SupplierProductData,
            SupplierProductInterface::class
        );
        
        return $SupplierProductDataObject;
    }
}
