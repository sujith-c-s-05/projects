<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Bazar\ProductManagement\Model;

use Bazar\ProductManagement\Api\Data\SupplierProductInterfaceFactory;
use Bazar\ProductManagement\Api\SupplierProductRepositoryInterface;
use Bazar\ProductManagement\Model\ResourceModel\SupplierProduct 
as ResourceSupplierProduct;
use Bazar\ProductManagement\Model\ResourceModel\SupplierProduct\CollectionFactory as
SupplierProductCollectionFactory;

use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Catalog\Api\ProductRepositoryInterface as productRepositoryInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Bazar\ProductManagement\Api\Data\SupplierProductSearchResultsInterfaceFactory;


/**
 * Class Supplier product Repository
 */
class SupplierProductRespository implements SupplierProductRepositoryInterface
{
    protected $supplierProductCollectionFactory;

    protected $dataObjectProcessor;

    private $collectionProcessor;

    protected $extensibleDataObjectConverter;

    protected $supplierProductFactory;

    private $storeManager;

    protected $resource;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $dataSupplierProductFactory;

    protected $productRepositoryInterface;

    protected $categoryRepository;

    protected $supplierProduct;

    protected $searchResultsFactory;

    protected $_productCollectionFactory;

    /**
     * @param ResourceSupplierProduct $resource
     * @param SupplierProductFactory $supplierProductFactory
     * @param SupplierProductInterfaceFactory $dataSupplierProductFactory
     * @param supplierProductCollectionFactory $supplierProductCollectionFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     * @param productRepositoryInterface $productRepositoryInterface
     * @param \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository
     * @param \Bazar\ProductManagement\Model\SupplierProduct $supplierProduct
     * @param \Magento\Framework\App\ResourceConnection $resourceConnection
     * @param SupplierProductSearchResultsInterfaceFactory $searchResultsFactory
     */

     /** @var \Magento\Framework\App\ResourceConnection */
    protected $_resourceConnection;

    /** @var  \Magento\Framework\DB\Adapter\AdapterInterface */
    protected $_conn;

    public function __construct(
        ResourceSupplierProduct $resource,
        SupplierProductFactory $supplierProductFactory,
        SupplierProductInterfaceFactory $dataSupplierProductFactory,
        SupplierProductCollectionFactory $supplierProductCollectionFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter,
        productRepositoryInterface $productRepositoryInterface,
        \Magento\Catalog\Api\CategoryRepositoryInterface $categoryRepository,
        \Bazar\ProductManagement\Model\SupplierProduct $supplierProduct,
        ScopeConfigInterface $scopeConfig,
        \Magento\Eav\Model\Config $eavConfig,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        SupplierProductSearchResultsInterfaceFactory $searchResultsFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
    ) {
        $this->resource = $resource;
        $this->supplierProductFactory = $supplierProductFactory;
        $this->supplierProductCollectionFactory = $supplierProductCollectionFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataSupplierProductFactory = $dataSupplierProductFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->productRepositoryInterface = $productRepositoryInterface;
        $this->categoryRepository = $categoryRepository;
        $this->supplierProduct = $supplierProduct;
        $this->scopeConfig = $scopeConfig;
        $this->eavConfig = $eavConfig;
        $this->_resourceConnection = $resourceConnection;
        $this->_conn = $resourceConnection->getConnection();
        $this->searchResultsFactory = $searchResultsFactory;
        $this->_productCollectionFactory = $productCollectionFactory;   
    }
  
    /**
     * {@inheritdoc}
     */
    public function save(\Bazar\ProductManagement\Api\Data\SupplierProductInterface $SupplierProduct)
    {
        
        try {
            $existingProduct = $this->getSupplierProductByProductIdAndSellerId(
                $SupplierProduct->getProductId(),
                $SupplierProduct->getSupplierId()
            );
            $ProductId=$existingProduct->getId();
            $SupplierProduct->setId($ProductId);
            $this->objectResourceModel->save($SupplierProduct);
        } catch (\Exception $e) {
            throw new CouldNotSaveException(__($e->getMessage()));
        }
        return $SupplierProduct;
    }

     /**
     * Get Supplier product based or product id and Supplier id.
     * @param $productId
     * @param $supplierId
     * @return \Magento\Framework\DataObject
     */
    public function getSupplierProductByProductIdAndSellerId($productId, $supplierId)
    {
        $ProductCollection = $this->supplierProductCollectionFactory->create();
        $supplierProduct = $ProductCollection->addFieldToFilter('product_id', ['eq' => $productId])
            ->addFieldToFilter('supplier_id', ['eq' => $supplierId])->getFirstItem();
        return $supplierProduct;
    }

    /**
     * @inheritDoc
     *
     */
    public function deleteProductById($supplierId, $productId)
    {
        try {
            $this->_conn->beginTransaction();
            $productModel = $this->supplierProductCollectionFactory->create();
            $productModel ->addFieldToFilter('supplier_id', $supplierId);
            $productModel ->addFieldToFilter('product_id', $productId);
            $firstItem = $productModel->getFirstItem();
            $firstItem->setData('is_delete', 1);
            $firstItem->setData('is_active', 0);
            $firstItem->save();
            $product = $this->productRepositoryInterface->getById($productId);
            $product->setStatus(0);
            $this->productRepositoryInterface->save($product);
            $this->_conn->commit();
        } catch (\Exception $e) {
            echo $e->getMessage();

            $this->_conn->rollBack();
        }
        return true;
    }

     /**
     * {@inheritdoc}
     */
    public function get($Id)
    { 
        $supplierProduct = $this->supplierProductFactory->create();
        $this->resource->load($supplierProduct, $Id);
        if (!$supplierProduct->getId()) {
            throw new NoSuchEntityException(__('supplierProduct with id "%1" does not exist.', $Id));
        }
        return $supplierProduct->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->supplierProductCollectionFactory->create();

        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Bazar\ProductManagement\Api\Data\SupplierProductInterface::class
        );

        $this->collectionProcessor->process($criteria, $collection);

        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);

        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }

        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }
    
    /**
     * @inheritDoc
     *
     */
    public function updateProductById($supplierId, $productId)
    {
        try {
            $this->_conn->beginTransaction();
            $productModel = $this->supplierProductCollectionFactory->create();
            $productModel ->addFieldToFilter('supplier_id', $supplierId);
            $productModel ->addFieldToFilter('product_id', $productId);
            $firstItem = $productModel->getFirstItem();
            $firstItem->setData('is_delete', 0);
            $firstItem->setData('is_active', 1);
            $firstItem->save();
            $product = $this->productRepositoryInterface->getById($productId);
            $product->setStatus(1);
            $this->productRepositoryInterface->save($product);
            $this->_conn->commit();
        } catch (\Exception $e) {
            echo $e->getMessage();

            $this->_conn->rollBack();
        }
        return true;
    }

     /**
     * {@inheritdoc}
     */
    public function getProductCount()
    { 
        $result2=[];
        $totalProductCollection = $this->_productCollectionFactory->create();
        $totalCount=count($totalProductCollection);
        $activeProductCollection = $this->_productCollectionFactory->create();
        $activeProductCollection->addFieldToFilter('status',1);
        $activeCount=count($activeProductCollection);
        $draftProductCollection = $this->_productCollectionFactory->create();
        $draftProductCollection->addFieldToFilter('status',0);
        $draftCount=count($draftProductCollection);
        $ArchiveProductCollection = $this->supplierProductCollectionFactory->create();
        $ArchiveProductCollection->addFieldToFilter('is_delete',1);
        $archiveCount=count($ArchiveProductCollection);

        $outOfStockCollection = $this->_productCollectionFactory->create()
                                ->addAttributeToSelect('*')
                                ->joinField('stock_item', 'cataloginventory_stock_item', 'qty', 'product_id=entity_id', 'qty=0')
                                ->load();
        $outOfStockCollectionCount = count($outOfStockCollection);                   
        $result['total_count']=$totalCount;
        $result['active_count']=$activeCount;
        $result['draft_count']=$draftCount;
        $result['archive_count']=$archiveCount;
        $result['out_of_stock']=$outOfStockCollectionCount;
        $result2[]=$result;
        
        return $result2;
    }

     /**
     * {@inheritdoc}
     */
    public function deleteProductByIds(array $Id)
    {  
        foreach ($Id as $i) 
        { 
             $product = $this->productRepositoryInterface->getById($i);
             $sku=$product->getSku();
             $this->productRepositoryInterface->deleteById($sku);
        }  
        return true;      
    }    

    /**
     * {@inheritdoc}
     */
    public function archiveProductByIds(array $Id)
    {  
        foreach ($Id as $i) 
        { 
            $productModel = $this->supplierProductCollectionFactory->create();
            $productModel ->addFieldToFilter('product_id', $i);
            $firstItem = $productModel->getFirstItem();
            $firstItem->setData('is_delete', 1);
            $firstItem->setData('is_active', 0);
            $firstItem->save();
            $product = $this->productRepositoryInterface->getById($i);
            $product->setStatus(0);
            $this->productRepositoryInterface->save($product);
             
        }  
        return true;      
    }    

    /**
     * {@inheritdoc}
     */
    public function activeProductByIds(array $Id)
    {  
        foreach ($Id as $i) 
        { 
            $productModel = $this->supplierProductCollectionFactory->create();
            $productModel ->addFieldToFilter('product_id', $i);
            $firstItem = $productModel->getFirstItem();
            $firstItem->setData('is_delete', 0);
            $firstItem->setData('is_active', 1);
            $firstItem->save();
            $product = $this->productRepositoryInterface->getById($i);
            $product->setStatus(1);
            $this->productRepositoryInterface->save($product);
             
        }  
        return true;      
    }    

    /**
     * {@inheritdoc}
     */
    public function draftProductByIds(array $Id)
    {  
        foreach ($Id as $i) 
        { 
            $product = $this->productRepositoryInterface->getById($i);
            $product->setStatus(0);
            $this->productRepositoryInterface->save($product);
             
        }  
        return true;      
    }    

}
