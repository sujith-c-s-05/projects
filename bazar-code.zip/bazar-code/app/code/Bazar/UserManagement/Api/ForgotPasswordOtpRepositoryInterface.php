<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\UserManagement\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface ForgotPasswordOtpRepositoryInterface
{

    /**
     * Save ForgotPasswordOtp
     * @param \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface $forgotPasswordOtp
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface $forgotPasswordOtp
    );

    /**
     * Retrieve ForgotPasswordOtp
     * @param string $forgotpasswordotpId
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($forgotpasswordotpId);

    /**
     * Retrieve ForgotPasswordOtp matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete ForgotPasswordOtp
     * @param \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface $forgotPasswordOtp
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface $forgotPasswordOtp
    );

    /**
     * Delete ForgotPasswordOtp by ID
     * @param string $forgotpasswordotpId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($forgotpasswordotpId);
}
