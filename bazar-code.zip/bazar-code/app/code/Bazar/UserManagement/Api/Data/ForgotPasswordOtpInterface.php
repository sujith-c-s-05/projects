<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\UserManagement\Api\Data;

interface ForgotPasswordOtpInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const ID = 'id';
    const CREATED_AT = 'created_at';
    const CUSTOMER_ID = 'customer_id';
    const CODE = 'code';
    const UPDATED_AT = 'updated_at';
    const IS_USED = 'is_used';
    const IS_EXPIRED = 'is_expired';

    /**
     * Get id
     * @return string|null
     */
    public function getForgotpasswordotpId();

    /**
     * Set id
     * @param string $forgotpasswordotpId
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setForgotpasswordotpId($forgotpasswordotpId);

    /**
     * Get code
     * @return string|null
     */
    public function getCode();

    /**
     * Set code
     * @param string $code
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setCode($code);

    /**
     * Get customer_id
     * @return string|null
     */
    public function getCustomerId();

    /**
     * Set customer_id
     * @param string $customerId
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setCustomerId($customerId);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setUpdatedAt($updatedAt);

    /**
     * Get is_used
     * @return string|null
     */
    public function getIsUsed();

    /**
     * Set is_used
     * @param string $isUsed
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setIsUsed($isUsed);

    /**
     * Get is_expired
     * @return string|null
     */
    public function getIsExpired();

    /**
     * Set is_expired
     * @param string $isExpired
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setIsExpired($isExpired);
}
