<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\UserManagement\Api\Data;

interface ForgotPasswordOtpSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get ForgotPasswordOtp list.
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface[]
     */
    public function getItems();

    /**
     * Set code list.
     * @param \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
