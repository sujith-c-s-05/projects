<?php

namespace Bazar\UserManagement\Api;

/**
 * Interface providing token generation for Customers
 *
 * @api
 */
interface LoginManagementInterface
{
    /**
     * Create access token for customer credentials.
     *
     * @param string $username
     * @param string $password
     * @return string Token created
     * @throws \Magento\Framework\Exception\AuthenticationException
     */
    public function createCustomerAccessToken($username, $password);
    
    /**
     * change customer password.
     *
     * @param string $customerId
     * @param string $currentPassword
     * @param string $newPassword
     *
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws InputException
     */
    public function changePassword($customerId, $currentPassword, $newPassword);

    /**
     * Get password reset code.
     *
     * @param string $email
     *
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws InputException
     */
    public function getPasswordResetCode($email);
    
    /**
     * Check verification code and set Password
     *
     * @param string $email
     * @param string $code
     * @param string $password
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     * @throws InputException
     */
    public function checkVerificationCodeAndSetPassword($email, $code, $password);
}
