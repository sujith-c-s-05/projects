<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\UserManagement\Model\Data;

use Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface;

class ForgotPasswordOtp extends \Magento\Framework\Api\AbstractExtensibleObject implements ForgotPasswordOtpInterface
{

    /**
     * Get id
     * @return string|null
     */
    public function getForgotpasswordotpId()
    {
        return $this->_get(self::ID);
    }

    /**
     * Set id
     * @param string $forgotpasswordotpId
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setForgotpasswordotpId($forgotpasswordotpId)
    {
        return $this->setData(self::ID, $forgotpasswordotpId);
    }

    /**
     * Get code
     * @return string|null
     */
    public function getCode()
    {
        return $this->_get(self::CODE);
    }

    /**
     * Set code
     * @param string $code
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setCode($code)
    {
        return $this->setData(self::CODE, $code);
    }

    /**
     * Get customer_id
     * @return string|null
     */
    public function getCustomerId()
    {
        return $this->_get(self::CUSTOMER_ID);
    }

    /**
     * Set customer_id
     * @param string $customerId
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setCustomerId($customerId)
    {
        return $this->setData(self::CUSTOMER_ID, $customerId);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

    /**
     * Get is_used
     * @return string|null
     */
    public function getIsUsed()
    {
        return $this->_get(self::IS_USED);
    }

    /**
     * Set is_used
     * @param string $isUsed
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setIsUsed($isUsed)
    {
        return $this->setData(self::IS_USED, $isUsed);
    }

    /**
     * Get is_expired
     * @return string|null
     */
    public function getIsExpired()
    {
        return $this->_get(self::IS_EXPIRED);
    }

    /**
     * Set is_expired
     * @param string $isExpired
     * @return \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface
     */
    public function setIsExpired($isExpired)
    {
        return $this->setData(self::IS_EXPIRED, $isExpired);
    }
}
