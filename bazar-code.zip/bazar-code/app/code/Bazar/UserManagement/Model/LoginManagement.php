<?php

namespace Bazar\UserManagement\Model;

use Magento\Customer\Api\AccountManagementInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Integration\Model\CredentialsValidator;
use Magento\Integration\Model\Oauth\Token as Token;
use Magento\Integration\Model\Oauth\TokenFactory as TokenModelFactory;
use Magento\Integration\Model\ResourceModel\Oauth\Token\CollectionFactory as TokenCollectionFactory;
use Magento\Integration\Model\Oauth\Token\RequestThrottler;
use Magento\Framework\Exception\AuthenticationException;
use Magento\Framework\Event\ManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Bazar\UserManagement\Model\ResourceModel\ForgotPasswordOtp\CollectionFactory as ForgotPasswordOtpCollectionFactory;
use Bazar\SupplierManagement\Model\ResourceModel\Supplier\CollectionFactory as SupplierCollectionFactory;

/**
 * @inheritdoc
 */
class LoginManagement implements \Bazar\UserManagement\Api\LoginManagementInterface
{
    /**
     * Token Model
     *
     * @var TokenModelFactory
     */
    private $tokenModelFactory;

    /**
     * @var Magento\Framework\Event\ManagerInterface
     */
    private $eventManager;

    /**
     * Customer Account Service
     *
     * @var AccountManagementInterface
     */
    private $accountManagement;

    /**
     * @var \Magento\Integration\Model\CredentialsValidator
     */
    private $validatorHelper;

    /**
     * Token Collection Factory
     *
     * @var TokenCollectionFactory
     */
    private $tokenModelCollectionFactory;

    /**
     * @var RequestThrottler
     */
    private $requestThrottler;

    /**
     * Initialize service
     *
     * @param TokenModelFactory $tokenModelFactory
     * @param AccountManagementInterface $accountManagement
     * @param TokenCollectionFactory $tokenModelCollectionFactory
     * @param \Magento\Integration\Model\CredentialsValidator $validatorHelper
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     */
    public function __construct(
        TokenModelFactory $tokenModelFactory,
        AccountManagementInterface $accountManagement,
        TokenCollectionFactory $tokenModelCollectionFactory,
        CredentialsValidator $validatorHelper,
        ManagerInterface $eventManager = null,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        \Magento\Framework\Math\Random $mathRandom,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Bazar\UserManagement\Model\ForgotPasswordOtpFactory $forgotPasswordOtpFactory,
        \Magento\Customer\Model\ResourceModel\Customer\CollectionFactory $customerCollectionFactory,
        ScopeConfigInterface $scopeConfig,
        \Magento\Framework\App\ResourceConnection $resourceConnection,
        StateInterface $state,
        TransportBuilder $transportBuilder,
        ForgotPasswordOtpCollectionFactory $forgotPasswordOtpCollectionFactory,
        \Magento\Customer\Model\CustomerRegistry $customerRegistry,
        \Magento\Framework\Encryption\EncryptorInterface $encryptor,
        SupplierCollectionFactory $supplierCollectionFactory
       
    ) {
        $this->customerCollectionFactory = $customerCollectionFactory;
        $this->tokenModelFactory = $tokenModelFactory;
        $this->accountManagement = $accountManagement;
        $this->tokenModelCollectionFactory = $tokenModelCollectionFactory;
        $this->validatorHelper = $validatorHelper;
        $this->storeManager = $storeManager;
        $this->customerRepository= $customerRepository;
        $this->mathRandom= $mathRandom;
        $this->forgotPasswordOtpFactory = $forgotPasswordOtpFactory;
        $this->scopeConfig = $scopeConfig;
        $this->inlineTranslation = $state;
        $this->resourceConnection = $resourceConnection;
        $this->transportBuilder = $transportBuilder;
        $this->forgotPasswordOtpCollectionFactory = $forgotPasswordOtpCollectionFactory;
        $this->customerRegistry = $customerRegistry;
        $this->encryptor = $encryptor;
        $this->supplierCollectionFactory = $supplierCollectionFactory;

        $this->eventManager = $eventManager ?: \Magento\Framework\App\ObjectManager::getInstance()
            ->get(ManagerInterface::class);
    }

    /**
     * @inheritdoc
     */
    public function createCustomerAccessToken($username, $password)
    {
        $isPasswordSet = 0 ;
        $this->validatorHelper->validate($username, $password);
        $this->getRequestThrottler()->throttle($username, RequestThrottler::USER_TYPE_CUSTOMER);
        try {
            $customerDataObject = $this->accountManagement->authenticate($username, $password);
        } catch (\Exception $e) {
            $this->getRequestThrottler()->logAuthenticationFailure($username, RequestThrottler::USER_TYPE_CUSTOMER);
            throw new AuthenticationException(
                __(
                    'Username or password incorrect. '
                    . 'Please wait and try again later.'
                )
            );
        }
        if (!$customerDataObject->getCustomAttribute('user_confirmation')->getValue()) {
            throw new AuthenticationException(
                __(
                    'You have not confirmed the Email that is sent to you Please confirm the Email and try Login again.'
                )
            );
        }

        $this->eventManager->dispatch('customer_login', ['customer' => $customerDataObject]);
        $this->getRequestThrottler()->resetAuthenticationFailuresCount($username, RequestThrottler::USER_TYPE_CUSTOMER);
        $token = $this->tokenModelFactory->create()->createCustomerToken($customerDataObject->getId())->getToken();
        if ($resetPassword = $customerDataObject->getCustomAttribute('is_password_set')) {
            $isPasswordSet = $resetPassword->getValue();
        }
        $userDetails['email_id'] = $customerDataObject->getEmail();
        $userDetails['is_password_reset'] = $isPasswordSet;
        $userDetails['token'] = $token;
        $userDetails['supplier_id'] = $this->getSupplierId($customerDataObject->getId());

        return  [$userDetails];
    }

    
    /**
     * @inheritdoc
     */
    public function changePassword($customerId, $currentPassword, $newPassword)
    {
        $this->accountManagement->changePasswordById($customerId, $currentPassword, $newPassword);

        $customer = $this->customerRepository->getById($customerId);
        $customer->setCustomAttribute('is_password_set', 1);
        $this->customerRepository->save($customer);

        return true;
    }

    /**
     * @inheritdoc
     */
    public function getPasswordResetCode($email)
    {
        $customerCollection = $this->customerCollectionFactory->create();
        $customerCollection->addAttributeToFilter('email', $email);

        if (count($customerCollection) ==1) {
            $customer = $customerCollection->getFirstItem();
            $this->setIsUsedStatus($customer->getId());
            $forgotPassword = $this->forgotPasswordOtpFactory->create();
            $verificationCode = rand(100000, 999999);
            $forgotPassword->setCode($verificationCode);
            $forgotPassword->setCustomerId($customer->getId());
            $forgotPassword->save();
            $this->sendEmailWithVerificationCode($email, $verificationCode);

            return true;
        } else {
            throw new AuthenticationException(
                __(
                    'Invalid Username or email.'
                )
            );
        }
        return false;
    }

    /**
     * Get request throttler instance
     *
     * @return RequestThrottler
     * @deprecated 100.0.4
     */
    private function getRequestThrottler()
    {
        if (!$this->requestThrottler instanceof RequestThrottler) {
            return \Magento\Framework\App\ObjectManager::getInstance()->get(RequestThrottler::class);
        }
        return $this->requestThrottler;
    }

    /**
     * To generate Password reset Token
     */
    public function getToken($email)
    {
        $customer = $this->_customerRepository->get($email, $this->storeManager->getStore()->getWebsiteId());

        $newPasswordToken = $this->_mathRandom->getUniqueHash();
        $this->_accountmanagement->changeResetPasswordLinkToken($customer, $newPasswordToken);
    }

    /**
     * Send Email with forgot password
     */
    public function sendEmailWithVerificationCode($email, $code)
    {
        $templateOptions = ['area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                            'store' => $this->storeManager->getStore()->getId()];
        $templateVars = [
            'code' => $code
        ];
        $senderEmail = $this->scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
        $sender_name  = $this->scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
        $from = ['email' => $senderEmail, 'name' => $sender_name];
        $this->inlineTranslation->suspend();
        $transport = $this->transportBuilder
                          ->setTemplateIdentifier('password_reset_code_template', ScopeInterface::SCOPE_STORE)
            ->setTemplateOptions($templateOptions)
            ->setTemplateVars($templateVars)
            ->setFrom($from)
            ->addTo($email)
            ->getTransport();
        $transport->sendMessage();
        $this->inlineTranslation->resume();
        return true;
    }

    /**
     * @inheritdoc
     */
    public function checkVerificationCodeAndSetPassword($email, $code, $password)
    {
        $customerCollection = $this->customerCollectionFactory->create();
        $customerCollection->addAttributeToFilter('email', $email);

        if (count($customerCollection) ==1) {
            $customer = $customerCollection->getFirstItem();
            $customerId = $customer->getId();
            if ($this->checkVerificationCodeExists($customerId, $code)) {
                $this->setPassword($customerId, $password);
                return true;
            }
        } else {
            throw new AuthenticationException(
                __(
                    'Invalid Username'
                )
            );
        }
        return false;
    }

    /**
     * Check wether the code exist for the customer
     */
    public function checkVerificationCodeExists($customerId, $code)
    {
        $date = date('Y-m-d H:i:s');
        $otpCollection = $this->forgotPasswordOtpCollectionFactory->create();
        $otpCollection->addFieldToFilter('customer_id', $customerId);
        $otpCollection->addFieldToFilter('code', $code);
        $otpCollection->addFieldToFilter('is_used', 0);
        $otpCollection->addFieldToFilter('is_expired', 0);
        $otpCollection->setOrder('id', 'DESC');

        if (count($otpCollection) >=1) {
            $otp = $otpCollection->getFirstItem();
            $createdAt = $otp->getCreatedAt();
            $hourdiff = round((strtotime($date) - strtotime($createdAt))/3600, 1);

            if ($hourdiff >= 10) {
                $this->updateUsedExpiredStatus($otp, 1);
                throw new AuthenticationException(
                    __(
                        'Code is Expired or used'
                    )
                );
            }
            $this->updateUsedExpiredStatus($otp, 1);

            return true;
        } else {
            throw new AuthenticationException(
                __(
                    'Code is Expired or used'
                )
            );
        }
    }

    /**
     * To set the Password
     */
    public function setPassword($customerId, $password)
    {
        $customer = $this->customerRepository->getById($customerId);
        $customerSecure = $this->customerRegistry->retrieveSecureData($customerId);
        $customerSecure->setRpToken(null);
        $customerSecure->setRpTokenCreatedAt(null);
        $customerSecure->setPasswordHash($this->encryptor->getHash($password, true));
        $this->customerRepository->save($customer);
    }

    /**
     * To set Used status for Code
     */
    public function setIsUsedStatus($customerId)
    {
        $otpCollection = $this->forgotPasswordOtpCollectionFactory->create();
        $otpCollection->addFieldToFilter('customer_id', $customerId);
        $otpCollection->addFieldToFilter('is_used', 0);
        $otpCollection->addFieldToFilter('is_expired', 0);

        if (count($otpCollection) >=1) {
            foreach ($otpCollection as $otp) {
                $otp->setIsUsed(1);
                $otp->setIsExpired(1);
                $otp->save();
            }

            return true;
        }
        return false;
    }

    /**
     * Update s_used, is_expired flags for given otp
     *
     * @param ForgotPasswordOtp $otp
     * @param $status int
     * @return mixed
     * @throws \Exception
     */
    public function updateUsedExpiredStatus($otp, $status)
    {
        $otp->setIsUsed($status);
        $otp->setIsExpired($status);
        $otp->save();

        return $otp;
    }

     /**
      * To get Supplier Id
      */
    public function getSupplierId($customerId)
    {
        $supplierCollection = $this->supplierCollectionFactory->create();
        $supplierCollection->addFieldToFilter('customer_id', $customerId);
        $supplierCollection->addFieldToFilter('is_active', 1);
        $supplierCollection->addFieldToFilter('is_deleted', 0);

        if (count($supplierCollection) == 1) {
            $supplier = $supplierCollection->getFirstItem();

            return $supplier->getId();
        }

        throw new AuthenticationException(
            __(
                'Invalid Supplier or supplier not active'
            )
        );
    }
     
}
