<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\UserManagement\Model;

use Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterfaceFactory;
use Bazar\UserManagement\Api\Data\ForgotPasswordOtpSearchResultsInterfaceFactory;
use Bazar\UserManagement\Api\ForgotPasswordOtpRepositoryInterface;
use Bazar\UserManagement\Model\ResourceModel\ForgotPasswordOtp as ResourceForgotPasswordOtp;
use Bazar\UserManagement\Model\ResourceModel\ForgotPasswordOtp\CollectionFactory as ForgotPasswordOtpCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;

class ForgotPasswordOtpRepository implements ForgotPasswordOtpRepositoryInterface
{

    protected $forgotPasswordOtpFactory;

    protected $resource;

    protected $extensibleDataObjectConverter;
    protected $searchResultsFactory;

    private $storeManager;

    protected $dataObjectHelper;

    protected $forgotPasswordOtpCollectionFactory;

    protected $dataForgotPasswordOtpFactory;

    protected $dataObjectProcessor;

    protected $extensionAttributesJoinProcessor;

    private $collectionProcessor;

    /**
     * @param ResourceForgotPasswordOtp $resource
     * @param ForgotPasswordOtpFactory $forgotPasswordOtpFactory
     * @param ForgotPasswordOtpInterfaceFactory $dataForgotPasswordOtpFactory
     * @param ForgotPasswordOtpCollectionFactory $forgotPasswordOtpCollectionFactory
     * @param ForgotPasswordOtpSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     */
    public function __construct(
        ResourceForgotPasswordOtp $resource,
        ForgotPasswordOtpFactory $forgotPasswordOtpFactory,
        ForgotPasswordOtpInterfaceFactory $dataForgotPasswordOtpFactory,
        ForgotPasswordOtpCollectionFactory $forgotPasswordOtpCollectionFactory,
        ForgotPasswordOtpSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter
    ) {
        $this->resource = $resource;
        $this->forgotPasswordOtpFactory = $forgotPasswordOtpFactory;
        $this->forgotPasswordOtpCollectionFactory = $forgotPasswordOtpCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataForgotPasswordOtpFactory = $dataForgotPasswordOtpFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface $forgotPasswordOtp
    ) {
        /* if (empty($forgotPasswordOtp->getStoreId())) {
            $storeId = $this->storeManager->getStore()->getId();
            $forgotPasswordOtp->setStoreId($storeId);
        } */
        
        $forgotPasswordOtpData = $this->extensibleDataObjectConverter->toNestedArray(
            $forgotPasswordOtp,
            [],
            \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface::class
        );
        
        $forgotPasswordOtpModel = $this->forgotPasswordOtpFactory->create()->setData($forgotPasswordOtpData);
        
        try {
            $this->resource->save($forgotPasswordOtpModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the forgotPasswordOtp: %1',
                $exception->getMessage()
            ));
        }
        return $forgotPasswordOtpModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($forgotPasswordOtpId)
    {
        $forgotPasswordOtp = $this->forgotPasswordOtpFactory->create();
        $this->resource->load($forgotPasswordOtp, $forgotPasswordOtpId);
        if (!$forgotPasswordOtp->getId()) {
            throw new NoSuchEntityException(__('ForgotPasswordOtp with id "%1" does not exist.', $forgotPasswordOtpId));
        }
        return $forgotPasswordOtp->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->forgotPasswordOtpCollectionFactory->create();
        
        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface::class
        );
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface $forgotPasswordOtp
    ) {
        try {
            $forgotPasswordOtpModel = $this->forgotPasswordOtpFactory->create();
            $this->resource->load($forgotPasswordOtpModel, $forgotPasswordOtp->getForgotpasswordotpId());
            $this->resource->delete($forgotPasswordOtpModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the ForgotPasswordOtp: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($forgotPasswordOtpId)
    {
        return $this->delete($this->get($forgotPasswordOtpId));
    }
}
