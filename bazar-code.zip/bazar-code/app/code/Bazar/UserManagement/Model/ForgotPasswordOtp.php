<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Bazar\UserManagement\Model;

use Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterface;
use Bazar\UserManagement\Api\Data\ForgotPasswordOtpInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class ForgotPasswordOtp extends \Magento\Framework\Model\AbstractModel
{

    protected $_eventPrefix = 'bazar_forgotpassword_otp';
    protected $dataObjectHelper;
    protected $forgotpasswordotpDataFactory;

    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param ForgotPasswordOtpInterfaceFactory $forgotpasswordotpDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Bazar\UserManagement\Model\ResourceModel\ForgotPasswordOtp $resource
     * @param \Bazar\UserManagement\Model\ResourceModel\ForgotPasswordOtp\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        ForgotPasswordOtpInterfaceFactory $forgotpasswordotpDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Bazar\UserManagement\Model\ResourceModel\ForgotPasswordOtp $resource,
        \Bazar\UserManagement\Model\ResourceModel\ForgotPasswordOtp\Collection $resourceCollection,
        array $data = []
    ) {
        $this->forgotpasswordotpDataFactory = $forgotpasswordotpDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve forgotpasswordotp model with forgotpasswordotp data
     * @return ForgotPasswordOtpInterface
     */
    public function getDataModel()
    {
        $forgotpasswordotpData = $this->getData();
        
        $forgotpasswordotpDataObject = $this->forgotpasswordotpDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $forgotpasswordotpDataObject,
            $forgotpasswordotpData,
            ForgotPasswordOtpInterface::class
        );
        
        return $forgotpasswordotpDataObject;
    }
}
